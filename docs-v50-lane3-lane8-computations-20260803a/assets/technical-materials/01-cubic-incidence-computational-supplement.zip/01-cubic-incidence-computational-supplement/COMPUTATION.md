# Computation index

All programs use exact arithmetic. They check displayed identities and finite
enumerations; the normalization and automorphism arguments remain
conventional proofs in the manuscript.

| Mathematical role | Files | What is checked |
| --- | --- | --- |
| Normalized \(A,B\) family | `code/core/AB_cubic_classification.py` | forced pole-cancellation jets, restriction at \(x=0\), determinant, discriminant pullback, and an explicit three-point collision |
| Left–right equivalence | `code/core/AB_left_right_equivalence_stress.py` | universal cubic transformation and cusp identities, plus a complete repeated-root conjugacy |
| Stable uniqueness | `code/core/binary_multiplication_full_uniqueness_verifier.py` | motivic identities, universal minors, and exhaustive small finite-field hyperplane counts |
| Root-slope extensions | `code/verify_root_slope_extensions.py` | the additional exact identities used in the root-slope appendix |
| Smooth minimal defect | `code/minimal-smooth-defect/cubic_jet_rank_check.py` | Hesse determinant and exact Fermat ranks for the normal-jet gauge map |

Minimal replay:

```bash
uv run --with sympy==1.14.0 python code/core/AB_cubic_classification.py
uv run --with sympy==1.14.0 python code/core/AB_left_right_equivalence_stress.py
uv run --with sympy==1.14.0 python code/core/binary_multiplication_full_uniqueness_verifier.py
uv run --with sympy==1.14.0 python code/verify_root_slope_extensions.py
uv run --with sympy==1.14.0 python code/minimal-smooth-defect/cubic_jet_rank_check.py
```

The imported smooth-defect script has SHA-256
`6b0c6be3b43f167c83a0aae8d0a7d18ac0deecac0d8dac27f775b4f3d0dfd4d4`.
It checks the model linear algebra; the bundle argument and local torsor
algebraization are conventional proofs.

The finite-field enumerations support the stable-uniqueness proof strategy;
they are not, by themselves, a proof over characteristic zero.
