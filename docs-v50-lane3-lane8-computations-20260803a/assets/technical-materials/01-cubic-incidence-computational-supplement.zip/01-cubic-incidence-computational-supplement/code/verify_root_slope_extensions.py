#!/usr/bin/env python3
"""Exact checks for the root-slope extension memo.

All calculations use SymPy over Q or symbolic polynomial rings.
"""
from __future__ import annotations

import sympy as sp


def check_root_slope_jacobian() -> None:
    t, r = sp.symbols("t r")
    Htt, Htc, Hc = sp.symbols("Htt Htc Hc")
    jac = sp.Matrix(
        [
            [(r - t * Htt) / 2, t / 2, (Hc - t * Htc) / 2],
            [-Htt, 1, -Htc],
            [0, 0, 1],
        ]
    )
    assert sp.factor(jac.det() - r / 2) == 0


def check_reciprocal_chart() -> None:
    x, y, z = sp.symbols("x y z", nonzero=True)
    wx, wy = sp.symbols("wx wy")
    jac = sp.Matrix(
        [
            [-x ** -2, 1, 0],
            [-2 * x ** -2, 0, 0],
            [wx - 3 * x**2 * z, wy, -x**3],
        ]
    )
    assert sp.factor(jac.det() + 2 * x) == 0


def check_cubic_discriminant() -> None:
    A, B, a, b, T, t, r = sp.symbols("A B a b T t r")
    P = A * T**3 + B * T**2 + b * T - 2 * a
    delta = sp.discriminant(P, T)
    expected = B**2 * b**2 - 4 * A * b**3 + 8 * a * B**3 - 36 * a * A * B * b - 108 * a**2 * A**2
    assert sp.factor(delta - expected) == 0

    b_root = r - 3 * A * t**2 - 2 * B * t
    a_root = -A * t**3 - sp.Rational(1, 2) * B * t**2 + sp.Rational(1, 2) * r * t
    pulled = sp.factor(delta.subs({a: a_root, b: b_root}))
    expected_pull = r**2 * ((3 * A * t + B) ** 2 - 4 * A * r)
    assert sp.factor(pulled - expected_pull) == 0

    disc_in_a = sp.factor(sp.discriminant(delta, a))
    assert sp.factor(disc_in_a + 64 * (3 * A * b - B**2) ** 3) == 0


def contact_matrix(a: int, m: int) -> sp.Matrix:
    """Numeric Hankel test matrix for b=a+1 and contact order m."""
    n = 2 * a + 1
    lam = [0] * (n + 1)
    for j in range(m, n + 1):
        lam[j] = j - m + 1
    return sp.Matrix(a + 1, a + 2, lambda i, j: lam[i + j])


def residual_matrix(a: int, m: int, u_value: int = 2, v_value: int = 1) -> sp.Matrix:
    n = 2 * a + 1
    lam = [0] * (n + 1)
    for j in range(m, n + 1):
        lam[j] = j - m + 1

    def rho(j: int) -> int:
        l0 = lam[j] if j <= n else 0
        l1 = lam[j + 1] if j + 1 <= n else 0
        l2 = lam[j + 2] if j + 2 <= n else 0
        return v_value**2 * l0 + 2 * u_value * v_value * l1 + u_value**2 * l2

    return sp.Matrix(a, a + 1, lambda i, j: rho(i + j))


def check_contact_rank_patterns(max_a: int = 12) -> None:
    for a in range(2, max_a + 1):
        n = 2 * a + 1
        for m in range(2, n - 1):
            M = contact_matrix(a, m)
            assert M.rank() >= 3, (a, m, M.rank())
        M = contact_matrix(a, n - 1)
        assert M.rank() == 2, (a, n - 1, M.rank())
        for m in range(2, n - 1):
            N = residual_matrix(a, m)
            assert N.rank() >= 2, (a, m, N.rank())


def check_almost_osculating_factorization() -> None:
    u, v, lm, ln, h1, h2 = sp.symbols("u v lm ln h1 h2")
    # At m=n-1, only rho_{n-3}=u^2*lm and rho_{n-2}=2uv*lm+u^2*ln survive.
    equation = u**2 * lm * h1 + (2 * u * v * lm + u**2 * ln) * h2
    assert sp.expand(equation - u * (u * lm * h1 + (2 * v * lm + u * ln) * h2)) == 0


def check_leading_motivic_deficit(max_a: int = 12) -> None:
    L = sp.Symbol("L")

    def P(d: int) -> sp.Expr:
        if d < 0:
            return sp.Integer(0)
        return sum(L**j for j in range(d + 1))

    for a in range(2, max_a + 1):
        n = 2 * a + 1
        C = sp.expand(L**n + L ** (n - 1))

        # Contact <= n-2: rank >=3, one top-dimensional intersection component.
        D1 = sp.expand(P(a) ** 2)  # radical correction has degree <= n-3
        Z1 = L ** (n - 2)
        U1 = sp.expand(C - D1 + Z1)
        assert sp.expand(U1).coeff(L, n) == 1
        assert sp.expand(U1).coeff(L, n - 1) == 0
        assert sp.expand(U1).coeff(L, n - 2) == -1

        # Contact n-1: rank 2 and two top-dimensional intersection components.
        D2 = sp.expand(P(a) ** 2 + L ** (a + 1) * P(a - 2))
        Z2 = 2 * L ** (n - 2)
        U2 = sp.expand(C - D2 + Z2)
        assert U2.coeff(L, n) == 1
        assert U2.coeff(L, n - 1) == 0
        assert U2.coeff(L, n - 2) == -1



def check_almost_osculating_exact_class(max_a: int = 12) -> None:
    L = sp.Symbol("L")
    for a in range(2, max_a + 1):
        n = 2 * a + 1
        open_open = L ** (n - 2) * (L - 1) ** 2
        boundary = 2 * (L ** (n - 1) - L ** (n - 2))
        assert sp.expand(open_open + boundary - (L**n - L ** (n - 2))) == 0

    # Cubic knife-edge: one degree-zero boundary stratum contributes L^2,
    # while the symmetric degree-(1,1) stratum contributes L^2-L.
    cubic = L * (L - 1) ** 2 + L**2 + (L**2 - L)
    assert sp.expand(cubic - L**3) == 0

def main() -> None:
    check_root_slope_jacobian()
    check_reciprocal_chart()
    check_cubic_discriminant()
    check_contact_rank_patterns()
    check_almost_osculating_factorization()
    check_leading_motivic_deficit()
    check_almost_osculating_exact_class()
    print("all exact root-slope extension checks passed")


if __name__ == "__main__":
    main()
