#!/usr/bin/env python3
"""Exact linear-algebra check for the normal-jet action on a smooth plane cubic.

The quotient generators q_i satisfy x_0 q_0+x_1 q_1+x_2 q_2=0.
For the Hesse cubic
    phi = q_0^3+q_1^3+q_2^3-3*lambda*q_0*q_1*q_2,
this script constructs the first-normal-jet action
    delta_phi : A_1 -> W_1
and computes its determinant in explicit quotient bases.  It also verifies
surjectivity for the Fermat cubic at normal orders k=0,...,4.
"""

from itertools import combinations_with_replacement
import sympy as sp


def exponent_monomials(nvars: int, degree: int):
    if degree < 0:
        return []
    result = []

    def rec(prefix, remaining, left):
        if left == 1:
            result.append(tuple(prefix + [remaining]))
            return
        for a in range(remaining + 1):
            rec(prefix + [a], remaining - a, left - 1)

    rec([], degree, nvars)
    return result


def q_monomials(degree: int):
    out = []
    for comb in combinations_with_replacement(range(3), degree):
        out.append(tuple(sum(1 for j in comb if j == i) for i in range(3)))
    return out


def first_jet_hesse_determinant():
    lam = sp.symbols("lambda")
    q3 = q_monomials(3)
    q2 = q_monomials(2)

    codomain_basis = [(ell, mon) for ell in range(3) for mon in q3]
    codomain_index = {b: i for i, b in enumerate(codomain_basis)}
    domain_basis = [(out, src, ell) for out in range(3) for src in range(3) for ell in range(3)]
    domain_index = {b: i for i, b in enumerate(domain_basis)}

    # Matrix before quotienting by x.q=0.
    action = sp.zeros(30, 27)
    for col, (out, src, ell) in enumerate(domain_basis):
        # d phi / d q_src = 3 q_src^2 - 3 lambda q_a q_b.
        mon = [0, 0, 0]
        mon[src] += 2
        mon[out] += 1
        action[codomain_index[(ell, tuple(mon))], col] += 3

        other = [i for i in range(3) if i != src]
        mon = [0, 0, 0]
        mon[other[0]] += 1
        mon[other[1]] += 1
        mon[out] += 1
        action[codomain_index[(ell, tuple(mon))], col] -= 3 * lam

    # Codomain relation space: (x_0 q_0+x_1 q_1+x_2 q_2) Sym^2(q).
    relations = sp.zeros(30, 6)
    for col, mon2 in enumerate(q2):
        for i in range(3):
            mon = list(mon2)
            mon[i] += 1
            relations[codomain_index[(i, tuple(mon))], col] += 1

    # Domain zero maps: A=x c^T.  Choose a complementary coordinate subspace.
    zero_maps = sp.zeros(27, 3)
    for src in range(3):
        for out in range(3):
            zero_maps[domain_index[(out, src, out)], src] += 1

    omitted = {domain_index[(0, src, 0)] for src in range(3)}
    complement_columns = [i for i in range(27) if i not in omitted]
    complement = sp.zeros(27, 24)
    for j, i in enumerate(complement_columns):
        complement[i, j] = 1
    assert sp.Matrix.hstack(zero_maps, complement).rank() == 27

    # Project to a basis of the quotient by the six codomain relations.
    quotient_projection = sp.Matrix.hstack(*relations.T.nullspace()).T
    assert quotient_projection.shape == (24, 30)
    assert quotient_projection * relations == sp.zeros(24, 6)

    quotient_action = quotient_projection * action * complement
    determinant = sp.factor(quotient_action.det())
    return determinant


def fermat_rank(normal_order: int):
    k = normal_order
    xk = exponent_monomials(3, k)
    xkm1 = exponent_monomials(3, k - 1)
    q3 = q_monomials(3)
    q2 = q_monomials(2)

    codomain_basis = [(xm, qm) for xm in xk for qm in q3]
    codomain_index = {b: i for i, b in enumerate(codomain_basis)}
    domain_basis = [(out, src, xm) for xm in xk for out in range(3) for src in range(3)]
    domain_index = {b: i for i, b in enumerate(domain_basis)}

    action = sp.zeros(len(codomain_basis), len(domain_basis))
    for col, (out, src, xm) in enumerate(domain_basis):
        qm = [0, 0, 0]
        qm[src] += 2
        qm[out] += 1
        action[codomain_index[(xm, tuple(qm))], col] += 3

    if k >= 1:
        relations = sp.zeros(len(codomain_basis), len(xkm1) * len(q2))
        col = 0
        for xm in xkm1:
            for qm2 in q2:
                for i in range(3):
                    xe = list(xm)
                    xe[i] += 1
                    qe = list(qm2)
                    qe[i] += 1
                    relations[codomain_index[(tuple(xe), tuple(qe))], col] += 1
                col += 1

        zero_maps = sp.zeros(len(domain_basis), 3 * len(xkm1))
        col = 0
        for src in range(3):
            for xm in xkm1:
                for out in range(3):
                    xe = list(xm)
                    xe[out] += 1
                    zero_maps[domain_index[(out, src, tuple(xe))], col] += 1
                col += 1
    else:
        relations = sp.zeros(len(codomain_basis), 0)
        zero_maps = sp.zeros(len(domain_basis), 0)

    induced_rank = sp.Matrix.hstack(relations, action).rank() - relations.rank()
    domain_dimension = len(domain_basis) - zero_maps.rank()
    codomain_dimension = len(codomain_basis) - relations.rank()
    return domain_dimension, codomain_dimension, induced_rank


if __name__ == "__main__":
    det = first_jet_hesse_determinant()
    print("det(delta_phi,1) =", det)
    print()
    print("k  dim(A_k)  dim(W_k)  rank(delta_phi,k)")
    for k in range(5):
        da, dw, rank = fermat_rank(k)
        print(f"{k:1d}  {da:8d}  {dw:8d}  {rank:17d}")
