#!/usr/bin/env python3
"""Exact checks for the A(C), B(C) cubic Keller classification.

This script verifies:
  * the necessary pole-cancellation jet equations;
  * the exact x=0 restriction;
  * the cubic discriminant formula;
  * its pullback factorization on the chosen-root incidence chart;
  * a nontrivial example with two unramified nonproperness planes.

The mathematical theorem is stated in the accompanying response.  All
computations use exact SymPy arithmetic.
"""
from __future__ import annotations

import sympy as sp


def azero(expr: sp.Expr, label: str) -> None:
    value = sp.factor(sp.cancel(expr))
    if value != 0:
        raise AssertionError(f"{label}: expected 0, got {value}")


# ---------------------------------------------------------------------------
# 1. Formal jet calculation around the distinguished zero alpha.
# ---------------------------------------------------------------------------
x, y, z = sp.symbols("x y z")
lam, mu, eta = sp.symbols("lam mu eta", nonzero=True)  # A', A'', A'''
nu, xi = sp.symbols("nu xi")                          # B', B''
p, q0, q1 = sp.symbols("p q0 q1")

# c-alpha = p*x + (q0+q1*y)*x^2 - x^3*z + O(x^3 source shear)
delta = p*x + (q0 + q1*y)*x**2 - x**3*z
Ajet = lam*delta + mu*delta**2/2 + eta*delta**3/6
Bjet = -2 + nu*delta + xi*delta**2/2
Q = 1 + x*y

Nb = sp.expand(2*x - 3*Ajet*Q**2 - 2*x*Bjet*Q)       # x^2*b
Na = sp.expand(2*x*Q - 2*Ajet*Q**3 - x*Bjet*Q**2)   # 2*x^3*a

# Coefficients forced to vanish.
nb_x = sp.expand(Nb).coeff(x, 1)
na_x = sp.expand(Na).coeff(x, 1)
na_x2 = sp.expand(Na).coeff(x, 2)
azero(nb_x - (-3*lam*p + 6), "formal b coefficient")
azero(na_x - (-2*lam*p + 4), "formal a coefficient")

forced = {
    p: 2/lam,
    q1: -3/lam,
    q0: -2*mu/lam**3 - nu/lam**2,
}
azero(nb_x.subs(forced), "b pole, order x")
azero(na_x.subs(forced), "a pole, order x")
azero(na_x2.subs(forced), "a pole, order x^2")

# With the forced jet, obtain the exact x=0 restrictions.
delta_forced = sp.expand(delta.subs(forced))
Ajet4 = lam*delta_forced + mu*delta_forced**2/2 + eta*delta_forced**3/6
Bjet3 = -2 + nu*delta_forced + xi*delta_forced**2/2

t = y + 1/x
bjet = sp.cancel(2/x - 3*Ajet4*t**2 - 2*Bjet3*t)
ajet = sp.cancel((2*t/x - 2*Ajet4*t**3 - Bjet3*t**2)/2)

b_on_x0 = sp.factor(sp.limit(bjet, x, 0))
a_on_x0 = sp.factor(sp.limit(ajet, x, 0))

expected_b0 = y - nu/lam
expected_a0 = (
    lam*z
    + 4*y**2
    + (sp.Rational(5, 2)*nu/lam + 6*mu/lam**2)*y
    + nu**2/(2*lam**2)
    - xi/lam**2
    + 3*mu*nu/lam**3
    - sp.Rational(4, 3)*eta/lam**3
    + 4*mu**2/lam**4
)
azero(b_on_x0 - expected_b0, "x=0 restriction of b")
azero(a_on_x0 - expected_a0, "x=0 restriction of a")

# ---------------------------------------------------------------------------
# 2. Universal discriminant and chosen-root pullback factorization.
# ---------------------------------------------------------------------------
AA, BB, aa, bb, T, tt, rr = sp.symbols("AA BB aa bb T tt rr")
P = AA*T**3 + BB*T**2 + bb*T - 2*aa
Disc = sp.factor(sp.discriminant(P, T))
Disc_expected = (
    BB**2*bb**2
    - 4*AA*bb**3
    + 8*aa*BB**3
    - 36*aa*AA*BB*bb
    - 108*aa**2*AA**2
)
azero(Disc - Disc_expected, "universal cubic discriminant")

# On the incidence chart, rr=P'(tt), and P(tt)=0.
bb_inc = rr - 3*AA*tt**2 - 2*BB*tt
aa_inc = -AA*tt**3 - BB*tt**2/2 + rr*tt/2
pullback = sp.factor(Disc.subs({aa: aa_inc, bb: bb_inc}))
expected_pullback = rr**2*((3*AA*tt + BB)**2 - 4*AA*rr)
azero(pullback - expected_pullback, "pullback discriminant factorization")

# At a leading-coefficient zero A=0 with B != 0, the discriminant restricts
# to B^2 (b^2+8aB), hence the branch divisor meets the plane transversely.
azero(Disc.subs(AA, 0) - BB**2*(bb**2 + 8*aa*BB), "A=0 restriction")
assert sp.diff(Disc, aa).subs(AA, 0) == 8*BB**3

# ---------------------------------------------------------------------------
# 3. Concrete example: A(C)=C(C-1)(C+2), B(C)=-2, alpha=0.
# ---------------------------------------------------------------------------
C = sp.symbols("C")
Apoly = sp.expand(C*(C-1)*(C+2))
Bpoly = sp.Integer(-2)
alpha = sp.Integer(0)
A1 = sp.diff(Apoly, C).subs(C, alpha)
A2 = sp.diff(Apoly, C, 2).subs(C, alpha)
B1 = sp.diff(Bpoly, C).subs(C, alpha)
assert A1 != 0 and Bpoly.subs(C, alpha) == -2

csrc = sp.expand(
    alpha
    + 2*x/A1
    + x**2*(-3*y/A1 - 2*A2/A1**3 - B1/A1**2)
    - x**3*z
)
tsrc = y + 1/x
Asrc = Apoly.subs(C, csrc)
Bsrc = Bpoly.subs(C, csrc)
bmap = sp.factor(sp.cancel(2/x - 3*Asrc*tsrc**2 - 2*Bsrc*tsrc))
amap = sp.factor(sp.cancel((2*tsrc/x - 2*Asrc*tsrc**3 - Bsrc*tsrc**2)/2))
assert not sp.denom(amap).has(x, y, z)
assert not sp.denom(bmap).has(x, y, z)
assert sp.factor(sp.Matrix([amap, bmap, csrc]).jacobian([x, y, z]).det()) == -2

# A transparent three-point collision over (a,b,c)=(0,2,0).
collision_points = [
    (sp.Integer(0), sp.Integer(2), sp.Integer(12)),
    (sp.Integer(1), sp.Integer(-1), sp.Integer(-2)),
    (-sp.Integer(1), sp.Integer(2), -sp.Rational(9, 2)),
]
for point in collision_points:
    values = tuple(sp.simplify(f.subs(dict(zip((x, y, z), point)))) for f in (amap, bmap, csrc))
    assert values == (0, 2, 0)

# Verify the chosen root identity and derivative.
Psrc = Asrc*T**3 + Bsrc*T**2 + bmap*T - 2*amap
azero(Psrc.subs(T, tsrc), "concrete source root")
azero(sp.diff(Psrc, T).subs(T, tsrc) - 2/x, "concrete source derivative")

# The two non-distinguished roots of A are 1 and -2; their unramified planes
# meet the branch divisor in the stated quadratic curves.
A_target = Apoly
B_target = Bpoly
D_target = sp.factor(Disc_expected.subs({AA: A_target, BB: B_target}))
for beta in (sp.Integer(1), sp.Integer(-2)):
    restricted = sp.factor(D_target.subs(C, beta))
    expected = sp.factor(Bpoly**2*(bb**2 + 8*aa*Bpoly))
    azero(restricted - expected, f"discriminant on c={beta}")

print("All exact A(C), B(C) cubic-classification checks passed.")
print("Forced jet:")
print("  p  =", forced[p])
print("  q1 =", forced[q1])
print("  q0 =", forced[q0])
print("x=0 restrictions:")
print("  b =", expected_b0)
print("  a =", expected_a0)
print("Concrete example third coordinate:")
print("  c =", csrc)
print("Concrete map degrees:")
print("  deg(a), deg(b), deg(c) =", (
    sp.Poly(amap, x, y, z).total_degree(),
    sp.Poly(bmap, x, y, z).total_degree(),
    sp.Poly(csrc, x, y, z).total_degree(),
))
