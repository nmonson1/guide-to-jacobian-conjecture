#!/usr/bin/env python3
"""Exact stress checks for the hardened left-right equivalence proof.

This is not a proof of the automorphism classification.  It verifies the
universal coefficient identities and a nontrivial repeated-root example,
including the complete equality F2 o Phi = Psi o F1.
"""
from __future__ import annotations
import sympy as sp


def zcheck(expr: sp.Expr, label: str) -> None:
    expr = sp.factor(sp.cancel(expr))
    if expr != 0:
        raise AssertionError(f"{label}: {expr}")

# Universal target/root identities.
A, B, a, b, T = sp.symbols("A B a b T")
lam, q = sp.symbols("lam q", nonzero=True)
Ap = A/lam
Bp = B - 3*A*q/lam
bp = lam*b + 3*A*q**2/lam - 2*B*q
ap = lam**2*a + lam*q*b/2 + A*q**3/(2*lam) - B*q**2/2
P1 = A*T**3+B*T**2+b*T-2*a
U = sp.symbols("U")
P2 = Ap*U**3+Bp*U**2+bp*U-2*ap
zcheck(P2.subs(U,lam*T+q)-lam**2*P1, "universal cubic identity")

p = 3*A*b-B**2
Q = 2*B**3-9*A*B*b-54*A**2*a
D = B**2*b**2-4*A*b**3+8*a*B**3-36*a*A*B*b-108*a**2*A**2
zcheck(Q**2+4*p**3+27*A**2*D, "cusp identity")

# Recovery of B mod A.
k, C = sp.symbols("k C", nonzero=True)
bhat = (p+C**2)/(3*k*A)
ahat = sp.solve(
    sp.Eq(2*C**3-9*k*A*C*bhat-54*k**2*A**2*sp.Symbol("ahat"),Q),
    sp.Symbol("ahat"),
)[0]
zcheck(sp.diff(ahat,b)-(B-C)/(6*k**2*A), "B mod A coefficient")

# A complete repeated-root sample.
x, y, z, c, Cvar = sp.symbols("x y z c C")

def canonical(Apoly, Bpoly, var, alpha, xv, yv, zv):
    A1 = sp.diff(Apoly,var).subs(var,alpha)
    A2 = sp.diff(Apoly,var,2).subs(var,alpha)
    B1 = sp.diff(Bpoly,var).subs(var,alpha)
    w = sp.expand(alpha+2*xv/A1+xv**2*(-3*yv/A1-2*A2/A1**3-B1/A1**2))
    cv = sp.expand(w-xv**3*zv)
    t = yv+1/xv
    av = sp.cancel((2*t/xv-2*Apoly.subs(var,cv)*t**3-Bpoly.subs(var,cv)*t**2)/2)
    bv = sp.cancel(2/xv-3*Apoly.subs(var,cv)*t**2-2*Bpoly.subs(var,cv)*t)
    if sp.denom(av) != 1 or sp.denom(bv) != 1:
        raise AssertionError("pole cancellation failed")
    return sp.expand(av),sp.expand(bv),cv,w

A1p = c*(c-1)**2
B1p = 2*(c-1)
a1,b1,c1,w1 = canonical(A1p,B1p,c,0,x,y,z)

u = sp.Rational(2)
v = sp.Rational(1)
kappa = sp.Rational(3)
lam0 = 1/kappa
phi = lambda e: u*e+v
phiinv = lambda e: (e-v)/u
qpoly = c**2+c
A2p = sp.expand(kappa*A1p.subs(c,phiinv(Cvar)))
B2p = sp.expand((B1p-3*A1p*qpoly/lam0).subs(c,phiinv(Cvar)))
alpha2 = phi(0)

q1 = qpoly.subs(c,c1)
aT = sp.expand(lam0**2*a1+lam0*q1*b1/2+A1p.subs(c,c1)*q1**3/(2*lam0)-B1p.subs(c,c1)*q1**2/2)
bT = sp.expand(lam0*b1+3*A1p.subs(c,c1)*q1**2/lam0-2*B1p.subs(c,c1)*q1)
cT = sp.expand(phi(c1))

X = sp.expand(x/lam0)
Y = sp.expand(lam0*y+q1)
A2d = sp.diff(A2p,Cvar).subs(Cvar,alpha2)
A2dd = sp.diff(A2p,Cvar,2).subs(Cvar,alpha2)
B2d = sp.diff(B2p,Cvar).subs(Cvar,alpha2)
w2XY = sp.expand(alpha2+2*X/A2d+X**2*(-3*Y/A2d-2*A2dd/A2d**3-B2d/A2d**2))
num = sp.expand(w2XY-cT)
if min(m[0] for m,_ in sp.Poly(num,x,y,z).terms()) < 3:
    raise AssertionError("source z numerator is not divisible by x^3")
Z = sp.expand(lam0**3*num/x**3)

a2,b2,c2,_ = canonical(A2p,B2p,Cvar,alpha2,X,Y,Z)
zcheck(a2-aT, "full source-target identity: a")
zcheck(b2-bT, "full source-target identity: b")
zcheck(c2-cT, "full source-target identity: c")

print("All hardened equivalence stress checks passed.")
print("Source automorphism degrees:",*[sp.Poly(f,x,y,z).total_degree() for f in (X,Y,Z)])
