#!/usr/bin/env python3
"""Exact checks supporting the stable-uniqueness argument.

Checks:
  * the coprime-pair identity for adjacent degrees;
  * the rank-three determinant forced by tangent/nonosculating normalization;
  * the top-order bilinear-divisor expansion;
  * exhaustive arbitrary-hyperplane counts for (a,b)=(2,3) over F_5,F_7;
  * exhaustive arbitrary-hyperplane counts for (a,b)=(3,4) over F_5;
  * canonical exact formulas from the companion verifier.
"""
from __future__ import annotations
from collections import Counter
from itertools import product
import sympy as sp

q=sp.symbols('q')

def P(m):
    if m<0: return sp.Integer(0)
    return sum(q**i for i in range(m+1))

for a in range(1,12):
    cop=sp.expand(P(a)*P(a+1)-(q+1)*P(a-1)*P(a)+q*P(a-2)*P(a-1))
    assert sp.expand(cop-(q**(2*a+1)+q**(2*a)))==0
print('Adjacent coprime-pair identity verified for a=1,...,11.')

l3,l4=sp.symbols('l3 l4')
M=sp.Matrix([[0,0,1],[0,1,l3],[1,l3,l4]])
assert sp.expand(M.det())==-1
Mres=sp.Matrix([[0,1],[1,l3]])
assert sp.expand(Mres.det())==-1
print('Universal rank-three/rank-two minors verified.')

for a in range(2,12):
    for r in range(3,a+2):
        D=sp.expand(P(a)**2+q**(a+1)*P(a-r))
        # coefficients of q^(2a), q^(2a-1) are 1 and 2.
        assert D.coeff(q,2*a)==1
        assert D.coeff(q,2*a-1)==2
        assert sp.degree(D-(q**(2*a)+2*q**(2*a-1)),q)<=2*a-2
print('Bilinear-divisor top-order expansion verified.')

# Small finite-field machinery.
def projective_vectors(deg,p):
    out=[]
    for j in range(deg+1):
        for tail in product(range(p),repeat=deg-j):
            out.append((0,)*j+(1,)+tail)
    return out

def trim(f,p):
    f=list(f)
    while len(f)>1 and f[-1]%p==0: f.pop()
    return f

def rem(f,g,p):
    f,g=trim(f,p),trim(g,p)
    while len(f)>=len(g) and any(f):
        sh=len(f)-len(g); c=f[-1]*pow(g[-1],-1,p)%p
        for i,x in enumerate(g): f[i+sh]=(f[i+sh]-c*x)%p
        f=trim(f,p)
    return f

def gcdp(f,g,p):
    f,g=list(f),list(g)
    while any(g): f,g=g,rem(f,g,p)
    return trim(f,p)

def coprime(f,g,p):
    if f[-1]%p==0 and g[-1]%p==0: return False
    return len(gcdp(f,g,p))==1

def conv(f,g,p):
    h=[0]*(len(f)+len(g)-1)
    for i,x in enumerate(f):
        if x:
            for j,y in enumerate(g): h[i+j]=(h[i+j]+x*y)%p
    return h

def rank_mod(M,p):
    M=[list(r) for r in M]
    nr=len(M); nc=len(M[0]); r=0
    for c in range(nc):
        k=next((i for i in range(r,nr) if M[i][c]%p),None)
        if k is None: continue
        M[r],M[k]=M[k],M[r]
        inv=pow(M[r][c]%p,-1,p)
        M[r]=[(x*inv)%p for x in M[r]]
        for i in range(r+1,nr):
            z=M[i][c]%p
            if z: M[i]=[(M[i][j]-z*M[r][j])%p for j in range(nc)]
        r+=1
        if r==nr: break
    return r

def homogeneous_mobius(h,d,p):
    top=max(i for i,c in enumerate(h) if c%p)
    infinity_mult=d-top
    if infinity_mult>=2: return 0
    t=sp.symbols('t')
    poly=sp.Poly(sum((c%p)*t**i for i,c in enumerate(h)),t,modulus=p)
    _,factors=sp.factor_list(poly,modulus=p)
    if any(e>1 for _,e in factors): return 0
    return -1 if (len(factors)+infinity_mult)%2 else 1

def divisor_data(a,p):
    data=[]
    for d in range(a+1):
        for h in projective_vectors(d,p):
            data.append((d,homogeneous_mobius(h,d,p),conv(h,h,p)))
    return data

def count_by_mobius(a,p,lam,data):
    b=a+1; total=0
    for d,mu,hh in data:
        if not mu: continue
        A=a-d+1; B=b-d+1
        M=[[sum(hh[k]*lam[k+i+j]
                for k in range(len(hh)) if k+i+j<len(lam))%p
            for j in range(B)] for i in range(A)]
        r=rank_mod(M,p)
        pairs=p**(B-1)*(p**A-p**(A-r))//(p-1)
        total += mu*pairs
    return total

def all_hyperplane_counts_mobius(a,p):
    data=divisor_data(a,p)
    target=p**(2*a+1)
    dist=Counter()
    for coeff in product(range(p),repeat=2*a-1):
        lam=(0,0,1)+coeff
        c=count_by_mobius(a,p,lam,data)
        assert c!=target
        dist[c]+=1
    return dist

for p in (5,7):
    d=all_hyperplane_counts_mobius(2,p)
    print(f'(2,3), F_{p}: checked {p**3} hyperplanes; count range {min(d)}..{max(d)}.')

d=all_hyperplane_counts_mobius(3,5)
print(f'(3,4), F_5: checked {5**5} hyperplanes; count range {min(d)}..{max(d)}.')
print('All checks passed.')
