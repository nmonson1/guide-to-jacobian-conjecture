#!/usr/bin/env python3
"""Aggregate the bounded exact Lane 5 encoded-shear diagnostics."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[2]
PACKET = ROOT / "research-notes/lane5-degree-budgets"
PROGRAMS = (
    "all_elementary_monomial_shears.py",
    "verify_reduced_word_separation.py",
    "lacunary_polynomial_shears.py",
)


def run_json(name: str) -> tuple[dict[str, object], str]:
    path = PACKET / name
    run = subprocess.run(
        [sys.executable, str(path)],
        cwd=PACKET,
        check=False,
        capture_output=True,
        text=True,
    )
    if run.returncode != 0:
        raise AssertionError(f"{name} failed:\n{run.stdout}{run.stderr}")
    return json.loads(run.stdout), hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    records = {name: run_json(name) for name in PROGRAMS}
    elementary = records[PROGRAMS[0]][0]
    reduced = records[PROGRAMS[1]][0]
    lacunary = records[PROGRAMS[2]][0]
    if elementary.get("status") != "pass" or elementary.get("finite_case_count") != 81:
        raise AssertionError("all-elementary certificate changed")
    if elementary.get("finite_rank_82_cases") != 10:
        raise AssertionError("rank-82 elementary case count changed")
    if elementary.get("finite_rank_83_cases") != 71:
        raise AssertionError("rank-83 elementary case count changed")
    if reduced.get("status") != "pass" or reduced.get("weight_width") != 18:
        raise AssertionError("reduced-word certificate changed")
    if lacunary.get("status") != "pass" or lacunary.get("weight_width") != 18:
        raise AssertionError("lacunary-tail certificate changed")

    result = {
        "schema_version": 1,
        "name": "Lane 5 finite encoded shear enumeration",
        "status": "pass",
        "source_sha256": {name: records[name][1] for name in PROGRAMS},
        "elementary_monomial_shears": {
            "finite_cases": 81,
            "rank_82_cases": 10,
            "rank_83_cases": 71,
            "resonant_minor_count": elementary["resonant"]["minor_count"],
            "all_exponents_closed_by_weight_tails": True,
        },
        "separated_words": {
            "weight_width": reduced["weight_width"],
            "nested_example": reduced["nested_example"],
            "arbitrary_length_example": reduced["arbitrary_length_example"],
        },
        "does_not_establish": [
            "the missing full semidegree-normalization group",
            "all resonant mixed-sign alternating words",
            "a statement for wild source automorphisms",
            "left--right or stable invariance of the degree-six filtration",
        ],
        "failed_large_job_policy": (
            "No 8-CPU/96-GB search was rerun; this packet replays the distinct finite "
            "81-case enumeration and structural exact word certificates."
        ),
    }
    canonical = json.dumps(result, sort_keys=True, separators=(",", ":")).encode()
    result["certificate_sha256"] = hashlib.sha256(canonical).hexdigest()
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
