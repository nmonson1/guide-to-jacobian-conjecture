#!/usr/bin/env python3
"""Verify the determinant and rational collision of the baseline map.

This finite exact check establishes only the displayed polynomial identities.
It does not prove any filtration, automorphism, or minimum-degree statement.
"""

from __future__ import annotations

import sympy as sp


def main() -> int:
    x, y, z = sp.symbols("x y z")
    frame = 1 + x * y
    p = sp.expand(frame**3 * z + y**2 * frame * (4 + 3 * x * y))
    q = sp.expand(y + 3 * x * frame**2 * z + 3 * x * y**2 * (4 + 3 * x * y))
    r = sp.expand(2 * x - 3 * x**2 * y - x**3 * z)

    determinant = sp.factor(sp.Matrix([p, q, r]).jacobian([x, y, z]).det())
    if determinant != -2:
        raise AssertionError(f"Jacobian determinant changed: {determinant}")

    points = (
        (sp.Integer(0), sp.Integer(0), -sp.Rational(1, 4)),
        (sp.Integer(1), -sp.Rational(3, 2), sp.Rational(13, 2)),
        (-sp.Integer(1), sp.Rational(3, 2), sp.Rational(13, 2)),
    )
    images = tuple(
        tuple(value.subs({x: px, y: py, z: pz}) for value in (p, q, r))
        for px, py, pz in points
    )
    expected = (-sp.Rational(1, 4), sp.Integer(0), sp.Integer(0))
    if any(image != expected for image in images):
        raise AssertionError(f"collision changed: {images}")
    if len(set(points)) != 3:
        raise AssertionError("the three source points are not distinct")

    print("baseline counterexample certificate: PASS")
    print("det J(P,Q,R) = -2")
    print(f"three distinct rational points map to {expected}")
    print("does not establish: filtration, orbit, or minimum-degree claims")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
