#!/usr/bin/env python3
"""Symbolic verifier for the Lane 5 uniform collision-separation theorem.

This script checks the exact algebraic identities used in
lane5_uniform_collision_separation.md.  It is not a finite-case substitute
for the proof: the theorem is uniform in the polynomials G and H once
`deg(G) > D` and H is nonconstant.

Dependencies: Python 3 and SymPy.
"""

from __future__ import annotations

import argparse
import json
from hashlib import sha256
from pathlib import Path
from typing import Any, Dict, List

import sympy as sp


def check_marked_root_coordinates() -> None:
    t, r, C = sp.symbols("t r C", nonzero=True)
    x = 2 / r
    y = t - r / 2
    z = (2 * x - 3 * x**2 * y - C) / x**3
    A0 = 1 + x * y

    P = sp.expand(A0**3 * z + y**2 * A0 * (4 + 3 * x * y))
    Q = sp.expand(y + 3 * x * A0**2 * z + 3 * x * y**2 * (4 + 3 * x * y))
    R = sp.expand(2 * x - 3 * x**2 * y - x**3 * z)

    assert sp.cancel(P - (t * r / 2 + t**2 - C * t**3)) == 0
    assert sp.cancel(Q - (r + 4 * t - 3 * C * t**2)) == 0
    assert sp.cancel(R - C) == 0


def collision_identities() -> Dict[str, str]:
    s, u, eps = sp.symbols("s u eps", nonzero=True)
    C = 2 / (2 * s + u)
    roots = [s + eps, s - eps, u]

    points = []
    for i, t in enumerate(roots):
        others = [roots[j] for j in range(3) if j != i]
        r = sp.factor(C * (t - others[0]) * (t - others[1]))
        x = sp.factor(2 / r)
        y = sp.factor(t - r / 2)
        z = sp.factor(2 / x**2 - 3 * y / x - C / x**3)
        points.append((r, x, y, z))

    r1, x1, y1, z1 = points[0]
    r3, x3, y3, z3 = points[2]

    expected_x1 = 1 / (C * eps * (s - u + eps))
    expected_y1 = s + eps - C * eps * (s - u + eps)
    assert sp.cancel(x1 - expected_x1) == 0
    assert sp.cancel(y1 - expected_y1) == 0
    assert sp.simplify(sp.limit(eps * x1, eps, 0) - 1 / (C * (s - u))) == 0
    assert sp.simplify(sp.limit(y1, eps, 0) - s) == 0
    assert sp.simplify(sp.limit(z1, eps, 0)) == 0

    expected_r3 = C * ((u - s) ** 2 - eps**2)
    assert sp.cancel(r3 - expected_r3) == 0

    y3_zero = sp.factor(sp.limit(y3, eps, 0))
    z3_zero = sp.factor(sp.limit(z3, eps, 0))
    expected_y3 = s * (4 * u - s) / (u + 2 * s)
    assert sp.cancel(y3_zero - expected_y3) == 0

    Y = sp.symbols("Y")
    u_from_Y = s * (2 * Y + s) / (4 * s - Y)
    assert sp.cancel(expected_y3.subs(u, u_from_Y) - Y) == 0

    zeta = (s - Y) ** 2 * (s**2 - 8 * s * Y - 2 * Y**2) / (9 * s**2)
    assert sp.cancel(z3_zero.subs(u, u_from_Y) - zeta) == 0

    return {
        "x1": str(sp.factor(x1)),
        "y1": str(sp.factor(y1)),
        "r3": str(sp.factor(r3)),
        "y3_at_collision": str(y3_zero),
        "z3_as_polynomial_in_Y": str(sp.factor(zeta)),
        "zeta_degree_in_Y": str(sp.Poly(zeta, Y).degree()),
        "zeta_leading_coefficient": str(sp.Poly(zeta, Y).LC()),
    }


def optional_modular_spots() -> List[Dict[str, Any]]:
    """Replay selected pre-existing determinant certificates when available."""
    try:
        from lane5_primitive_resonance_frontier import certify_case
    except ImportError as exc:  # pragma: no cover - convenience path
        raise RuntimeError(
            "lane5_primitive_resonance_frontier.py must be in the same directory"
        ) from exc

    records = []
    for k in (8, 9, 10, 12, 15, 20, 25, 50):
        records.append(certify_case((1, 1, k, k - 1, k + 2)))
    return records


def canonical_hash(payload: Dict[str, Any]) -> str:
    data = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--modular-spots",
        action="store_true",
        help="also replay eight expensive 83x83 determinant certificates",
    )
    parser.add_argument("--json-output", type=Path, default=None)
    args = parser.parse_args()

    check_marked_root_coordinates()
    identities = collision_identities()
    payload: Dict[str, Any] = {
        "symbolic_identities": identities,
        "theorem_parameters": {
            "degree_bound": "D >= 1",
            "first_shear": "G in C[x], deg(G) > D",
            "second_shear": "H in C[y], H nonconstant",
            "conclusion": "sigma_{G,H}(S) intersect B_{<=D} = C",
        },
    }

    if args.modular_spots:
        payload["modular_spot_checks"] = optional_modular_spots()

    payload["canonical_sha256"] = canonical_hash(payload)

    print("Lane 5 uniform collision-separation identities: PASS")
    print("marked-root formulas                         = verified")
    print("double-root collision limits                = verified")
    print("third-sheet quartic zeta_s(Y)               = verified")
    print(f"zeta_s degree                               = {identities['zeta_degree_in_Y']}")
    print(
        "zeta_s leading coefficient                  = "
        f"{identities['zeta_leading_coefficient']}"
    )
    if args.modular_spots:
        print("modular equal-shift spot checks             = 8/8 passed")
    print(f"canonical payload sha256                    = {payload['canonical_sha256']}")

    if args.json_output is not None:
        args.json_output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        print(f"wrote {args.json_output}")


if __name__ == "__main__":
    main()
