# Lane 5: three-letter collision cycles

## Theorem

Let \(D\ge1\), and let

\[
G\in\mathbf C[x],\qquad
H\in\mathbf C[y],\qquad
K\in\mathbf C[z]
\]

be nonconstant polynomials with degrees

\[
N=\deg G\ge1,
\qquad
M=\deg H>D,
\qquad
L=\deg K>D.
\tag{1}
\]

Define a polynomial automorphism \(\sigma\) by specifying its inverse
recursively:

\[
Y_1=y-G(x),
\tag{2}
\]

\[
Z_1=z-H(Y_1),
\tag{3}
\]

\[
X_1=x-K(Z_1),
\tag{4}
\]

and

\[
\sigma^{-1}(x,y,z)=(X_1,Y_1,Z_1).
\tag{5}
\]

For the Lane 5 image algebra \(S=\mathbf C[P,Q,R]\),

\[
\boxed{
\sigma(S)\cap\mathbf C[x,y,z]_{\le D}=\mathbf C.
}
\tag{6}
\]

The same conclusion holds for the opposite cycle obtained by interchanging
\(y\) and \(z\):

\[
Z_1=z-G(x),
\qquad
Y_1=y-H(Z_1),
\qquad
X_1=x-K(Y_1),
\tag{7}
\]

with the polynomial domains relabeled accordingly.

## Proof

Use the standard marked-root collision arc

\[
t_1=s+\varepsilon,
\qquad
t_2=s-\varepsilon,
\qquad
t_3=u.
\]

On the first sheet,

\[
x\sim\alpha\varepsilon^{-1},
\qquad
y\to s,
\qquad
z\to0,
\qquad
\alpha\ne0,
\tag{8}
\]

while the third sheet is regular.

Let \(g_N,h_M,k_L\) be the leading coefficients. Equations (2)--(4) give
successively

\[
Y_1
 \sim -g_N\alpha^N\varepsilon^{-N},
\tag{9}
\]

\[
Z_1
 \sim -h_M(-g_N)^M\alpha^{NM}\varepsilon^{-NM},
\tag{10}
\]

and

\[
X_1
 \sim
 -k_L\bigl[-h_M(-g_N)^M\bigr]^L
 \alpha^{NML}\varepsilon^{-NML}.
\tag{11}
\]

Thus the inverse-coordinate pole vector, in the order \((X_1,Y_1,Z_1)\), is

\[
(NML,N,NM)=N(LM,1,M).
\tag{12}
\]

It remains to check that

\[
(a,b,c)\longmapsto aLM+b+cM
\tag{13}
\]

is injective on

\[
\Delta_D=\{(a,b,c)\in\mathbf N^3:a+b+c\le D\}.
\]

Suppose two exponent vectors have the same value in (13). Reducing their
difference modulo \(M\) gives

\[
b-b'\equiv0\pmod M.
\]

Since \(|b-b'|\le D<M\), it follows that \(b=b'\). Dividing the remaining
equality by \(M\) gives

\[
L(a-a')+(c-c')=0.
\]

Reduction modulo \(L\), together with \(|c-c'|\le D<L\), gives \(c=c'\),
and then \(a=a'\). Hence (13) is injective.

The collision-pole criterion now applies: every nonconstant polynomial of
degree at most \(D\) has a unique leading pole on the first inverse-transformed
sheet, while its value on the inverse-transformed third sheet is regular.
Such a polynomial cannot belong to \(\sigma(S)\). This proves (6).

For the opposite cycle (7), the pole vector is

\[
N(LM,M,1),
\]

and the same mixed-radix argument applies.

## Degree-six form

For \(D=6\), it is enough that

\[
\deg G\ge1,
\qquad
\deg H\ge7,
\qquad
\deg K\ge7.
\tag{14}
\]

Thus a large class of genuinely alternating three-letter words is closed,
including cyclic words whose first elementary factor has low degree.

For monomials, one representative inverse word is

\[
\begin{aligned}
y&\longmapsto y-cx^N,\\
z&\longmapsto z-dy^M,\\
x&\longmapsto x-ez^L,
\end{aligned}
\]

where each later line uses the coordinate produced by the preceding lines.
For every \(c,d,e\ne0\), \(N\ge1\), and \(M,L\ge7\), its transformed image
algebra contains no nonconstant polynomial of ordinary degree at most six.

## Consequence for the Lane 5 frontier

The unresolved tame frontier can be reduced further. It no longer includes:

- either ordering of a high-degree two-letter chain rooted at \(x\);
- either orientation of a three-letter cycle whose final two degrees exceed
  six.

The remaining short words are those for which tropical pole propagation
leaves a nonpositive coordinate, produces equal leading orders, or produces a
positive pole vector that is not degree-six injective. These are the cases
that still require residue analysis or exact common-fiber matrices.
