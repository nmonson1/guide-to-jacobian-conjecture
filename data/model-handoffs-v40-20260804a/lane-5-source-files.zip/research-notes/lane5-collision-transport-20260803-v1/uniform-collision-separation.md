# Lane 5: uniform collision separation for two-stage triangular words

## Main theorem

Let

\[
S=\mathbf C[P,Q,R]\subset B=\mathbf C[x,y,z],
\]

where

\[
\begin{aligned}
P&=(1+xy)^3z+y^2(1+xy)(4+3xy),\\
Q&=y+3x(1+xy)^2z+3xy^2(4+3xy),\\
R&=2x-3x^2y-x^3z.
\end{aligned}
\]

Fix an integer \(D\ge1\). Let \(G\in\mathbf C[x]\) have degree
\(N>D\), and let \(H\in\mathbf C[y]\) be nonconstant. Define the triangular
source automorphism

\[
\sigma_{G,H}(x,y,z)
 =\bigl(x,\ y+G(x),\ z+H(y+G(x))\bigr).
\tag{1}
\]

Then

\[
\boxed{
\sigma_{G,H}(S)\cap B_{\le D}=\mathbf C.
}
\tag{2}
\]

No torus-weight separation or arithmetic nonresonance condition is needed.
The proof uses the behavior of the three sheets when two marked roots collide.

## Consequence for the Lane 5 mixed-sign family

For

\[
\Psi_{c,d}^{N,M}(x,y,z)
 =\bigl(x,\ y+c x^N,\ z+d(y+c x^N)^M\bigr),
\tag{3}
\]

if \(c,d\ne0\), \(N\ge7\), and \(M\ge1\), then

\[
\boxed{
\Psi_{c,d}^{N,M}(S)\cap B_{\le6}=\mathbf C.
}
\tag{4}
\]

Thus the entire two-letter family previously controlled only under a Taylor
no-return condition is closed, including every exact-return and near-return
strip.

In particular, on the equal-shift ray

\[
N=k-1,\qquad M=k+2,
\]

one has, using the already-certified single-shear cases when one coefficient
vanishes,

\[
\boxed{
 k\ge8,\quad (c,d)\ne(0,0)
 \quad\Longrightarrow\quad
 \Psi_{c,d}^{k-1,k+2}(S)\cap B_{\le6}=\mathbf C.
}
\tag{5}
\]

This contains the full unresolved ray \(k\ge20\) and strengthens the previous
isolated certificates at \(k=19\) and the 23 primitive frontier points.

## Marked-root coordinates

Put

\[
t=y+\frac1x,\qquad r=\frac2x,\qquad C=R.
\]

A direct substitution gives

\[
Q=r+4t-3Ct^2,
\qquad
P=\frac{tr}{2}+t^2-Ct^3.
\tag{6}
\]

Hence the marked roots satisfy

\[
CT^3-2T^2+QT-2P=0.
\tag{7}
\]

For three distinct roots \(t_1,t_2,t_3\), put

\[
C=\frac2{t_1+t_2+t_3},
\qquad
r_i=C(t_i-t_j)(t_i-t_k),
\tag{8}
\]

and reconstruct the three source points by

\[
 x_i=\frac2{r_i},\qquad
 y_i=t_i-\frac{r_i}{2},\qquad
 z_i=\frac{2x_i-3x_i^2y_i-C}{x_i^3}.
\tag{9}
\]

Equations (6)--(9) show that the three points have the same values of
\((P,Q,R)\).

## Collision family

Work over \(K=\mathbf C(s,u)\) and introduce a parameter \(\varepsilon\).
Take

\[
t_1=s+\varepsilon,
\qquad
t_2=s-\varepsilon,
\qquad
t_3=u,
\qquad
C=\frac2{2s+u}.
\tag{10}
\]

For the first sheet, (8)--(9) give

\[
 x_1=\frac1{C\varepsilon(s-u+\varepsilon)},
\tag{11}
\]

\[
 y_1=s+\varepsilon-C\varepsilon(s-u+\varepsilon).
\tag{12}
\]

Consequently, for the \(\varepsilon\)-adic valuation \(\nu\),

\[
\nu(x_1)=-1,
\qquad
y_1\longrightarrow s,
\qquad
z_1\longrightarrow0.
\tag{13}
\]

The third sheet is regular at \(\varepsilon=0\), because

\[
r_3=C\bigl((u-s)^2-\varepsilon^2\bigr)
\]

is a unit in \(K[[\varepsilon]]\).

The inverse of (1) is

\[
\sigma_{G,H}^{-1}(X,Y,Z)
 =\bigl(X,\ Y-G(X),\ Z-H(Y)\bigr).
\tag{14}
\]

Let \(g_N\ne0\) be the leading coefficient of \(G\). On the first sheet,
write

\[
X_1=x_1,
\qquad
Y_1=y_1-G(x_1),
\qquad
Z_1=z_1-H(y_1).
\]

Then

\[
\nu(X_1)=-1,
\qquad
\nu(Y_1)=-N,
\qquad
\nu(Z_1)=0,
\tag{15}
\]

and the residue of \(Z_1\) is \(-H(s)\). More precisely, if

\[
\alpha=\frac1{C(s-u)},
\]

then

\[
\varepsilon X_1\longrightarrow\alpha,
\qquad
\varepsilon^N Y_1\longrightarrow-g_N\alpha^N,
\qquad
Z_1\longrightarrow-H(s).
\tag{16}
\]

Since \(H\) is nonconstant, \(H(s)\) is transcendental over \(\mathbf C\).

## Pole-separation step

Take

\[
f\in \sigma_{G,H}(S)\cap B_{\le D}.
\]

Then \(\sigma_{G,H}^{-1}(f)\in S\), so it has equal values on the three
points (9). Equivalently,

\[
f(X_1,Y_1,Z_1)=f(X_3,Y_3,Z_3).
\tag{17}
\]

The right side is regular in \(\varepsilon\).

Write

\[
f(X,Y,Z)=\sum_{a,b\ge0}X^aY^b p_{ab}(Z),
\qquad
a+b+\deg p_{ab}\le D.
\tag{18}
\]

If \(f\) contains an \(X\)- or \(Y\)-dependent term, choose \(b_0\) maximal
with some \(p_{a b_0}\ne0\), and then choose \(a_0\) maximal with
\(p_{a_0b_0}\ne0\). Because \(N>D\),

\[
a+Nb<a_0+Nb_0
\tag{19}
\]

for every other nonzero pair \((a,b)\). Indeed, this is immediate for
\(b=b_0\), while for \(b<b_0\),

\[
a+Nb\le D+N(b_0-1)<Nb_0\le a_0+Nb_0.
\]

Thus (18), evaluated on the first sheet, has a unique largest pole order
\(a_0+Nb_0\). Its leading coefficient is

\[
\alpha^{a_0}(-g_N\alpha^N)^{b_0}
 p_{a_0b_0}(-H(s)),
\tag{20}
\]

which is nonzero. This contradicts (17), since the third-sheet value is
regular. Therefore \(a_0=b_0=0\), and

\[
f=p(Z)
\tag{21}
\]

for some \(p\in\mathbf C[Z]\).

## Elimination of the remaining one-variable polynomial

At \(\varepsilon=0\), let \(Y=y_3\). From (8)--(10),

\[
Y=\frac{s(4u-s)}{u+2s},
\qquad
u=\frac{s(2Y+s)}{4s-Y}.
\tag{22}
\]

Thus \(Y\) is transcendental over \(\mathbf C(s)\). A direct simplification
of (9) gives

\[
z_3=
\zeta_s(Y)
:=\frac{(s-Y)^2(s^2-8sY-2Y^2)}{9s^2}.
\tag{23}
\]

Taking \(\varepsilon\to0\) in the fiber equality for (21) yields

\[
p(-H(s))=p\bigl(\zeta_s(Y)-H(Y)\bigr).
\tag{24}
\]

The polynomial \(\zeta_s(Y)-H(Y)\in\mathbf C(s)[Y]\) is nonconstant. Indeed,
\(\zeta_s\) has degree four and leading coefficient \(-2/(9s^2)\). If
\(\deg H\ne4\), nonconstancy is immediate; if \(\deg H=4\), its leading
coefficient cannot cancel \(-2/(9s^2)\), because the former lies in
\(\mathbf C\) and the latter genuinely depends on \(s\).

Hence \(\zeta_s(Y)-H(Y)\) is transcendental over \(\mathbf C(s)\). If \(p\)
were nonconstant, the right side of (24) would also be transcendental over
\(\mathbf C(s)\), whereas the left side belongs to \(\mathbf C(s)\). This is
impossible. Therefore \(p\) is constant, proving (2).

## Exact computational cross-checks

The pre-existing two-minor certificate was replayed at the equal-shift points

\[
k=8,9,10,12,15,20,25,50.
\]

For every point, both selected \(83\times83\) determinant polynomials retained
full degree 126 modulo \(1000003\), and their gcd was 1. These checks are not
used in the uniform proof; they independently confirm the first cases below,
at, and far above the old weight-window threshold.

## Scope

The theorem closes every word of the form (1) with \(\deg G>D\) and
nonconstant \(H\). It does not directly address:

- the reverse nesting order, whose inverse third coordinate contains
  \(H(y-G(x))\) and therefore has a second large pole;
- three-letter alternating words;
- words in which the first shear polynomial has degree at most \(D\);
- wild source automorphisms.

The next minimal target is the reverse-nested family

\[
\widetilde\sigma_{G,H}(x,y,z)
 =\bigl(x,\ y+G(x),\ z+H(y)\bigr),
\]

whose inverse is

\[
(X,Y,Z)\longmapsto
\bigl(X,\ Y-G(X),\ Z-H(Y-G(X))\bigr).
\]

Its collision pole weights are \((1,N,N\deg H)\), so a corresponding
mixed-radix separation theorem appears plausible when these weights separate
all degree-\(D\) monomials.
