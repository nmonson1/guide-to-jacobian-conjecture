#!/usr/bin/env python3
"""Exact combinatorial checker for Lane 5 collision-pole separation.

The script verifies mixed-radix injectivity of pole vectors on all monomials
of total degree at most D and records the degree-six reverse-word frontier.
"""

from __future__ import annotations

import argparse
import json
from hashlib import sha256
from itertools import product
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

Exponent = Tuple[int, int, int]


def monomials_leq(D: int) -> List[Exponent]:
    return [
        (a, b, c)
        for a in range(D + 1)
        for b in range(D + 1 - a)
        for c in range(D + 1 - a - b)
    ]


def collision(
    D: int, weights: Sequence[int]
) -> Optional[Tuple[Exponent, Exponent, int]]:
    seen: Dict[int, Exponent] = {}
    for exponent in monomials_leq(D):
        value = sum(a * w for a, w in zip(exponent, weights))
        if value in seen:
            return seen[value], exponent, value
        seen[value] = exponent
    return None


def reverse_word_weights(N: int, M: int) -> Tuple[int, int, int]:
    return (1, N, N * M)


def canonical_hash(payload: object) -> str:
    data = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--degree", type=int, default=6)
    parser.add_argument("--max-exponent", type=int, default=30)
    parser.add_argument("--json-output", type=Path, default=None)
    args = parser.parse_args()

    D = args.degree
    cases = []
    for N in range(1, args.max_exponent + 1):
        first_good_M = None
        first_collision = None
        for M in range(1, args.max_exponent + 1):
            weights = reverse_word_weights(N, M)
            witness = collision(D, weights)
            if witness is None:
                first_good_M = M
                break
            if first_collision is None:
                first_collision = witness
        cases.append(
            {
                "N": N,
                "first_injective_M": first_good_M,
                "expected_first_injective_M": D + 1 if N > D else None,
            }
        )

    for record in cases:
        N = int(record["N"])
        expected = record["expected_first_injective_M"]
        observed = record["first_injective_M"]
        if N > D and observed != expected:
            raise AssertionError(
                f"mixed-radix frontier mismatch for N={N}: {observed} != {expected}"
            )
        if N <= D and observed is not None:
            raise AssertionError(
                f"unexpected injective weights with N={N} <= D: M={observed}"
            )

    payload = {
        "degree_bound": D,
        "monomial_count": len(monomials_leq(D)),
        "weight_family": [1, "N", "N*M"],
        "criterion": "injective iff N>D and M>D within scanned range",
        "scan_max_exponent": args.max_exponent,
        "cases": cases,
    }
    payload["canonical_sha256"] = canonical_hash(payload)

    print("Lane 5 collision-pole mixed-radix scan: PASS")
    print(f"degree bound                  = {D}")
    print(f"monomial count                = {len(monomials_leq(D))}")
    print(f"scanned N,M                   = 1..{args.max_exponent}")
    print(f"exact frontier for N>{D}       = M={D+1}")
    print(f"canonical payload sha256      = {payload['canonical_sha256']}")

    if args.json_output is not None:
        args.json_output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        print(f"wrote {args.json_output}")


if __name__ == "__main__":
    main()
