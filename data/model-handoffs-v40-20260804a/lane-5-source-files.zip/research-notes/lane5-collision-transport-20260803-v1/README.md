# Lane 5 collision and transport packet

This packet contains two complementary advances for the displayed Keller image
algebra \(S=\mathbf C[P,Q,R]\subset\mathbf C[x,y,z]\).

First, `RELATIVE_DERIVATION_COVARIANCE.md` gives the intrinsic transformation
law for the relative-derivation module over a branch component. It separates
the global filtered Jacobian ideal from frame-dependent determinants and states
the exact one-way filtration transport available under source automorphisms.

Second, three collision-arc theorems prove that broad high-degree triangular
families have no nonconstant element of bounded ordinary degree:

- `uniform-collision-separation.md` treats the forward two-stage word;
- `collision-pole-criterion.md` gives the general pole criterion and reverse
  two-stage word;
- `three-letter-collision-cycles.md` treats both orientations of a three-letter
  cycle.

The three Python programs replay the exact algebra and finite scans. These
results close the stated high-degree families. They do not decide the low-weight
word \((x,y+x^2,z+(y+x^2)^2)\), all tame automorphisms, or wild
automorphisms.

Immutable replay logs are under
`/path/to/versioned-artifact`.
