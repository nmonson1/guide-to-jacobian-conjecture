#!/usr/bin/env python3
"""Combinatorial verifier for Lane 5 three-letter collision cycles."""

from __future__ import annotations

import argparse
import json
from hashlib import sha256
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

Exponent = Tuple[int, int, int]


def monomials_leq(D: int) -> List[Exponent]:
    return [
        (a, b, c)
        for a in range(D + 1)
        for b in range(D + 1 - a)
        for c in range(D + 1 - a - b)
    ]


def first_collision(D: int, weights: Sequence[int]) -> Optional[Dict[str, object]]:
    seen: Dict[int, Exponent] = {}
    for exponent in monomials_leq(D):
        value = sum(a * w for a, w in zip(exponent, weights))
        if value in seen:
            return {
                "value": value,
                "first": list(seen[value]),
                "second": list(exponent),
            }
        seen[value] = exponent
    return None


def canonical_hash(payload: object) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return sha256(raw).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--degree", type=int, default=6)
    parser.add_argument("--max-degree", type=int, default=20)
    parser.add_argument("--json-output", type=Path, default=None)
    args = parser.parse_args()

    D = args.degree
    records = []
    for N in range(1, args.max_degree + 1):
        for M in range(1, args.max_degree + 1):
            for L in range(1, args.max_degree + 1):
                weights = (N * M * L, N, N * M)
                witness = first_collision(D, weights)
                expected = M > D and L > D
                if (witness is None) != expected:
                    raise AssertionError(
                        f"frontier mismatch at (N,M,L)=({N},{M},{L}), "
                        f"weights={weights}, witness={witness}"
                    )
                if N in (1, D, D + 1) and M in (D, D + 1) and L in (D, D + 1):
                    records.append(
                        {
                            "N": N,
                            "M": M,
                            "L": L,
                            "weights": list(weights),
                            "injective": witness is None,
                            "collision": witness,
                        }
                    )

    payload = {
        "degree_bound": D,
        "monomial_count": len(monomials_leq(D)),
        "scanned_degree_range": [1, args.max_degree],
        "pole_weights": ["N*M*L", "N", "N*M"],
        "verified_frontier": "injective iff M>D and L>D",
        "boundary_records": records,
    }
    payload["canonical_sha256"] = canonical_hash(payload)

    print("Lane 5 three-letter collision-cycle scan: PASS")
    print(f"degree bound                      = {D}")
    print(f"monomial count                    = {len(monomials_leq(D))}")
    print(f"scanned N,M,L                     = 1..{args.max_degree}")
    print(f"exact injectivity frontier        = M,L > {D}")
    print(f"canonical payload sha256          = {payload['canonical_sha256']}")

    if args.json_output is not None:
        args.json_output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        print(f"wrote {args.json_output}")


if __name__ == "__main__":
    main()
