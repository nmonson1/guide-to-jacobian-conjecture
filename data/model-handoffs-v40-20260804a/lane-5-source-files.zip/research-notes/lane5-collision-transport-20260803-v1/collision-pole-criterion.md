# Lane 5: collision-pole criterion and the reverse two-shear word

## 1. General collision-pole criterion

Let

\[
F:\mathbf A^3\to\mathbf A^3,
\qquad
S=\mathbf C[F_1,F_2,F_3]\subset B=\mathbf C[x_1,x_2,x_3].
\]

Fix \(D\ge1\). Suppose that, over a field extension \(K/\mathbf C\), there
are two Laurent-series arcs

\[
p(\varepsilon),q(\varepsilon)\in\mathbf A^3(K((\varepsilon)))
\]

such that

\[
F(p(\varepsilon))=F(q(\varepsilon)),
\tag{1}
\]

and \(q(\varepsilon)\) is regular at \(\varepsilon=0\).

Let \(\sigma\in\operatorname{Aut}(B)\). Assume that

\[
\sigma^{-1}(p(\varepsilon))_j
 =c_j\varepsilon^{-w_j}+
 O(\varepsilon^{-w_j+1}),
\qquad c_j\in K^\times,
\tag{2}
\]

with positive integers \(w_1,w_2,w_3\). If the map

\[
\alpha=(\alpha_1,\alpha_2,\alpha_3)
\longmapsto
\alpha\cdot w
\tag{3}
\]

is injective on

\[
\Delta_D=\{\alpha\in\mathbf N^3:|\alpha|\le D\},
\tag{4}
\]

then

\[
\boxed{
\sigma(S)\cap B_{\le D}=\mathbf C.
}
\tag{5}
\]

### Proof

Take \(f\in\sigma(S)\cap B_{\le D}\). Then
\(\sigma^{-1}(f)\in S\), so (1) implies

\[
f(\sigma^{-1}p(\varepsilon))
 =f(\sigma^{-1}q(\varepsilon)).
\tag{6}
\]

The right side is regular because polynomial automorphisms preserve the
regularity of the arc \(q\).

If \(f\) is nonconstant, its support contains a unique exponent
\(\alpha_0\) maximizing \(\alpha\cdot w\), by injectivity. The corresponding
term in the left side of (6) has nonzero leading coefficient

\[
f_{\alpha_0}c_1^{\alpha_{0,1}}
 c_2^{\alpha_{0,2}}c_3^{\alpha_{0,3}}
\]

and strictly larger pole order than every other term. It cannot cancel.
Thus the left side has a pole, contradicting (6). Hence \(f\) is constant.
\(\square\)

The criterion is entirely source-coordinate based. It requires neither a
semidegree invariant under the automorphism group nor a finite common-fiber
matrix.

## 2. Lane 5 collision arc

For the Lane 5 map, use the marked-root collision

\[
t_1=s+\varepsilon,
\qquad t_2=s-\varepsilon,
\qquad t_3=u,
\qquad C=\frac2{2s+u}.
\]

The first and third sheets satisfy

\[
\nu_\varepsilon(x_1)=-1,
\qquad
\nu_\varepsilon(y_1)=0,
\qquad
\nu_\varepsilon(z_1)\ge1,
\tag{7}
\]

while \((x_3,y_3,z_3)\) is regular. Thus the initial signed pole-order vector
is

\[
(1,0,-1).
\tag{8}
\]

## 3. Reverse two-shear theorem

Let \(G\in\mathbf C[x]\) and \(H\in\mathbf C[y]\) have degrees

\[
N=\deg G>D,
\qquad
M=\deg H>D.
\tag{9}
\]

Define

\[
\widetilde\sigma_{G,H}(x,y,z)
 =\bigl(x,\ y+G(x),\ z+H(y)\bigr).
\tag{10}
\]

Its inverse is

\[
\widetilde\sigma_{G,H}^{-1}(X,Y,Z)
 =\bigl(X,\ Y-G(X),\ Z-H(Y-G(X))\bigr).
\tag{11}
\]

If \(g_N,h_M\ne0\) are the leading coefficients, then on the first
collision sheet,

\[
X_1\sim \alpha\varepsilon^{-1},
\tag{12}
\]

\[
Y_1-G(X_1)
 \sim -g_N\alpha^N\varepsilon^{-N},
\tag{13}
\]

and

\[
Z_1-H(Y_1-G(X_1))
 \sim
 -h_M(-g_N)^M\alpha^{NM}\varepsilon^{-NM}.
\tag{14}
\]

Thus the inverse-coordinate pole vector is

\[
w=(1,N,NM).
\tag{15}
\]

This vector is injective on \(\Delta_D\). Indeed, if

\[
a+Nb+NMc=a'+Nb'+NMc',
\tag{16}
\]

then reduction modulo the mixed-radix bounds gives the result directly. More
explicitly, if \(c\ne c'\), then

\[
NM\le |(a-a')+N(b-b')|
 \le D+ND=D(N+1),
\]

but \(M>D\) and \(N>D\) imply

\[
NM-D(N+1)=N(M-D)-D\ge N-D>0.
\]

Hence \(c=c'\). Then \(b\ne b'\) would imply

\[
N\le|a-a'|\le D,
\]

which is impossible; therefore \(b=b'\), and finally \(a=a'\).

Applying the collision-pole criterion gives

\[
\boxed{
\widetilde\sigma_{G,H}(S)\cap B_{\le D}=\mathbf C.
}
\tag{17}
\]

The degree conditions are sharp for this particular mixed-radix argument:
if \(M\le D\), the two exponent vectors

\[
(0,M,0),\qquad(0,0,1)
\]

both lie in \(\Delta_D\) and have the same weight \(NM\); similarly,
\(N\le D\) creates collisions between the first two digits.

## 4. Degree-six corollaries

For \(D=6\), if

\[
\deg G\ge7,
\qquad
\deg H\ge7,
\]

then

\[
\widetilde\sigma_{G,H}(S)\cap B_{\le6}=\mathbf C.
\tag{18}
\]

In particular, for the reverse equal-shift monomial word

\[
\widetilde\Psi_{c,d}^{k}(x,y,z)
 =\bigl(x,\ y+c x^{k-1},\ z+d y^{k+2}\bigr),
\]

with \(c,d\ne0\), one has

\[
\boxed{
 k\ge8
 \quad\Longrightarrow\quad
 \widetilde\Psi_{c,d}^{k}(S)\cap B_{\le6}=\mathbf C.
}
\tag{19}
\]

Together with the uniform collision-separation theorem for the opposite
ordering,

\[
(x,y,z)\mapsto
\bigl(x,y+G(x),z+H(y+G(x))\bigr),
\]

this closes both orderings of the high-degree two-letter chain

\[
x\longrightarrow y\longrightarrow z.
\]

## 5. Tropical extension to longer words

For an inverse elementary shear

\[
x_i\longmapsto x_i-cm(x_j,x_k),
\]

assign signed pole orders \(w_1,w_2,w_3\). If

\[
\deg_w m>w_i,
\]

then, absent an equal-leading-order cancellation, the new pole order is

\[
w_i\longleftarrow\deg_wm.
\tag{20}
\]

If the inequality is strict, cancellation is impossible. Iterating (20)
through an inverse word produces a tropical pole vector. Whenever the final
three entries are positive and injective on \(\Delta_6\), the criterion above
closes that word immediately.

Therefore the next computational task should not enumerate coefficient-space
kernels first. It should enumerate short reduced words, propagate their
collision pole vectors, and send only the non-separated or equal-leading-order
cases to exact common-fiber algebra.
