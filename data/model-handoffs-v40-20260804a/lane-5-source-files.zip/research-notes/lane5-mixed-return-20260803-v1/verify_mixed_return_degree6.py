#!/usr/bin/env python3
"""Verify the Lane 5 bounded mixed-return degree-six certificate.

Let ``S = Q[P,Q,R]`` be the displayed image algebra and let

    Psi_{N,M}(x,y,z) = (x, y+x^N, z+(y+x^N)^M).

For every ``2 <= N,M <= 6``, this script reconstructs 83 exact rational
common-fibre difference rows on the 84 monomials of total degree at most six.
It then checks a nonzero 83 by 83 minor modulo 1,000,003.  Constants are in
the exact kernel, so the modular lower bound and the constant upper bound
prove that the exact rational kernel is precisely the constants.

The inverse source substitution is implemented compositionally:

    Psi_{N,M}^{-1}(x,y,z) = (x, y-x^N, z-y^M).

The modular calculation is only a certificate that a particular reduction
of an exact rational minor is nonzero; all rows themselves are reconstructed
over Q from the stored split-fibre descriptors.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import shutil
import sys
from fractions import Fraction
from pathlib import Path
from typing import Iterable


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE_PACKET = ROOT / "research-notes" / "lane5-degree-budgets"
if str(BASE_PACKET) not in sys.path:
    sys.path.insert(0, str(BASE_PACKET))

from standard_filtration_certificate import (  # noqa: E402
    evaluate_monomials,
    fraction_mod,
    map_f,
    monomials_degree_at_most,
    split_target,
)


CERTIFICATE = HERE / "mixed_return_degree6_certificate.json"
HELPER = BASE_PACKET / "standard_filtration_certificate.py"
PRIME = 1_000_003
BOUND = 6
MONOMIALS = monomials_degree_at_most(BOUND)
CONSTANT_COLUMN = MONOMIALS.index((0, 0, 0))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inverse_psi(
    exponent_n: int,
    exponent_m: int,
    point: tuple[Fraction, Fraction, Fraction],
) -> tuple[Fraction, Fraction, Fraction]:
    """Apply Psi^{-1}, respecting the order of the two noncommuting factors."""
    x, y, z = point
    return x, y - x**exponent_n, z - y**exponent_m


def forward_psi(
    exponent_n: int,
    exponent_m: int,
    point: tuple[Fraction, Fraction, Fraction],
) -> tuple[Fraction, Fraction, Fraction]:
    x, y, z = point
    shifted_y = y + x**exponent_n
    return x, shifted_y, z + shifted_y**exponent_m


def candidate_fibres() -> list[dict[str, object]]:
    """Return the deterministic exact split-fibre search list."""
    candidates: list[dict[str, object]] = []
    for h in (Fraction(1), Fraction(2), Fraction(3)):
        for a in range(-12, 1):
            for b in range(-12, 2):
                for sign in (1, -1):
                    try:
                        target, points = split_target(
                            Fraction(a), Fraction(b), h, sign
                        )
                    except (ValueError, ZeroDivisionError):
                        continue
                    candidates.append(
                        {
                            "descriptor": {
                                "a": str(a),
                                "b": str(b),
                                "h": str(h),
                                "sign": sign,
                            },
                            "target": target,
                            "points": points,
                        }
                    )
    return candidates


def add_row_echelon(
    row: list[int], basis: dict[int, list[int]], prime: int
) -> bool:
    work = [entry % prime for entry in row]
    for pivot in sorted(basis):
        factor = work[pivot]
        if not factor:
            continue
        basis_row = basis[pivot]
        for column in range(pivot, len(work)):
            work[column] = (work[column] - factor * basis_row[column]) % prime
    pivot = next((index for index, entry in enumerate(work) if entry), None)
    if pivot is None:
        return False
    inverse = pow(work[pivot], prime - 2, prime)
    for column in range(pivot, len(work)):
        work[column] = work[column] * inverse % prime
    basis[pivot] = work
    return True


def determinant_mod(matrix: list[list[int]], prime: int) -> int:
    work = [[entry % prime for entry in row] for row in matrix]
    size = len(work)
    if any(len(row) != size for row in work):
        raise ValueError("determinant matrix must be square")
    determinant = 1
    for column in range(size):
        pivot_row = next(
            (row for row in range(column, size) if work[row][column]), None
        )
        if pivot_row is None:
            return 0
        if pivot_row != column:
            work[column], work[pivot_row] = work[pivot_row], work[column]
            determinant = -determinant
        pivot = work[column][column] % prime
        determinant = determinant * pivot % prime
        inverse = pow(pivot, prime - 2, prime)
        for row in range(column + 1, size):
            factor = work[row][column] * inverse % prime
            if not factor:
                continue
            for offset in range(column, size):
                work[row][offset] = (
                    work[row][offset] - factor * work[column][offset]
                ) % prime
    return determinant % prime


def exact_row(
    exponent_n: int,
    exponent_m: int,
    descriptor: dict[str, object],
) -> list[Fraction]:
    target, original_points = split_target(
        Fraction(str(descriptor["a"])),
        Fraction(str(descriptor["b"])),
        Fraction(str(descriptor["h"])),
        int(descriptor["sign"]),
    )
    pair = int(descriptor["pair"])
    if pair not in (1, 2):
        raise ValueError("pair must be 1 or 2")
    points = [
        inverse_psi(exponent_n, exponent_m, point) for point in original_points
    ]
    if any(
        forward_psi(exponent_n, exponent_m, transformed) != original
        for transformed, original in zip(points, original_points)
    ):
        raise AssertionError("the recorded forward/inverse composition changed")
    if any(
        map_f(forward_psi(exponent_n, exponent_m, point)) != target
        for point in points
    ):
        raise AssertionError("transformed points do not lie in one Psi(S)-fibre")
    first = evaluate_monomials(points[0], MONOMIALS, BOUND)
    second = evaluate_monomials(points[pair], MONOMIALS, BOUND)
    return [left - right for left, right in zip(first, second)]


def select_case(
    exponent_n: int,
    exponent_m: int,
    candidates: Iterable[dict[str, object]],
) -> dict[str, object]:
    basis: dict[int, list[int]] = {}
    selected_rows: list[dict[str, object]] = []
    exact_rows: list[list[Fraction]] = []

    for candidate in candidates:
        base = candidate["descriptor"]
        if not isinstance(base, dict):
            raise TypeError("candidate descriptor must be an object")
        for pair in (1, 2):
            descriptor = {**base, "pair": pair}
            row = exact_row(exponent_n, exponent_m, descriptor)
            modular = [fraction_mod(value, PRIME) for value in row]
            if not add_row_echelon(modular, basis, PRIME):
                continue
            selected_rows.append(descriptor)
            exact_rows.append(row)
            if len(basis) == len(MONOMIALS) - 1:
                break
        if len(basis) == len(MONOMIALS) - 1:
            break

    if len(basis) != len(MONOMIALS) - 1:
        raise AssertionError(
            f"N={exponent_n}, M={exponent_m}: rank 83 was not reached"
        )
    pivots = sorted(basis)
    expected_pivots = [
        column for column in range(len(MONOMIALS)) if column != CONSTANT_COLUMN
    ]
    if pivots != expected_pivots:
        raise AssertionError("the selected minor is not the full nonconstant block")
    modular_rows = [
        [fraction_mod(value, PRIME) for value in row] for row in exact_rows
    ]
    determinant = determinant_mod(
        [[row[column] for column in pivots] for row in modular_rows], PRIME
    )
    if determinant == 0:
        raise AssertionError("selected modular determinant vanished")
    return {
        "N": exponent_n,
        "M": exponent_m,
        "rank": len(pivots),
        "kernel_dimension": 1,
        "intersection_basis": ["1"],
        "generated_algebra_transcendence_degree": 0,
        "J6": "zero ideal",
        "selected_rows": selected_rows,
        "pivot_columns": pivots,
        "pivot_minor_determinant_mod_prime": determinant,
    }


def build_certificate() -> dict[str, object]:
    candidates = candidate_fibres()
    return {
        "schema_version": 1,
        "theorem_id": "lane5-mixed-return-degree6-25-cases",
        "field": "Q",
        "characteristic_extension": "every characteristic-zero field by base change",
        "degree_bound": BOUND,
        "prime": PRIME,
        "map": {
            "A0": "1+x*y",
            "P": "A0^3*z + y^2*A0*(4+3*x*y)",
            "Q": "y + 3*x*A0^2*z + 3*x*y^2*(4+3*x*y)",
            "R": "2*x - 3*x^2*y - x^3*z",
        },
        "family": {
            "range": "2 <= N,M <= 6",
            "Psi": "(x, y+x^N, z+(y+x^N)^M)",
            "Psi_inverse": "(x, y-x^N, z-y^M)",
            "composition_convention": (
                "Psi=exp(x^N*d/dy) exp(y^M*d/dz), acting on coordinate "
                "functions in the displayed order"
            ),
        },
        "monomial_order": [list(monomial) for monomial in MONOMIALS],
        "monomial_order_description": (
            "(i,j,k), with i=0..6, j=0..6-i, k=0..6-i-j; "
            "column x^i*y^j*z^k"
        ),
        "common_fibre_search": {
            "h_values": ["1", "2", "3"],
            "a_range": [-12, 0],
            "b_range": [-12, 1],
            "signs": [1, -1],
            "candidate_count_after_nondegeneracy_filter": len(candidates),
        },
        "source_sha256": {
            "verify_mixed_return_degree6.py": sha256(Path(__file__).resolve()),
            "standard_filtration_certificate.py": sha256(HELPER),
        },
        "cases": [
            select_case(exponent_n, exponent_m, candidates)
            for exponent_n in range(2, 7)
            for exponent_m in range(2, 7)
        ],
        "conclusion": (
            "For every 2 <= N,M <= 6, Psi_{N,M}(Q[P,Q,R]) intersect "
            "Q[x,y,z]_{<=6}=Q. Hence F_6^{Psi_{N,M}}A=span_Q{1}, the "
            "generated algebra has transcendence degree zero, and "
            "J_6^{Psi_{N,M}}=0; the same statements hold over every "
            "characteristic-zero field."
        ),
        "does_not_establish": [
            "the same conclusion for exponents outside 2 <= N,M <= 6",
            "a classification of every low-weight or mixed-sign tame word",
            "a transformation law for the filtration under arbitrary source automorphisms",
            "any statement for wild polynomial automorphisms",
        ],
    }


def verify(certificate: dict[str, object]) -> dict[str, object]:
    if int(certificate["schema_version"]) != 1:
        raise AssertionError("unsupported certificate schema")
    if (
        int(certificate["degree_bound"]) != BOUND
        or int(certificate["prime"]) != PRIME
    ):
        raise AssertionError("global certificate parameters changed")
    if certificate["monomial_order"] != [list(monomial) for monomial in MONOMIALS]:
        raise AssertionError("source monomial ordering changed")
    expected_hashes = {
        "verify_mixed_return_degree6.py": sha256(Path(__file__).resolve()),
        "standard_filtration_certificate.py": sha256(HELPER),
    }
    if certificate["source_sha256"] != expected_hashes:
        raise AssertionError("certificate source hashes do not match the current programs")

    raw_cases = certificate["cases"]
    if not isinstance(raw_cases, list):
        raise TypeError("cases must be a list")
    expected_pairs = [(n, m) for n in range(2, 7) for m in range(2, 7)]
    observed_pairs: list[tuple[int, int]] = []
    results: list[dict[str, object]] = []
    for case in raw_cases:
        if not isinstance(case, dict):
            raise TypeError("case must be an object")
        exponent_n, exponent_m = int(case["N"]), int(case["M"])
        observed_pairs.append((exponent_n, exponent_m))
        rows = case["selected_rows"]
        if not isinstance(rows, list) or len(rows) != 83:
            raise AssertionError(f"N={exponent_n}, M={exponent_m}: expected 83 rows")
        exact_rows = [
            exact_row(exponent_n, exponent_m, descriptor) for descriptor in rows
        ]
        modular_rows = [
            [fraction_mod(value, PRIME) for value in row] for row in exact_rows
        ]
        pivots = [int(column) for column in case["pivot_columns"]]
        if pivots != list(range(1, 84)):
            raise AssertionError(f"N={exponent_n}, M={exponent_m}: pivots changed")
        determinant = determinant_mod(
            [[row[column] for column in pivots] for row in modular_rows], PRIME
        )
        if (
            determinant == 0
            or determinant != int(case["pivot_minor_determinant_mod_prime"])
        ):
            raise AssertionError(
                f"N={exponent_n}, M={exponent_m}: determinant changed"
            )
        if any(row[CONSTANT_COLUMN] != 0 for row in exact_rows):
            raise AssertionError("constants are not in the exact rational kernel")
        if (
            int(case["rank"]) != 83
            or int(case["kernel_dimension"]) != 1
            or case["intersection_basis"] != ["1"]
            or int(case["generated_algebra_transcendence_degree"]) != 0
            or case["J6"] != "zero ideal"
        ):
            raise AssertionError(
                f"N={exponent_n}, M={exponent_m}: result metadata changed"
            )
        results.append(
            {
                "N": exponent_n,
                "M": exponent_m,
                "rank": 83,
                "kernel_dimension": 1,
                "pivot_minor_determinant_mod_prime": determinant,
                "status": "pass",
            }
        )
    if observed_pairs != expected_pairs:
        raise AssertionError("the certificate does not cover the ordered 5 by 5 family")
    return {
        "status": "pass",
        "case_count": len(results),
        "degree_bound": BOUND,
        "monomial_count": len(MONOMIALS),
        "prime": PRIME,
        "all_ranks": sorted({result["rank"] for result in results}),
        "all_kernel_dimensions": sorted(
            {result["kernel_dimension"] for result in results}
        ),
        "source_sha256": expected_hashes,
        "cases": results,
        "conclusion": certificate["conclusion"],
        "does_not_establish": certificate["does_not_establish"],
    }


def canonical_json(data: object) -> str:
    return json.dumps(data, indent=2, sort_keys=True) + "\n"


def write_certificate(path: Path) -> dict[str, object]:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite certificate: {path}")
    certificate = build_certificate()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(canonical_json(certificate), encoding="utf-8")
    return verify(certificate)


def write_run_receipt(path: Path, certificate_path: Path) -> dict[str, object]:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite run directory: {path}")
    certificate = json.loads(certificate_path.read_text(encoding="utf-8"))
    result = verify(certificate)
    path.mkdir(parents=True, exist_ok=False)
    copied_certificate = path / certificate_path.name
    shutil.copyfile(certificate_path, copied_certificate)

    replay_argv = [
        "uv",
        "run",
        "python",
        "-B",
        str(Path(__file__).resolve()),
        "--certificate",
        str(copied_certificate),
    ]
    (path / "COMMAND.json").write_text(
        canonical_json(
            {
                "argv": replay_argv,
                "cwd": str(ROOT),
                "command": " ".join(replay_argv),
            }
        ),
        encoding="utf-8",
    )
    (path / "DEPENDENCIES.json").write_text(
        canonical_json(
            {
                "implementation": platform.python_implementation(),
                "python_version": platform.python_version(),
                "external_python_packages": [],
                "arithmetic": "fractions.Fraction plus modular integer elimination",
            }
        ),
        encoding="utf-8",
    )
    (path / "SOURCES.json").write_text(
        canonical_json(
            {
                "sources": {
                    str(Path(__file__).resolve()): sha256(Path(__file__).resolve()),
                    str(HELPER): sha256(HELPER),
                    str(certificate_path.resolve()): sha256(certificate_path),
                }
            }
        ),
        encoding="utf-8",
    )
    (path / "RESULT.json").write_text(canonical_json(result), encoding="utf-8")
    (path / "stdout.log").write_text(canonical_json(result), encoding="utf-8")
    (path / "stderr.log").write_text("", encoding="utf-8")
    (path / "EXIT.json").write_text(
        canonical_json({"exit_code": 0, "status": "pass"}), encoding="utf-8"
    )
    limitations = certificate["does_not_establish"]
    (path / "DOES_NOT_ESTABLISH.md").write_text(
        "# Scope boundary\n\n"
        + "\n".join(f"- {item}" for item in limitations)
        + "\n",
        encoding="utf-8",
    )
    manifest_entries = []
    for item in sorted(path.iterdir(), key=lambda candidate: candidate.name):
        if item.name == "MANIFEST.sha256" or not item.is_file():
            continue
        manifest_entries.append(f"{sha256(item)}  {item.name}")
    (path / "MANIFEST.sha256").write_text(
        "\n".join(manifest_entries) + "\n", encoding="utf-8"
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--certificate", type=Path, default=CERTIFICATE)
    parser.add_argument("--write-certificate", type=Path)
    parser.add_argument("--write-run", type=Path)
    args = parser.parse_args()
    if args.write_certificate is not None and args.write_run is not None:
        parser.error("--write-certificate and --write-run are mutually exclusive")
    if args.write_certificate is not None:
        result = write_certificate(args.write_certificate)
    elif args.write_run is not None:
        result = write_run_receipt(args.write_run, args.certificate)
    else:
        certificate = json.loads(args.certificate.read_text(encoding="utf-8"))
        result = verify(certificate)
    print(canonical_json(result), end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
