# Exact input contract for the Q4-F4 compatibility problem

## Status

This document specifies the minimum data needed for an auditable elimination
of the surviving Lane 4 terminal system. It is deliberately fail-closed.

The current sources identify an exceptional branch with ramification degree
3 and Hilbert--Burch type (3,4), and report that the remaining
weighted-inflection family is defined over a finite extension of
Q(tau). They do not publish, in one reconstructible artifact, the defining
polynomial q4(d,tau), the normalized forms P,Q,R, the complete gauge choices,
every allowed coefficient of H3,H2,L, or every factor inverted on the F4
chart.

Consequently this packet does not manufacture an F4 checker from descriptive
prose. An elimination result is admissible only after a complete instance of
f4-contract.schema.json has been supplied and independently reconstructed
from the geometric normal form.

## Required payload

A complete instance must contain all of the following:

1. Exact source commit, source paths, SHA-256 digests, and derivation
   locators for every formula.
2. The explicit polynomial q4(d,tau), immutable variable order, and exact
   open set on which its field statement is used.
3. Exact P,Q,R, with direct checks of their degrees, gcd(P,Q)=1,
   Hilbert--Burch type (3,4), and ramification degree 3.
4. The most general H3,H2,L allowed after normalization. Every removed
   coefficient must be paired with the invertible action that removes it.
5. One product S containing every pivot, denominator, discriminant,
   resultant, and rank minor inverted in reaching F4.
6. A separate route or saturated system for every irreducible factor of S
   and for intersections where the rank profile changes.
7. A canonical determinant-layer convention and the exact list of layers
   already solved.
8. At least two exact sample reconstructions, including a previously
   reported obstruction, with expected coefficient vectors and hashes.

The linear part may be normalized to the identity only if the supplied
source and target actions prove that this preserves the F4 chart and all
lower-layer freedom. Otherwise L remains a general invertible matrix and the
ideal includes an auxiliary equation u det(L)-1.

## Canonical ring and symbol order

The intended generic coordinate ring is

    Q[tau,d,a,b,l,u] / (q4(d,tau), u*S*det(L)-1),

where a, b, and l are precisely the coefficients left in H3, H2, and L.
The instance must prescribe an immutable symbol order. Hashes are computed
from canonical polynomial serialization, not pretty-printed CAS output.

## Elimination protocol

### Stage A: solve D6 as a module

Separate the coefficients occurring linearly in D6 and write M6*u=b6.
Compute its generic rank and rank-drop Fitting ideals, an exact affine
solution u=u0+N*lambda on the declared open set, and a substitution check of
every D6 coefficient. Every pivot division must be recorded in S.

### Stage B: test all D5 cancellations in the cokernel

After substituting the full D6 solution, write D5=omega+T*v, where v includes
every still-free coefficient able to cancel the reported obstruction.
Cancellation is possible exactly when omega vanishes in coker(T). A useful
certificate is either a symbolic left-kernel vector ell*T=0 with ell*omega
invertible on the chart, or augmented maximal minors proving a rank jump.

A coefficient obstruction obtained after setting any allowed component of v
to zero is not a certificate for the unrestricted branch.

### Stage C: saturation certificate

Let I contain q4, all D6 and D5 coefficients, the normal-form relations, and
u*S*det(L)-1. The generic chart is empty exactly when 1 lies in I. The final
artifact must include a compact exact certificate and an independent
characteristic-zero verifier.

Finite-field computations may discover ranks, monomial orders, and
certificate support. They are not the final characteristic-zero proof.

### Stage D: exceptional factors

Every factor of S=0 is recomputed from its own polynomial system. It cannot
be obtained by substituting zero into a formula derived after division by
that factor. Intersections are separate whenever rank or stabilizer dimension
changes.

### Stage E: a surviving component

If the saturated D6/D5 ideal is not the unit ideal, compute a primary
component or rational univariate representation and continue through every
remaining determinant layer. Solving D6 and D5 alone produces only a
candidate jet.

## Acceptance checklist

- q4(d,tau) is explicit and hash-pinned.
- P,Q,R are explicit and independently reconstructed.
- All unrestricted coefficients of H3,H2,L are present.
- Every gauge removal has an explicit invertible action.
- The complete open-factor product S is explicit.
- Every factor of S=0 has a separate owner or saturation.
- D6 is solved without a hidden pivot division.
- D5 is tested modulo all cancellation variables.
- The characteristic-zero certificate is independently verified.
- Sample values are reconstruction tests, not a generic proof.

Until these items are supplied, Q4-F4 is an exact research target but not a
publicly reconstructible finite system.
