#!/usr/bin/env python3
"""Check the finite skeleton of the Lane 4 repairs and F4 contract.

This is a regression checker, not a proof of the geometric inputs and not an
elimination of Q4-F4.
"""

from __future__ import annotations

import itertools
import json
from pathlib import Path

import sympy as sp

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[1]
MANUSCRIPT = REPOSITORY / "manuscripts" / "02-low-degree" / "main.tex"
CONTRACT = ROOT / "F4_INPUT_CONTRACT.md"
SCHEMA = ROOT / "f4-contract.schema.json"


def leading_image_leaves() -> tuple[tuple[int, int, int], ...]:
    leaves = tuple(
        sorted(
            (e, k, g)
            for e in range(2, 5)
            for k in range(1, 5)
            for g in range(5)
            if g + e * k == 4
        )
    )
    expected = ((2, 1, 2), (2, 2, 0), (3, 1, 1), (4, 1, 0))
    assert leaves == expected
    return leaves


def relative_closure_regression() -> None:
    x, t = sp.symbols("x t")
    polynomial = sp.Poly(x**2 - t, x, domain=sp.QQ.frac_field(t))
    assert polynomial.is_irreducible

    text = MANUSCRIPT.read_text(encoding="utf-8")
    for marker in (
        "Singular homogeneous Jacobian forces a curve image",
        "The span-three entry to the curve tree",
        "does not by itself prove that a chosen parametrization",
        "[x^2:y^2:0]",
        "proof above avoids this shortcut",
    ):
        assert marker in text, marker


def composite_table() -> tuple[tuple[int, int, int, int], ...]:
    rows = tuple(
        sorted(
            (g, n, e, n // e)
            for g in range(4)
            for n in (4 - g,)
            for e in range(2, n + 1)
            if n % e == 0
        )
    )
    expected = (
        (0, 4, 2, 2),
        (0, 4, 4, 1),
        (1, 3, 3, 1),
        (2, 2, 2, 1),
    )
    assert rows == expected
    return rows


def valuation_skeleton() -> None:
    for length in range(1, 6):
        for values in itertools.product(range(4), repeat=length):
            if sum(values) == 3:
                assert any(value % 2 for value in values)

    for c in (1, 3):
        for multiplicity in range(1, 17):
            if (c * multiplicity) % 4 == 0:
                assert multiplicity % 4 == 0

    assert all((3 * multiplicity) % 4 for multiplicity in (1, 2, 3))

    text = MANUSCRIPT.read_text(encoding="utf-8")
    for marker in (
        "4\\nu_\\Gamma(R)=3\\mu",
        "fixed components can cancel poles",
        "nonnegativity of \\(c_\\xi\\) was used only",
    ):
        assert marker in text, marker


def contract_shape() -> int:
    schema = json.loads(SCHEMA.read_text(encoding="utf-8"))
    required = set(schema["required"])
    expected = {
        "schema_version",
        "branch_id",
        "status",
        "provenance",
        "coefficient_field",
        "symbols",
        "leading_data",
        "lower_layers",
        "chart",
        "determinant_contract",
        "sample_reconstructions",
    }
    assert required == expected
    assert schema["properties"]["status"]["const"] == "complete"
    assert schema["properties"]["branch_id"]["const"] == "Q4-F4"

    text = CONTRACT.read_text(encoding="utf-8")
    for marker in (
        "deliberately fail-closed",
        "does not manufacture an F4 checker",
        "solve D6 as a module",
        "test all D5 cancellations in the cokernel",
        "saturation certificate",
        "Finite-field computations",
    ):
        assert marker in text, marker
    return len(required)


def main() -> int:
    leaves = leading_image_leaves()
    relative_closure_regression()
    rows = composite_table()
    valuation_skeleton()
    keys = contract_shape()
    print("lane4 structural repair validation: PASS")
    print("leading_image_leaves=" + ";".join(map(str, leaves)))
    print("relative_closure_regression=PASS")
    print(f"composite_rows={len(rows)}")
    print("valuation_skeleton=PASS")
    print(f"f4_required_blocks={keys}")
    print("f4_status=awaiting exact complete instance")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
