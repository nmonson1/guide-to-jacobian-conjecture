#!/usr/bin/env python3
"""Verify the recovered Q4-F4 local-chart certificate and its fail-closed gate."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[1]
INSTANCE = ROOT / "q4-f4-local-chart-v1.json"
LOCAL_SCHEMA = ROOT / "q4-f4-local-chart.schema.json"
COMPLETE_SCHEMA = ROOT / "f4-contract.schema.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    instance = json.loads(INSTANCE.read_text(encoding="utf-8"))
    local_schema = json.loads(LOCAL_SCHEMA.read_text(encoding="utf-8"))
    complete_schema = json.loads(COMPLETE_SCHEMA.read_text(encoding="utf-8"))
    Draft202012Validator(local_schema).validate(instance)

    for source in instance["provenance"]["sources"]:
        path = REPOSITORY / source["path"]
        assert path.is_file(), path
        assert sha256(path) == source["sha256"], path

    archive_path = REPOSITORY / instance["provenance"]["sources"][-1]["path"]
    archive = json.loads(archive_path.read_text(encoding="utf-8"))
    assert archive["q4"] == instance["coefficient_field"]["q4"]
    for name in ("P", "Q", "R"):
        assert archive[name] == instance["leading_forms"][name]
    for name in ("A", "B"):
        assert archive[name] == instance["encoded_lower_data"][name]
    assert archive["normal"] == instance["encoded_lower_data"]["normal_solution"]
    assert archive["D6_remainders_mod_q4"] == ["0"] * 6
    assert archive["raw_resultant_gcd"] == (
        instance["determinant_layers"]["D5"]["resultant_raw_gcd"]
    )
    assert archive["primitive_resultant_gcd"] == "1"
    assert [sample["Xi(1,1)"] for sample in archive["tau3"]] == [
        sample["Xi_1_1"] for sample in instance["samples"]
    ]

    checker_path = REPOSITORY / instance["provenance"]["sources"][0]["path"]
    with tempfile.TemporaryDirectory(prefix="lane4-q4-f4-local-") as temporary:
        completed = subprocess.run(
            [
                sys.executable,
                "-u",
                str(checker_path),
                "--output-dir",
                temporary,
            ],
            cwd=checker_path.parent,
            check=True,
            capture_output=True,
            text=True,
        )
        fresh_path = Path(temporary) / "F4_weighted.json"
        assert fresh_path.read_bytes() == archive_path.read_bytes()
        print(completed.stdout.strip())

    complete_errors = list(Draft202012Validator(complete_schema).iter_errors(instance))
    assert complete_errors, "partial instance unexpectedly passed the complete F4 schema"
    assert not instance["full_contract_gate"]["accepted_by_complete_f4_schema"]
    print("PASS Q4-F4 local chart: source hashes and byte replay match")
    print("full_f4_contract=REJECTED_AS_INCOMPLETE")
    print("scope=encoded D6 solution and four pure-z2 D5 coefficients only")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
