# Recovered Q4-F4 local-chart certificate

The public degree-three v5 archive contains more exact F4 data than the
earlier intake summary preserved here: it reconstructs explicit `q4`,
`P,Q,R`, one normal solution `(u,v,C,D=d)`, six encoded `D6` coefficients,
and four pure-`z^2` `D5` coefficients.  All twelve surviving archive programs
replay deterministically with SymPy 1.14.0, and every fresh output is
byte-identical to its stored replay target.

`q4-f4-local-chart-v1.json` preserves that result without weakening the
complete `f4-contract.schema.json` gate.  Its local schema requires the
following negative facts:

- the archived solution is not a general `D6` module solution;
- the four `D5` coefficients do not include every possible lower-layer
  cancellation variable;
- the reported denominator list is not certified as the complete chart-open
  product;
- complement routes, gauges, and unrestricted `H3,H2,L` are absent; and
- there is no characteristic-zero saturation or unit-ideal certificate for
  the full system.

Within the encoded chart, the exact calculation proves that all six displayed
`D6` coefficients vanish modulo `q4`.  For the four displayed `D5`
coefficients, their resultants with `q4` have only the reported common
boundary factor, and the residual primitive gcd is one.  The two roots over
`tau=3` give nonzero values `Xi(1,1)=-5/54` and `5/54` as reconstruction
samples.

This is a local algebra certificate, not a global chart theorem.  In
particular it does not show that every allowed `D5` cancellation has been
tested, that all F4 complements are owned, that the degree-three chart family
is exhaustive, or that the rooted quartic case tree covers every normalized
quartic Keller map.

Replay from the repository root with:

```bash
uv run --with sympy==1.14.0 python \
  research-notes/lane4-f4-contract-20260803-v1/verify_q4_f4_local_chart.py

uv run --with sympy==1.14.0 python \
  research-notes/lane4-f4-contract-20260803-v1/verify_degree3_archive_replay.py
```
