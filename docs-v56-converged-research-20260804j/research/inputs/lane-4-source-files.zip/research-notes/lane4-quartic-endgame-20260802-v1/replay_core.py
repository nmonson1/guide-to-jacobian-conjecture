#!/usr/bin/env python3
"""Replay the compact exact certificate set for the Lane 4 repair packet.

The default suite reruns the two standalone chart checkers, the z^2 conic
checker, the compact conic terminal identities, and selected rational-cubic
calculations.  ``--full-conic`` additionally invokes each of the ten larger
conic branch scripts through its assertion-based wrapper.

This program verifies finite symbolic identities only.  It does not prove the
upstream geometric classifications or chart-exhaustiveness statements.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FRESH = ROOT / "fresh-outputs"


@dataclass(frozen=True)
class Check:
    name: str
    command: tuple[str, ...]
    cwd: Path
    needles: tuple[str, ...] = ()
    exact_output: Path | None = None
    timeout: int = 300


def run(check: Check) -> None:
    print(f"[{check.name}]", flush=True)
    proc = subprocess.run(
        check.command,
        cwd=check.cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=check.timeout,
        check=False,
    )
    output = proc.stdout
    FRESH.mkdir(exist_ok=True)
    fresh_path = FRESH / f"{check.name}.txt"
    fresh_path.write_text(output, encoding="utf-8")

    problems: list[str] = []
    if proc.returncode:
        problems.append(f"return code {proc.returncode}")
    for needle in check.needles:
        if needle not in output:
            problems.append(f"missing {needle!r}")
    if check.exact_output is not None:
        stored = check.exact_output.read_text(encoding="utf-8")
        if output != stored:
            problems.append(
                f"output differs from {check.exact_output.relative_to(ROOT)}"
            )
    if problems:
        print(output)
        raise RuntimeError(f"{check.name}: " + "; ".join(problems))
    print(f"PASS {check.name}")


def core_checks() -> dict[str, list[Check]]:
    py = sys.executable
    high = ROOT / "checks" / "high-ramification"
    tau = ROOT / "checks" / "tau-minus-one"
    conic = ROOT / "checks" / "conic"
    cubic = ROOT / "checks" / "rational-cubic" / "scripts"
    structural = [
        Check(
            "high-ramification",
            (py, "verify_r4_high_ramification.py"),
            high,
            exact_output=high / "verify_r4_high_ramification.out",
        ),
        Check(
            "tau-minus-one",
            (py, "verify_tau_minus_one.py"),
            tau,
            exact_output=tau / "verify_tau_minus_one.out",
        ),
    ]
    conic_checks = [
        Check(
            "conic-z2",
            (py, "z2_conic_independent_check.py"),
            conic,
            exact_output=conic / "stored-outputs" / "replay_z2_conic.txt",
        ),
        Check(
            "conic-terminal-identities",
            (py, "verify_terminal_identities.py"),
            conic,
            needles=("PASS: all quoted terminal factor identities hold over Q.",),
        ),
    ]
    rational_cubic = [
        Check(
            "rational-cubic-transverse-cusp",
            (py, "transverse_after_translation.py", "cusp"),
            cubic,
            needles=("rank 8 nullity 1", "detL reduced 0"),
        ),
        Check(
            "rational-cubic-transverse-node",
            (py, "transverse_after_translation.py", "node"),
            cubic,
            needles=("rank 9 nullity 0", "detL reduced 0"),
        ),
        Check(
            "rational-cubic-node-pivot",
            (py, "node_h2z_pivotminor.py"),
            cubic,
            needles=("det 12582912",),
        ),
        Check(
            "rational-cubic-node-marked-family",
            (py, "node_marked_lambda_d7.py"),
            cubic,
            needles=("leftnull 6", "PURE 0", "PURE 3", "PURE 5"),
        ),
        Check(
            "rational-cubic-cusp-fiber-q",
            (py, "cusp_fiber_q_branch.py"),
            cubic,
            needles=("(1, 3, 1) -6", "solutions 0"),
        ),
        Check(
            "rational-cubic-cusp-smooth-q",
            (py, "cusp_smooth_q_branch.py"),
            cubic,
            needles=("(0, 4, 1) -6",),
        ),
        Check(
            "rational-cubic-cusp-generic-q",
            (py, "cusp_generic_q_d5.py"),
            cubic,
            needles=("(1, 3, 1) -6", "(0, 4, 1) 6"),
        ),
    ]
    return {
        "structural": structural,
        "conic": conic_checks,
        "rational-cubic": rational_cubic,
    }


def full_conic_checks() -> list[Check]:
    py = sys.executable
    conic = ROOT / "checks" / "conic"
    names = (
        "x2-scalar",
        "x2-semisimple",
        "x2-nilpotent-1",
        "x2-nilpotent-2",
        "x2-second-normal-p",
        "x2-second-normal-q",
        "xy-scalar",
        "xy-anti-scalar",
        "xy-second-normal-axis",
        "xy-second-normal-open",
    )
    return [
        Check(
            f"conic-{name}",
            (py, "run_replays.py", name),
            conic,
            needles=(f"PASS {name}",),
            timeout=420,
        )
        for name in names
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--group",
        choices=("all", "structural", "conic", "rational-cubic"),
        default="all",
        help="run one compact group or the complete compact suite",
    )
    parser.add_argument(
        "--full-conic",
        action="store_true",
        help="also run the ten larger conic branch scripts",
    )
    args = parser.parse_args()

    groups = core_checks()
    if args.group == "all":
        checks = [check for name in ("structural", "conic", "rational-cubic") for check in groups[name]]
    else:
        checks = list(groups[args.group])
    if args.full_conic:
        if args.group not in ("all", "conic"):
            parser.error("--full-conic requires --group all or --group conic")
        checks.extend(full_conic_checks())
    for check in checks:
        run(check)
    print(f"PASS: {len(checks)} Lane 4 exact replay groups completed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
