# Lane 4 proof-to-code crosswalk

The table distinguishes conventional mathematics from finite symbolic
certificates.  A script locator means only that the displayed algebra was
checked on the stated chart.

| Proof component | Statement or equation range | Exact program(s) | What the program certifies | What remains conventional or imported |
| --- | --- | --- | --- | --- |
| Leading-image factorization | first replacement proof in `proofs/10-structural-repairs-and-z2.tex` | none | not applicable | rationality of a unirational curve, normalization, coprime-pencil representation |
| Four-locus reduction | second replacement proof in `proofs/10-structural-repairs-and-z2.tex` | none | not applicable | weighted one-variable field input and divisorial valuation argument |
| `R=0` branch | Proposition `quartic-r-zero-repair` | none | not applicable | quadratic-coordinate lemma, plane degree theorem, birational Keller implication |
| Homogeneous cubic centralizer | Lemma `homogeneous-cubic-centralizer` | none | not applicable | two-variable common-generator/closed-polynomial theorem and descent |
| `G=z^2` conic | Proposition `conic-z2-exclusion` | `checks/conic/z2_conic_independent_check.py` | full determinant arc on the two normal-form branches with arbitrary quadratic and linear coefficients | completeness of the normal-form reductions and allowed source/target actions |
| `G=x^2` conic | Theorem `quartic-conic-x2` | `checks/conic/raw-scripts/x2_*.py`, invoked by `checks/conic/run_replays.py` | scalar, semisimple, two nilpotent, and two second-normal terminal systems; fresh output equals stored output | the stabilizer-orbit split and its ownership |
| `G=xy` conic | Theorem `quartic-conic-xy` | `checks/conic/raw-scripts/xy_*.py`, invoked by `checks/conic/run_replays.py` | scalar, anti-scalar, and two second-normal terminal systems; fresh output equals stored output | the stabilizer-orbit split and its ownership |
| Conic terminal identities | square/determinant factorizations in both conic proofs | `checks/conic/verify_terminal_identities.py` | exact polynomial identities over `Q` | does not reconstruct the full determinant elimination |
| Rational cubic, transverse factor | first case of `proofs/30-rational-cubic.tex` | `checks/rational-cubic/scripts/transverse_after_translation.py` | cusp rank eight/nullity one and node rank nine/nullity zero; `det L=0` after translation | classification of proper rational plane cubics and normalization of the transverse factor |
| Rational cubic, marked node | parameterized nodal family | `node_marked_lambda_d7.py`, `node_h2z_pivotminor.py`, `node_h2z_fullmatrix.py` | three pure compatibility equations and a parameter-independent maximal minor `12582912` | projective marked-point coverage, including the branch interchange at infinity |
| Rational cubic, marked cusp | three cusp marked-point orbits | `cusp_fiber_*.py`, `cusp_smooth_*.py`, `cusp_generic_*.py` | fixed nonzero `D_6/D_5` coefficients on every displayed normal-amplitude branch | stabilizer-orbit classification and branch normalization |
| Conditional span-three synthesis | `proofs/40-span-three-corollary.tex` | none | not applicable | public rank-one and rational-quartic frontier inputs plus review of the new conic/cubic arguments |
| Primitive binary `r=4` | equations `(H.3)`--`(H.24)` | `checks/high-ramification/verify_r4_high_ramification.py` | reduced quadratic normalization, repeated-root parametrization, generic and `3+1` kernels, internal `2+2`, endpoint, and second-normal obstructions | upstream primitive binary/Hilbert--Burch placement and final plane theorem |
| Primitive binary `r=5` | first branch of `proofs/50-high-ramification.tex` | supporting identities in the same checker | displayed aligned cube/fourth-power identities | cubic-coordinate lemma and plane theorem |
| Primitive `r=3`, `tau=-1` | `proofs/60-tau-minus-one.tex` | `checks/tau-minus-one/verify_tau_minus_one.py` | reconstruction of `P,Q,R`, resultant factors, projective first-normal strata, saturation certificates, and two unrestricted next-layer obstructions | upstream chart placement and zero-normal plane reduction |
| Global case tree | `case-tree/lane4-global-case-tree.md` | `case-tree/lane4-case-tree.csv` | machine-readable ownership inventory only | every cited theorem hypothesis and proof-code attachment still needs specialist audit |

## Excluded from this crosswalk

The public v5 degree-three family contains generic, resonant, `c=0`,
dependent-syzygy, quadratic-exceptional, and zero-normal programs.  Those
programs are not copied or independently derived in this packet.  Only the
new `tau=-1` checker above is claimed as an independent retained derivation
within the `r=3` family.
