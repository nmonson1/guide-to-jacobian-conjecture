# Lane 4 quartic case tree — candidate repaired routing

## Status and scope

This document is an ownership map for the ordinary-degree-four branch in
three variables.  It combines public Program 2 inputs with the candidate
proof repairs and exact calculations in this packet.  It is intended for
specialist review; it is not a generated claim-graph update and does not
promote the global conclusion

\[
D_{\min}\ge 5.
\]

The unconditional public interval remains

\[
4\le D_{\min}\le 7.
\]

Status terms used below have the following meanings.

| Status | Meaning |
| --- | --- |
| public input | A theorem or certificate already present in the public Program 2 source; this packet does not re-prove it. |
| candidate proof | A complete prose argument supplied here, but not yet independently refereed. |
| exact replay | A finite symbolic calculation rerun over exact characteristic-zero arithmetic. |
| conditional | The implication uses an upstream chart-placement, classification, or plane theorem stated separately. |
| not independently reproduced here | The public v5 packet reports a successful replay, but this packet does not supply a new derivation of that chart. |

## Ownership convention

The structural loci overlap.  To turn the cover into a case tree, assign a
map to the first applicable branch in the following order:

1. the zero cubic normal layer `R=0`;
2. the binary branch `P,Q,R in k[x,y]`;
3. the genuinely nonbinary quadratic-source branch;
4. the primitive coprime fourth-power branch;
5. the genuinely nonbinary fixed-component branch.

Inside the binary branch, assign a nonconstant fixed factor before the
fourth-power and ramification branches.  In the coprime branch, remove zero
minors before defining the common ramification degree.  This is an ownership
rule only; it does not claim that the underlying geometric loci are disjoint.

## Structural tree

```text
quartic Keller map F = LX + H2 + H3 + H4
|
+-- rho4 = 1
|   `-- rank-one theorem -> automorphism                         [public input]
|
+-- rho4 = 3
|   |
|   +-- leading image a conic
|   |   +-- four historical invariant-field orbits              [public input]
|   |   `-- G = x^2, xy, z^2                                   [candidate proofs + exact checks]
|   |
|   +-- leading image a proper rational cubic
|   |   `-- cusp/node; transverse and all marked factors        [candidate proof + exact checks]
|   |
|   `-- leading image a proper rational quartic
|       `-- balanced and tricuspidal/frontier types              [public input; preclassification required]
|
`-- rho4 = 2
    |
    +-- normalize H4=(P,Q,0), P,Q independent quartics;
    |   put R=(H3)_3
    |
    +-- R=0
    |   `-- quadratic coordinate + plane reduction              [candidate proof; plane theorem]
    |
    `-- R != 0 and Jac(P,Q,R)=0
        |
        +-- P,Q,R binary in two source forms
        |   |
        |   +-- G=gcd(P,Q) nonconstant
        |   |   +-- deg G=3: squarefree / 2+1 / triple line      [public exact packet]
        |   |   +-- deg G=2: divisor and endpoint tree           [public 38-group packet]
        |   |   `-- deg G=1: residual-cubic orbit tree           [public exact packet]
        |   |
        |   `-- gcd(P,Q)=1
        |       |
        |       +-- U,V,or W zero                                [public edge theorem; R=0 repaired here]
        |       |
        |       +-- pencil contains a fourth power               [public routing proposition]
        |       |
        |       `-- U,V,W nonzero; r=deg gcd(U,V,W)
        |           +-- r=0                                     [public regular theorem]
        |           +-- r=1                                     [public simple-ramification theorem]
        |           +-- r=2                                     [public double-ramification theorem]
        |           +-- r=3
        |           |   +-- dependent (2,5) syzygy               [public v5; not independently reproduced here]
        |           |   `-- independent (3,4) syzygy
        |           |       +-- primitive tau=-1 divisor         [candidate proof + exact replay here]
        |           |       `-- all other generic/exceptional
        |           |           v5 charts                         [public v5; not independently reproduced here]
        |           +-- r=4
        |           |   +-- dependent residual syzygies          [candidate algebraic proof]
        |           |   +-- independent, residual square         [candidate gcd contradiction]
        |           |   `-- independent, reduced residual
        |           |       +-- squarefree Gamma                  [candidate kernel argument]
        |           |       +-- repeated root away from endpoints
        |           |       |   +-- nonprimitive component       [gcd exit]
        |           |       |   +-- generic / 3+1                [candidate proof + exact replay]
        |           |       |   `-- internal 2+2                 [candidate proof + exact replay]
        |           |       `-- repeated endpoint                [candidate proof + exact replay]
        |           `-- r=5                                     [candidate aligned cube/fourth-power proof]
        |
        +-- genuinely nonbinary composite intermediate field
        |   `-- only n=4=(e,d)=(2,2)
        |       +-- binary degeneration                          [binary owner]
        |       +-- fixed-component degeneration                 [fixed owner]
        |       `-- no-fixed genuinely nonbinary locus           [public nine-chart packet]
        |
        +-- composition-primitive, gcd(P,Q)=1, nonbinary
        |   `-- valuation forces a fourth-power member           [candidate repaired routing]
        |       `-- binary / quadratic-source / aligned exit
        |
        `-- composition-primitive, gcd(P,Q)=G nonconstant, nonbinary
            +-- deg G=2                                         [public corrected valuation]
            `-- deg G=1
                `-- aligned / binary / residual-pole branch
                    `-- homogeneous cubic centralizer endpoint   [candidate repair]
```

## Why the span-two structural cover has four owners

Write

\[
P=GA,\qquad Q=GB,\qquad \gcd(A,B)=1,
\]

and put `n=deg A=deg B`.  The weighted one-variable field input gives an
intermediate rational parameter with

\[
n=ed.
\]

After the binary branch is removed, the composite possibilities are

\[
\begin{array}{c|c|c}
\deg G&n&(e,d)\\ \hline
0&4&(4,1),(2,2)\\
1&3&(3,1)\\
2&2&(2,1).
\end{array}
\]

The repaired valuation argument sends every `d=1` case to the binary owner;
the only genuinely nonbinary composite case is `(e,d)=(2,2)`.  For a
primitive coprime reduced pencil, the valuation sum produces a fourth-power
fiber.  For a primitive pencil with `G != 1`, the generic-divisor valuation
puts every component of `G` on a special fiber.  These are exactly the four
structural owners listed above.

## Leaf-to-evidence table

| ID | Leaf | Mathematical owner | Packet evidence | Remaining boundary |
| --- | --- | --- | --- | --- |
| S1 | `rho4=1` | public rank-one theorem | locator only | hypotheses of public theorem |
| S2 | seven conic orbits | four public orbits plus three packet propositions | exact `z^2` checker; exact branch scripts and terminal identities for `x^2,xy` | specialist review; second CAS desirable |
| S3 | proper rational cubic | packet cusp/node argument | exact transverse, marked-node, marked-cusp and pivot-minor scripts | specialist review; plane theorem |
| S4 | proper rational quartic | public frontier theorems | locator only | upstream quartic-image preclassification |
| B0 | `R=0` | packet quadratic-coordinate argument | prose proof | exact per-coordinate plane-theorem citation |
| B1 | nonbinary `(2,2)` | public nine-chart theorem | locator only | proof-to-code crosswalk |
| B2 | binary fixed factors | public fixed-factor packets | locator only | proof-to-code crosswalk; second lineage |
| B3 | coprime binary `r<=2` | public ramification filtration | locator only | source hypotheses as stated |
| B4a | primitive `r=3`, `tau=-1` | packet theorem | exact standalone checker and stored output | upstream chart placement; specialist review |
| B4b | remaining `r=3` charts | public v5 family | no new independent packet here | generic and exceptional proof-code crosswalk; independent reproduction |
| B5 | primitive binary `r=4` | packet projective theorem | exact repeated-root, `3+1`, `2+2`, endpoint and second-normal checker | upstream Hilbert--Burch placement; specialist review; second CAS |
| B6 | primitive binary `r=5` | packet algebraic argument | exact supporting identities in the high-ramification checker | plane theorem; specialist review |
| B7 | fourth-power member | public edge proposition | locator only | overlap ownership |
| B8 | nonbinary fixed components | public valuation plus packet centralizer repair | prose lemma | verify preceding coefficient derivation; specialist review |
| B9 | zero minor | public edge proposition plus packet `R=0` proof | prose proof | plane theorem citation |

## Material not promoted by this packet

Earlier exploratory session notes reported additional work on a generic
`r=3` kernel-plane calculation and on a `tau=0` specialization.  No complete,
self-contained source-and-output artifact for those reports was retained in
the present packet.  They are therefore **not evidence in this submission**
and do not change row B4b.

## Remaining publication gates

Even if every candidate argument in this packet survives review, a public
global theorem still requires:

1. a line-by-line audit that every edge in this ownership tree matches the
   hypotheses of its cited source statement;
2. a proof-to-code crosswalk for the public quadratic-source, fixed-factor,
   and remaining degree-three charts;
3. independent reproduction of the remaining `r=3` generic and exceptional
   systems, preferably in a second computer-algebra system;
4. verification and exact citation of the Appelgate--Onishi/Nowicki--Nakai
   plane theorem in every function-field use; and
5. specialist review of the new structural, conic, rational-cubic,
   high-ramification, and `tau=-1` arguments.

Until those gates close, this is a candidate repaired synthesis rather than
an unconditional proof of `D_min >= 5`.
