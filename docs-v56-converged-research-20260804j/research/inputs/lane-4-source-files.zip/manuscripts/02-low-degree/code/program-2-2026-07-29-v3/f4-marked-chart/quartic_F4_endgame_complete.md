# The exceptional triple-ramification F4 endgame in a regular Hilbert--Burch chart

## Status

This note gives a candidate closure of the weighted-inflection `F4` endgame in the primitive binary triple-ramification branch.  It is conditional on the upstream leading-curve and Hilbert--Burch reductions placing the map in the `(3,4)` chart described below.  The calculation is exact, but it has not received independent specialist review.

The public handoff formulates the remaining calculation using a chart-dependent algebraic extension

\[
\mathbf Q(\tau)[d]/(q_4(d,\tau))
\]

and asks for the solution of `D_6=0` followed by a uniform `D_5` obstruction.  The polynomial `q_4(d,\tau)` and the full displayed `D_6,D_5` formulas are not present in the reviewed public artifacts.  The argument below avoids reconstructing that eliminant: it marks the double ramification root and works in regular Hilbert--Burch coordinates.  In those coordinates the highest-\(z\) part of `D_6` is a two-variable divisibility problem, while the coefficient of \(z^2\) in `D_5` is rigid under all lower binary corrections.

The calculation reproduces the recorded anchor

\[
[y^3z^2]D_5=-\frac13
\]

after interchanging \(x\) and \(y\).  It does not yet reproduce the two recorded `D_6` coefficients \(104/3\), because those belong to the unrecovered rational chart rather than the regular marked-root chart used here.

---

## 1. Determinant arc and the rigid coefficient

After rescaling the third target coordinate, write the quartic determinant arc as

\[
\widetilde K_\epsilon
 =\Phi+\epsilon\Psi+\epsilon^2\Xi+\epsilon^3\Lambda,
\]

where

\[
\Phi=(P,Q,R),
\]

with \(P,Q\in k[x,y]_4\) and \(R\in k[x,y]_3\).  Write the normal parts of \(\Psi\) as

\[
A=z\alpha+A_0(x,y),\qquad
B=z\beta+B_0(x,y),\qquad
E=z\eta+E_0(x,y).
\]

The first determinant equation is

\[
J(Q,R)\alpha-J(P,R)\beta+J(P,Q)\eta=0. \tag{1.1}
\]

At the next layer, write

\[
C=\frac{c_0}{2}z^2+zC_1+C_0,
\qquad
D=\frac{d_0}{2}z^2+zD_1+D_0.
\]

Only \(c_0,d_0\) enter the coefficient of \(z\) in `D_6`.  More importantly, the coefficient of \(z^2\) in `D_5` is independent of

* all binary integration constants \(A_0,B_0,E_0,C_0,D_0\);
* the linear forms \(C_1,D_1\);
* the third component of \(\Xi\);
* all linear terms \(\Lambda\).

Indeed, a \(z^2\) term in a three-row Jacobian determinant must use the two \(x,y\)-derivatives of the normal terms and one \(z\)-derivative.  Binary integration constants lower the \(z\)-degree, and the third component of \(\Xi\) is only linear.

For later use, the rigid coefficient is

\[
\begin{aligned}
\Omega_5={}&
 \eta J(\alpha,\beta)
 -\beta J(\alpha,\eta)
 +\alpha J(\beta,\eta)\\
&+c_0\bigl(J(\beta,R)+J(Q,\eta)\bigr)
-d_0\bigl(J(\alpha,R)+J(P,\eta)\bigr).
\end{aligned} \tag{1.2}
\]

Consequently, if \(\Omega_5\ne0\), no choice of lower binary terms can complete the determinant arc.

---

## 2. A regular `(3,4)` Hilbert--Burch chart

Choose the marked one-form

\[
\omega=x\,dy.
\]

Let

\[
R=ax^3+bx^2y+cxy^2+\rho y^3, \tag{2.1}
\]

and define

\[
u=ax^2+bxy+cy^2,\tag{2.2}
\]

\[
v=-\frac b3x^2-cxy-3\rho y^2,\tag{2.3}
\]

\[
P=\frac{3a}{4}x^4+\frac{2b}{3}x^3y+\frac c2x^2y^2,\tag{2.4}
\]

\[
Q_0=ax^3y+bx^2y^2+cxy^3+\frac{3\rho}{4}y^4.\tag{2.5}
\]

Then

\[
dP=x\,dR+v\omega,
\qquad
dQ_0=y\,dR+u\omega. \tag{2.6}
\]

Set

\[
H=-xR_x,
\qquad
w=vy-xu.
\]

Taking exterior products in (2.6) gives the exact factorization

\[
J(Q_0,R)=Hu,
\qquad
J(P,R)=Hv,
\qquad
J(P,Q_0)=Hw. \tag{2.7}
\]

The residual Hilbert--Burch syzygies are

\[
s_3=(x,y,1),
\qquad
s_4=(v,u,0). \tag{2.8}
\]

Hence every normal of degree pattern \((2,2,1)\) satisfying (1.1) is

\[
(\alpha,\beta,\eta)
 =\ell(x,y,1)+\kappa(v,u,0), \tag{2.9}
\]

where

\[
\ell=px+qy
\]

is linear and \(\kappa\in k\).

Define the quadratic form

\[
\begin{aligned}
M={}&\left(\frac{b^2}{3}-ac\right)x^2
 +\left(\frac{2bc}{3}-6a\rho\right)xy
 +(c^2-3b\rho)y^2.
\end{aligned} \tag{2.10}
\]

A direct calculation gives

\[
v\,du-u\,dv=M(y\,dx-x\,dy). \tag{2.11}
\]

Substituting (2.9) into the pure-normal part of `D_6` reduces its coefficient of \(z\) to

\[
S_6=xu\ell^2-2\kappa xyM\ell+3\kappa^2MR. \tag{2.12}
\]

The complete coefficient of \(z\) in `D_6` is therefore

\[
S_6+H(c_0u-d_0v)=0. \tag{2.13}
\]

This is the regular-chart replacement for the rational `q_4,D_6` compatibility calculation.

---

## 3. Weighted inflection

The weighted-inflection condition is that the quadratic \(R_x\) be a square:

\[
R_x=3ax^2+2bxy+cy^2=L^2. \tag{3.1}
\]

Equivalently,

\[
b^2=3ac. \tag{3.2}
\]

There are three geometric cases.

1. The double root of \(R_x\) is distinct from the marked root and from the projective endpoint.  This is the generic chart.
2. The double root collides with one endpoint.  This is the reduced chart.
3. The square is supported on the transverse endpoint.  Then \(a=b=0\), and both leading quartics have the fixed quadratic factor \(y^2\).  This is the already-separated quadratic fixed-factor branch.

If \(R_x=0\), the leading data degenerate to a lower-span or fixed-component leaf.

Thus only the first two cases are intrinsic to the primitive `F4` endgame.

---

## 4. Generic marked weighted-inflection chart

Normalize

\[
a=\frac13,
\qquad b=c=1,
\qquad \rho=\tau.
\]

Then

\[
R=\frac13x^3+x^2y+xy^2+\tau y^3, \tag{4.1}
\]

\[
L=x+y,
\qquad R_x=L^2, \tag{4.2}
\]

\[
u=\frac13x^2+xy+y^2, \tag{4.3}
\]

\[
v=-\frac13x^2-xy-3\tau y^2, \tag{4.4}
\]

\[
H=-xL^2, \tag{4.5}
\]

and

\[
M=\frac{1-3\tau}{3}\,y(2x+3y). \tag{4.6}
\]

The constant target shear

\[
Q=Q_0-\frac12P
\]

gives

\[
Q=-\frac18x^4+\frac34x^2y^2+xy^3+\frac{3\tau}{4}y^4. \tag{4.7}
\]

This is exactly the displayed weighted-quartic shape

\[
q_0x^4+q_2x^2y^2+q_3xy^3+q_4y^4
\]

with \(q_3\ne0\).

### 4.1 Classification of the `D_6` highest-normal part

The coefficient of \(y^5\) in (2.12) is

\[
[y^5]S_6=3\kappa^2\tau(1-3\tau). \tag{4.8}
\]

On the primitive generic open set

\[
\tau\ne0,
\qquad
\tau\ne\frac13,
\]

we must have

\[
\kappa=0. \tag{4.9}
\]

Equation (2.13) becomes

\[
u(\ell^2-c_0L^2)+d_0L^2v=0. \tag{4.10}
\]

Now

\[
u+v=(1-3\tau)y^2,
\]

so \(\gcd(u,v)=1\) for \(\tau\ne1/3\), and

\[
u(-y,y)=\frac13y^2,
\]

so \(L\nmid u\).  Hence

\[
\gcd(u,L^2v)=1. \tag{4.11}
\]

Reducing (4.10) modulo \(u\) forces

\[
d_0=0. \tag{4.12}
\]

It follows that

\[
\ell^2=c_0L^2. \tag{4.13}
\]

Every nonzero normal is therefore, for some \(\lambda\ne0\),

\[
\ell=\lambda L,
\qquad
c_0=\lambda^2,
\qquad
d_0=0. \tag{4.14}
\]

This classifies the highest-\(z\) part of every possible full `D_6` solution.  The remaining, lower-\(z\) equations may or may not be solvable; that distinction is irrelevant because the next rigid coefficient never vanishes.

### 4.2 The `D_5` obstruction

For \(\kappa=0\),

\[
\alpha=\lambda xL,
\qquad
\beta=\lambda yL,
\qquad
\eta=\lambda L.
\]

Substitution into (1.2) gives

\[
\boxed{
\Omega_5=-\lambda^3xu
=-\frac{\lambda^3}{3}x(x^2+3xy+3y^2).
} \tag{4.15}
\]

This is nonzero for every \(\lambda\ne0\).  Since it is the coefficient of \(z^2\), no lower binary term can cancel it.

With \(\lambda=1\), the coefficient of \(x^3z^2\) is

\[
-\frac13.
\]

After interchanging \(x\) and \(y\), this reproduces the recorded consistency anchor

\[
[y^3z^2]D_5=-\frac13. \tag{4.16}
\]

### 4.3 Boundary values of \(\tau\)

If \(\tau=0\), then

\[
R=xu,
\qquad Q_0=yR,
\]

and \(P,Q_0\) have a common linear factor \(x\).  This is the fixed-linear-factor branch.

If \(\tau=1/3\), then

\[
R=\frac13(x+y)^3,
\qquad v=-u.
\]

The residual pair is dependent and all three planar minors acquire the extra factor \(u\); this routes to the high-ramification/aligned-fourth-power branch rather than the primitive triple-ramification chart.

Thus no exceptional value of \(\tau\) remains inside the primitive generic `F4` branch.

---

## 5. Reduced weighted-inflection chart

When the double root reaches the marked endpoint, normalize

\[
a=\frac13,
\qquad b=c=0,
\qquad \rho=\tau\ne0.
\]

Then

\[
R=\frac13x^3+\tau y^3, \tag{5.1}
\]

\[
P=\frac14x^4, \tag{5.2}
\]

\[
Q_0=\frac13x^3y+\frac{3\tau}{4}y^4, \tag{5.3}
\]

\[
u=\frac13x^2,
\qquad v=-3\tau y^2,
\qquad H=-x^3,
\qquad M=-2\tau xy. \tag{5.4}
\]

The coefficient of \(xy^4\) in (2.12) is

\[
[xy^4]S_6=-6\kappa^2\tau^2. \tag{5.5}
\]

Thus

\[
\kappa=0. \tag{5.6}
\]

Equation (2.13), after division by \(x^3\), reads

\[
\frac13\ell^2-rac{c_0}{3}x^2-3\tau d_0y^2=0. \tag{5.7}
\]

The mixed coefficient forces \(pq=0\).  Projectively there are exactly two nonzero branches.

### 5.1 Branch \(\ell=x\)

Here

\[
c_0=1,
\qquad d_0=0.
\]

Formula (1.2) gives

\[
\boxed{\Omega_5=-\frac13x^3.} \tag{5.8}
\]

### 5.2 Branch \(\ell=y\)

Here

\[
c_0=0,
\qquad d_0=\frac{1}{9\tau}.
\]

Formula (1.2) gives

\[
\boxed{\Omega_5=\frac23y^3.} \tag{5.9}
\]

Both branches are obstructed.

At \(\tau=0\), the leading pair has the common cubic factor \(x^3\), so this endpoint belongs to the fixed-component boundary.

---

## 6. Conclusion

Within the regular marked `(3,4)` Hilbert--Burch chart, every primitive weighted-inflection normal satisfying the highest-\(z\) part of `D_6` has a nonzero, rigid coefficient of \(z^2\) in `D_5`.

More precisely:

\[
\boxed{
\begin{array}{ll}
\text{generic chart:}&
\Omega_5=-\lambda^3xu\ne0,\\[1mm]
\text{reduced }\ell=x\text{ chart:}&
\Omega_5=-\frac13x^3\ne0,\\[1mm]
\text{reduced }\ell=y\text{ chart:}&
\Omega_5=\frac23y^3\ne0.
\end{array}}
\]

All parameter values at which the `D_6` classification changes route to an already separated fixed-component or high-ramification branch.

Therefore the regular-chart calculation gives a candidate closure of the exceptional `F4` endgame:

> **Candidate F4 exclusion.**  Subject to the upstream triple-ramification Hilbert--Burch classification and the stated boundary routing, no primitive quartic Keller map exists on the weighted-inflection `F4` locus.

The chart-dependent quartic extension \(q_4(d,\tau)\) is not needed for the exclusion: marking the double ramification root replaces it by the linear syzygy coordinate \(\ell\), and `D_6` forces \(\ell\) to be the square root \(L\) itself.  The surviving `D_5` coefficient is then visibly nonzero.

---

## 7. Remaining audit items

Before this should be promoted from a candidate result to a theorem in the guide, four checks remain.

1. Verify line by line that the continuation appendix's exceptional `F4` divisor is birationally identical to the marked chart (2.1)--(2.9), including the reduced endpoint.
2. Translate between the unrecovered \((d,\tau)\) coordinates and the marked double-root coordinate.  This is expected to explain the eliminant \(q_4(d,\tau)\) as a chart artifact.
3. Reproduce the recorded `D_6` coefficients \(104/3\) after translating normalizations.  The `D_5` anchor \(-1/3\) is already reproduced exactly.
4. Replay the calculation independently in a second computer-algebra system and audit the upstream case tree.

None of these items changes the internal algebra of the regular-chart obstruction; they concern identification and exhaustiveness relative to the public continuation chart.
