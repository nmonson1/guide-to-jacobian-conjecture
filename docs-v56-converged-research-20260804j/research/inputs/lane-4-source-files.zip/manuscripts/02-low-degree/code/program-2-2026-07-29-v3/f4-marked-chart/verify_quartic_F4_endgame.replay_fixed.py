#!/usr/bin/env python3
"""Exact verifier for the weighted-inflection F4 endgame.

The calculation is performed in a regular Hilbert--Burch chart.  It proves
that the z^2 coefficient of D5 is nonzero after all D6-compatible normals,
for both the generic q3 != 0 chart and the reduced q3 = 0 chart.
"""
from __future__ import annotations
import sympy as sp
x,y,z,t,p,q,k,c0,d0=sp.symbols('x y z t p q k c0 d0')

def J(f,g): return sp.expand(sp.diff(f,x)*sp.diff(g,y)-sp.diff(f,y)*sp.diff(g,x))
def detJ(f1,f2,f3):
    return sp.expand(sp.Matrix([[sp.diff(f1,v) for v in (x,y,z)],
                                [sp.diff(f2,v) for v in (x,y,z)],
                                [sp.diff(f3,v) for v in (x,y,z)]]).det())
def hpart(f,n):
    P=sp.Poly(sp.expand(f),x,y,z); out=0
    for mon,coef in P.terms():
        if sum(mon)==n: out += coef*x**mon[0]*y**mon[1]*z**mon[2]
    return sp.expand(out)
def zcoef(f,j): return sp.Poly(sp.expand(f),z).coeff_monomial(z**j)

# --------------------------------------------------------------------------
# 1. Canonical (3,4) Hilbert--Burch gradient factorization.
# --------------------------------------------------------------------------
a,b,c,rho=sp.symbols('a b c rho')
u=a*x**2+b*x*y+c*y**2
v=-sp.Rational(1,3)*b*x**2-c*x*y-3*rho*y**2
R=a*x**3+b*x**2*y+c*x*y**2+rho*y**3
P=sp.Rational(3,4)*a*x**4+sp.Rational(2,3)*b*x**3*y+sp.Rational(1,2)*c*x**2*y**2
Q0=a*x**3*y+b*x**2*y**2+c*x*y**3+sp.Rational(3,4)*rho*y**4
w=sp.expand(v*y-u*x)
H=sp.expand(-x*sp.diff(R,x))
assert sp.expand(J(Q0,R)-H*u)==0
assert sp.expand(J(P,R)-H*v)==0
assert sp.expand(J(P,Q0)-H*w)==0
# Gradient factorization with omega=x dy.
assert sp.expand(sp.diff(P,x)-x*sp.diff(R,x))==0
assert sp.expand(sp.diff(P,y)-x*sp.diff(R,y)-x*v)==0
assert sp.expand(sp.diff(Q0,x)-y*sp.diff(R,x))==0
assert sp.expand(sp.diff(Q0,y)-y*sp.diff(R,y)-x*u)==0

# Hessian-like quadratic M from v du-u dv.
M=(sp.Rational(1,3)*b**2-a*c)*x**2+(sp.Rational(2,3)*b*c-6*a*rho)*x*y+(c**2-3*b*rho)*y**2
eta_x=sp.expand(v*sp.diff(u,x)-u*sp.diff(v,x))
eta_y=sp.expand(v*sp.diff(u,y)-u*sp.diff(v,y))
assert sp.expand(eta_x-y*M)==0
assert sp.expand(eta_y+x*M)==0

# General binary D7 normal ell*s3+k*s4.
ell=p*x+q*y
Az=sp.expand(x*ell+k*v)
Bz=sp.expand(y*ell+k*u)
Ez=ell
assert sp.expand(u*Az-v*Bz+w*Ez)==0
A3=z*Az; B3=z*Bz; E2=z*Ez
D6self=zcoef(detJ(A3,B3,R)+detJ(P,B3,E2)+detJ(A3,Q0,E2),1)
D6compact=sp.expand(x*u*ell**2-2*k*x*y*M*ell+3*k**2*M*R)
assert sp.expand(D6self-D6compact)==0

# General z^2 coefficient of D5 after Czz=c0 and Dzz=d0.
C2=sp.Rational(1,2)*c0*z**2
D2=sp.Rational(1,2)*d0*z**2
D5=hpart(detJ(A3,B3,E2)+detJ(A3,D2,R)+detJ(C2,B3,R)
         +detJ(P,D2,E2)+detJ(C2,Q0,E2),5)
O5=zcoef(D5,2)
O5formula=(Ez*J(Az,Bz)-Bz*J(Az,Ez)+Az*J(Bz,Ez)
           +c0*(J(Bz,R)+J(Q0,Ez))-d0*(J(Az,R)+J(P,Ez)))
assert sp.expand(O5-O5formula)==0

# --------------------------------------------------------------------------
# 2. Generic weighted-inflection chart q3 != 0.
# Normalize b=c=1, a=1/3; then R_x=(x+y)^2.
# --------------------------------------------------------------------------
subs_generic={a:sp.Rational(1,3),b:1,c:1,rho:t}
ug=sp.expand(u.subs(subs_generic)); vg=sp.expand(v.subs(subs_generic))
Rg=sp.expand(R.subs(subs_generic)); Pg=sp.expand(P.subs(subs_generic)); Qg0=sp.expand(Q0.subs(subs_generic))
Hg=sp.expand(H.subs(subs_generic)); Mg=sp.factor(M.subs(subs_generic))
L=x+y
assert sp.expand(sp.diff(Rg,x)-L**2)==0
assert sp.expand(Hg+x*L**2)==0
assert sp.expand(Mg-(1-3*t)*y*(2*x+3*y)/3)==0
# Target shear gives exactly the displayed weighted quartic shape.
Qg=sp.expand(Qg0-sp.Rational(1,2)*Pg)
assert sp.expand(Qg-(-sp.Rational(1,8)*x**4+sp.Rational(3,4)*x**2*y**2+x*y**3+sp.Rational(3,4)*t*y**4))==0

# The generic D6-compatible normal is ell=L,k=0, with Czz=1,Dzz=0.
normal_generic={p:1,q:1,k:0,c0:1,d0:0,**subs_generic}
Sg=sp.expand(D6self.subs(normal_generic))
assert sp.expand(Sg+Hg*ug)==0
Og=sp.factor(O5.subs(normal_generic))
expected_generic=-sp.Rational(1,3)*x*(x**2+3*x*y+3*y**2)
assert sp.expand(Og-expected_generic)==0

# Check the decisive extreme coefficient forcing k=0 away from t=0,1/3.
Sg_general=sp.Poly(sp.expand(D6self.subs(subs_generic)),x,y)
assert sp.expand(Sg_general.coeff_monomial(y**5)-3*k**2*t*(1-3*t))==0

# --------------------------------------------------------------------------
# 3. Reduced weighted-inflection chart q3=0.
# Normalize a=1/3,b=c=0,rho=t, so R_x=x^2 and H=-x^3.
# --------------------------------------------------------------------------
subs_red={a:sp.Rational(1,3),b:0,c:0,rho:t}
ur=sp.expand(u.subs(subs_red)); vr=sp.expand(v.subs(subs_red))
Rr=sp.expand(R.subs(subs_red)); Pr=sp.expand(P.subs(subs_red)); Qr=sp.expand(Q0.subs(subs_red))
Hr=sp.expand(H.subs(subs_red)); Mr=sp.expand(M.subs(subs_red))
assert sp.expand(sp.diff(Rr,x)-x**2)==0
assert sp.expand(Hr+x**3)==0
assert sp.expand(Mr+2*t*x*y)==0
# The xy^4 coefficient forces k=0 for t != 0.
Sr_general=sp.Poly(sp.expand(D6self.subs(subs_red)),x,y)
assert sp.factor(Sr_general.coeff_monomial(x*y**4))==-6*k**2*t**2

# Two projective normals remain: ell=x and ell=y.
red_x={p:1,q:0,k:0,c0:1,d0:0,**subs_red}
assert sp.expand(D6self.subs(red_x)+Hr*ur)==0
Oredx=sp.factor(O5.subs(red_x))
assert sp.expand(Oredx+sp.Rational(1,3)*x**3)==0
red_y={p:0,q:1,k:0,c0:0,d0:1/(9*t),**subs_red}
assert sp.expand(D6self.subs(red_y)+Hr*(-sp.Rational(1,1)/(9*t))*0)==sp.expand(D6self.subs(red_y))  # no-op sanity
# Direct D6 cancellation: S+H*(c0*u-d0*v)=0.
assert sp.expand(D6self.subs(red_y)+Hr*(0*ur-(1/(9*t))*vr))==0
Oredy=sp.factor(O5.subs(red_y))
assert sp.expand(Oredy-sp.Rational(2,3)*y**3)==0

# --------------------------------------------------------------------------
# 4. Direct determinant replay for the generic and reduced x branches.
# --------------------------------------------------------------------------
def replay(Pv,Qv,Rv,az,bz,ez,cv,dv):
    F1=Pv+z*az+sp.Rational(1,2)*cv*z**2
    F2=Qv+z*bz+sp.Rational(1,2)*dv*z**2
    F3=Rv+z*ez
    Det=detJ(F1,F2,F3)
    return hpart(Det,7),hpart(Det,6),hpart(Det,5)
D7g,D6g,D5g=replay(Pg,Qg0,Rg,x*L,y*L,L,1,0)
assert D7g==0 and D6g==0
assert sp.expand(zcoef(D5g,2)-expected_generic)==0
D7r,D6r,D5r=replay(Pr,Qr,Rr,x**2,x*y,x,1,0)
assert D7r==0 and D6r==0
assert sp.expand(zcoef(D5r,2)+sp.Rational(1,3)*x**3)==0

print('PASS: canonical (3,4) Hilbert--Burch gradient factorization')
print('PASS: compact D6 self-obstruction formula')
print('PASS: general rigid z^2 coefficient formula for D5')
print('PASS: generic weighted-inflection chart; D5 obstruction =', expected_generic)
print('PASS: reduced x-normal chart; D5 obstruction = -x^3/3')
print('PASS: reduced y-normal chart; D5 obstruction = 2*y^3/3')
print('PASS: direct determinant replay through D5')
