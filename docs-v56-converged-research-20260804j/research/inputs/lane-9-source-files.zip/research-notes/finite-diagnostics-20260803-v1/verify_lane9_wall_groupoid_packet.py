#!/usr/bin/env python3
"""Replay and summarize the exact 73-test Lane 9 ambient groupoid packet."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[2]
PACKET = (
    ROOT
    / "research-notes/lane9-wall-shear-20260802-v1"
    / "research-notes/p6-chart-correspondence"
)


def load(name: str) -> dict[str, object]:
    return json.loads((PACKET / name).read_text(encoding="utf-8"))


def main() -> int:
    run = subprocess.run(
        [
            sys.executable,
            "-m",
            "unittest",
            "discover",
            "-s",
            str(PACKET),
            "-p",
            "test_*.py",
            "-v",
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    transcript = run.stdout + run.stderr
    match = re.search(r"Ran (\d+) tests", transcript)
    if run.returncode != 0 or match is None or int(match.group(1)) != 73:
        raise AssertionError(f"wall-groupoid suite failed or changed:\n{transcript}")

    overlap = load("degree21_k4_overlap_saturation.expected.json")
    triple = load("degree21_k4_triple_overlap.expected.json")
    support = load("degree21_k4_support_audit.expected.json")
    flow = load("wall_shear_rees_hamiltonian_flow.expected.json")
    result = {
        "schema_version": 1,
        "name": "Lane 9 ambient wall-groupoid comparison",
        "status": "pass",
        "test_count": 73,
        "packet_source_sha256": {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(PACKET.glob("*.py"))
        },
        "support": {
            "bare_k4_first_layer": support["normal_layer"],
            "lies_in_fixed_chart_window": support["lies_in_fixed_chart_window"],
        },
        "saturation_dimensions": {
            "deformation_old": overlap["deformation_space"]["old_dimension"],
            "deformation_saturated": overlap["deformation_space"]["saturated_dimension"],
            "equation_old": overlap["equation_space"]["old_dimension"],
            "equation_saturated": overlap["equation_space"]["saturated_dimension"],
        },
        "overlap_dimensions": {
            "deformation_pairwise": triple["deformation_space"]["pairwise_overlap_dimension"],
            "deformation_all_parameter": triple["deformation_space"]["stable_all_parameter_core_dimension"],
            "deformation_pairwise_only": triple["deformation_space"]["pairwise_only_dimension"],
            "equation_pairwise": triple["equation_space"]["pairwise_overlap_dimension"],
            "equation_all_parameter": triple["equation_space"]["stable_all_parameter_core_dimension"],
            "equation_pairwise_only": triple["equation_space"]["pairwise_only_dimension"],
        },
        "quotient_flow": flow["quotient_chart"],
        "does_not_establish": [
            "that the ambient wall transport is an actual adjacent complete-chain chart",
            "the fixed-chart admissible polynomial subgroup",
            "the archived layer-four residual identification",
            "the missing F2 endpoint blocks or their global attachment",
        ],
    }
    canonical = json.dumps(result, sort_keys=True, separators=(",", ":")).encode()
    result["certificate_sha256"] = hashlib.sha256(canonical).hexdigest()
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
