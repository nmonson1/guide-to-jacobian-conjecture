# Cyclic descent of a wall parameter in the F2 quotient

**Status:** exact character and filtration bookkeeping. This identifies the
parameter line required for an equivariant wall family. It does not supply
the missing `F_2` normal support windows or prove that the `k=4` wall is an
allowed complete-chain transition for `F_2`.

## 1. Character shift

Let the lattice quotient be

\[
u=z^g,
\]

with deck action

\[
z\longmapsto\zeta z,
\qquad \zeta^g=1,
\]

and assume the normal parameter is fixed. The order-\(q\) term in the
`k`-wall transport contains

\[
\lambda^q z^{-qk}.
\]

If \(\lambda\) is treated as an invariant scalar, the coefficient character
changes by

\[
\chi_j\longmapsto\chi_{j-qk}.
\]

Thus scalar wall transport mixes the cyclic character sectors.

An equivariant family instead requires

\[
\boxed{
\lambda\longmapsto\zeta^k\lambda.
}
\]

Then

\[
\lambda^qz^{j-qk}
\longmapsto
\zeta^{qk+j-qk}\lambda^qz^{j-qk}
 =\zeta^j\lambda^qz^{j-qk},
\]

so each original character sector is preserved over the eigenparameter
line.

## 2. Scalar descent sees only a return-order power

If the wall parameter must itself be invariant, the first order returning to
the original character is

\[
q_0=\frac{g}{\gcd(g,k)}.
\]

For `F_2`,

\[
g=5,
\qquad k=4,
\]

so

\[
\boxed{q_0=5.}
\]

The unweighted normal shift per wall order is seven, hence the first scalar
return occurs at normal shift

\[
\boxed{5\cdot7=35.}
\]

Equivalently, the invariant quotient parameter is locally represented by

\[
\mu=\lambda^5.
\]

Plain averaging in the coefficient space discards the intermediate
noninvariant wall terms. It therefore does not commute with recharting unless
the eigenparameter line is included in the descent datum.

## 3. Necessary bidegree for a layer-four reconciliation

The bare `k=4` wall starts at normal layer seven. If one tries to interpret
its first term as a layer-four rechart direction, the unique necessary normal
weight of \(\lambda\) is

\[
\boxed{\operatorname{wt}_t(\lambda)=4-7=-3.}
\]

Combined with cyclic equivariance in the `F_2` gap-five cover, the required
parameter bidegree would be

\[
\boxed{
(\operatorname{wt}_t,\chi_{C_5})(\lambda)=(-3,4).
}
\]

With this bookkeeping, one wall order has weighted normal degree four and the
first scalar return \(\lambda^5\) has weighted degree

\[
5\cdot4=20.
\]

The negative normal weight is significant. Such a parameter is not an
ordinary coordinate of the nonnegative `t`-adic Rees deformation base. It is
a localized or chart-moving parameter. Therefore a layer-four repair along
these lines would itself prove that the operation is a rechart rather than
fixed-chart gauge—but the corresponding Rees/groupoid construction still has
to be supplied.


## 4. Weight alone does not restore the layer operator

There is an additional compatibility condition.  The bare wall pair

\[
f=2z^{-3},\qquad g=z^{-4}
\]

is a kernel field for \(D_7\), not \(D_4\).  Reassigning the parameter weight
without changing the field gives

\[
(fz^2)' +(4-5)gz^2=-3z^{-2}.
\]

Thus the bidegree `(-3,4)` is necessary bookkeeping but not a complete
repair.  With the same horizontal component, the unique layer-four vertical
component is

\[
g=-2z^{-4}.
\]

A valid descent theorem must construct the Rees/Euler mechanism that produces
this correction and then transport its operation image across the chart
atlas.

## 5. Consequence for the `F_2` attachment problem

The exact order-520 recurrence uses cyclic invariance, but a wall transition
must be descended together with its parameter line. There are two distinct
questions:

1. solve the invariant coefficient recurrence in one fixed presentation;
2. glue presentations using eigenparameters and then descend the entire
   chart groupoid.

The first cannot replace the second. A scalar Reynolds operator sees only
powers at the return order and can miss the intermediate chart data required
for exact gluing.

## 6. Reproduction

```bash
python research-notes/p6-chart-correspondence/f2_cyclic_wall_descent.py \
  --gap 5 --k 4 --requested-layer 4 \
  --output /tmp/f2-cyclic-wall-descent.json
```
