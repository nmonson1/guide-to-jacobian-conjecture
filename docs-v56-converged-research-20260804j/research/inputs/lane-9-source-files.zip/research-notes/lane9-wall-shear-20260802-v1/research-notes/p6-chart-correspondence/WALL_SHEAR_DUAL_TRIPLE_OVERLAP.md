# Wall-shear dual transport and triple-overlap theorem

**Status:** exact finite Laurent-jet theorem through normal layer 15 for the
stored degree-21 support. The theorem supplies coefficient, equation,
obstruction-dual, forcing, inverse, and triple-overlap transport for the
ambient wall atlas. It does not identify the intrinsic complete-chain
stabilizer or prove that the transported Laurent windows are the intended
monomial Newton charts.

## 1. Contragredient residue transport

For a coefficient density of pole order `p`, write

\[
e_{n,j}=t^{n-p}z^j.
\]

The exact `k`-wall transport is

\[
T_{k,\lambda}^{(p)}e_{n,j}
 =\sum_{q\ge0}
 \binom{n-p+2j}{q}\lambda^q
 e_{n+q(2k-1),j-qk}.
\]

Let \(\epsilon_{n,j}\) denote the coefficient dual. At fixed normal layer it
is represented by the residue principal part

\[
\epsilon_{n,j}(w)
 =\operatorname {Res}_{z=0}
   z^{-j-1}w_n(z)\,dz.
\]

The dual functional in the transported chart must satisfy

\[
\langle U_{k,\lambda}^{(p)}\ell,
        T_{k,\lambda}^{(p)}w\rangle
 =\langle\ell,w\rangle.
\]

Since \(T_{k,\lambda}^{-1}=T_{k,-\lambda}\), one has

\[
U_{k,\lambda}^{(p)}
 =\left(T_{k,\lambda}^{(p),-1}\right)^\mathsf T.
\]

A direct coefficient calculation gives the closed formula

\[
\boxed{
U_{k,\lambda}^{(p)}\epsilon_{m,l}
 =\sum_{q\ge0}
 \binom{p-m-2l-1}{q}\lambda^q
 \epsilon_{m-q(2k-1),l+qk}.
}
\]

Indeed, the coefficient before applying the elementary binomial identity is

\[
(-1)^q\binom{m-p+2l+q}{q}
 =\binom{p-m-2l-1}{q}.
\]

The implementation checks \(U^\mathsf TT=I\) on every basis vector of the
complete layer-15 saturations:

| density | saturated dimension | maximum primal terms | maximum dual terms |
| --- | ---: | ---: | ---: |
| `P`, pole order 2 | 114 | 3 | 3 |
| `Q`, pole order 3 | 180 | 3 | 3 |
| equation residual, pole order 4 | 300 | 3 | 3 |

Thus every finite obstruction functional and forcing pairing transports
exactly. In particular, if

\[
D_\lambda T_E=T_WD_0,
\qquad \ell^\mathsf TD_0=0,
\]

then

\[
\ell_\lambda=T_W^{-\mathsf T}\ell
\]

satisfies

\[
\ell_\lambda^\mathsf TD_\lambda=0.
\]

For \(\Phi_\lambda=T_W\Phi\),

\[
\boxed{
\langle\ell_\lambda,\Phi_\lambda\rangle
 =\langle\ell,\Phi\rangle.
}
\]

This is the exact residue/forcing transport required by a chart theorem at
the ambient Laurent-jet level.

## 2. Pairwise overlap is not triple overlap

For `k=4`, the wall shift is seven. Through layer 15,

\[
N_4^3=0,
\qquad
T_\lambda=I+\lambda N_4+\frac{\lambda^2}{2}N_4^2.
\]

Let \(E_0\) be the old coefficient window. A vector common to the charts
with parameters \(0,1,-1\) lies in every transported chart. To see this,
project \(T_\lambda v\) to the coordinates outside \(E_0\). The result is a
polynomial of degree at most two in \(\lambda\). If it vanishes at
\(0,1,-1\), it vanishes identically.

Consequently,

\[
\boxed{
E_0\cap E_1\cap E_{-1}
 =\{v\in E_0:T_\lambda v\in E_0\text{ for every }\lambda\}.
}
\]

This is the maximal all-parameter stable core of the old window. The same
statement holds for the equation-density space.

The exact dimensions are:

| space | old | one pairwise overlap | all-parameter core | pairwise-only |
| --- | ---: | ---: | ---: | ---: |
| `P` | 61 | 15 | 8 | 7 |
| `Q` | 125 | 74 | 60 | 14 |
| total deformation `E` | 186 | 89 | 68 | 21 |
| equation density `W` | 257 | 216 | 206 | 10 |

Thus a two-chart check leaves 21 deformation directions and 10 equation
directions that fail the third-chart condition.

The all-parameter stability constraints split as follows:

| space | first-order external rank | extra rank from `N^2` | total |
| --- | ---: | ---: | ---: |
| `P` | 46 | 7 | 53 |
| `Q` | 51 | 14 | 65 |
| total `E` | 97 | 21 | 118 |
| `W` | 41 | 10 | 51 |

These are source-constraint ranks. The corresponding numbers of new ambient
target directions are smaller:

| space | from `N` | new directions from `N^2` | total saturation increment |
| --- | ---: | ---: | ---: |
| `P` | 46 | 7 | 53 |
| `Q` | 51 | 4 | 55 |
| total `E` | 97 | 11 | 108 |
| `W` | 41 | 2 | 43 |

The difference is important: multiple independent source constraints can
land in the same external coefficient coordinate. Counting overflow
monomials alone does not count triple-overlap conditions.

The eight `P` monomials stable under the entire wall orbit are

\[
(0,1),\ (2,0),\ (2,4),\ (2,5),\ (3,4),\
(9,0),\ (9,1),\ (10,0),
\]

where each pair is `(normal layer, z exponent)`. The implementation records
the analogous 60-dimensional `Q` core and 206-dimensional equation core.

## 3. Exact cocycle

On the stable core, every wall transport remains in the old finite window,
and

\[
T_{b-c}T_{a-b}=T_{a-c},
\qquad T_{-\lambda}=T_\lambda^{-1}.
\]

Therefore the three-chart ambient atlas satisfies the required inverse and
triple-overlap cocycle identities exactly. This is stronger than checking one
transition square, but weaker than a complete-chain chart theorem because the
intrinsic monomial charts and their admissible operation groups remain
unidentified.

## 4. Reproduction

```bash
python research-notes/p6-chart-correspondence/wall_shear_dual_transport.py \
  --k 4 --cutoff 15 \
  --output /tmp/wall-shear-dual.json

python research-notes/p6-chart-correspondence/degree21_k4_triple_overlap.py \
  --k 4 --cutoff 15 \
  --output /tmp/degree21-k4-triple-overlap.json
```
