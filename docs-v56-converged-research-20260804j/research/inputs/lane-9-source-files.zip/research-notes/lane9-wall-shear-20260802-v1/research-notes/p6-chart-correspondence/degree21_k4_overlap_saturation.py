#!/usr/bin/env python3
"""Construct the minimal finite transported-window overlap for degree 21.

The old full-support coefficient spaces are closed under neither the ``k=4``
wall generator nor its exponential.  This program constructs the smallest
layer-15 Laurent support containing the old space and closed under that
generator.  It then compares the old chart with one transported chart and
with the two opposite transported charts.

All ranks are exact over Q and use only the Python standard library.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence

from wall_shear_master_covariance import generalized_binomial

BasisElement = tuple[int, int]
Support = dict[int, list[int]]
Matrix = list[list[Fraction]]


def full_support_fixture() -> dict[str, Support]:
    p_supports: Support = {
        0: list(range(1, 9)),
        1: list(range(1, 9)),
        2: list(range(0, 9)),
    }
    for layer in range(3, 11):
        p_supports[layer] = list(range(0, 11 - layer))
    for layer in range(11, 16):
        p_supports[layer] = []

    q_supports: Support = {
        0: list(range(2, 13)),
        1: list(range(2, 13)),
        2: list(range(1, 13)),
        3: list(range(0, 13)),
    }
    for layer in range(4, 16):
        q_supports[layer] = list(range(0, 16 - layer))
    return {"P": p_supports, "Q": q_supports}


def basis_from_support(support: Mapping[int, Sequence[int]]) -> list[BasisElement]:
    return sorted(
        (layer, power)
        for layer, powers in support.items()
        for power in powers
    )


def saturate(
    support: Mapping[int, Sequence[int]],
    *,
    pole_order: int,
    k: int,
    cutoff: int,
) -> list[BasisElement]:
    shift = 2 * k - 1
    result = set(basis_from_support(support))
    while True:
        additions: set[BasisElement] = set()
        for layer, power in result:
            coefficient = layer - pole_order + 2 * power
            target = (layer + shift, power - k)
            if coefficient and target[0] <= cutoff:
                additions.add(target)
        new = additions - result
        if not new:
            return sorted(result)
        result.update(new)


def matrix_rank(matrix: Matrix) -> int:
    if not matrix:
        return 0
    rows = [row[:] for row in matrix]
    columns = len(rows[0])
    if any(len(row) != columns for row in rows):
        raise ValueError("ragged matrix")
    pivot_row = 0
    for column in range(columns):
        pivot = next(
            (row for row in range(pivot_row, len(rows)) if rows[row][column]),
            None,
        )
        if pivot is None:
            continue
        rows[pivot_row], rows[pivot] = rows[pivot], rows[pivot_row]
        scale = rows[pivot_row][column]
        rows[pivot_row] = [value / scale for value in rows[pivot_row]]
        for row in range(len(rows)):
            if row == pivot_row:
                continue
            factor = rows[row][column]
            if factor:
                rows[row] = [
                    value - factor * pivot_value
                    for value, pivot_value in zip(rows[row], rows[pivot_row])
                ]
        pivot_row += 1
        if pivot_row == len(rows):
            break
    return pivot_row


def horizontal_join(left: Matrix, right: Matrix) -> Matrix:
    if len(left) != len(right):
        raise ValueError("row counts do not agree")
    return [a + b for a, b in zip(left, right)]


def external_transport_matrix(
    old_basis: Sequence[BasisElement],
    saturated_basis: Sequence[BasisElement],
    *,
    pole_order: int,
    k: int,
    parameter: Fraction,
    cutoff: int,
) -> tuple[list[BasisElement], Matrix]:
    old_set = set(old_basis)
    external = [element for element in saturated_basis if element not in old_set]
    external_index = {element: index for index, element in enumerate(external)}
    matrix = [
        [Fraction(0) for _ in range(len(old_basis))]
        for _ in range(len(external))
    ]
    shift = 2 * k - 1
    for column, (layer, power) in enumerate(old_basis):
        wall_order = 1
        while layer + wall_order * shift <= cutoff:
            target = (
                layer + wall_order * shift,
                power - wall_order * k,
            )
            coefficient = generalized_binomial(
                layer - pole_order + 2 * power,
                wall_order,
            )
            if target in external_index and coefficient:
                matrix[external_index[target]][column] += (
                    coefficient * parameter**wall_order
                )
            wall_order += 1
    return external, matrix


def rational_text(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else str(value)


def matrix_digest(matrix: Matrix) -> str:
    payload = [
        [rational_text(value) for value in row]
        for row in matrix
    ]
    return hashlib.sha256(
        json.dumps(payload, separators=(",", ":"), sort_keys=False).encode()
    ).hexdigest()


def added_by_layer(
    old_basis: Sequence[BasisElement],
    saturated_basis: Sequence[BasisElement],
) -> list[dict[str, Any]]:
    old = set(old_basis)
    grouped: defaultdict[int, list[int]] = defaultdict(list)
    for layer, power in saturated_basis:
        if (layer, power) not in old:
            grouped[layer].append(power)
    return [
        {"layer": layer, "z_exponents": sorted(powers), "count": len(powers)}
        for layer, powers in sorted(grouped.items())
    ]


def analyze_space(
    name: str,
    support: Mapping[int, Sequence[int]],
    *,
    pole_order: int,
    k: int,
    cutoff: int,
) -> dict[str, Any]:
    old_basis = basis_from_support(support)
    saturated_basis = saturate(
        support,
        pole_order=pole_order,
        k=k,
        cutoff=cutoff,
    )
    external, plus = external_transport_matrix(
        old_basis,
        saturated_basis,
        pole_order=pole_order,
        k=k,
        parameter=Fraction(1),
        cutoff=cutoff,
    )
    _, minus = external_transport_matrix(
        old_basis,
        saturated_basis,
        pole_order=pole_order,
        k=k,
        parameter=Fraction(-1),
        cutoff=cutoff,
    )
    _, twice = external_transport_matrix(
        old_basis,
        saturated_basis,
        pole_order=pole_order,
        k=k,
        parameter=Fraction(2),
        cutoff=cutoff,
    )
    external_rank = matrix_rank(plus)
    if matrix_rank(twice) != external_rank:
        raise AssertionError("nonzero wall parameters changed the overlap rank")
    opposite_rank = matrix_rank(horizontal_join(plus, minus))

    old_dimension = len(old_basis)
    saturated_dimension = len(saturated_basis)
    sum_dimension = old_dimension + external_rank
    intersection_dimension = old_dimension - external_rank
    opposite_span_dimension = old_dimension + opposite_rank

    return {
        "name": name,
        "pole_order": pole_order,
        "old_dimension": old_dimension,
        "saturated_dimension": saturated_dimension,
        "added_dimension": saturated_dimension - old_dimension,
        "one_nonzero_transported_chart": {
            "external_increment": external_rank,
            "intersection_dimension": intersection_dimension,
            "sum_dimension": sum_dimension,
            "saturation_defect": saturated_dimension - sum_dimension,
            "rank_constant_for_nonzero_parameters_verified_at": ["1", "2", "-1"],
        },
        "base_plus_opposite_charts": {
            "span_dimension": opposite_span_dimension,
            "spans_minimal_saturation": (
                opposite_span_dimension == saturated_dimension
            ),
        },
        "added_basis_by_layer": added_by_layer(old_basis, saturated_basis),
        "external_basis_dimension": len(external),
        "positive_external_matrix_sha256": matrix_digest(plus),
        "negative_external_matrix_sha256": matrix_digest(minus),
    }


def master_support(
    p_supports: Mapping[int, Sequence[int]],
    q_supports: Mapping[int, Sequence[int]],
    *,
    alpha: int,
    beta: int,
    cutoff: int,
) -> Support:
    result: defaultdict[int, set[int]] = defaultdict(set)
    for left_layer, left_powers in p_supports.items():
        for right_layer, right_powers in q_supports.items():
            layer = left_layer + right_layer
            if layer > cutoff:
                continue
            for left_power in left_powers:
                for right_power in right_powers:
                    coefficient = (
                        alpha * right_power
                        - beta * left_power
                        + right_layer * left_power
                        - left_layer * right_power
                    )
                    if coefficient:
                        result[layer].add(left_power + right_power - 1)
    result[0].add(2)
    return {
        layer: sorted(powers)
        for layer, powers in sorted(result.items())
    }


def support_summary(support: Mapping[int, Sequence[int]]) -> list[dict[str, Any]]:
    return [
        {
            "layer": layer,
            "minimum_exponent": min(powers) if powers else None,
            "maximum_exponent": max(powers) if powers else None,
            "dimension": len(powers),
            "contiguous": (
                not powers
                or len(powers) == max(powers) - min(powers) + 1
            ),
        }
        for layer, powers in sorted(support.items())
    ]


def analyze(*, k: int = 4, cutoff: int = 15) -> dict[str, Any]:
    alpha, beta = 2, 3
    supports = full_support_fixture()
    p_report = analyze_space(
        "P coefficients",
        supports["P"],
        pole_order=alpha,
        k=k,
        cutoff=cutoff,
    )
    q_report = analyze_space(
        "Q coefficients",
        supports["Q"],
        pole_order=beta,
        k=k,
        cutoff=cutoff,
    )
    equation_support = master_support(
        supports["P"],
        supports["Q"],
        alpha=alpha,
        beta=beta,
        cutoff=cutoff,
    )
    equation_report = analyze_space(
        "master-equation density",
        equation_support,
        pole_order=alpha + beta - 1,
        k=k,
        cutoff=cutoff,
    )

    deformation_old = p_report["old_dimension"] + q_report["old_dimension"]
    deformation_saturated = (
        p_report["saturated_dimension"] + q_report["saturated_dimension"]
    )
    deformation_external = (
        p_report["one_nonzero_transported_chart"]["external_increment"]
        + q_report["one_nonzero_transported_chart"]["external_increment"]
    )
    deformation_intersection = (
        p_report["one_nonzero_transported_chart"]["intersection_dimension"]
        + q_report["one_nonzero_transported_chart"]["intersection_dimension"]
    )
    deformation_sum = deformation_old + deformation_external
    opposite_span = (
        p_report["base_plus_opposite_charts"]["span_dimension"]
        + q_report["base_plus_opposite_charts"]["span_dimension"]
    )

    report = {
        "schema_version": 1,
        "name": "degree-21 k=4 transported-window overlap",
        "alpha": alpha,
        "beta": beta,
        "k": k,
        "normal_layer_shift": 2 * k - 1,
        "cutoff": cutoff,
        "interpretation": (
            "E_lambda=T_E(lambda)E_0 and W_lambda=T_W(lambda)W_0 form an "
            "exact ambient Laurent-jet chart pair. They are not yet proved "
            "to be the complete-chain monomial adjacent chart or its "
            "presentation stabilizer."
        ),
        "deformation_space": {
            "old_dimension": deformation_old,
            "saturated_dimension": deformation_saturated,
            "added_dimension": deformation_saturated - deformation_old,
            "one_nonzero_transported_chart": {
                "external_increment": deformation_external,
                "intersection_dimension": deformation_intersection,
                "sum_dimension": deformation_sum,
                "saturation_defect": deformation_saturated - deformation_sum,
            },
            "base_plus_opposite_charts": {
                "span_dimension": opposite_span,
                "spans_minimal_saturation": (
                    opposite_span == deformation_saturated
                ),
            },
            "components": [p_report, q_report],
        },
        "equation_space": equation_report,
        "old_equation_support": support_summary(equation_support),
        "filtered_conjugacy_consequence": {
            "principal_shift": 2 * k - 1,
            "statement": (
                "Conjugation by a filtration-preserving automorphism with "
                "invertible associated graded map preserves this principal "
                "shift. For k=4 it cannot produce a layer-four tangent."
            ),
        },
    }

    expected = {
        "deformation_old": 186,
        "deformation_saturated": 294,
        "deformation_external": 97,
        "deformation_intersection": 89,
        "deformation_sum": 283,
        "equation_old": 257,
        "equation_saturated": 300,
        "equation_external": 41,
        "equation_intersection": 216,
        "equation_sum": 298,
    }
    actual = {
        "deformation_old": deformation_old,
        "deformation_saturated": deformation_saturated,
        "deformation_external": deformation_external,
        "deformation_intersection": deformation_intersection,
        "deformation_sum": deformation_sum,
        "equation_old": equation_report["old_dimension"],
        "equation_saturated": equation_report["saturated_dimension"],
        "equation_external": equation_report[
            "one_nonzero_transported_chart"
        ]["external_increment"],
        "equation_intersection": equation_report[
            "one_nonzero_transported_chart"
        ]["intersection_dimension"],
        "equation_sum": equation_report[
            "one_nonzero_transported_chart"
        ]["sum_dimension"],
    }
    if k == 4 and cutoff == 15 and actual != expected:
        raise AssertionError({"expected": expected, "actual": actual})
    return report


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--k", type=int, default=4)
    parser.add_argument("--cutoff", type=int, default=15)
    parser.add_argument("-o", "--output", type=Path)
    args = parser.parse_args(argv)
    report = analyze(k=args.k, cutoff=args.cutoff)
    rendered = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
