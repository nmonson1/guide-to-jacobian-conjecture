#!/usr/bin/env python3
"""Build the exact first-order k=4 transport on the stored full support.

For a normal basis monomial

    e_(n,j) = t^(n-alpha) z^j,

the derivative at ``lambda=0`` of ``Y -> Y+lambda X^(-k)`` is

    N_k e_(n,j) = (n-alpha+2j) e_(n+2k-1,j-k).

This script applies that formula to every basis monomial in the archived full
support.  It separates internal entries, exits through a coefficient-window
wall, terms beyond the finite stored cutoff, and zero entries.  It also reports
the powers of the projected sparse operator on the old window.

The ambient exact transport is ``exp(lambda N_k)``: after each application the
coefficient drops by one, so

    N_k^q e_(n,j)
      = (n-alpha+2j)_(q) e_(n+q(2k-1),j-qk),

where ``(a)_(q)`` is the falling factorial.  The projected old-window matrix is
a diagnostic only; a genuine chart transition needs the adjacent support
window rather than discarding the reported overflow.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any, Mapping, Sequence


BasisElement = tuple[int, int]


def full_layers(document: Mapping[str, Any]) -> dict[int, Mapping[str, Any]]:
    cases = document.get("cases")
    if not isinstance(cases, list):
        raise ValueError("support document has no cases list")
    full = next(
        (case for case in cases if isinstance(case, Mapping) and case.get("label") == "full"),
        None,
    )
    if not isinstance(full, Mapping):
        raise ValueError("support document has no full case")
    layers = full.get("layers")
    if not isinstance(layers, list):
        raise ValueError("full support case has no layers list")
    result: dict[int, Mapping[str, Any]] = {}
    for layer in layers:
        if not isinstance(layer, Mapping) or not isinstance(layer.get("r"), int):
            raise ValueError("invalid full support layer")
        result[int(layer["r"])] = layer
    return result


def component_supports(
    layers: Mapping[int, Mapping[str, Any]], component: str
) -> dict[int, list[int]]:
    if component not in {"P", "Q"}:
        raise ValueError("component must be P or Q")
    key = "a_support" if component == "P" else "b_support"
    result: dict[int, list[int]] = {}
    for normal_layer, layer in sorted(layers.items()):
        values = layer.get(key, [])
        if not isinstance(values, list) or not all(
            isinstance(value, int) and not isinstance(value, bool) for value in values
        ):
            raise ValueError(f"invalid {key} at layer {normal_layer}")
        result[normal_layer] = list(values)
    return result


def projected_operator(
    supports: Mapping[int, Sequence[int]], pole_order: int, k: int
) -> tuple[list[BasisElement], dict[BasisElement, tuple[BasisElement, int]]]:
    basis = [
        (normal_layer, exponent)
        for normal_layer in sorted(supports)
        for exponent in supports[normal_layer]
    ]
    basis_set = set(basis)
    shift = 2 * k - 1
    operator: dict[BasisElement, tuple[BasisElement, int]] = {}
    for normal_layer, exponent in basis:
        coefficient = normal_layer - pole_order + 2 * exponent
        target = (normal_layer + shift, exponent - k)
        if coefficient != 0 and target in basis_set:
            operator[(normal_layer, exponent)] = (target, coefficient)
    return basis, operator


def projected_power_entries(
    basis: Sequence[BasisElement],
    operator: Mapping[BasisElement, tuple[BasisElement, int]],
    power: int,
) -> list[dict[str, Any]]:
    if power < 1:
        raise ValueError("power must be positive")
    entries: list[dict[str, Any]] = []
    for source in basis:
        current = source
        coefficient = 1
        for _ in range(power):
            image = operator.get(current)
            if image is None:
                break
            current, factor = image
            coefficient *= factor
        else:
            entries.append(
                {
                    "source_layer": source[0],
                    "source_exponent": source[1],
                    "target_layer": current[0],
                    "target_exponent": current[1],
                    "coefficient": coefficient,
                }
            )
    return entries


def component_report(
    supports: Mapping[int, Sequence[int]],
    *,
    component: str,
    pole_order: int,
    k: int,
) -> dict[str, Any]:
    maximum_layer = max(supports)
    shift = 2 * k - 1
    internal: list[dict[str, Any]] = []
    window_exit: list[dict[str, Any]] = []
    beyond_cutoff: list[dict[str, Any]] = []
    zero: list[dict[str, Any]] = []

    for source_layer in sorted(supports):
        for source_exponent in supports[source_layer]:
            coefficient = source_layer - pole_order + 2 * source_exponent
            target_layer = source_layer + shift
            target_exponent = source_exponent - k
            entry = {
                "source_layer": source_layer,
                "source_exponent": source_exponent,
                "coefficient": coefficient,
                "target_layer": target_layer,
                "target_exponent": target_exponent,
            }
            if coefficient == 0:
                zero.append(entry)
            elif target_layer > maximum_layer:
                beyond_cutoff.append(entry)
            elif target_exponent in supports.get(target_layer, []):
                internal.append(entry)
            else:
                window_exit.append(entry)

    basis, operator = projected_operator(supports, pole_order, k)
    projected_powers: list[dict[str, Any]] = []
    power = 1
    while True:
        entries = projected_power_entries(basis, operator, power)
        projected_powers.append(
            {
                "power": power,
                "rank": len(entries),
                "entries": entries,
            }
        )
        if not entries:
            break
        power += 1
        if power > len(basis) + 1:
            raise AssertionError("projected operator did not become nilpotent")

    def layer_counts(entries: Sequence[Mapping[str, Any]]) -> list[dict[str, int]]:
        counts = Counter(int(entry["source_layer"]) for entry in entries)
        return [
            {"source_layer": normal_layer, "count": counts[normal_layer]}
            for normal_layer in sorted(counts)
        ]

    return {
        "component": component,
        "pole_order": pole_order,
        "domain_dimension": len(basis),
        "maximum_stored_layer": maximum_layer,
        "first_order_internal_rank": len(internal),
        "first_order_internal_entries": internal,
        "window_exit_count": len(window_exit),
        "window_exit_by_source_layer": layer_counts(window_exit),
        "window_exit_entries": window_exit,
        "beyond_cutoff_count": len(beyond_cutoff),
        "beyond_cutoff_by_source_layer": layer_counts(beyond_cutoff),
        "beyond_cutoff_entries": beyond_cutoff,
        "zero_entry_count": len(zero),
        "zero_entries": zero,
        "projected_operator_powers": projected_powers,
        "projected_nilpotence_index": projected_powers[-1]["power"],
    }


def analyze(document: Mapping[str, Any], k: int) -> dict[str, Any]:
    if not isinstance(k, int) or isinstance(k, bool) or k < 1:
        raise ValueError("k must be a positive integer")
    layers = full_layers(document)
    p_report = component_report(
        component_supports(layers, "P"),
        component="P",
        pole_order=2,
        k=k,
    )
    q_report = component_report(
        component_supports(layers, "Q"),
        component="Q",
        pole_order=3,
        k=k,
    )
    return {
        "schema_version": 1,
        "name": "degree-21 full-window infinitesimal wall transport",
        "k": k,
        "normal_layer_shift": 2 * k - 1,
        "basis_formula": (
            "N_k e_(n,j)=(n-alpha+2j)e_(n+2k-1,j-k)"
        ),
        "ambient_exponential_formula": (
            "F_lambda^*=exp(lambda N_k), with "
            "N_k^q e_(n,j)=(n-alpha+2j)_(q)e_(n+q(2k-1),j-qk)"
        ),
        "components": [p_report, q_report],
        "total_domain_dimension": (
            p_report["domain_dimension"] + q_report["domain_dimension"]
        ),
        "total_first_order_internal_rank": (
            p_report["first_order_internal_rank"]
            + q_report["first_order_internal_rank"]
        ),
        "total_window_exit_count": (
            p_report["window_exit_count"] + q_report["window_exit_count"]
        ),
        "total_beyond_cutoff_count": (
            p_report["beyond_cutoff_count"] + q_report["beyond_cutoff_count"]
        ),
        "total_zero_entry_count": (
            p_report["zero_entry_count"] + q_report["zero_entry_count"]
        ),
        "interpretation": (
            "The internal matrix is only the projection to the old fixed-chart "
            "window. The window-exit entries must be transported into an "
            "explicit adjacent-chart basis; deleting them is not a chart "
            "correspondence theorem."
        ),
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("supports", type=Path)
    parser.add_argument("--k", type=int, default=4)
    parser.add_argument("-o", "--output", type=Path)
    args = parser.parse_args(argv)

    try:
        document = json.loads(args.supports.read_text(encoding="utf-8"))
        if not isinstance(document, Mapping):
            raise ValueError("support input must be a JSON object")
        result = analyze(document, args.k)
    except (OSError, TypeError, ValueError, json.JSONDecodeError) as exc:
        parser.error(str(exc))

    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
