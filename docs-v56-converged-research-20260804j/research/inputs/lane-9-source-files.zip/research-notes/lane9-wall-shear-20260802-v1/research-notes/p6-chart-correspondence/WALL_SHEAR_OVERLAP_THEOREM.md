# Exact wall-shear overlap and master-equation covariance

**Status:** exact ambient Laurent-jet theorem and degree-21 finite-window
calculation. This constructs a genuine transported-window chart pair. It does
not yet identify the complete-chain presentation stabilizer or prove that the
transported coefficient space is the intended monomial Newton chart.

## 1. Density transport

Let

\[
t'=t(1+h),\qquad z'=z(1+h)^2,\qquad
h=\lambda t^{2k-1}z^{-k}.
\]

For a coefficient density with pole order \(p\), define

\[
T^{(p)}_{k,\lambda}(t^nz^j)
=
\sum_{q\ge0}
\binom{n-p+2j}{q}\lambda^q
t^{n+q(2k-1)}z^{j-qk}.
\]

On any finite normal cutoff this is a finite exact sum. It satisfies

\[
T^{(p)}_{k,\lambda}T^{(p)}_{k,\mu}
=
T^{(p)}_{k,\lambda+\mu},
\qquad
(T^{(p)}_{k,\lambda})^{-1}=T^{(p)}_{k,-\lambda}.
\]

## 2. Exact nonlinear master covariance

Write

\[
\mathcal R_{\alpha,\beta}(A,B)
=
\alpha AB_z-\beta A_zB
+t(A_zB_t-A_tB_z)-z^2.
\]

The coefficient pairs \(A,B\) have pole orders \(\alpha,\beta\). The residual
is a coefficient density of pole order

\[
\gamma=\alpha+\beta-1.
\]

Exact pullback of the determinant two-form gives

\[
\boxed{
\mathcal R_{\alpha,\beta}
\left(T^{(\alpha)}_{k,\lambda}A,
      T^{(\beta)}_{k,\lambda}B\right)
=
T^{(\gamma)}_{k,\lambda}
\mathcal R_{\alpha,\beta}(A,B).
}
\]

Differentiating at any base pair gives the full cumulative-jet chain map

\[
D_{T(A,B)}\mathcal R\circ
\left(T^{(\alpha)}\oplus T^{(\beta)}\right)
=
T^{(\gamma)}\circ D_{(A,B)}\mathcal R.
\]

This supplies the previously missing equation-space map for the ambient wall
overlap, including all lower-triangular normal-layer mixing.

## 3. A canonical transported-window chart pair

Let \(E_0\) be the archived full degree-21 coefficient window through layer
15 and let \(W_0\) be the complete support of its nonlinear master residual.
For nonzero \(\lambda\), put

\[
E_\lambda=T_E(\lambda)E_0,\qquad
W_\lambda=T_W(\lambda)W_0.
\]

Then

\[
\mathcal R(E_\lambda)\subseteq W_\lambda
\]

exactly. Thus \((E_0,W_0)\) and \((E_\lambda,W_\lambda)\) form a genuine
finite-dimensional ambient Laurent-jet chart pair.

The exact dimensions are:

| space | old dimension | minimal wall saturation | added |
| --- | ---: | ---: | ---: |
| \(P\)-coefficients | 61 | 114 | 53 |
| \(Q\)-coefficients | 125 | 180 | 55 |
| total deformation space \(E\) | 186 | 294 | 108 |
| equation density \(W\) | 257 | 300 | 43 |

For every tested nonzero parameter—and, by chainwise diagonal rescaling, for
every nonzero parameter—the old and transported spaces satisfy:

| space | intersection | sum | new independent directions |
| --- | ---: | ---: | ---: |
| \(P\) | 15 | 107 | 46 |
| \(Q\) | 74 | 176 | 51 |
| total \(E\) | 89 | 283 | 97 |
| \(W\) | 216 | 298 | 41 |

The deformation increment \(97=46+51\) is exactly the previously observed
first-order coefficient-wall exit rank. A single transported chart does not
span the whole orbit saturation: it misses 11 deformation coordinates and 2
equation coordinates that occur as independent second-order wall terms.
However,

\[
\boxed{
E^{\mathrm{sat}}=E_0+E_1+E_{-1},
\qquad
W^{\mathrm{sat}}=W_0+W_1+W_{-1}.
}
\]

This gives an exact three-chart finite overlap model.

## 4. Filtered conjugacy cannot lower seven to four

For \(k=4\), the infinitesimal generator has exact \(t\)-adic degree \(7\).
Let \(C\) be a filtration-preserving automorphism with filtration-preserving
inverse and invertible associated-graded map. If \(N\) has nonzero principal
symbol in degree seven, then

\[
\sigma_7(CNC^{-1})
=
\operatorname{gr}(C)\sigma_7(N)\operatorname{gr}(C)^{-1}
\ne0.
\]

Hence \(CNC^{-1}\) still has degree seven. Therefore the displayed wall shear
cannot become a normal layer-four tangent through a filtration-preserving
conjugacy. Any reconciliation must use a filtration-changing birational
coordinate map, assign degree \(-3\) to the wall parameter, or correct one of
the labels.

## 5. An explicit false obstruction removed by the wall arc

Take

\[
A_0=z+\frac32z^2,\qquad B_0=z^2+z^3.
\]

It satisfies

\[
2A_0B_0'-3A_0'B_0=z^2.
\]

The exact \(k=4\), \(\lambda=1\) wall transform through layer 15 is

\[
A=A_0+3t^7z^{-2}+\frac32t^{14}z^{-6},
\]

\[
B=B_0+t^7(z^{-2}+3z^{-1})+3t^{14}z^{-5}.
\]

The layer-seven correction lies in the kernel. At layer 14,

\[
D_{14}(a_{14},b_{14})
=
-6z^{-5}+27z^{-4},
\]

while the quadratic forcing from the layer-seven correction is

\[
\Phi_{14}
=
6z^{-5}-27z^{-4}.
\]

They cancel exactly. Setting the second wall correction to zero creates a
nonzero residual even though the full chart transition is an exact solution.
This is a small exact model of the logical error behind a
zero-new-parameter obstruction slice.

## 6. What remains

The construction solves the ambient coefficient and equation transport
problem. It does not yet determine:

- the intrinsic complete-chain fixed-presentation stabilizer;
- the intended adjacent monomial Newton window;
- the filtration-changing map, if any, connecting the public layer-four
  residual to the \(k=4\) wall;
- the actual `F_2` attachment matrices.

The next useful export is the real adjacent-chart normalization map. It can be
tested against the transported-window space above instead of discarding wall
overflow terms.


## 7. Dual and triple-overlap continuation

The exact obstruction-dual map is

\[
U\epsilon_{m,l}
 =\sum_q\binom{p-m-2l-1}{q}\lambda^q
 \epsilon_{m-q(2k-1),l+qk},
\qquad U^\mathsf TT=I.
\]

Forcing pairings and left-null obstruction spaces therefore transport exactly.

The pairwise deformation overlap has dimension 89, whereas the all-parameter
core detected by the charts `0`, `1`, and `-1` has dimension 68.  The
corresponding equation dimensions are 216 and 206.  Thus triple-overlap
compatibility imposes 21 additional deformation conditions and 10 additional
equation conditions beyond one pairwise transition.

The layer-four support-admissible field also acquires a compulsory
layer-eleven commutator term under the wall.  Finally, in the `F_2` gap-five
quotient the wall parameter is a character-four eigenparameter; scalar cyclic
descent sees its first return only at order five.
