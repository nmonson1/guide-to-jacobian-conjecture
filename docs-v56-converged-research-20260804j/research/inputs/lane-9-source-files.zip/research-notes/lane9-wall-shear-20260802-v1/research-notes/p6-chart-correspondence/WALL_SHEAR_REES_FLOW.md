# The corrected layer-four candidate is a Kummer Hamiltonian flow

**Status:** exact coordinate conversion and formal-flow calculation. This
strengthens the Rees-weight audit. It does not construct the missing
complete-chain chart.

## 1. Back to the original affine coordinates

The degree-21 coordinate dictionary is

\[
t=x^4y,\qquad z=x^7y^2.
\]

The unique corrected layer-four pair from the Rees-weight audit is

\[
V=t^4\left(2z^{-3}\partial_z-2z^{-4}t\partial_t\right).
\]

Writing

\[
u=\frac{\delta t}{t},\qquad v=\frac{\delta z}{z},
\]

the logarithmic coordinate equations are

\[
4\frac{\delta x}{x}+\frac{\delta y}{y}=u,
\qquad
7\frac{\delta x}{x}+2\frac{\delta y}{y}=v.
\]

Here

\[
u=-2M,\qquad v=2M,\qquad
M=t^4z^{-4}=x^{-12}y^{-4}.
\]

Consequently

\[
\boxed{
V=-6x^{-11}y^{-4}\partial_x
  +22x^{-12}y^{-3}\partial_y.
}
\]

Its ordinary divergence is zero.

## 2. Hamiltonian form

With the convention

\[
D_H=H_y\partial_x-H_x\partial_y,
\]

the field is Hamiltonian for

\[
\boxed{H=2x^{-11}y^{-3}.}
\]

On Laurent monomials,

\[
V(x^ay^b)=(-6a+22b)x^{a-12}y^{b-4}.
\]

In particular,

\[
V(H)=0,
\qquad
V(M)=-16M^2.
\]

The iterates of \(x\) have nonzero leading coefficient

\[
V^n(x)=
\left(\prod_{j=0}^{n-1}(-6-16j)\right)
 x^{1-12n}y^{-4n},
\]

so this Laurent derivation is not locally nilpotent.

## 3. Exact formal flow

Solving \(\dot M=-16M^2\) gives

\[
M_s=\frac{M}{1+16sM}.
\]

Put

\[
R^8=1+16sM.
\]

Then the exact flow is

\[
\boxed{
 x_s=xR^{-3},\qquad
 y_s=yR^{11},\qquad
 t_s=tR^{-1},\qquad
 z_s=zR.
}
\]

As a formal power series in \(s\), the binomial root \(R\) exists uniquely
with constant term one. Thus the corrected candidate is formally integrable.


## 4. The degree-eight quotient linearizes the flow

Set

\[
\boxed{
H=2x^{-11}y^{-3}=\frac{2}{tz},
\qquad
Q=x^{12}y^4=\left(\frac zt\right)^4=M^{-1}.
}
\]

Then

\[
V(H)=0,
\qquad
V(Q)=16.
\]

Thus on the quotient function field,

\[
\boxed{H_s=H,\qquad Q_s=Q+16s.}
\]

The exponent matrix of the monomial map \((x,y)\mapsto(H/2,Q)\) is

\[
\begin{pmatrix}
-11&-3\\
12&4
\end{pmatrix},
\]

with determinant \(-8\). Hence

\[
[K(x,y):K(H,Q)]=8
\]

generically. Explicitly,

\[
x^8=\frac{16}{H^4Q^3},
\qquad
y^8=\frac{H^{12}Q^{11}}{4096}.
\]

The Kummer root in the original flow is precisely

\[
R^8=\frac{Q+16s}{Q}.
\]

So the corrected field is not mysterious: it is an ordinary translation on
a degree-eight monomial quotient chart. The eighth-root extension is exactly
the inverse lattice-index obstruction to lifting that translation back to
\((x,y)\).


In the adjacent blowdown variables used by the stored proposition,

\[
u=(xy)^{-1},\qquad v=y,
\]

these quotient coordinates are

\[
H=2u^{11}v^8,
\qquad
Q=u^{-12}v^{-8}.
\]

Therefore

\[
\boxed{K(H,Q)=K(u,v^8).}
\]

The degree-eight quotient is exactly the \(\mu_8\)-quotient of the adjacent
blowdown chart.  The corrected field descends to this quotient, while the bare
`k=4` operation is the translation \(v\mapsto v+s\), which is not the same
quotient operation.  This isolates a precise missing lift in the public
correspondence claim.


Because

\[
Q=\left(\frac zt\right)^4
\]

has normal \(t\)-exponent \(-4\), translation in \(Q\) naturally has the
missing layer-four label.  This gives the strongest current repaired
correspondence candidate:

> match the stored layer-four residual to the pullback of the quotient
> translation \(Q\mapsto Q+16s\), not to the bare layer-seven translation
> \(v\mapsto v+s\).

The scalar `16` is a parameter normalization.  What remains is an exact
coefficientwise comparison with the archived residual representative.

## 5. It is not a same-field rational chart operation

Over \(K(x,y,s)\), the radicand is

\[
1+16sx^{-12}y^{-4}.
\]

After multiplication by the Laurent unit \(x^{12}y^4\), its non-monomial
factor is the prime

\[
x^{12}y^4+16s.
\]

The radicand has valuation one at this prime. An eighth power has valuation
divisible by eight. Therefore the radicand is not an eighth power in
\(K(x,y,s)\), and the generic flow requires the degree-eight Kummer
extension

\[
K(x,y,s)\subset K(x,y,s)(R),
\qquad R^8=1+16sM.
\]

Hence the corrected field cannot be identified with an ordinary rational
one-parameter coordinate change on the same function field.

## 6. Compatibility with the F2 cyclic character

For the `F_2` quotient, \(z\) has `C_5` character one and the wall parameter
has character four. Both \(H\) and \(Q\) have character four, so the quotient
translation \(Q\mapsto Q+16s\) is equivariant. Since

\[
M=t^4z^{-4}
\]

has character one, \(sM\) is invariant modulo five. The Kummer radicand and
root equation are therefore compatible with cyclic descent. The independent
eighth-root extension nevertheless remains.

This gives a sharper alternative:

- the bare `k=4` wall is the polynomial translation \(y\mapsto y+s\) and
  occurs at normal layer seven;
- the corrected layer-four candidate is Hamiltonian and formally integrable,
  but algebraically lives on an eighth-root Kummer cover;
- identifying it with a complete-chain rechart requires a root-stack or
  filtration-changing construction, not a same-field polynomial wall shear.
