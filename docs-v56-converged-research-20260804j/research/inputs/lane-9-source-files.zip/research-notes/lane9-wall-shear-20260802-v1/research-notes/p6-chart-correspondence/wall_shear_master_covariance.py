#!/usr/bin/env python3
"""Exact covariance of the normal-boundary master equation under wall shears.

For

    t' = t(1+h),  z' = z(1+h)^2,
    h = lambda * t^(2k-1) * z^(-k),

a coefficient density of pole order ``p`` is transported by

    T_p(t^n z^j)
      = sum_q binom(n-p+2j,q) lambda^q
          t^(n+q(2k-1)) z^(j-qk).

The determinant master residual has density pole order
``alpha + beta - 1``.  The module verifies, exactly over Q,

    R(T_alpha A, T_beta B)
      = T_(alpha+beta-1) R(A,B),

as well as the differentiated chain-map square and an explicit second-order
wall arc.  No computer-algebra dependency is required.
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence

Exponent = tuple[int, int]
Series = dict[Exponent, Fraction]


def q(value: Any) -> Fraction:
    if isinstance(value, Fraction):
        return value
    if isinstance(value, bool):
        raise TypeError("booleans are not rational coefficients")
    if isinstance(value, int):
        return Fraction(value)
    if isinstance(value, str):
        return Fraction(value)
    raise TypeError(f"unsupported rational coefficient {value!r}")


def scalar_text(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else str(value)


def generalized_binomial(exponent: int, order: int) -> Fraction:
    if order < 0:
        return Fraction(0)
    value = Fraction(1)
    for index in range(order):
        value *= Fraction(exponent - index, index + 1)
    return value


def clean(series: Mapping[Exponent, Fraction]) -> Series:
    return {key: value for key, value in series.items() if value}


def add(*series: Mapping[Exponent, Fraction]) -> Series:
    result: defaultdict[Exponent, Fraction] = defaultdict(Fraction)
    for item in series:
        for key, value in item.items():
            result[key] += value
    return clean(result)


def scale(series: Mapping[Exponent, Fraction], scalar: Fraction | int) -> Series:
    scalar = q(scalar)
    return clean({key: scalar * value for key, value in series.items()})


def multiply(
    left: Mapping[Exponent, Fraction],
    right: Mapping[Exponent, Fraction],
    *,
    cutoff: int,
) -> Series:
    result: defaultdict[Exponent, Fraction] = defaultdict(Fraction)
    for (left_layer, left_power), left_value in left.items():
        for (right_layer, right_power), right_value in right.items():
            layer = left_layer + right_layer
            if layer <= cutoff:
                result[(layer, left_power + right_power)] += (
                    left_value * right_value
                )
    return clean(result)


def derivative_z(series: Mapping[Exponent, Fraction]) -> Series:
    return clean(
        {
            (layer, power - 1): value * power
            for (layer, power), value in series.items()
            if power
        }
    )


def t_derivative(series: Mapping[Exponent, Fraction]) -> Series:
    """Return ``t * partial_t(series)``."""

    return clean(
        {
            (layer, power): value * layer
            for (layer, power), value in series.items()
            if layer
        }
    )


def master(
    A: Mapping[Exponent, Fraction],
    B: Mapping[Exponent, Fraction],
    *,
    alpha: int,
    beta: int,
    cutoff: int,
) -> Series:
    """The scalar master expression before subtracting ``Psi=z^2``."""

    return add(
        scale(multiply(A, derivative_z(B), cutoff=cutoff), alpha),
        scale(multiply(derivative_z(A), B, cutoff=cutoff), -beta),
        multiply(derivative_z(A), t_derivative(B), cutoff=cutoff),
        scale(
            multiply(t_derivative(A), derivative_z(B), cutoff=cutoff),
            -1,
        ),
    )


def residual(
    A: Mapping[Exponent, Fraction],
    B: Mapping[Exponent, Fraction],
    *,
    alpha: int,
    beta: int,
    cutoff: int,
) -> Series:
    return add(
        master(A, B, alpha=alpha, beta=beta, cutoff=cutoff),
        {(0, 2): Fraction(-1)},
    )


def linearization(
    A: Mapping[Exponent, Fraction],
    B: Mapping[Exponent, Fraction],
    a: Mapping[Exponent, Fraction],
    b: Mapping[Exponent, Fraction],
    *,
    alpha: int,
    beta: int,
    cutoff: int,
) -> Series:
    return add(
        master(a, B, alpha=alpha, beta=beta, cutoff=cutoff),
        master(A, b, alpha=alpha, beta=beta, cutoff=cutoff),
    )


def transport(
    series: Mapping[Exponent, Fraction],
    *,
    pole_order: int,
    k: int,
    parameter: Fraction | int,
    cutoff: int,
) -> Series:
    """Pull a primed coefficient density back to the unprimed wall chart."""

    if k < 1:
        raise ValueError("k must be positive")
    parameter = q(parameter)
    shift = 2 * k - 1
    result: defaultdict[Exponent, Fraction] = defaultdict(Fraction)
    for (layer, power), value in series.items():
        wall_order = 0
        while layer + wall_order * shift <= cutoff:
            coefficient = generalized_binomial(
                layer - pole_order + 2 * power,
                wall_order,
            )
            if coefficient:
                result[
                    (
                        layer + wall_order * shift,
                        power - wall_order * k,
                    )
                ] += value * coefficient * parameter**wall_order
            wall_order += 1
    return clean(result)


def extract_layer(series: Mapping[Exponent, Fraction], layer: int) -> dict[int, Fraction]:
    return {
        power: value
        for (current_layer, power), value in series.items()
        if current_layer == layer
    }


def polynomial_series(polynomial: Mapping[int, Fraction], layer: int = 0) -> Series:
    return {(layer, power): value for power, value in polynomial.items() if value}


def determinant_layer(
    A0: Mapping[int, Fraction],
    B0: Mapping[int, Fraction],
    a: Mapping[int, Fraction],
    b: Mapping[int, Fraction],
    *,
    alpha: int,
    beta: int,
    layer: int,
) -> dict[int, Fraction]:
    """The universal linear layer operator in scalar-coefficient form."""

    A = polynomial_series(A0)
    B = polynomial_series(B0)
    aa = polynomial_series(a)
    bb = polynomial_series(b)
    result = add(
        scale(multiply(aa, derivative_z(B), cutoff=0), alpha - layer),
        scale(multiply(B, derivative_z(aa), cutoff=0), -beta),
        scale(multiply(A, derivative_z(bb), cutoff=0), alpha),
        scale(multiply(bb, derivative_z(A), cutoff=0), layer - beta),
    )
    return extract_layer(result, 0)


def series_json(series: Mapping[Exponent, Fraction]) -> list[dict[str, Any]]:
    return [
        {
            "layer": layer,
            "z_exponent": power,
            "coefficient": scalar_text(value),
        }
        for (layer, power), value in sorted(series.items())
    ]


def polynomial_json(polynomial: Mapping[int, Fraction]) -> list[dict[str, Any]]:
    return [
        {"z_exponent": power, "coefficient": scalar_text(value)}
        for power, value in sorted(polynomial.items())
    ]


def verify_covariance(
    A: Mapping[Exponent, Fraction],
    B: Mapping[Exponent, Fraction],
    *,
    alpha: int,
    beta: int,
    k: int,
    parameter: Fraction,
    cutoff: int,
) -> bool:
    transformed_A = transport(
        A,
        pole_order=alpha,
        k=k,
        parameter=parameter,
        cutoff=cutoff,
    )
    transformed_B = transport(
        B,
        pole_order=beta,
        k=k,
        parameter=parameter,
        cutoff=cutoff,
    )
    left = residual(
        transformed_A,
        transformed_B,
        alpha=alpha,
        beta=beta,
        cutoff=cutoff,
    )
    right = transport(
        residual(A, B, alpha=alpha, beta=beta, cutoff=cutoff),
        pole_order=alpha + beta - 1,
        k=k,
        parameter=parameter,
        cutoff=cutoff,
    )
    return left == right


def toy_wall_arc(*, k: int = 4, cutoff: int = 15) -> dict[str, Any]:
    """A nontrivial exact face whose wall arc needs a second-order correction."""

    alpha, beta = 2, 3
    A0: Series = {(0, 1): Fraction(1), (0, 2): Fraction(3, 2)}
    B0: Series = {(0, 2): Fraction(1), (0, 3): Fraction(1)}
    if residual(A0, B0, alpha=alpha, beta=beta, cutoff=cutoff):
        raise AssertionError("the toy face does not satisfy Psi=z^2")

    transformed_A = transport(
        A0, pole_order=alpha, k=k, parameter=1, cutoff=cutoff
    )
    transformed_B = transport(
        B0, pole_order=beta, k=k, parameter=1, cutoff=cutoff
    )
    if residual(
        transformed_A,
        transformed_B,
        alpha=alpha,
        beta=beta,
        cutoff=cutoff,
    ):
        raise AssertionError("the exact wall arc does not solve the master equation")

    shift = 2 * k - 1
    second_layer = 2 * shift
    A0_poly = extract_layer(A0, 0)
    B0_poly = extract_layer(B0, 0)
    a_first = extract_layer(transformed_A, shift)
    b_first = extract_layer(transformed_B, shift)
    a_second = extract_layer(transformed_A, second_layer)
    b_second = extract_layer(transformed_B, second_layer)

    first_linear = determinant_layer(
        A0_poly,
        B0_poly,
        a_first,
        b_first,
        alpha=alpha,
        beta=beta,
        layer=shift,
    )
    second_linear = determinant_layer(
        A0_poly,
        B0_poly,
        a_second,
        b_second,
        alpha=alpha,
        beta=beta,
        layer=second_layer,
    )
    quadratic = extract_layer(
        master(
            polynomial_series(a_first, shift),
            polynomial_series(b_first, shift),
            alpha=alpha,
            beta=beta,
            cutoff=cutoff,
        ),
        second_layer,
    )
    cancellation = add(
        polynomial_series(second_linear),
        polynomial_series(quadratic),
    )

    return {
        "face": {
            "A0": polynomial_json(A0_poly),
            "B0": polynomial_json(B0_poly),
        },
        "first_nonzero_layer": shift,
        "second_wall_layer": second_layer,
        "first_correction": {
            "a": polynomial_json(a_first),
            "b": polynomial_json(b_first),
            "linear_image": polynomial_json(first_linear),
            "kernel_verified": not first_linear,
        },
        "second_correction": {
            "a": polynomial_json(a_second),
            "b": polynomial_json(b_second),
            "linear_image": polynomial_json(second_linear),
            "quadratic_forcing": polynomial_json(quadratic),
            "cancellation_verified": not cancellation,
        },
        "zero_second_correction_slice": {
            "residual": polynomial_json(quadratic),
            "inconsistent_with_exact_wall_arc": bool(quadratic),
        },
    }


def build_report(*, k: int, cutoff: int, parameter: Fraction) -> dict[str, Any]:
    alpha, beta = 2, 3
    sample_A: Series = {
        (0, 1): Fraction(1),
        (0, 2): Fraction(2),
        (1, 0): Fraction(3),
        (4, 3): Fraction(1, 2),
    }
    sample_B: Series = {
        (0, 2): Fraction(1),
        (0, 3): Fraction(1),
        (2, -1): Fraction(2),
        (5, 4): Fraction(-1),
    }
    sample_a: Series = {(0, 0): Fraction(2), (3, 2): Fraction(-1)}
    sample_b: Series = {(1, 1): Fraction(3), (4, -2): Fraction(1)}

    transformed_A = transport(
        sample_A,
        pole_order=alpha,
        k=k,
        parameter=parameter,
        cutoff=cutoff,
    )
    transformed_B = transport(
        sample_B,
        pole_order=beta,
        k=k,
        parameter=parameter,
        cutoff=cutoff,
    )
    transformed_a = transport(
        sample_a,
        pole_order=alpha,
        k=k,
        parameter=parameter,
        cutoff=cutoff,
    )
    transformed_b = transport(
        sample_b,
        pole_order=beta,
        k=k,
        parameter=parameter,
        cutoff=cutoff,
    )
    left_linear = linearization(
        transformed_A,
        transformed_B,
        transformed_a,
        transformed_b,
        alpha=alpha,
        beta=beta,
        cutoff=cutoff,
    )
    right_linear = transport(
        linearization(
            sample_A,
            sample_B,
            sample_a,
            sample_b,
            alpha=alpha,
            beta=beta,
            cutoff=cutoff,
        ),
        pole_order=alpha + beta - 1,
        k=k,
        parameter=parameter,
        cutoff=cutoff,
    )

    group_left = transport(
        transport(
            sample_A,
            pole_order=alpha,
            k=k,
            parameter=Fraction(2, 3),
            cutoff=cutoff,
        ),
        pole_order=alpha,
        k=k,
        parameter=Fraction(-1, 5),
        cutoff=cutoff,
    )
    group_right = transport(
        sample_A,
        pole_order=alpha,
        k=k,
        parameter=Fraction(7, 15),
        cutoff=cutoff,
    )

    return {
        "schema_version": 1,
        "name": "wall-shear master-equation covariance",
        "alpha": alpha,
        "beta": beta,
        "equation_density_pole_order": alpha + beta - 1,
        "k": k,
        "normal_layer_shift": 2 * k - 1,
        "cutoff": cutoff,
        "parameter": scalar_text(parameter),
        "transport_formula": (
            "T_p(t^n z^j)=sum_q binom(n-p+2j,q) lambda^q "
            "t^(n+q(2k-1)) z^(j-qk)"
        ),
        "master_covariance": (
            "R(T_alpha A,T_beta B)=T_(alpha+beta-1)R(A,B)"
        ),
        "master_covariance_verified": verify_covariance(
            sample_A,
            sample_B,
            alpha=alpha,
            beta=beta,
            k=k,
            parameter=parameter,
            cutoff=cutoff,
        ),
        "linearized_chain_map_verified": left_linear == right_linear,
        "additive_group_law_verified": group_left == group_right,
        "rhs_z_squared_fixed": transport(
            {(0, 2): Fraction(1)},
            pole_order=alpha + beta - 1,
            k=k,
            parameter=parameter,
            cutoff=cutoff,
        )
        == {(0, 2): Fraction(1)},
        "filtered_conjugacy_boundary": {
            "statement": (
                "A filtration-preserving conjugacy with invertible associated "
                "graded map preserves the principal shift 2k-1."
            ),
            "k4_shift": 7 if k == 4 else None,
            "can_become_layer_four_by_filtered_conjugacy": (
                False if k == 4 else None
            ),
        },
        "toy_exact_wall_arc": toy_wall_arc(k=k, cutoff=cutoff),
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--k", type=int, default=4)
    parser.add_argument("--cutoff", type=int, default=15)
    parser.add_argument("--parameter", default="1")
    parser.add_argument("-o", "--output", type=Path)
    args = parser.parse_args(argv)

    report = build_report(
        k=args.k,
        cutoff=args.cutoff,
        parameter=Fraction(args.parameter),
    )
    rendered = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
