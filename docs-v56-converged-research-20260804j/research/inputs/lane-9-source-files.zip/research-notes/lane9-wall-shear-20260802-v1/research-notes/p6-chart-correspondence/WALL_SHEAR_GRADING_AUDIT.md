# Wall-shear grading audit for the degree-21 lower face

**Status:** exact coordinate calculation and regression-tested research note.
It identifies a grading/provenance gap in the current public formulation of the
claimed layer-four/`k=4` correspondence. It does not invalidate the separate
adjacent-chart terminal calculation; it shows that the bridge to that
calculation has not been written in a filtration-compatible form.

**Audited repository state:** draft PR 1, head
`fd9e29f5c2ee24acdfee8e3165d7b9da0df859f0`.

## 1. Coordinate dictionary

The degree-21 lower face uses

\[
t=Y,\qquad z=XY^2,
\]

and

\[
P=t^{-\alpha}\sum_{n\ge 0}t^nA_n(z),\qquad
Q=t^{-\beta}\sum_{n\ge 0}t^nB_n(z),
\qquad (\alpha,\beta)=(2,3).
\]

Consider the elementary wall shear

\[
X'=X,\qquad Y'=Y+\lambda X^{-k},\qquad k\ge 1,
\]

with scalar parameter \(\lambda\). Since \(X=z/t^2\), put

\[
h=\lambda t^{2k-1}z^{-k}.
\]

Then the transport in normal coordinates is the exact identity

\[
\boxed{
 t'=t(1+h),\qquad z'=z(1+h)^2.
}
\]

No series expansion is used here.

## 2. The normal order is \(2k-1\)

Differentiating at \(\lambda=0\) gives

\[
\delta t=t^{2k}z^{-k},\qquad
\delta z=2t^{2k-1}z^{1-k}.
\]

In the source-field convention

\[
V_r=t^r\bigl(f(z)\partial_z+g(z)t\partial_t\bigr),
\]

this is

\[
\boxed{
 r=2k-1,\qquad f=2z^{1-k},\qquad g=z^{-k}.
}
\]

For the lower face \(\Psi=z^2\), the weighted-divergence identity is checked
exactly:

\[
(fz^2)' +(r-5)gz^2
=2(3-k)z^{2-k}+2(k-3)z^{2-k}=0.
\]

Thus the shear tangent lies in the unrestricted determinant kernel at normal
order \(2k-1\).

For \(k=4\),

\[
\boxed{
 r=7,\qquad
 V_4=t^7\bigl(2z^{-3}\partial_z+z^{-4}t\partial_t\bigr).
}
\]

Consequently, under the displayed lower-face grading, the bare `k=4` shear is
the identity on the normal jet through layer six. It cannot itself be a
nonzero vector in the layer-four coefficient space.

In the archived affine coordinates

\[
X=x^{-1},\qquad Y=x^4y,
\]

the same operation is simply

\[
y\longmapsto y+\lambda.
\]

This explains why it is a polynomial source operation globally while changing
the center of the completed Newton chart. It does not alter the \(t\)-adic
order computed above.

## 3. Exact transport of every normal monomial

For a normal basis monomial

\[
t^{n-\alpha}z^j,
\]

one has

\[
\boxed{
(t')^{n-\alpha}(z')^j
 =\sum_{q\ge0}
 \binom{n-\alpha+2j}{q}\lambda^q
 t^{n-\alpha+q(2k-1)}z^{j-qk}.
}
\]

The generalized binomial coefficient is interpreted in the usual way for
negative integral upper index. The first-order basis shift is therefore

\[
(n,j)\longmapsto(n+2k-1,j-k)
\]

with coefficient \(n-\alpha+2j\). Define the infinitesimal transport
operator

\[
N_k e_{n,j}=(n-\alpha+2j)e_{n+2k-1,j-k}.
\]

After one application the coefficient drops by one, so

\[
N_k^q e_{n,j}
=(n-\alpha+2j)_{\underline q}
 e_{n+q(2k-1),j-qk}.
\]

Consequently the exact wall transport is

\[
\boxed{F_\lambda^*=\exp(\lambda N_k).}
\]

This supplies the inverse and composition laws formally:

\[
F_{-\lambda}^*=(F_\lambda^*)^{-1},\qquad
F_\lambda^*F_\mu^*=F_{\lambda+\mu}^*.
\]

On a finite normal jet, \(N_k\) is nilpotent after an ambient cutoff is
chosen. This exact sparse operator, rather than support-set closure alone, is
the transition matrix needed in a chart-correspondence packet.

For `k=4`, every first-order coefficient moves up by exactly seven normal
layers and left by four \(z\)-exponents.

## 4. Full stored-window transport profile

Applying \(N_4\) to all 186 monomial basis elements in the archived full
support gives:

| classification | count |
| --- | ---: |
| internal old-window entries | 55 |
| exits through a stored coefficient wall | 97 |
| terms above the stored layer-15 cutoff | 31 |
| zero first-order entries | 3 |

The componentwise counts are:

| component | dimension | internal | window exit | above cutoff | zero |
| --- | ---: | ---: | ---: | ---: | ---: |
| `P` | 61 | 10 | 46 | 3 | 2 |
| `Q` | 125 | 45 | 51 | 28 | 1 |

On the old-window projection, \(N_4^2\) has rank three and
\(N_4^3=0\). Those three second-order entries are the falling-factorial paths

\[
(0,8)\mapsto(14,0):13\cdot12,
\quad
(0,9)\mapsto(14,1):15\cdot14,
\quad
(1,8)\mapsto(15,0):14\cdot13
\]

in the `Q` component.

The important datum is not the small internal rank. More than half of the
first-order basis vectors leave the old coefficient window. Deleting those
97 entries is not a quotient or a chart transition; they must be expressed in
an explicit adjacent-chart basis.

## 5. First exact support exit for the stored degree-21 face

Write

\[
A_0=zp(z),\qquad B_0=z^2q(z).
\]

At the first nonzero normal layer \(r=2k-1\), the tangent action is

\[
a_r=fA_0'-2gA_0=2z^{2-k}p'(z),
\]

\[
b_r=fB_0'-3gB_0
=z^{2-k}q(z)+2z^{3-k}q'(z).
\]

For `k=4`, this becomes

\[
\boxed{
 a_7=2z^{-2}p'(z),\qquad
 b_7=z^{-2}q(z)+2z^{-1}q'(z).
}
\]

The exact degree-21 face has nonzero coefficients through
\(\deg p=7\) and \(\deg q=10\). Hence

\[
\operatorname{supp}(a_7)=\{-2,-1,0,1,2,3,4\},
\]

\[
\operatorname{supp}(b_7)=\{-2,-1,0,1,2,3,4,5,6,7,8\}.
\]

The archived full fixed-chart layer-seven windows are

\[
\operatorname{supp}(A_7)\subseteq\{0,1,2,3\},\qquad
\operatorname{supp}(B_7)\subseteq\{0,1,2,3,4,5,6,7,8\}.
\]

Therefore the exact forbidden exponents are

\[
\boxed{
 A:\{-2,-1,4\},\qquad B:\{-2,-1\}.
}
\]

This is a clean support certificate that the `k=4` tangent leaves the old
fixed-chart window at layer seven. It is consistent with a rechart there; it
is not a fixed-chart gauge vector.

## 6. Consequence for the public layer-four statement

The current public proposition combines:

1. a one-dimensional residual quotient at normal layer four;
2. the elementary operation \(Y\mapsto Y+\lambda X^{-4}\);
3. a subsequent adjacent-chart terminal calculation.

Items 1 and 2 do not match under the public coordinate dictionary:

\[
\text{wall index }k=4
\quad\Longrightarrow\quad
\text{normal order }r=2k-1=7,
\]

not \(r=4\).

A valid repair must provide at least one of the following and verify it
coefficientwise:

- a different pair of coordinates denoted by \((X,Y)\) in the operation;
- a nonzero filtration degree assigned to \(\lambda\);
- an intervening conjugation whose induced graded map sends order seven to
  the stated layer-four quotient;
- a correction of either the layer label or the operation.

A relabeling by `k` alone is insufficient because the manuscript explicitly
uses the normal-layer operator \(D_r\) and calls the residual a normal
layer-four class.

Until this bridge is supplied, the safe public statement is:

> The stored calculation reports a one-dimensional layer-four residual and a
> separate `k=4` adjacent-chart operation. Their claimed identification has an
> unresolved grading map. The adjacent-chart no-gluing certificate should be
> treated as exact for its displayed transformed system, while its provenance
> from the layer-four quotient remains review-pending.

## 7. A separate layer-four integrability result

The maximal linear support-admissible Laurent calculation at normal layer four
has a one-dimensional source basis with

\[
f(z)=c_0+c_1z+z^2.
\]

In the original affine coordinates \(z=x^7y^2\), the corresponding source
field is Hamiltonian:

\[
D_H=H_y\partial_x-H_x\partial_y,
\qquad
H=x^{10}y^3(c_0+c_1z+z^2).
\]

The highest monomial of \(H\) is \(x^{24}y^7\). Its Hamiltonian derivation
acts on a monomial by

\[
D_{\mathrm{top}}(x^py^q)
 =(7p-24q)x^{p+23}y^{q+6}.
\]

Inductively, the leading term of \(D_H^n(x)\) is

\[
\boxed{
\left(\prod_{m=0}^{n-1}(7+17m)\right)
 x^{1+23n}y^{6n}.
}
\]

Every factor is nonzero in characteristic zero, so \(D_H^n(x)\ne0\) for all
\(n\). Hence this support-admissible polynomial derivation is **not locally
nilpotent** and does not generate an algebraic additive one-parameter shear.

This result does not prove the manuscript's full fixed-chart nonintegrability
claim: arbitrary formal flows and non-group polynomial paths are broader than
\(\mathbb G_a\)-actions. It does prove a useful strict separation:

\[
\text{supported polynomial infinitesimal field}
\not\Longrightarrow
\text{integrable additive complete-chain operation}.
\]

The certificate is replayed by
`degree21_r4_hamiltonian_audit.py`.

## 8. Correct chart-correspondence target

For each chart \(C\) and layer \(r\), distinguish

\[
\mathfrak g^{\mathrm{adm}}_{C,r}
 \xrightarrow{\Theta_{C,r}}
E_{C,r}
 \xrightarrow{D_{C,r}}
W_{C,r}.
\]

The tangent and obstruction spaces are

\[
T_{C,r}=\ker D_{C,r}/\operatorname{im}\Theta_{C,r},
\qquad
O_{C,r}=\operatorname{coker}D_{C,r}.
\]

A chart transition \(\tau:C\to C'\) must include exact maps

\[
T_{\tau,E},\quad T_{\tau,W},\quad T_{\tau,\mathfrak g}
\]

satisfying

\[
D_{C'}T_{\tau,E}=T_{\tau,W}D_C,
\qquad
T_{\tau,E}\Theta_C=\Theta_{C'}T_{\tau,\mathfrak g}.
\]

If coefficient transport is affine,

\[
e'=T_{\tau,E}e+\delta_\tau,
\]

then forcing must satisfy

\[
T_{\tau,W}\Phi_C=\Phi_{C'}+D_{C'}\delta_\tau.
\]

Inverse transitions and triple overlaps must satisfy their corresponding
cocycle identities. Only after these checks is it legitimate to identify two
local tangent classes or to quotient by rechart directions.

## 9. Exact nonlinear master-equation covariance

For a coefficient density of pole order \(p\), define

\[
T^{(p)}_{k,\lambda}(t^nz^j)
=
\sum_{q\ge0}
\binom{n-p+2j}{q}\lambda^q
t^{n+q(2k-1)}z^{j-qk}.
\]

Let

\[
\mathcal R_{\alpha,\beta}(A,B)
=
\alpha AB_z-\beta A_zB
+t(A_zB_t-A_tB_z)-z^2.
\]

The residual density has pole order \(\alpha+\beta-1\), and exact two-form
pullback gives

\[
\boxed{
\mathcal R_{\alpha,\beta}
(T^{(\alpha)}A,T^{(\beta)}B)
=
T^{(\alpha+\beta-1)}
\mathcal R_{\alpha,\beta}(A,B).
}
\]

Differentiation gives the full cumulative-jet chain-map square. Thus the wall
transition now has an exact equation-space map, not merely a coefficient
support closure.

## 10. Minimal transported-window overlap

For the archived full degree-21 support through layer 15, the minimal
`k=4` wall-saturated deformation space has dimension 294:

| component | old | saturated | added |
| --- | ---: | ---: | ---: |
| `P` | 61 | 114 | 53 |
| `Q` | 125 | 180 | 55 |
| total | 186 | 294 | 108 |

For every nonzero wall parameter,

\[
\dim(E_0\cap E_\lambda)=89,\qquad
\dim(E_0+E_\lambda)=283.
\]

The transported chart contributes 97 independent directions beyond the old
window, exactly the first-order wall-exit rank. The corresponding nonlinear
equation-density dimensions are

\[
\dim W_0=257,\quad
\dim W^{\mathrm{sat}}=300,\quad
\dim(W_0\cap W_\lambda)=216,\quad
\dim(W_0+W_\lambda)=298.
\]

The base chart and the two opposite charts span the whole minimal saturation:

\[
E^{\mathrm{sat}}=E_0+E_1+E_{-1},\qquad
W^{\mathrm{sat}}=W_0+W_1+W_{-1}.
\]

This is an exact ambient Laurent-jet chart groupoid. It is not yet the
complete-chain monomial atlas.

## 11. Two consequences

First, a filtration-preserving conjugacy cannot turn the `k=4` shift seven
into shift four. If \(C\) has invertible associated graded, then

\[
\sigma_7(CN_4C^{-1})
=
\operatorname{gr}(C)\sigma_7(N_4)\operatorname{gr}(C)^{-1}\ne0.
\]

Any reconciliation of the public layer-four statement must therefore change
the filtration, reweight the wall parameter, or correct a label.

Second, the exact face

\[
A_0=z+\frac32z^2,\qquad B_0=z^2+z^3
\]

has a `k=4` wall arc

\[
A=A_0+3t^7z^{-2}+\frac32t^{14}z^{-6},
\]

\[
B=B_0+t^7(z^{-2}+3z^{-1})+3t^{14}z^{-5}.
\]

At layer 14 the quadratic forcing is

\[
6z^{-5}-27z^{-4},
\]

and the second wall correction has linear image

\[
-6z^{-5}+27z^{-4}.
\]

They cancel exactly. Setting the second correction to zero creates a false
nonzero residual.

## 12. Reproduction

```bash
python research-notes/p6-chart-correspondence/wall_shear_normal_coordinates.py \
  --k 4 \
  --output /tmp/wall-shear-k4.json

python research-notes/p6-chart-correspondence/degree21_k4_support_audit.py \
  research-notes/p6-chart-correspondence/fixtures/exact_belyi_data.json \
  research-notes/p6-chart-correspondence/lower_face_supports.json \
  --k 4 \
  --output /tmp/degree21-k4-support.json

python research-notes/p6-chart-correspondence/degree21_k4_jet_transport_audit.py \
  research-notes/p6-chart-correspondence/lower_face_supports.json \
  --k 4 \
  --output /tmp/degree21-k4-jet-transport.json

python research-notes/p6-chart-correspondence/degree21_r4_hamiltonian_audit.py \
  research-notes/p6-chart-correspondence/degree21_lower_face_full_gauge.json \
  --output /tmp/degree21-r4-hamiltonian.json

python -m unittest discover \
  -s research-notes/p6-chart-correspondence \
  -p 'test_*wall_shear*.py' -v

python -m unittest discover \
  -s research-notes/p6-chart-correspondence \
  -p 'test_degree21_k4_support_audit.py' -v
```

The six new test modules contain thirty-two exact regression tests.


Additional commands:

```bash
python research-notes/p6-chart-correspondence/wall_shear_master_covariance.py \
  --k 4 --cutoff 15 \
  --output /tmp/wall-master-covariance.json

python research-notes/p6-chart-correspondence/degree21_k4_overlap_saturation.py \
  --k 4 --cutoff 15 \
  --output /tmp/degree21-k4-overlap.json
```


## 13. Exact residue-dual transport

The wall transition on a coefficient density of pole order \(p\) has the
pairing-preserving contragredient

\[
U\epsilon_{m,l}
 =\sum_q\binom{p-m-2l-1}{q}\lambda^q
 \epsilon_{m-q(2k-1),l+qk}.
\]

It satisfies \(U^\mathsf TT=I\).  The formula has been checked on every basis
vector of the 114-dimensional `P`, 180-dimensional `Q`, and 300-dimensional
equation-density wall saturations.  Hence left-null obstruction functionals
and forcing pairings transport exactly through the ambient wall chain map.

## 14. Triple-overlap core

Through layer 15, \(T_\lambda\) is quadratic in \(\lambda\).  The
three-chart intersection at parameters `0`, `1`, and `-1` is therefore the
subspace stable under every wall parameter.  Its exact dimensions are

\[
\dim E^{\mathrm{core}}=68,
\qquad
\dim W^{\mathrm{core}}=206.
\]

A single pairwise overlap has dimensions 89 and 216.  Thus 21 deformation
directions and 10 equation directions pass one overlap but fail the
triple-overlap test.

## 15. Operation commutator and cyclic parameter line

Transporting the maximal support-admissible layer-four source field across the
wall forces a layer-eleven bracket whose action contains nonzero `P` exponent
5 and `Q` exponent 9 terms.  The old layer-eleven windows omit both.  This is
an exact required adjacent-chart operation term.

For the `F_2` quotient `u=z^5`, a `k=4` wall parameter must have `C_5`
character four.  If it is treated as an invariant scalar, the first return to
the original character occurs only at wall order five.  Reconciling the bare
layer-seven wall with a layer-four associated-graded direction would also
require normal weight `-3`; the resulting necessary bidegree is `(-3,4 mod
5)`.  This is localized chart data, not ordinary fixed-chart gauge.


## 16. Parameter weight is necessary but not sufficient

Assigning weight \(w\) to the wall parameter changes the bookkeeping layer
from \(r=2k-1\) to \(r+w\).  If the bare source pair is left unchanged, its
ordinary weighted-divergence defect becomes

\[
(fz^2)' +(r+w-5)gz^2=wz^{2-k}.
\]

For `k=4` and target layer four, \(w=-3\), so the defect is

\[
-3z^{-2}\ne0.
\]

Thus reweighting alone cannot identify the bare wall tangent with a
\(D_4\)-kernel class.  Keeping \(f=2z^{-3}\) uniquely restores the layer-four
identity with

\[
g=-2z^{-4}.
\]

The resulting candidate associated-graded action is

\[
a_4=6z^{-3}p+2z^{-2}p',
\qquad
b_4=10z^{-2}q+2z^{-1}q'.
\]

It exits the old layer-four window through principal parts
`A={-3,-2,-1}`, `B={-2,-1}`.  A complete repair must construct the
Rees/Euler mechanism that produces this correction and match its tangent line
to the archived residual quotient.
