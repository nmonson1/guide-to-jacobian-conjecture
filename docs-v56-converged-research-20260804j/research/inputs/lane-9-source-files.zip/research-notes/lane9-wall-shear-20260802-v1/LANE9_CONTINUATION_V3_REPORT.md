# Lane 9 continuation v3 report

## Result

The ambient wall atlas now includes exact residue-dual transport, forcing
pairings, triple-overlap constraints, an operation-space commutator, and
cyclic parameter descent.

## 1. Obstruction duals and forcing transport

For primal density transport

\[
T e_{n,j}
 =\sum_q\binom{n-p+2j}{q}\lambda^q
 e_{n+q(2k-1),j-qk},
\]

the exact contragredient is

\[
U\epsilon_{m,l}
 =\sum_q\binom{p-m-2l-1}{q}\lambda^q
 \epsilon_{m-q(2k-1),l+qk}.
\]

It satisfies

\[
U^\mathsf TT=I.
\]

The formula was checked on every basis vector of the 114-dimensional `P`,
180-dimensional `Q`, and 300-dimensional equation-density wall
saturations. Consequently left-null obstruction functionals and their
pairings with forcing vectors transport exactly through the ambient chain
map.

## 2. Triple overlap adds real conditions

Through layer 15,

\[
T_\lambda=I+\lambda N+\lambda^2N^2/2.
\]

The old chart and one nonzero transported chart overlap in 89 deformation
dimensions. The intersection of the charts at parameters `0`, `1`, and `-1`
is only 68-dimensional and equals the subspace stable under every wall
parameter.

For the equation density, the corresponding dimensions are 216 and 206.
Thus a two-chart check leaves

\[
\boxed{21\text{ deformation directions}}
\]

and

\[
\boxed{10\text{ equation directions}}
\]

that fail triple-overlap compatibility.

The first-order coefficient overflow has rank 97, but all-parameter stability
imposes 118 independent source conditions. The quadratic wall term therefore
adds 21 independent constraints, even though it creates only 11 new ambient
coefficient coordinates.

## 3. Transporting the layer-four candidate forces a layer-eleven term

Let the layer-four support-admissible field be

\[
f_4=c_0+c_1z+z^2,
\qquad g_4=2c_0z^{-1}+3c_1+4z,
\]

and let the `k=4` wall field be

\[
f_7=2z^{-3},
\qquad g_7=z^{-4}.
\]

Their bracket is the layer-eleven field

\[
f_{11}=18c_0z^{-4}+30c_1z^{-3}+42z^{-2},
\]

\[
g_{11}=6c_0z^{-5}+5c_1z^{-4}.
\]

Its action on the degree-21 face has unavoidable top terms

\[
336\operatorname{lead}(A_0)z^5,
\qquad
504\operatorname{lead}(B_0)z^9.
\]

The stored layer-eleven windows allow no `P` coefficient and only `Q`
exponents `0,...,4`. Therefore carrying the layer-four direction across the
wall requires a genuine adjacent-chart layer-eleven operation coordinate.
The old fixed-chart operation space cannot be used unchanged.

## 4. The F2 wall parameter is a character line

For a cyclic quotient `u=z^g`, the order-`q` `k`-wall term shifts cyclic
character by `-qk`. Equivariance requires

\[
\lambda\mapsto\zeta^k\lambda.
\]

For `F_2`, `g=5` and `k=4`. The parameter has `C_5` character four, and an
invariant scalar effect first returns at wall order five, unweighted normal
shift 35.

If one simultaneously tries to reconcile the public layer-four label with
the bare layer-seven wall, the unique required normal weight is `-3`. The
necessary parameter bidegree is therefore

\[
\boxed{(-3,4\bmod5)}.
\]

This negative Rees weight is chart-moving data, not an ordinary fixed-chart
deformation coordinate.


## 5. Parameter weight alone fails the layer-four kernel test

Assigning weight `-3` to the `k=4` wall parameter changes the bookkeeping
layer from seven to four, but the bare source pair then has exact defect

\[
-3z^{-2}
\]

in the ordinary \(D_4\) weighted-divergence identity.  The unique correction
with the same horizontal component changes

\[
g:z^{-4}\longmapsto -2z^{-4}.
\]

This produces the candidate associated-graded rechart field

\[
t^4(2z^{-3}\partial_z-2z^{-4}t\partial_t),
\]

whose degree-21 action exits the old layer-four window only through the
principal parts `A={-3,-2,-1}` and `B={-2,-1}`.  The remaining task is to
construct the Rees/Euler action producing this correction and compare it with
the archived residual vector.


## 6. The corrected candidate is a Kummer Hamiltonian flow

Using the original affine-coordinate dictionary

\[
t=x^4y,\qquad z=x^7y^2,
\]

the corrected associated-graded field becomes

\[
\boxed{
V=-6x^{-11}y^{-4}\partial_x
  +22x^{-12}y^{-3}\partial_y.
}
\]

It has ordinary divergence zero and is Hamiltonian for

\[
H=2x^{-11}y^{-3}.
\]

With

\[
M=x^{-12}y^{-4}=t^4z^{-4},
\]

one has

\[
V(H)=0,\qquad V(M)=-16M^2.
\]

The exact formal flow is therefore

\[
R^8=1+16sM,
\]

\[
\boxed{
x_s=xR^{-3},\qquad y_s=yR^{11},\qquad
t_s=tR^{-1},\qquad z_s=zR.
}
\]

The binomial root exists formally in the deformation parameter.  It is not,
however, rational over \(K(x,y,s)\): the radicand has valuation one at the
prime \(x^{12}y^4+16s\), whereas an eighth power has valuation divisible by
eight.  The generic algebraic flow therefore requires a degree-eight Kummer
extension.

There is an exact quotient-coordinate linearization.  Put

\[
H=2x^{-11}y^{-3}=\frac{2}{tz},
\qquad
Q=x^{12}y^4=\left(\frac zt\right)^4=M^{-1}.
\]

Then

\[
V(H)=0,
\qquad
V(Q)=16,
\]

so the flow on the quotient is simply

\[
\boxed{H_s=H,\qquad Q_s=Q+16s.}
\]

The exponent-lattice determinant of \((x,y)\mapsto(H,Q)\) is \(-8\), and

\[
x^8=\frac{16}{H^4Q^3},
\qquad
y^8=\frac{H^{12}Q^{11}}{4096}.
\]

Thus the Kummer extension is exactly the inverse of a degree-eight monomial
quotient.  For the `F_2` `C_5` assignment, both \(Q\) and the parameter have
character four, so \(Q\mapsto Q+16s\) is equivariant; lifting back to
\((x,y)\) still requires the independent eighth root.

In the adjacent blowdown variables used by the stored proposition,

\[
u=(xy)^{-1},\qquad v=y,
\]

these quotient coordinates are

\[
H=2u^{11}v^8,
\qquad
Q=u^{-12}v^{-8}.
\]

Therefore

\[
\boxed{K(H,Q)=K(u,v^8).}
\]

The degree-eight quotient is exactly the \(\mu_8\)-quotient of the adjacent
blowdown chart.  The corrected field descends to this quotient, while the bare
`k=4` operation is the translation \(v\mapsto v+s\), which is not the same
quotient operation.  This isolates a precise missing lift in the public
correspondence claim.


The corrected layer-four candidate is therefore an ordinary translation on a
concrete degree-eight quotient chart, but not an ordinary same-function-field
rational wall operation.  A successful complete-chain interpretation would
have to identify this quotient—or another filtration-changing model—with the
actual adjacent presentation.


Because

\[
Q=\left(\frac zt\right)^4
\]

has normal \(t\)-exponent \(-4\), translation in \(Q\) naturally has the
missing layer-four label.  This gives the strongest current repaired
correspondence candidate:

> match the stored layer-four residual to the pullback of the quotient
> translation \(Q\mapsto Q+16s\), not to the bare layer-seven translation
> \(v\mapsto v+s\).

The scalar `16` is a parameter normalization.  What remains is an exact
coefficientwise comparison with the archived residual representative.

## 7. Current boundary

These results provide an exact finite ambient wall groupoid with:

- coefficient transport;
- nonlinear equation transport;
- inverse and additive cocycles;
- residue-dual and forcing transport;
- pairwise and triple-overlap dimensions;
- a required operation-map commutator term;
- cyclic eigenparameter descent;
- the exact weight-only defect and unique corrected layer-four vertical term.

They still do not provide the actual complete-chain monomial adjacent chart,
its presentation stabilizer, or the real `F_2` order-by-order matrices. Those
are now the remaining external inputs rather than undefined linear-algebra
steps.

## 8. Validation

The combined bundle contains 73 exact regression tests, all passing.
