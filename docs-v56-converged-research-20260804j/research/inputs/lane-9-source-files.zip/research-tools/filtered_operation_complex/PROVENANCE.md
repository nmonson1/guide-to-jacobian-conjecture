# Provenance

- PR URL: <https://github.com/nmonson1/guide-to-jacobian-conjecture/pull/1>
- Branch: `agent/p6-chart-correspondence`
- Initial imported head: `d07d7bf5684967f6e4f698dd58a38b52215447b7`
- Complete selectively harvested head: `3736475bfa2e6b02679042b503f8f52cf46c5749`
- Port dates: 2026-07-31 and 2026-08-03
- Status: selectively recovered model-generated source and exact evidence; see
  `private-source/audit-v1/GITHUB_PR_RECOVERY_INTAKE_88C2E9C303E24D1B_2026-07-30.md`
  for the initial boundaries and
  `private-source/audit-v1/PR1_SELECTIVE_HARVEST_2026-08-03.md` for the completed
  result-by-result harvest.

Boundary paragraph, verbatim from the recovery audit:

**Boundary:** the package audits supplied finite-dimensional contracts and the
pinned 115-dimensional Program 5 operation model. It does not construct the
complete stable operation quotient, prove convergence or algebraization,
classify the full row-base fibre, discover all adjacent complete-chain charts,
or solve global `F_2` attachment. The archived upper-face replay and the later
lower-face Proposition C.9 complex also remain distinct.
