#!/usr/bin/env python3
"""Construct and exactly verify an explicit type-IV quartic net.

Requires SymPy 1.14 or compatible.  All calculations are over Q.

The section of T_{P^2}(2) is represented by a cubic triple (P,Q,R),
modulo radial triples h(x,y,z)(x,y,z).  Its zero scheme is the base locus
of the quartic cross-product net

    (q1,q2,q3) = (yR-zQ, zP-xR, xQ-yP).

The checker proves for the chosen triple:
  * the projective base scheme is reduced, has length 13, and misses z=0;
  * no target line divides its associated cubic, so the resolved map is finite;
  * a sample target fibre consists of three distinct points;
  * the ramification determinant is an irreducible degree-9 curve;
  * the branch equation is an irreducible homogeneous decic;
  * its singular Jacobian scheme has length 42, supported at exactly
    21 points, each of local Jacobian length 2;
  * no branch singularity lies on c=0 and the quadratic term never vanishes,
    so the 21 singularities are ordinary A2 cusps.

Use --write-json PATH to save all explicit equations and exact metadata.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Iterable

import sympy as sp


def standard_monomials_length(gb: sp.GroebnerBasis) -> tuple[int, list[tuple[int, ...]]]:
    """Count standard monomials of a zero-dimensional monomial initial ideal."""
    n = len(gb.gens)
    leading = [tuple(poly.LM(order=gb.order).exponents) for poly in gb.polys]
    bounds: list[int] = []
    for axis in range(n):
        pure = [exp[axis] for exp in leading if all(exp[j] == 0 for j in range(n) if j != axis)]
        if not pure:
            raise AssertionError(f"no pure-power leading monomial in axis {axis}: {leading}")
        bounds.append(min(pure))

    standard: list[tuple[int, ...]] = []
    ranges = [range(bound) for bound in bounds]
    import itertools

    for exponent in itertools.product(*ranges):
        if not any(all(exponent[j] >= lm[j] for j in range(n)) for lm in leading):
            standard.append(exponent)
    return len(standard), standard


def common_univariate_gcd(expressions: Iterable[sp.Expr], variable: sp.Symbol) -> sp.Poly:
    polys = [sp.Poly(sp.expand(expr), variable, domain=sp.QQ) for expr in expressions]
    gcd = polys[0]
    for poly in polys[1:]:
        gcd = sp.gcd(gcd, poly)
    return gcd.monic()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--write-json", type=Path, help="write explicit equations and metadata")
    args = parser.parse_args()

    x, y, z = sp.symbols("x y z")
    a, b, c = sp.symbols("a b c")
    t = sp.symbols("t")

    # A deliberately small integral representative of a generic section of T(2).
    P = x**3 + 2 * y**3 + 3 * z**3 + x * y * z + y**2 * z
    Q = 2 * x**3 - y**3 + z**3 + x**2 * z + x * y**2
    R = x**3 + y**3 - 2 * z**3 + x * z**2 + y * z**2 + x**2 * y

    q1 = sp.expand(y * R - z * Q)
    q2 = sp.expand(z * P - x * R)
    q3 = sp.expand(x * Q - y * P)
    quartics = [q1, q2, q3]
    assert all(sp.Poly(q, x, y, z).total_degree() == 4 for q in quartics)
    assert sp.gcd(sp.gcd(sp.Poly(q1, x, y, z), sp.Poly(q2, x, y, z)), sp.Poly(q3, x, y, z)).total_degree() == 0

    # ------------------------------------------------------------------
    # Base scheme: all points lie in z=1; quotient length is 13.
    # ------------------------------------------------------------------
    affine_quartics = [sp.expand(q.subs(z, 1)) for q in quartics]
    base_gb = sp.groebner(affine_quartics, x, y, order="grevlex")
    assert base_gb.is_zero_dimensional
    base_length, base_standard = standard_monomials_length(base_gb)
    assert base_length == 13
    expected_base_leading = {(0, 6), (1, 4), (4, 0), (3, 1), (2, 2)}
    assert {tuple(poly.LM(order=base_gb.order).exponents) for poly in base_gb.polys} == expected_base_leading

    # No base point on z=0.  Check the y=1 chart and the point [1:0].
    infinity_chart = [sp.expand(q.subs({z: 0, y: 1})) for q in quartics]
    assert common_univariate_gcd(infinity_chart, x).degree() == 0
    assert any(sp.expand(q.subs({x: 1, y: 0, z: 0})) != 0 for q in quartics)

    # Reducedness: no base point has Jacobian rank < 2.
    base_jacobian = sp.Matrix(affine_quartics).jacobian([x, y])
    jacobian_minors = [
        sp.expand(base_jacobian[i, 0] * base_jacobian[j, 1] - base_jacobian[i, 1] * base_jacobian[j, 0])
        for i in range(3)
        for j in range(i + 1, 3)
    ]
    reduced_test = sp.groebner(affine_quartics + jacobian_minors, x, y, order="grevlex")
    assert list(reduced_test) == [1]

    # ------------------------------------------------------------------
    # Finiteness of the resolved quartic-net morphism.
    # ------------------------------------------------------------------
    # A target [a:b:c] has fibre away from the base scheme cut out by
    #
    #       a*x+b*y+c*z = 0,
    #       a*P+b*Q+c*R = 0.
    #
    # A positive-dimensional fibre therefore occurs exactly when the first
    # line divides the second cubic. Check that this never happens on the
    # target charts c=1, c=0,b=1, and at [1:0:0].
    restricted_cubic_c1 = sp.expand((a * P + b * Q + R).subs(z, -a * x - b * y))
    restricted_cubic_c1_poly = sp.Poly(restricted_cubic_c1, x, y)
    divisibility_coeffs_c1 = [
        restricted_cubic_c1_poly.coeff_monomial(x**i * y ** (3 - i))
        for i in range(4)
    ]
    assert list(sp.groebner(divisibility_coeffs_c1, a, b, order="grevlex")) == [1]

    restricted_cubic_c0_b1 = sp.Poly(sp.expand((a * P + Q).subs(y, -a * x)), x, z)
    divisibility_coeffs_c0_b1 = [
        restricted_cubic_c0_b1.coeff_monomial(x**i * z ** (3 - i))
        for i in range(4)
    ]
    assert list(sp.groebner(divisibility_coeffs_c0_b1, a, order="grevlex")) == [1]
    assert sp.expand(P.subs(x, 0)) != 0  # target [1:0:0]

    # ------------------------------------------------------------------
    # Sample fibre over [1:2:3].  Saturate by q3 in the z=1 chart.
    # ------------------------------------------------------------------
    saturation_variable = sp.symbols("s")
    fibre_eq1 = sp.expand(3 * affine_quartics[0] - affine_quartics[2])
    fibre_eq2 = sp.expand(3 * affine_quartics[1] - 2 * affine_quartics[2])
    fibre_sat = sp.groebner(
        [fibre_eq1, fibre_eq2, 1 - saturation_variable * affine_quartics[2]],
        saturation_variable,
        x,
        y,
        order="lex",
    )
    fibre_elimination = [
        sp.expand(poly.as_expr())
        for poly in fibre_sat.polys
        if not poly.as_expr().has(saturation_variable)
    ]
    assert len(fibre_elimination) == 2
    assert x + 2 * y + 3 in fibre_elimination
    fibre_cubic = next(expr for expr in fibre_elimination if not expr.has(x))
    fibre_cubic = sp.Poly(fibre_cubic, y, domain=sp.QQ).primitive()[1].as_expr()
    assert sp.Poly(fibre_cubic, y).degree() == 3
    fibre_discriminant = int(sp.discriminant(fibre_cubic, y))
    assert fibre_discriminant == -14858267

    # ------------------------------------------------------------------
    # Ramification in the source plane.
    # ------------------------------------------------------------------
    ramification = sp.expand(sp.Matrix(quartics).jacobian([x, y, z]).det())
    assert sp.Poly(ramification, x, y, z).total_degree() == 9
    ram_constant, ram_factors = sp.factor_list(ramification)
    assert ram_constant == -4
    assert len(ram_factors) == 1 and ram_factors[0][1] == 1
    assert sp.Poly(ram_factors[0][0], x, y, z).total_degree() == 9

    # ------------------------------------------------------------------
    # Branch decic.  A target [a:b:c] corresponds to the line
    # a*x+b*y+c*z=0.  On c=1 use z=-a*x-b*y and restrict aP+bQ+R.
    # Its binary-cubic discriminant is the branch equation.
    # ------------------------------------------------------------------
    restricted_binary_cubic = sp.expand((a * P + b * Q + R).subs(z, -a * x - b * y))
    restricted_univariate = sp.expand(restricted_binary_cubic.subs({x: t, y: 1}))
    assert sp.Poly(restricted_univariate, t).degree() == 3
    branch_affine = sp.Poly(sp.discriminant(restricted_univariate, t), a, b, domain=sp.QQ).primitive()[1].as_expr()
    branch_affine = sp.expand(branch_affine)
    assert sp.Poly(branch_affine, a, b).total_degree() == 10
    branch = sp.Poly(branch_affine, a, b).homogenize(c).as_expr()
    branch = sp.expand(branch)
    assert sp.Poly(branch, a, b, c).total_degree() == 10
    branch_constant, branch_factors = sp.factor_list(branch)
    assert len(branch_factors) == 1 and branch_factors[0][1] == 1
    assert sp.Poly(branch_factors[0][0], a, b, c).total_degree() == 10

    # ------------------------------------------------------------------
    # Singular scheme of the branch in c=1.
    # ------------------------------------------------------------------
    branch_a = sp.expand(branch.subs(c, 1))
    singular_ideal = [branch_a, sp.diff(branch_a, a), sp.diff(branch_a, b)]
    singular_gb = sp.groebner(singular_ideal, a, b, order="grevlex")
    assert singular_gb.is_zero_dimensional
    singular_length, singular_standard = standard_monomials_length(singular_gb)
    assert singular_length == 42

    # FGLM gives a shape basis.  The univariate polynomial is the square of
    # a squarefree degree-21 polynomial: 21 support points, Jacobian length 2 each.
    singular_lex = singular_gb.fglm(order="lex")
    assert len(singular_lex.polys) == 2
    assert sorted(tuple(poly.LM(order=singular_lex.order).exponents) for poly in singular_lex.polys) == [(0, 42), (1, 0)]
    univariate = next(poly for poly in singular_lex.polys if not poly.as_expr().has(a))
    univariate_poly = sp.Poly(univariate.as_expr(), b, domain=sp.QQ)
    squarefree_data = univariate_poly.sqf_list()[1]
    assert len(squarefree_data) == 1
    support_polynomial, multiplicity = squarefree_data[0]
    assert support_polynomial.degree() == 21 and multiplicity == 2
    assert sp.gcd(support_polynomial, support_polynomial.diff()).degree() == 0

    # No singularity on c=0: check b=1 plus [1:0].
    branch_derivatives = [branch, sp.diff(branch, a), sp.diff(branch, b), sp.diff(branch, c)]
    infinity_singular_chart = [sp.expand(expr.subs({c: 0, b: 1})) for expr in branch_derivatives]
    assert common_univariate_gcd(infinity_singular_chart, a).degree() == 0
    assert any(sp.expand(expr.subs({a: 1, b: 0, c: 0})) != 0 for expr in branch_derivatives)

    # The quadratic term is nonzero at every singular point.  Combined with
    # local Jacobian length 2, this identifies every point as an A2 cusp.
    second_derivatives = [
        sp.diff(branch_a, a, 2),
        sp.diff(branch_a, a, b),
        sp.diff(branch_a, b, 2),
    ]
    zero_quadratic_test = sp.groebner(singular_ideal + second_derivatives, a, b, order="grevlex")
    assert list(zero_quadratic_test) == [1]

    # Numerical consistency with type IV.
    assert 16 - base_length == 3  # (4L-sum E_i)^2
    assert math.comb(9, 2) - 21 == 15  # genus of normalization of a 21-cuspidal decic

    print("explicit type-IV quartic net")
    print("  base scheme: reduced length 13, no point at infinity")
    print("  sample fibre [1:2:3]: 3 distinct points")
    print("  fibre cubic:", fibre_cubic)
    print("  ramification: irreducible degree 9")
    print("  branch: irreducible degree 10 with", len(sp.Poly(branch, a, b, c).terms()), "terms")
    print("  branch singular scheme: length 42 on 21 support points")
    print("  singularities: 21 ordinary A2 cusps")
    print("all explicit-net checks: PASS")

    if args.write_json is not None:
        payload = {
            "schema_version": 1,
            "variables": {
                "source": ["x", "y", "z"],
                "target": ["a", "b", "c"],
            },
            "section_TP2_2": {
                "P": str(P),
                "Q": str(Q),
                "R": str(R),
            },
            "quartic_net": {
                "q1": str(q1),
                "q2": str(q2),
                "q3": str(q3),
            },
            "restricted_cubic_c_eq_1": str(restricted_univariate),
            "sample_fibre_1_2_3": {
                "linear_equation": "x + 2*y + 3",
                "cubic_equation": str(fibre_cubic),
                "discriminant": fibre_discriminant,
            },
            "ramification_degree_9": str(ram_factors[0][0]),
            "branch_affine_c_eq_1": str(branch_affine),
            "branch_homogeneous_degree_10": str(branch),
            "certificates": {
                "base_length": base_length,
                "base_standard_monomials": [list(exp) for exp in base_standard],
                "base_reduced": True,
                "resolved_map_finite": True,
                "generic_degree": 3,
                "ramification_irreducible_over_Q": True,
                "branch_irreducible_over_Q": True,
                "branch_singular_jacobian_length": singular_length,
                "branch_singular_support_degree": support_polynomial.degree(),
                "branch_local_jacobian_multiplicity": multiplicity,
                "branch_cusp_count": 21,
                "support_polynomial_in_b": str(support_polynomial.as_expr()),
            },
        }
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        payload["canonical_sha256"] = sha256_text(canonical)
        args.write_json.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print("wrote", args.write_json)
        print("canonical data sha256:", payload["canonical_sha256"])


if __name__ == "__main__":
    main()
