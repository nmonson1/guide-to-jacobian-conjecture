#!/usr/bin/env python3
"""Exact root-difference certificates for the marked-root P1-T1 model.

At any omitted value on the triple-root curve, the completed S_3 normalization
is C[[u,v,lambda]].  This script verifies the invariant map, the three root
slopes, the S_3 permutation action, and the equality of the chart-complement
ideal with (u,v)^2.

The final saturation statement uses the reader proof that
H^2_(u,v)(C[[u,v,lambda]]) is lambda-torsion-free; that local-cohomology fact
is recorded but is not replaced by a finite computation.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

import sympy as sp


def assert_zero(expr: sp.Expr, message: str = "") -> None:
    value = sp.factor(sp.cancel(sp.expand(expr)))
    if value != 0:
        raise AssertionError(message or f"expected zero, got {value}")


def substitute_linear(expr: sp.Expr, image_u: sp.Expr, image_v: sp.Expr) -> sp.Expr:
    u, v = sp.symbols("u v")
    return sp.expand(expr.subs({u: image_u, v: image_v}, simultaneous=True))


def main() -> None:
    u, v, lam, x = sp.symbols("u v lambda x")

    # Ordered depressed roots: u=alpha_1-alpha_2, v=alpha_2-alpha_3.
    alpha_1 = sp.Rational(1, 3) * (2 * u + v)
    alpha_2 = sp.Rational(1, 3) * (-u + v)
    alpha_3 = sp.Rational(1, 3) * (-u - 2 * v)
    roots = (alpha_1, alpha_2, alpha_3)
    assert_zero(sum(roots), "root sum")

    p = sp.factor(-(alpha_1 * alpha_2 + alpha_1 * alpha_3 + alpha_2 * alpha_3) / 3)
    h = sp.factor(alpha_1 * alpha_2 * alpha_3 / 2)
    assert_zero(p - (u**2 + u * v + v**2) / 9, "p invariant")
    assert_zero(
        h - (u - v) * (u + 2 * v) * (2 * u + v) / 54,
        "h invariant",
    )

    cubic = x**3 - 3 * p * x - 2 * h
    for index, root in enumerate(roots, start=1):
        assert_zero(cubic.subs(x, root), f"root alpha_{index}")

    # The three source-sheet boundary functions are the root derivatives,
    # up to the common unit 9c.
    q_1 = sp.factor(3 * (alpha_1**2 - p))
    q_2 = sp.factor(3 * (alpha_2**2 - p))
    q_3 = sp.factor(3 * (alpha_3**2 - p))
    assert_zero(q_1 - u * (u + v), "first root slope")
    assert_zero(q_2 + u * v, "second root slope")
    assert_zero(q_3 - v * (u + v), "third root slope")

    # The actual chart-complement ideal is exactly the square of the transverse
    # maximal ideal.
    g_chart = sp.groebner([q_1, q_2, q_3], u, v, order="lex", domain=sp.QQ)
    g_square = sp.groebner([u**2, u * v, v**2], u, v, order="lex", domain=sp.QQ)
    assert g_chart == g_square
    assert_zero(q_1 + q_2 - u**2, "u^2 certificate")
    assert_zero(q_3 + q_2 - v**2, "v^2 certificate")

    # Triple-intersection denominator and discriminant.
    product = sp.factor(q_1 * q_2 * q_3)
    assert_zero(product + u**2 * v**2 * (u + v) ** 2, "triple denominator")
    discriminant = sp.discriminant(cubic, x)
    assert_zero(
        discriminant - u**2 * v**2 * (u + v) ** 2,
        "ordered-root discriminant",
    )

    # S_3 on the standard root-difference plane.
    # s=(12): (u,v)->(-u,u+v)
    # r=(123): (u,v)->(v,-u-v)
    s_u, s_v = -u, u + v
    r_u, r_v = v, -u - v

    # Relations s^2=r^3=1 and srs=r^{-1}.
    S = sp.Matrix([[-1, 0], [1, 1]])
    R = sp.Matrix([[0, 1], [-1, -1]])
    identity = sp.eye(2)
    assert S**2 == identity
    assert R**3 == identity
    assert S * R * S == R.inv()

    ss_u = substitute_linear(s_u, s_u, s_v)
    ss_v = substitute_linear(s_v, s_u, s_v)
    assert_zero(ss_u - u, "s^2 on u")
    assert_zero(ss_v - v, "s^2 on v")

    rr_u = substitute_linear(r_u, r_u, r_v)
    rr_v = substitute_linear(r_v, r_u, r_v)
    rrr_u = substitute_linear(rr_u, r_u, r_v)
    rrr_v = substitute_linear(rr_v, r_u, r_v)
    assert_zero(rrr_u - u, "r^3 on u")
    assert_zero(rrr_v - v, "r^3 on v")

    # Invariants p,h are fixed by both generators.
    for name, invariant in (("p", p), ("h", h)):
        assert_zero(substitute_linear(invariant, s_u, s_v) - invariant, f"s fixes {name}")
        assert_zero(substitute_linear(invariant, r_u, r_v) - invariant, f"r fixes {name}")

    # The three slope functions are permuted exactly as the source charts.
    assert_zero(substitute_linear(q_1, s_u, s_v) - q_2, "s(q1)=q2")
    assert_zero(substitute_linear(q_2, s_u, s_v) - q_1, "s(q2)=q1")
    assert_zero(substitute_linear(q_3, s_u, s_v) - q_3, "s(q3)=q3")
    assert_zero(substitute_linear(q_1, r_u, r_v) - q_2, "r(q1)=q2")
    assert_zero(substitute_linear(q_2, r_u, r_v) - q_3, "r(q2)=q3")
    assert_zero(substitute_linear(q_3, r_u, r_v) - q_1, "r(q3)=q1")

    # The target maximal ideal (p,h,lambda) pulls back to an ideal whose radical
    # is (u,v,lambda).  A finite certificate is (u,v)^4 subset (p,h).
    p_integral = sp.expand(9 * p)
    h_integral = sp.expand(54 * h)
    g_invariants = sp.groebner(
        [p_integral, h_integral], u, v, order="lex", domain=sp.QQ
    )
    for i in range(5):
        monomial = u**i * v ** (4 - i)
        assert_zero(
            g_invariants.reduce(monomial)[1],
            f"degree-four radical certificate for {monomial}",
        )

    # The Cech quotient is H^2_(u,v)(C[[u,v,lambda]]) and has the monomial
    # decomposition direct_sum_{i,j>=1} C[[lambda]] u^{-i}v^{-j}.  Therefore
    # multiplication by lambda is injective, so its (p,h,lambda)-power torsion
    # vanishes.  This establishes I^sat/I=0 in the reader proof.

    print("completed Galois ring = C[[u,v,lambda]]")
    print("root slopes =", q_1, q_2, q_3)
    print("verified chart ideal = (u,v)^2")
    print("verified pair/triple chart denominators and S_3 permutation action")
    print("verified radical pullback: (u,v)^4 is contained in (p,h)")
    print("reader proof: lambda is injective on H^2_(u,v), hence I^sat/I=0")
    print("therefore the closed-point standard-isotypic saturation quotient is zero")
    path = Path(__file__)
    print("script_sha256 =", hashlib.sha256(path.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
