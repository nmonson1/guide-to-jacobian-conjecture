# P1-T1 research attempt: an elliptic-cone model with nonzero standard saturation

## Status

This note constructs a **complete negative local model in the category of normal
finite \(S_3\)-algebras with three conjugate affine simple-root charts**.
It has

\[
I^{\mathrm{sat}}/I\cong V_{\mathrm{std}}\neq 0,
\qquad
\Delta_B\cong \mathbf C,
\]

and supplies the cubic algebra, its \(S_3\)-Galois closure, multiplication,
involutions, source-base-change splitting, quadratic resolvent, singular
height-two primes, eigensheaf, and local class vector.

It is **not** a Keller counterexample: the affine source chart constructed below
is smooth and étale over its image but is not identified with \(\mathbf A^3\),
and no polynomial coordinate system with constant Jacobian is supplied.
Consequently, the construction shows that the normal \(S_3\) algebra and
source-splitting identities alone do not force saturation. Any proof for Keller
maps must use genuinely global \(\mathbf A^3\) input.

---

## 1. The ordered-root surface

Let

\[
E=V(x^3+y^3+z^3)\subset \mathbf P^2_{\mathbf C}
\]

be the Fermat cubic, with a flex chosen as the origin \(0_E\). Then
\(\mathcal O_E(1)\simeq \mathcal O_E(3\cdot 0_E)\), and the dual plane

\[
Y=|\mathcal O_E(1)|\simeq \mathbf P^2
\]

parametrizes line sections of \(E\).

Define

\[
Z=\{(p_1,p_2,p_3)\in E^3:p_1+p_2+p_3=0_E\}.
\]

The map \((p_1,p_2)\mapsto(p_1,p_2,-p_1-p_2)\) identifies \(Z\) with the
abelian surface \(E^2\). The group \(G=S_3\) acts by permuting the three
coordinates. Sending an ordered triple to its line section gives a finite
quotient map

\[
\pi:Z\longrightarrow Z/S_3=Y.
\]

Indeed, an effective divisor \(p_1+p_2+p_3\) is cut by a line precisely when it
is linearly equivalent to \(3\cdot0_E\), equivalently when
\(p_1+p_2+p_3=0_E\).

Let \(H_i\leq S_3\) be the transposition subgroup stabilizing the label \(i\).
Then

\[
X_i:=Z/H_i
\]

is the marked-root incidence surface

\[
X_i\simeq\{(p,\ell)\in E\times Y:p\in \ell\}.
\]

It is a \(\mathbf P^1\)-bundle over \(E\), hence smooth, and the map
\(f_i:X_i\to Y\) is finite flat of degree three.

Put \(M=\pi^*\mathcal O_Y(1)\), and form the full section rings

\[
A_0=\bigoplus_{n\geq0}H^0(Y,\mathcal O_Y(n))=\mathbf C[a,b,c],
\]

\[
T_0=\bigoplus_{n\geq0}H^0(Z,M^n),
\qquad
B_{i,0}=T_0^{H_i},
\qquad
Q_0=T_0^{A_3}.
\]

These are finite normal graded \(A_0\)-algebras, with generic ranks
\(6,3,2\), respectively, and

\[
T_0^{S_3}=A_0.
\]

Normality follows because the full section ring of a Cartier divisor on a
normal variety is an intersection of the corresponding divisorial valuation
rings inside \(\mathbf C(Z)[t,t^{-1}]\).

Let \(\mathfrak m=(a,b,c)\), let \(\mathfrak n=T_{0,+}\), and complete the
localizations at the cone vertices:

\[
A=\widehat{(A_0)_{\mathfrak m}}\simeq\mathbf C[[a,b,c]],
\quad
T=\widehat{(T_0)_{\mathfrak n}},
\quad
B_i=T^{H_i},
\quad
Q=T^{A_3}.
\]

The generic extension \(\operatorname{Frac}(T)/\operatorname{Frac}(A)\) is
Galois with group \(S_3\), and \(B_i\) is the corresponding non-Galois cubic
subalgebra.

---

## 2. The cubic algebra and its minimal defect

Let \(X=X_i\), \(f=f_i\). The incidence divisor in \(E\times Y\) is cut by the
universal section of
\(\mathcal O_E(1)\boxtimes\mathcal O_Y(1)\), so

\[
0\to
\mathcal O_E(-1)\boxtimes\mathcal O_Y(-1)
\to\mathcal O_{E\times Y}
\to\mathcal O_X\to0.
\]

Push forward to \(Y\). Since

\[
h^0(E,\mathcal O_E(-1))=0,
\quad
h^1(E,\mathcal O_E(-1))=3,
\quad
h^0(E,\mathcal O_E)=h^1(E,\mathcal O_E)=1,
\]

and \(f\) is finite, the resulting exact sequence is

\[
0\to\mathcal O_Y\to f_*\mathcal O_X
\to\mathcal O_Y(-1)^3\xrightarrow{(a,b,c)}\mathcal O_Y\to0.
\]

The kernel of the displayed Euler map is \(\Omega_Y^1\). The trace splits the
unit inclusion, hence

\[
f_*\mathcal O_X\simeq\mathcal O_Y\oplus\Omega_Y^1.
\]

Consequently, as a graded \(A_0\)-module,

\[
B_{i,0}\simeq A_0\oplus N,
\qquad
N=\bigoplus_{n\geq0}H^0(Y,\Omega_Y^1(n)).
\]

The Euler sequence identifies

\[
N=\ker\bigl(A_0(-1)^3\xrightarrow{(a,b,c)}A_0\bigr)
  =\Omega^2_{A_0}(\mathbf C),
\]

and the Koszul complex gives the minimal presentation

\[
0\to A_0(-3)\longrightarrow A_0(-2)^3\longrightarrow N\to0.
\]

After completion and forgetting grading, the trace-zero module \(E_i\) of
\(B_i=A\oplus E_i\) therefore has a presentation

\[
0\to A\xrightarrow{\Phi}A^3\to E_i\to0,
\]

where, after choosing a Koszul basis, \(\Phi\) is a column formed by the regular
parameters \(a,b,c\). Dualizing gives

\[
\operatorname{Ext}^1_A(E_i,A)
 \simeq A/(a,b,c)\simeq\mathbf C.
\]

Thus

\[
\boxed{\Delta_{B_i}=\operatorname{Ext}^1_A(B_i,A)\simeq\mathbf C.}
\]

This is the one-generator defect stratum. In particular,

\[
\dim_{\mathbf C}(B_i/\mathfrak mB_i)=4,
\]

and the trace-zero part of the closed fibre is a three-dimensional square-zero
ideal. The algebra is free away from the vertex and is nonflat only there.

The multiplication is not being specified by an abstract module ansatz. It is
the ordinary section-ring multiplication. Equivalently, if

\[
0\to K\to H^0(E,\mathcal O_E(1))\otimes\mathcal O_E
   \xrightarrow{\mathrm{ev}}\mathcal O_E(1)\to0,
\]

then the marked-root affine incidence space is the total space of \(K\), and

\[
B_{i,0}=\Gamma\bigl(E,\operatorname{Sym}K^\vee\bigr)
\]

with its usual symmetric-algebra multiplication. This gives a complete,
algorithmic algebra definition.

---

## 3. Equivariant decomposition and the quadratic resolvent

The generic fibre of \(\pi_*\mathcal O_Z\) is the regular representation of
\(S_3\). Equivariant idempotents split it as

\[
\pi_*\mathcal O_Z
\simeq
\mathcal O_Y\otimes\mathbf 1
\oplus \mathcal F_{\mathrm{sgn}}\otimes\mathrm{sgn}
\oplus \Omega_Y^1\otimes V_{\mathrm{std}}.
\]

The standard multiplicity bundle is \(\Omega_Y^1\) because taking
\(H_i\)-invariants must recover
\(\mathcal O_Y\oplus\Omega_Y^1\).

The quotient \(Z/A_3\to Y\) is a double cover branched along the dual sextic
\(E^\vee\). Hence

\[
\mathcal F_{\mathrm{sgn}}\simeq\mathcal O_Y(-3).
\]

For the Fermat cubic, the dual sextic has equation

\[
d(a,b,c)=a^6+b^6+c^6
 -2a^3b^3-2a^3c^3-2b^3c^3.
\]

Indeed, the tangent line at \([x:y:z]\in E\) has dual coordinates
\([x^2:y^2:z^2]\), and

\[
d(x^2,y^2,z^2)=
(x^3-y^3-z^3)(x^3-y^3+z^3)
(x^3+y^3-z^3)(x^3+y^3+z^3).
\]

Therefore

\[
\boxed{Q\simeq A[w]/(w^2-d),}
\]

up to rescaling \(w\) by a unit.

As an \(A_0[S_3]\)-module,

\[
T_0\simeq
A_0\otimes\mathbf1
\oplus A_0(-3)\otimes\mathrm{sgn}
\oplus N\otimes V_{\mathrm{std}}.
\]

Restricting \(V_{\mathrm{std}}\) to \(A_3=C_3\) gives the two nontrivial
characters \(\chi,\chi^{-1}\). Thus

\[
T=Q\oplus L\oplus L^{[2]},
\qquad
L^{[3]}\simeq Q,
\]

where, as an \(A\)-module, each of \(L,L^{[2]}\) is isomorphic to the completed
module \(N\). In particular,

\[
0\to A\to A^3\to L\to0,
\qquad
\operatorname{Ext}^1_A(L,A)\simeq\mathbf C,
\]

so \(L\) has depth two and is not maximal Cohen--Macaulay over \(Q\).
A transposition interchanges \(L\) and \(L^{[2]}\), giving
\(\sigma^*L\simeq L^\vee\).

### The nine singular curves

The derivatives of \(d\) are

\[
\begin{aligned}
 d_a&=6a^2(a^3-b^3-c^3),\\
 d_b&=-6b^2(a^3-b^3+c^3),\\
 d_c&=-6c^2(a^3+b^3-c^3).
\end{aligned}
\]

The projective singular points of \(E^\vee\) are

\[
[1:\rho:0],\quad[1:0:\rho],\quad[0:1:\rho],
\qquad \rho^3=1.
\]

Hence the height-two singular primes of the completed threefold \(Q\) are

\[
\begin{aligned}
\mathfrak p_{ab,\rho}&=(w,c,b-\rho a),\\
\mathfrak p_{ac,\rho}&=(w,b,c-\rho a),\\
\mathfrak p_{bc,\rho}&=(w,a,c-\rho b),
\end{aligned}
\qquad \rho^3=1.
\]

At the generic point of each curve the transverse equation is \(A_2\): after
choosing a unit parameter along the curve, the branch equation begins with
\(9u^2-4v^3\), so the double cover is analytically equivalent to

\[
UV-v^3=0.
\]

The \(A_3\)-fixed points on \(Z\) are the nine triples \((p,p,p)\) with
\(3p=0_E\). On the tangent plane, a generator of \(A_3\) has eigenvalues
\(\zeta,\zeta^{-1}\). Thus the two eigensheaves localize to the two nonzero
classes of

\[
\operatorname{Cl}(A_2)\simeq\mathbf Z/3.
\]

After choosing the \(\chi\)-orientation consistently, the local class vector is

\[
\boxed{([L_{\mathfrak p}])_{\mathfrak p}=(1,1,1,1,1,1,1,1,1)
\in(\mathbf Z/3)^9,}
\]

while \(L^{[2]}\) has the negative vector.

The extension \(T/Q\) is unramified in codimension one: the fixed locus of
\(A_3\) on \(Z\) is finite, so on the affine cone it consists of the nine
height-two curves above.

---

## 4. Three conjugate affine source charts

Write

\[
\Delta_{ij}=\{p_i=p_j\}\subset Z.
\]

For the chart in which root \(i\) is marked, ramification occurs exactly when
that root collides with one of the other two. Define

\[
D_1=\Delta_{12}+\Delta_{13},\qquad
D_2=\Delta_{12}+\Delta_{23},\qquad
D_3=\Delta_{13}+\Delta_{23}.
\]

The divisors are permuted by \(S_3\), and \(D_i\) is invariant under \(H_i\).
The two elliptic curves occurring in each \(D_i\) meet transversely in the nine
points \((p,p,p)\), \(p\in E[3]\). Hence

\[
D_i^2=2\cdot9=18>0,
\]

and the sum of the two elliptic subgroup divisors is ample. Therefore
\(Z\setminus|D_i|\) is affine.

Let \(T^\times\) be the punctured affine cone. Its map to \(Z\) is the
\(\mathbf G_m\)-bundle associated with \(M^{-1}\). Define

\[
U_i=T^\times\big|_{Z\setminus|D_i|}.
\]

Each \(U_i\) is affine, the three are \(S_3\)-conjugate, and

\[
X_i^\circ:=U_i/H_i
\]

is an affine open in the cubic quotient. Let

\[
\widetilde S_i=\Gamma(U_i,\mathcal O),
\qquad
S_i=\widetilde S_i^{H_i}=\Gamma(X_i^\circ,\mathcal O).
\]

On \(X_i^\circ\), the marked root is simple, so the diagonal is open and
closed in the base change of the cubic cover. Consequently the complete
source-base-change identity is

\[
\boxed{B_i\otimes_A S_i\simeq S_i\times\widetilde S_i.}
\]

The first factor is the marked root. The second factor is the normal quadratic
algebra ordering the two residual roots; it may ramify when the two unmarked
roots collide. The transposition in \(H_i\) is its involution.

For \(i\neq j\),

\[
U_i\cap U_j
=T^\times\big|_{Z\setminus
 (\Delta_{12}\cup\Delta_{13}\cup\Delta_{23})},
\]

because two different marked roots can both be simple only when all three
roots are distinct. Thus all pair intersections, and the triple intersection,
are the same fully ordered distinct-root algebra. They are affine because the
complement is an ample divisor.

At the level of finite collision algebras, the standard double-coset
calculation gives

\[
\boxed{(B_i\widehat\otimes_A B_i)^\nu\simeq B_i\times T.}
\]

The first factor is the diagonal pair and the second is the off-diagonal
ordered pair. The normalization of the pairwise-distinct component of
\(B_i^{\widehat\otimes_A3}\) is \(T\). The factor-swap involution on a pair is
root exchange, and the \(S_3\)-action on the triple factor is ordinary
permutation of the ordered roots.

This identifies both the pair and triple collision carriers. The raw collision
rings are the corresponding finite tensor-product subalgebras of
\(B_i\times T\) and \(T\); all multiplication maps are inherited from the
section rings above.

---

## 5. The local collision ideal is the standard one

The common intersection of the supports of \(D_1,D_2,D_3\) is

\[
\Delta_{12}\cap\Delta_{13}
=\{(p,p,p):p\in E[3]\},
\]

so there are nine triple-collision points on \(Z\), hence nine collision axes
in the affine cone.

At one such point, use the characteristic-zero formal logarithm on \(E\) so
that the local group law is additive. Put

\[
u=t_1-t_2,\qquad v=t_2-t_3.
\]

Up to units, local equations for the three chart complements are

\[
 f_1=u(u+v),\qquad
 f_2=uv,\qquad
 f_3=v(u+v).
\]

They generate

\[
(f_1,f_2,f_3)=(u^2,uv,v^2)=(u,v)^2.
\]

Thus every generic collision axis is exactly the standard ordered-root model.
In particular, no defect is created by any one axis separately. The nonzero
closed-point class below comes from the global way the nine axes are glued
through the cone vertex.

---

## 6. Direct computation of the saturation quotient

Let

\[
W=\overline{\{\text{the nine triple-collision axes}\}}
\subset\operatorname{Spec}T,
\qquad
U=U_1\cup U_2\cup U_3=\operatorname{Spec}T\setminus W.
\]

All nonempty intersections of the \(U_i\) are affine, so their affine Cech
complex computes \(H^1(U,\mathcal O_U)\). Write

\[
K=\ker(d_1),\qquad I=\operatorname{im}(d_0).
\]

Then

\[
K/I=H^1(U,\mathcal O_U).
\]

Because \(T\) is normal and \(W\) has pure codimension two,

\[
H_W^0(T)=H_W^1(T)=0,
\]

and the localization sequence gives

\[
K/I\simeq H_W^2(T).
\]

Let \(\mathfrak n\) be the cone maximal ideal. Since
\(\sqrt{\mathfrak mT}=\mathfrak n\), saturation by \(\mathfrak m\) is the same
as saturation by \(\mathfrak n\), and

\[
I^{\mathrm{sat}}/I
=H^0_{\mathfrak n}(K/I)
=H^0_{\mathfrak n}(H_W^2(T)).
\]

The support spectral sequence

\[
H^p_{\mathfrak n}(H^q_W(T))\Longrightarrow H^{p+q}_{\mathfrak n}(T)
\]

has no terms with \(q<2\). Its total-degree-two edge map is therefore an
isomorphism:

\[
H^0_{\mathfrak n}(H_W^2(T))\simeq H^2_{\mathfrak n}(T).
\]

For a section ring of an ample line bundle on a projective surface,

\[
[H^2_{\mathfrak n}(T_0)]_q\simeq H^1(Z,M^q).
\]

Since \(Z\) is an abelian surface, \(K_Z\simeq\mathcal O_Z\). Kodaira vanishing
for \(q>0\), followed by Serre duality for \(q<0\), gives

\[
H^1(Z,M^q)=0\quad(q\neq0),
\qquad
H^1(Z,\mathcal O_Z)\simeq\mathbf C^2.
\]

Hence \(H^2_{\mathfrak n}(T)\) is a length-two module killed by
\(\mathfrak n\).

The \(S_3\)-representation on it is standard. Indeed,
\(Z=\ker(E^3\xrightarrow{+}E)\), so \(H^1(Z,\mathcal O_Z)\) is the quotient of
the three-dimensional permutation representation by its diagonal trivial
line. Therefore

\[
\boxed{
I^{\mathrm{sat}}/I
\simeq H^1(Z,\mathcal O_Z)
\simeq V_{\mathrm{std}}.
}
\]

In particular,

\[
\boxed{\operatorname{length}_A(I^{\mathrm{sat}}/I)=2.}
\]

Taking \(H_i\)-invariants gives a one-dimensional fixed line:

\[
(I^{\mathrm{sat}}/I)^{H_i}\simeq\mathbf C
\simeq\operatorname{MatlisDual}(\Delta_{B_i}),
\]

exactly matching

\[
I^{\mathrm{sat}}/I
\simeq\operatorname{MatlisDual}(\Delta_{B_i})
\otimes V_{\mathrm{std}}
\]

in this model.

---

## 7. What this does and does not settle

### Established by the model

1. A normal rank-six \(S_3\)-algebra over \(A=\mathbf C[[a,b,c]]\).
2. A normal non-Galois cubic quotient \(B_i\) with the minimal defect
   \(\Delta_{B_i}\simeq\mathbf C\).
3. A quadratic resolvent
   \(Q=A[w]/(w^2-d)\) with nine explicit height-two \(A_2\) curves.
4. A rank-one reflexive eigensheaf \(L\), its finite presentation, involution,
   and local class vector \((1,\ldots,1)\).
5. Three \(S_3\)-conjugate affine simple-root source charts.
6. The full diagonal/off-diagonal source-base-change splitting.
7. Pair and pairwise-distinct triple collision normalizations.
8. Standard local collision ideals \((u,v)^2\) along every collision axis.
9. A nonzero closed-point standard-isotypic saturation quotient
   \(V_{\mathrm{std}}\).

### Not established

The chart \(X_i^\circ\) is not shown to be \(\mathbf A^3\), and the map to the
base is not supplied by three polynomial coordinates with constant nonzero
Jacobian. Thus this is not a Keller map and does not refute saturation in the
Keller category.

The conclusion is narrower but useful:

> Normality, \(S_3\)-monodromy, codimension-one unramifiedness of the cyclic
> resolvent cover, the canonical marked-root factor, and the complete
> three-chart simple-root algebra do not by themselves force
> \(I^{\mathrm{sat}}=I\).

A Keller-specific proof must use at least one additional global property of the
actual source \(\mathbf A^3\), such as its factoriality, unit group, boundary
incidence, or a consequence of the constant-Jacobian condition that excludes
this elliptic-cone gluing.

---

## 8. Reproducibility note about the public packet

The public Lane 1 page says that the linked packet defines the collision Cech
complex and proves the saturation-carrier theorem. In the currently published
packet, however, the displayed `flatness-defect-repairs.tex` ends with the
resolvent/ADE task, and the remaining two files are the idempotent and standard
local-model checkers. The exact Cech definitions do not appear in the public
text. Accordingly, the construction above uses the natural affine Cech complex
of the three conjugate simple-root charts and independently computes its
closed-point saturation quotient. Matching notation line-by-line to the
private proof packet requires publication of the omitted Cech definition.
