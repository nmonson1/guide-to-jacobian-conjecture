# Lane 1 explicit models and homogeneous gate

This versioned packet records three separate pieces of reusable mathematics:

- an exact marked-root benchmark whose finite completion is flat and whose closed-point collision-saturation quotient vanishes;
- an elliptic-cone example showing that normal cubic data, source splitting, and transverse \(A_2\) carriers do not by themselves force the collision quotient to vanish; and
- the smooth homogeneous one-generator reduction, its surviving type-IV triple-plane family, and an explicit type-IV test object.

The latter two are not polynomial Keller maps. They are boundary and necessity tests for the Lane 1 problem.

## Exact sources

- `explicit-marked-root-benchmark.tex`
- `explicit-marked-root-collision-saturation.tex`
- `elliptic-cone-negative-model.md`
- `TYPEIV_GATE.md`

The Python files replay the polynomial, matrix-factorization, conductor, branch, cusp, and collision identities. The immutable replay record is `/path/to/versioned-artifact`.

## Literature input

The type-IV identification uses D. Faenzi, F. Polizzi, and J. Vallès, *Triple planes with \(p_g=q=0\)*, especially Proposition 3.7 and Proposition 2.4, together with R. Miranda, *Triple covers in algebraic geometry* for the cubic-cover construction.

## Scope boundary

The explicit marked-root benchmark proves vanishing only for that completed family. The elliptic and type-IV cones are not Keller realizations. The type-IV reduction assumes that the projectivized cubic cover is smooth; singular projectivizations require a separate analysis.
