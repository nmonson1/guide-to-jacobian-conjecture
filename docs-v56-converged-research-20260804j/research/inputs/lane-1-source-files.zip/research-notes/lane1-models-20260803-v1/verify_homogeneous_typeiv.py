#!/usr/bin/env python3
"""Exact checks for the P1-T1 homogeneous/type-IV reduction.

The script verifies:
  * graded one-generator numerical formulas;
  * the stable-birational d=4 survivor table;
  * type-IV intersection, ramification, and genus data;
  * the 13-element boundary basis and canonical coordinates;
  * boundary/nonproperness component lower bounds;
  * the Hodge-polynomial failure of the natural invariant opening.

Optionally, a JSON file can supply 13 candidate boundary classes in the
Picard basis [L,E1,...,E13]. The verifier checks that they form a basis of
Pic(X)/Z H and, when ramification data are supplied, that their weighted
ramified sum equals R modulo H.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

import sympy as sp


N_EXCEPTIONAL = 13
RANK_PIC = 1 + N_EXCEPTIONAL


def col(values: list[int]) -> sp.Matrix:
    if len(values) != RANK_PIC:
        raise ValueError(f"expected {RANK_PIC} coordinates, got {len(values)}")
    return sp.Matrix(values)


def intersection(x: sp.Matrix, y: sp.Matrix) -> sp.Integer:
    """Intersection form diag(1,-1,...,-1) on Bl_13(P^2)."""
    return sp.Integer(x[0] * y[0] - sum(x[i] * y[i] for i in range(1, RANK_PIC)))


def h0_projective_O(n: int) -> int:
    return math.comb(n + 2, 2) if n >= 0 else 0


def h0_tangent(n: int) -> int:
    """h^0(P^2,T(n)), from 0 -> O(n) -> O(n+1)^3 -> T(n) -> 0."""
    return 3 * h0_projective_O(n + 1) - h0_projective_O(n)


def graded_row(d: int) -> dict[str, int]:
    if d < 3:
        building = 0
    else:
        building = 2 * (d + 2) * (d - 2)
    q = 1 if d == 3 else 0
    pg = h0_tangent(d - 6)
    return {
        "d": d,
        "defect_weight": d - 3,
        "c1": 2 * d - 3,
        "c2": d * d - 3 * d + 3,
        "branch_degree": 4 * d - 6,
        "building_dimension": building,
        "q": q,
        "pg": pg,
        "K2": 5 * d * d - 39 * d + 72,
    }


def quotient_coordinates(
    vector: sp.Matrix, H: sp.Matrix, boundary: list[sp.Matrix]
) -> tuple[int, list[int]]:
    """Solve vector = h_coeff*H + sum boundary_coeff_i*D_i over Z."""
    matrix = sp.Matrix.hstack(H, *boundary)
    solution = matrix.inv() * vector
    if any(not entry.is_Integer for entry in solution):
        raise AssertionError(f"non-integral coordinates: {list(solution)}")
    return int(solution[0]), [int(entry) for entry in solution[1:]]


def verify_candidate(path: Path, H: sp.Matrix, R: sp.Matrix) -> None:
    data: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    raw_classes = data.get("boundary_classes")
    if not isinstance(raw_classes, list) or len(raw_classes) != 13:
        raise ValueError("candidate JSON must contain exactly 13 boundary_classes")
    boundary = [col([int(v) for v in raw]) for raw in raw_classes]
    matrix = sp.Matrix.hstack(H, *boundary)
    determinant = int(matrix.det())
    if abs(determinant) != 1:
        raise AssertionError(
            "candidate classes do not form a Z-basis of Pic(X)/Z H; "
            f"augmented determinant is {determinant}"
        )

    ramified_indices = data.get("ramified_indices")
    if ramified_indices is not None:
        if not isinstance(ramified_indices, list):
            raise ValueError("ramified_indices must be a list")
        multiplicities = data.get("ramification_multiplicities", [1] * len(ramified_indices))
        if len(multiplicities) != len(ramified_indices):
            raise ValueError("ramification multiplicities have wrong length")
        ram_sum = sp.zeros(RANK_PIC, 1)
        for index, multiplicity in zip(ramified_indices, multiplicities, strict=True):
            index = int(index)
            if not 0 <= index < 13:
                raise ValueError(f"ramified index {index} is outside [0,12]")
            ram_sum += int(multiplicity) * boundary[index]
        _, coords = quotient_coordinates(ram_sum - R, H, boundary)
        if any(coords):
            raise AssertionError("weighted ramified sum is not R modulo H")

    print(f"candidate {path}: PASS (det={determinant})")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--candidate",
        type=Path,
        help="optional JSON candidate with 13 boundary classes",
    )
    args = parser.parse_args()

    # Picard basis [L,E1,...,E13].
    L = col([1] + [0] * N_EXCEPTIONAL)
    exceptional = [
        col([0] + [1 if j == i else 0 for j in range(N_EXCEPTIONAL)])
        for i in range(N_EXCEPTIONAL)
    ]
    H = 4 * L - sum(exceptional, sp.zeros(RANK_PIC, 1))
    K = -3 * L + sum(exceptional, sp.zeros(RANK_PIC, 1))
    R = K + 3 * H

    # Graded table and stable-birational survivor.
    rows = [graded_row(d) for d in range(3, 9)]
    assert rows[0]["building_dimension"] == 10
    assert rows[1]["building_dimension"] == 24
    survivors = [row["d"] for row in rows if row["q"] == 0 and row["pg"] == 0]
    assert survivors == [4], survivors

    # Type-IV intersection data.
    assert intersection(H, H) == 3
    assert intersection(K, K) == -4
    assert intersection(H, K) == 1
    assert R == 9 * L - 2 * sum(exceptional, sp.zeros(RANK_PIC, 1))
    assert intersection(H, R) == 10
    assert intersection(R, R) == 29
    assert intersection(K, R) == -1
    genus_H = 1 + (intersection(H, H) + intersection(H, K)) // 2
    genus_R = 1 + (intersection(R, R) + intersection(R, K)) // 2
    assert genus_H == 3
    assert genus_R == 15
    assert math.comb(10 - 1, 2) - 21 == genus_R  # decic with 21 cusps

    # Effective boundary basis [R,E1,...,E12].
    natural_boundary = [R, *exceptional[:12]]
    augmented = sp.Matrix.hstack(H, *natural_boundary)
    determinant = int(augmented.det())
    assert determinant == 1
    h_coeff_R, coords_R = quotient_coordinates(R, H, natural_boundary)
    h_coeff_K, coords_K = quotient_coordinates(K, H, natural_boundary)
    assert h_coeff_R == 0 and coords_R == [1] + [0] * 12
    assert h_coeff_K == -3 and coords_K == [1] + [0] * 12
    assert all(intersection(H, E) == 1 for E in exceptional)
    assert all(intersection(R, E) == 2 for E in exceptional)

    # Boundary count and corrected U1/U2/B count.
    class_rank = 13
    max_ramification_components = intersection(H, R)  # every component has positive H-degree
    min_unramified = class_rank - max_ramification_components
    assert min_unramified == 3
    component_bounds = {
        b: b + math.ceil((class_rank - b) / 2)
        for b in range(1, max_ramification_components + 1)
    }
    assert min(component_bounds.values()) == 7
    assert component_bounds[1] == 7

    # Hodge polynomial of the natural invariant opening.
    u, v = sp.symbols("u v")
    q_uv = u * v
    E_X = 1 + 14 * q_uv + q_uv**2
    E_R = 1 - 15 * (u + v) + q_uv
    E_P1 = 1 + q_uv
    E_boundary = sp.expand(E_R + 12 * E_P1 - 24)
    E_X_open = sp.expand(E_X - E_boundary)
    expected_X_open = sp.expand(q_uv**2 + q_uv + 12 + 15 * (u + v))
    assert sp.expand(E_X_open - expected_X_open) == 0
    E_cone_open = sp.expand((q_uv - 1) * E_X_open)
    assert sp.expand(E_cone_open - q_uv**3) != 0
    assert E_cone_open.subs({u: 1, v: 1}) == 0
    assert (q_uv**3).subs({u: 1, v: 1}) == 1

    print("graded one-generator table")
    for row in rows:
        print(
            "  d={d}: weight={defect_weight}, h0(build)={building_dimension}, "
            "branch={branch_degree}, q={q}, pg={pg}, K2={K2}".format(**row)
        )
    print("stable-birational survivor: d=4")
    print(
        "type IV: H^2=3, K^2=-4, H.K=1, H.R=10, "
        "R^2=29, g(H)=3, g(R)=15"
    )
    print("natural boundary basis determinant:", determinant)
    print("canonical coordinates in [R,E1,...,E12]:", coords_K)
    print("minimum unramified boundary divisors:", min_unramified)
    print("minimum nonproperness hypersurface components:", min(component_bounds.values()))
    print("natural invariant opening E-polynomial:", E_cone_open)
    print("all built-in checks: PASS")

    if args.candidate is not None:
        verify_candidate(args.candidate, H, R)


if __name__ == "__main__":
    main()
