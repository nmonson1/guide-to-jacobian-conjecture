#!/usr/bin/env python3
"""Exact checker for the Hessian-resolvent continuation of the explicit type-IV cone.

The input is p1t1_typeIV_explicit_net_data.json from the preceding continuation.
The script reconstructs the Hessian covariant W, the correction row r, the global
rank-one resolvent module over Q(zeta_3), and a 4x4 matrix factorization through
the cone vertex.  It also verifies the universal depressed-cubic conductor and
Kahler-different formulas used in the accompanying note.

Requires: Python 3.10+ and SymPy.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable

import sympy as sp


def canonical_sha256(payload: dict[str, Any]) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def assert_zero(expr: sp.Expr, label: str) -> None:
    if sp.expand(expr) != 0:
        raise AssertionError(f"{label}: expected zero, got {sp.factor(expr)}")


def assert_zero_matrix(mat: sp.Matrix, label: str) -> None:
    for i in range(mat.rows):
        for j in range(mat.cols):
            assert_zero(mat[i, j], f"{label}[{i},{j}]")


def homogeneous_degree(expr: sp.Expr, variables: Iterable[sp.Symbol]) -> int:
    poly = sp.Poly(sp.expand(expr), *variables)
    degrees = {sum(monomial) for monomial, coeff in poly.terms() if coeff != 0}
    if len(degrees) != 1:
        raise AssertionError(f"polynomial is not homogeneous in {tuple(variables)}: {degrees}")
    return next(iter(degrees))


def matrix_to_strings(mat: sp.Matrix) -> list[list[str]]:
    return [[str(sp.expand(mat[i, j])) for j in range(mat.cols)] for i in range(mat.rows)]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve().parent
    parser.add_argument(
        "--input-json",
        type=Path,
        default=here / "typeiv-explicit-net-data.json",
        help="preceding explicit-net JSON certificate",
    )
    parser.add_argument("--write-json", type=Path, help="write reconstructed certificate")
    parser.add_argument("--check-json", type=Path, help="compare reconstructed certificate byte-for-byte")
    return parser.parse_args()


def build_certificate(input_path: Path) -> dict[str, Any]:
    input_bytes = input_path.read_bytes()
    source = json.loads(input_bytes)

    a, b, c = sp.symbols("a b c")
    x, y, z = sp.symbols("x y z")
    rho = sp.symbols("rho")
    target_vars = (a, b, c)
    source_vars = (x, y, z)

    local_env = {name: symbol for name, symbol in zip("abcxyz", (a, b, c, x, y, z))}
    P = sp.sympify(source["section_TP2_2"]["P"], locals=local_env)
    Q = sp.sympify(source["section_TP2_2"]["Q"], locals=local_env)
    R = sp.sympify(source["section_TP2_2"]["R"], locals=local_env)
    branch = sp.sympify(
        source["branch_homogeneous_degree_10"], locals={"a": a, "b": b, "c": c}
    )

    # Ternary cubic on the fibre line v.x=0.
    v = sp.Matrix([a, b, c])
    G = sp.expand(a * P + b * Q + c * R)
    hessian_G = sp.hessian(G, source_vars)

    # Quadratic Hessian covariant on the fibre line and its polar matrix.
    h = sp.expand(-sp.Rational(1, 4) * (v.T * hessian_G.adjugate() * v)[0])
    S = (sp.hessian(h, source_vars) / 2).applyfunc(sp.expand)
    cross_v = sp.Matrix([[0, -c, b], [c, 0, -a], [-b, a, 0]])
    W = (-2 * S * cross_v).applyfunc(sp.expand)

    if homogeneous_degree(h, source_vars) != 2:
        raise AssertionError("h must be quadratic in source variables")
    if homogeneous_degree(h, target_vars) != 4:
        raise AssertionError("h must have target degree four")
    for entry in W:
        if entry != 0 and homogeneous_degree(entry, target_vars) != 5:
            raise AssertionError("W entries must have target degree five")

    assert_zero_matrix(W * v, "Wv")
    assert_zero(sp.trace(W), "trace(W)")

    # W^2 is scalar only after quotienting by the radial relation Av.
    defect_matrix = (W * W + 3 * branch * sp.eye(3)).applyfunc(sp.expand)
    assert_zero_matrix(cross_v * defect_matrix, "K_v(W^2+3BI)")

    # Recover the unique correction row r from the c-row and verify globally.
    row_entries: list[sp.Expr] = []
    for j in range(3):
        quotient, remainder = sp.div(
            sp.Poly(defect_matrix[2, j], *target_vars), sp.Poly(c, *target_vars)
        )
        assert_zero(remainder.as_expr(), f"division remainder for r_{j}")
        row_entries.append(sp.expand(quotient.as_expr()))
    r = sp.Matrix(1, 3, row_entries)
    for entry in r:
        if homogeneous_degree(entry, target_vars) != 9:
            raise AssertionError("r entries must have target degree nine")

    assert_zero_matrix(defect_matrix - v * r, "W^2+3BI-vr")
    assert_zero_matrix(r * W, "rW")
    assert_zero((r * v)[0] - 3 * branch, "rv-3B")

    # Exact 4x4 homogeneous matrix factorization over S=k[a,b,c,rho].
    Phi = (rho * sp.eye(3) - W).row_join(v)
    Phi = Phi.col_join((-r).row_join(sp.Matrix([[rho]])))
    Psi = (rho * sp.eye(3) + W).row_join(-v)
    Psi = Psi.col_join(r.row_join(sp.Matrix([[rho]])))
    hypersurface = sp.expand(rho**2 + 3 * branch)
    assert_zero_matrix(Phi * Psi - hypersurface * sp.eye(4), "PhiPsi-fI")
    assert_zero_matrix(Psi * Phi - hypersurface * sp.eye(4), "PsiPhi-fI")

    # Exact determinant identity; it also certifies generic rank two of coker(Phi).
    determinant_phi = sp.expand(Phi.det(method="domain-ge"))
    assert_zero(determinant_phi - hypersurface**2, "det(Phi)-f^2")

    # Chart c=1: the induced endomorphism is the classical binary-Hessian matrix.
    t = sp.symbols("t")
    restricted = sp.expand(G.subs({c: 1, x: t, y: 1, z: -a * t - b}))
    coeffs = sp.Poly(restricted, t).all_coeffs()
    if len(coeffs) != 4:
        raise AssertionError("restricted fibre equation is not cubic")
    A0, B0, C0, D0 = coeffs
    H0 = sp.expand(B0**2 - 3 * A0 * C0)
    H1 = sp.expand(B0 * C0 - 9 * A0 * D0)
    H2 = sp.expand(C0**2 - 3 * B0 * D0)
    classical_W = sp.Matrix([[-H1, 2 * H0], [-2 * H2, H1]])
    projection = sp.Matrix([[1, 0, -a], [0, 1, -b]])
    chart_W = (projection * W.subs(c, 1)[:, :2]).applyfunc(sp.expand)
    assert_zero_matrix(chart_W - classical_W, "chart Hessian identity")
    assert_zero_matrix(chart_W * chart_W + 3 * branch.subs(c, 1) * sp.eye(2), "chart square")
    assert_zero(chart_W.det() - 3 * branch.subs(c, 1), "chart determinant")

    # Universal binary-cubic identity, independent of the chosen type-IV net.
    A1, B1, C1, D1 = sp.symbols("A1 B1 C1 D1")
    delta = sp.expand(
        B1**2 * C1**2
        - 4 * A1 * C1**3
        - 4 * B1**3 * D1
        - 27 * A1**2 * D1**2
        + 18 * A1 * B1 * C1 * D1
    )
    UH0 = B1**2 - 3 * A1 * C1
    UH1 = B1 * C1 - 9 * A1 * D1
    UH2 = C1**2 - 3 * B1 * D1
    universal_W = sp.Matrix([[-UH1, 2 * UH0], [-2 * UH2, UH1]])
    assert_zero_matrix(universal_W**2 + 3 * delta * sp.eye(2), "universal Hessian square")

    # Depressed cubic and its transverse A2 matrix factorization.
    p, q = sp.symbols("p q")
    depressed_delta = -4 * p**3 - 27 * q**2
    depressed_W = sp.Matrix([[9 * q, -6 * p], [-2 * p**2, -9 * q]])
    assert_zero_matrix(
        depressed_W**2 + 3 * depressed_delta * sp.eye(2), "depressed Hessian square"
    )
    U = rho - 9 * q
    V = rho + 9 * q
    assert_zero(U * V - 12 * p**3 - (rho**2 + 3 * depressed_delta), "A2 coordinate identity")
    local_phi = rho * sp.eye(2) - depressed_W
    local_psi = rho * sp.eye(2) + depressed_W
    local_f = rho**2 + 3 * depressed_delta
    assert_zero_matrix(local_phi * local_psi - local_f * sp.eye(2), "local phi psi")
    assert_zero_matrix(local_psi * local_phi - local_f * sp.eye(2), "local psi phi")

    # Universal ordered-root normalization and conductor.
    u, vv = sp.symbols("u vv")
    root_p = -u * vv / 3
    root_q = -(u**3 + vv**3) / 27
    root_t = (u + vv) / 3
    root_rho = (u**3 - vv**3) / 3
    assert_zero(root_t**3 + root_p * root_t + root_q, "Cardano cubic")
    assert_zero(root_rho**2 + 3 * depressed_delta.subs({p: root_p, q: root_q}), "Cardano discriminant")
    s = u + vv
    zz = u * vv
    dd = u - vv
    assert_zero(root_rho - dd * (s**2 - zz) / 3, "rho=d(s^2-z)/3")
    derivative = sp.expand(3 * root_t**2 + root_p)
    assert_zero(derivative - (s**2 - zz) / 3, "f'(t)=(s^2-z)/3")
    assert_zero((s**2 - zz) * dd - 3 * root_rho, "conductor generator times d")
    assert_zero(root_rho * dd - (s**2 - 4 * zz) * (s**2 - zz) / 3, "rho times d")

    # Exact normalization-module presentation.  With R=3*rho and ell=s^2-z,
    # C=k[s,z,R]/(R^2-(s^2-4z)*ell^2), and its normalization is generated by
    # 1,d with R=ell*d and d^2=s^2-4z.  Modulo the copy of C generated by 1,
    # the quotient is C/(R,ell), proving the conductor formula.
    ss, z0, RR, d0 = sp.symbols("ss z0 RR d0")
    ell = ss**2 - z0
    delta0 = ss**2 - 4 * z0
    conductor_hypersurface = RR**2 - delta0 * ell**2
    normalization_matrix = sp.Matrix([[-RR, -delta0 * ell], [ell, RR]])
    assert_zero_matrix(
        normalization_matrix**2 - conductor_hypersurface * sp.eye(2),
        "normalization conductor matrix factorization",
    )
    relation_values = normalization_matrix.subs({RR: ell * d0, delta0: d0**2})
    assert_zero(relation_values[0, 0] + relation_values[1, 0] * d0, "normalization relation 1")
    assert_zero(relation_values[0, 1] + relation_values[1, 1] * d0, "normalization relation 2")

    # Kahler different of k[u,v] over k[u^3,v^3,uv].
    relation_matrix = sp.Matrix([[3 * u**2, 0, vv], [0, 3 * vv**2, u]])
    kahler_minors = [
        sp.expand(relation_matrix[:, [0, 1]].det()),
        sp.expand(relation_matrix[:, [0, 2]].det()),
        sp.expand(relation_matrix[:, [1, 2]].det()),
    ]
    expected_minors = [9 * u**2 * vv**2, 3 * u**3, -3 * vv**3]
    for i, (actual, expected) in enumerate(zip(kahler_minors, expected_minors)):
        assert_zero(actual - expected, f"Kahler minor {i}")

    # Fitting support of the normalization index M/WM.
    index_presentation = v.row_join(W)
    maximal_minors = []
    expected_quotients = [0, 3 * a, -3 * b, 3 * c]
    for omitted in range(4):
        columns = [j for j in range(4) if j != omitted]
        minor = sp.expand(index_presentation[:, columns].det())
        maximal_minors.append(minor)
        assert_zero(minor - expected_quotients[omitted] * branch, f"index minor {omitted}")

    payload: dict[str, Any] = {
        "schema_version": 2,
        "input_file": input_path.name,
        "input_sha256": hashlib.sha256(input_bytes).hexdigest(),
        "base_field": "Q",
        "splitting_field": "Q(zeta_3)",
        "resolvent_coordinate": {
            "lambda": "zeta_3-zeta_3**2",
            "lambda_square": "-3",
            "rho": "lambda*w",
            "equation": str(hypersurface),
            "rho_degree": 5,
        },
        "hessian_covariant": {
            "definition": "h=-(1/4)*v^T*adj(Hess_x(aP+bQ+cR))*v; S=(1/2)*Hess_x(h); W=-2*S*K_v",
            "h": str(h),
            "W": matrix_to_strings(W),
            "correction_row_r": matrix_to_strings(r)[0],
        },
        "module_presentations": {
            "M": "A(-4) --(a,b,c)^T--> A(-3)^3 --> M --> 0",
            "L": "Qrho(-4) plus Qrho(-8)^3 --[v | rho*I-W]--> Qrho(-3)^3 --> L --> 0",
            "P": "coker(Phi), with Phi: Qrho(-8)^3 plus Qrho(-4) -> Qrho(-3)^3 plus Qrho(1)",
            "extension": "0 --> Qrho(1) --> P --> L --> 0",
            "normalization_index": "T/(Qrho tensor_A B) is isomorphic as an A-module to M/W*M",
        },
        "matrix_factorization": {
            "Phi_block_form": "[[rho*I-W, v],[-r,rho]]",
            "Psi_block_form": "[[rho*I+W,-v],[r,rho]]",
            "Phi": matrix_to_strings(Phi),
            "Psi": matrix_to_strings(Psi),
            "hypersurface": str(hypersurface),
            "determinant": str(determinant_phi),
            "determinant_identity": "det(Phi)=hypersurface**2",
        },
        "local_models": {
            "binary_hessian_matrix": "[[-H1,2*H0],[-2*H2,H1]]",
            "binary_hessian_coefficients": {
                "H0": "B^2-3*A*C",
                "H1": "B*C-9*A*D",
                "H2": "C^2-3*B*D",
            },
            "depressed_cubic": "t^3+p*t+q",
            "discriminant": str(depressed_delta),
            "W_depressed": matrix_to_strings(depressed_W),
            "A2_coordinates": {"U": str(U), "V": str(V), "equation": "U*V=12*p^3"},
            "conductor_order_in_normalization": "(rho,3*t^2+p)",
            "kahler_different_T_over_Q": "(u^3,v^3,u^2*v^2)",
        },
        "index_fitting": {
            "presentation": "coker([v|W])",
            "maximal_minors": [str(m) for m in maximal_minors],
            "ideal": "branch*(a,b,c)",
            "annihilator": "(branch)",
            "Q_scalar_conductor": "(rho)",
        },
        "certificates": {
            "h_source_degree": 2,
            "h_target_degree": 4,
            "W_target_degree": 5,
            "r_target_degree": 9,
            "Wv_zero": True,
            "trace_W_zero": True,
            "W_square_mod_radial": True,
            "rW_zero": True,
            "rv_equals_3_branch": True,
            "matrix_factorization_both_orders": True,
            "chart_binary_hessian_identity": True,
            "universal_binary_hessian_identity": True,
            "local_A2_class_nonfree": True,
            "universal_conductor_identity": True,
            "normalization_conductor_presentation": True,
            "kahler_different_identity": True,
            "index_fitting_identity": True,
        },
    }
    payload["canonical_sha256"] = canonical_sha256(payload)
    return payload


def main() -> None:
    args = parse_args()
    payload = build_certificate(args.input_json)
    rendered = json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True) + "\n"

    if args.write_json:
        args.write_json.write_text(rendered, encoding="utf-8")
        print(f"WROTE {args.write_json}")

    if args.check_json:
        expected = args.check_json.read_text(encoding="utf-8")
        if rendered != expected:
            raise AssertionError(f"reconstructed JSON differs from {args.check_json}")
        print(f"PASS byte-for-byte certificate replay: {args.check_json}")

    cert = payload["certificates"]
    print("PASS Hessian covariant: Wv=0 and W^2=-3*branch on M")
    print("PASS correction row: W^2+3*branch*I=v*r, rW=0, rv=3*branch")
    print("PASS global 4x4 matrix factorization in both orders")
    print("PASS chart c=1 equals the classical binary-Hessian endomorphism")
    print("PASS transverse depressed-cubic model is A2 with a nonfree order-three class")
    print("PASS universal conductor and Kahler-different identities")
    print("PASS normalization-index Fitting ideal = branch*(a,b,c)")
    print(f"canonical_sha256={payload['canonical_sha256']}")
    if not all(cert.values()):
        raise AssertionError("one or more boolean certificates are false")


if __name__ == "__main__":
    main()
