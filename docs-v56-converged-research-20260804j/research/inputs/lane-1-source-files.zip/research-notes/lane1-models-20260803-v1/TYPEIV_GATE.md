# Smooth homogeneous one-generator defects and the type-IV gate

Work over \(\mathbf C\). Let \(A=\mathbf C[a,b,c]\) with its standard grading and suppose a connected normal graded cubic \(A\)-algebra has trace decomposition

\[
B=A\oplus M
\]

and a one-generator defect supported at \((a,b,c)\). After a linear change of target variables, assume

\[
0\longrightarrow A(-d)
\xrightarrow{(a,b,c)^t}
A(1-d)^3\longrightarrow M\longrightarrow0.
\tag{1}
\]

This note isolates what follows from (1), what comes from the classification of smooth triple planes, and what the explicit calculation proves. None of the projective or conical examples below is asserted to be a polynomial Keller map.

## 1. The smooth projective reduction

Sheafifying (1) gives

\[
\widetilde M\simeq T_{\mathbf P^2}(-d)
\simeq\Omega^1_{\mathbf P^2}(3-d).
\tag{2}
\]

If \(f:X\to\mathbf P^2\) is the corresponding smooth projectivized cubic cover, then

\[
f_*\mathcal O_X
=\mathcal O_{\mathbf P^2}\oplus\Omega^1_{\mathbf P^2}(3-d).
\]

Consequently

\[
q(X)=
\begin{cases}
1,&d=3,\\
0,&d\ne3,
\end{cases}
\qquad
p_g(X)=h^0\!\left(\mathbf P^2,T_{\mathbf P^2}(d-6)\right).
\]

The cubic building-section space vanishes for \(d<3\), while \(p_g(X)>0\) for \(d\ge5\). If the normalized affine cone over \((X,H=f^*\mathcal O(1))\) contained a dense open \(\mathbf A^3\), then \(\mathbf C(X)(t)\) would be rational, so the smooth projective surface \(X\) would be stably rational. The stable-birational invariance of \(p_g\) and \(q\) therefore leaves exactly

\[
\boxed{d=4}
\]

among smooth projectivized one-generator defects.

This conclusion does not cover singular projectivizations unless their resolutions preserve the required trace-free cohomology, for example under suitable rational-singularity hypotheses.

## 2. Identification with type IV

For \(d=4\), the trace-zero bundle is \(T_{\mathbf P^2}(-4)\). The classification of smooth general triple planes identifies this case with type IV. The source surface is

\[
X=\operatorname{Bl}_{Z}\check{\mathbf P}^{\,2},
\qquad
H=4L-\sum_{i=1}^{13}E_i,
\tag{3}
\]

where \(Z\) is the length-13 zero scheme of a section of
\(T_{\check{\mathbf P}^{\,2}}(2)\). In particular

\[
H^2=3,\quad
K_X=-3L+\sum E_i,\quad
R_f=K_X+3H=9L-2\sum E_i,
\]

and

\[
K_X^2=-4,\quad H\cdot K_X=1,\quad
H\cdot R_f=10,\quad R_f^2=29,\quad g(R_f)=15.
\tag{4}
\]

The classification and cusp count are the literature inputs: Faenzi--Polizzi--Vallès, Proposition 3.7 and Proposition 2.4, using Miranda's construction of triple covers. The formulas in (3)--(4) are direct intersection calculations.

## 3. An explicit type-IV net

In homogeneous coordinates \([x:y:z]\), take

\[
\begin{aligned}
P&=x^3+2y^3+3z^3+xyz+y^2z,\\
Q&=2x^3-y^3+z^3+x^2z+xy^2,\\
R&=x^3+y^3-2z^3+xz^2+yz^2+x^2y.
\end{aligned}
\]

The cross-product quartics

\[
(q_1,q_2,q_3)=(yR-zQ,\ zP-xR,\ xQ-yP)
\]

define a rational map \(\mathbf P^2\dashrightarrow\mathbf P^2\). The exact checker proves:

1. their projective base scheme is reduced of length \(13\) and has no point on \(z=0\);
2. after blowing up those points, no target fibre contains a curve and no exceptional divisor is contracted;
3. the resulting morphism is finite flat of degree \(3\);
4. the source-plane ramification polynomial has degree \(9\) and is irreducible over \(\mathbf Q\);
5. the target branch polynomial has degree \(10\), is irreducible over \(\mathbf Q\), and has a Jacobian scheme of length \(42\) on \(21\) geometric support points;
6. at each support point the quadratic term is nonzero and the local Jacobian length is \(2\), hence every singularity is an ordinary \(A_2\) cusp.

The complete equations are in
`typeiv-explicit-net-data.json`; `verify_typeiv_explicit_net.py`
reconstructs them instead of trusting the stored file.

## 4. The cone defect and the resolvent module

Let \(B=\bigoplus_{n\ge0}H^0(X,\mathcal O_X(nH))\). Its trace-zero summand has the graded presentation

\[
0\longrightarrow A(-4)
\xrightarrow{(a,b,c)^t}
A(-3)^3\longrightarrow M\longrightarrow0.
\tag{5}
\]

Dualizing (5) gives

\[
\operatorname{Ext}^1_A(B,A)
\simeq A/(a,b,c)(4).
\tag{6}
\]

Thus the cone has a length-one finite defect at its vertex and its closed fibre has scheme length \(4\). Its quadratic resolvent is

\[
Q_{\mathrm{res}}
=\mathbf Q[a,b,c,\rho]/(\rho^2+3\mathcal B),
\tag{7}
\]

where \(\mathcal B\) is the branch decic. The \(21\) cusps cone to \(21\) height-two singular lines. Transversely (7) is \(UV=v^3\), so each line has local class group \(\mathbf Z/3\), and the two cubic eigensheaves give the two nonzero classes.

The Hessian checker constructs a \(3\times3\) matrix \(W\), a row \(r\), and \(v=(a,b,c)^t\) satisfying

\[
Wv=0,\qquad
W^2+3\mathcal B I_3=vr,\qquad
rW=0,\qquad
rv=3\mathcal B.
\tag{8}
\]

It then verifies the \(4\times4\) matrix factorization

\[
\Phi=
\begin{pmatrix}
\rho I_3-W&v\\
-r&\rho
\end{pmatrix},
\qquad
\Psi=
\begin{pmatrix}
\rho I_3+W&-v\\
r&\rho
\end{pmatrix},
\]

\[
\Phi\Psi=\Psi\Phi=(\rho^2+3\mathcal B)I_4.
\tag{9}
\]

Therefore \(\operatorname{coker}\Phi\) is a rank-two maximal Cohen--Macaulay module through the cone vertex. Projection to the \(3\times3\) Hessian eigensheaf gives an extension by the residue-field module at the vertex. The same calculation recovers the universal ordered-root conductor and Kähler different on the punctured cubic cover, and computes the normalization-index Fitting ideal as

\[
\operatorname{Fitt}_0(T/C)=\mathcal B\,(a,b,c).
\tag{10}
\]

Equations (8)--(10) are exact identities. They do not supply the three affine source openings needed to define the Keller collision Čech quotient.

## 5. Two Keller-specific rejection tests

First, no grading-invariant open of the punctured cone is \(\mathbf A^3\). Such an open has a fixed-point-free \(\mathbf G_m\)-action, so its compactly supported Euler characteristic is zero, whereas \(e_c(\mathbf A^3)=1\).

Second, let \(F:\mathbf A^3\to\mathbf A^3\) be a polynomial map with \(\det JF=c\ne0\). The target Euler field has the polynomial lift

\[
D=(JF)^{-1}F,\qquad D(F_i)=F_i,\qquad\operatorname{div}D=3.
\tag{11}
\]

If \(0\notin F(\mathbf A^3)\), then \(D\) is nowhere zero. It cannot be locally finite: otherwise its locally nilpotent Jordan part vanishes on the finite separable extension \(\mathbf C(x_1,x_2,x_3)/\mathbf C(F_1,F_2,F_3)\), so \(D\) is semisimple and integrates to an algebraic torus action on \(\mathbf A^3\). Torus localization gives a fixed point, where \(D\) vanishes, a contradiction.

Thus a type-IV Keller realization, if one exists, needs a genuinely non-grading-invariant affine opening and a nowhere-zero, divergence-three, non-locally-finite Euler lift.

## 6. What remains open

For the explicit type-IV cone, the following are still unavailable:

- a polynomial Keller realization;
- a non-grading-invariant affine open isomorphic to \(\mathbf A^3\);
- three conjugate source charts and their exact Čech gluing;
- the full conductor and different at the vertex in the eigensheaf presentation; and
- the collision-saturation quotient for an actual Keller opening.

The explicit cone is therefore a fixed equation-level test object and a sharp homogeneous gate, not a solution of the general Lane 1 flatness problem.
