#!/usr/bin/env python3
"""Exact symbolic checks for the elliptic-cone P1-T1 negative model.

This script verifies the explicit Fermat dual sextic, its singular lines and
local cusp leading form, and the standard triple-collision ideal.
It does not attempt to machine-check the sheaf-cohomology or local-duality
arguments in the accompanying note.
"""
from __future__ import annotations

import sympy as sp


a, b, c, w = sp.symbols("a b c w")
x, y, z = sp.symbols("x y z")
u, v = sp.symbols("u v")

# Dual sextic of x^3+y^3+z^3=0.
d = (
    a**6 + b**6 + c**6
    - 2*a**3*b**3 - 2*a**3*c**3 - 2*b**3*c**3
)

# Tangent line at [x:y:z] has dual coordinates [x^2:y^2:z^2].
tangent_pullback = sp.factor(d.subs({a: x**2, b: y**2, c: z**2}))
expected = sp.factor(
    (x**3-y**3-z**3)
    * (x**3-y**3+z**3)
    * (x**3+y**3-z**3)
    * (x**3+y**3+z**3)
)
assert sp.expand(tangent_pullback - expected) == 0

# Gradient formulas.
derivatives = [sp.factor(sp.diff(d, q)) for q in (a, b, c)]
assert derivatives == [
    6*a**2*(a**3-b**3-c**3),
    -6*b**2*(a**3-b**3+c**3),
    -6*c**2*(a**3+b**3-c**3),
]

# One cusp chart: a=1, b=1+u, c=v.  The lowest part is 9u^2-4v^3.
local = sp.Poly(sp.expand(d.subs({a: 1, b: 1+u, c: v})), u, v)
lowest_degree = min(sum(mon) for mon, _ in local.terms())
lowest = sum(
    coeff * u**mon[0] * v**mon[1]
    for mon, coeff in local.terms()
    if sum(mon) == lowest_degree
)
assert lowest_degree == 2
assert sp.expand(lowest - 9*u**2) == 0
# The first term transverse to the double tangent is -4v^3.
assert local.coeff_monomial(v**3) == -4

# Standard ordered-root collision ideal.
f1 = sp.expand(u*(u+v))
f2 = sp.expand(u*v)
f3 = sp.expand(v*(u+v))
G_collision = sp.groebner([f1, f2, f3], u, v, order="lex")
G_square = sp.groebner([u**2, u*v, v**2], u, v, order="lex")
assert G_collision == G_square

# Standard representation: a transposition has a one-dimensional fixed space;
# a 3-cycle has no fixed vectors.
transposition = sp.Matrix([[0, 1], [1, 0]])
# A convenient rational matrix of order 3 with characteristic polynomial t^2+t+1.
three_cycle = sp.Matrix([[0, -1], [1, -1]])
I2 = sp.eye(2)
assert (transposition - I2).rank() == 1
assert (three_cycle - I2).rank() == 2
assert three_cycle**3 == I2

print("dual sextic d =", d)
print("verified tangent parametrization of the dual sextic")
print("gradient =", derivatives)
print("verified cusp leading terms 9*u^2 - 4*v^3 + higher terms")
print("verified (u(u+v), uv, v(u+v)) = (u,v)^2")
print("verified standard-representation fixed-space dimensions: H-fixed 1, A3-fixed 0")
