# Lane 1: cubic flatness and finite normalization defects

**Portfolio role:** settle the intrinsic finite-cover problem for generic-degree-three Keller maps before attempting boundary reconstruction.

## Research objective

Let

```text
F : X = A^3_C -> Y = A^3_C
```

be a Keller map of generic degree three. Let `B` be the normalization of
`R=O(Y)` in `C(X)`, and write

```text
pi : Xbar = Spec(B) -> Y.
```

Lane 1 asks whether `pi` is finite flat. This is a general degree-three Keller
question, not a statement restricted to the named counterexample or the
explicit normalized `A,B` family.

The affine opening is a separate gate. Even after flatness, recovering the
original `A^3` inside `Xbar` requires boundary completeness. Do not merge Lane
1 with the boundary/Torelli lane.

## Reusable mathematics

Write

```text
R = C[y1,y2,y3],   S = C[x1,x2,x3],
B = R ⊕ E,         E = ker Tr_(B/R).
```

The following statements are the repaired reusable core.

### 1. The defect is a canonical finite Ext module

Define

```text
Delta_F := Ext^1_R(B,R) = Ext^1_R(E,R).
```

The modules `B` and the rank-two trace-zero module `E` are reflexive. Hence
`E` is free at every prime of height at most two, `Delta_F` has finite length,
and

```text
Supp(Delta_F) = { y in Y : B_y is not free over R_y }.
B is finite flat over R  <=>  Delta_F = 0.
```

At a possible defect point `y`, with `A=R_y`, a minimal presentation is

```text
0 -> A^b --Phi--> A^(b+2) -> E_y -> 0,
Delta_(F,y) = coker(Phi^dual).
```

The integer `b` is the minimal number of generators of `Delta_(F,y)`. Local
duality identifies its Matlis dual with `H^2_m(E_y)`.

An orientation of `E_y` extends this presentation to an alternating self-dual
free resolution

```text
0 -> A^b -> A^(b+2) -> A^(b+2)^dual -> A^b^dual
  -> Delta_(F,y) -> 0.
```

Thus `Delta_(F,y)` is Matlis self-dual and its socle dimension is also `b`.
Any proposed defect must satisfy this finite certificate.

The first stratum is explicit. If `b=1`, then

```text
Delta_(F,y) = A/(f1,f2,f3),
E_y = Omega_A^2(Delta_(F,y)),
```

for an `A`-regular sequence, and the resolution is Koszul with Betti numbers
`(1,3,3,1)`.

### 2. Source splitting is proved and its direct scope is exhausted

Base change to the affine source has a canonical marked factor:

```text
B tensor_R S = S × C,
C = S[eta]/(eta^2-D).
```

The factor `S` is canonical. The trace-zero generator `eta` is a choice, and
`D` changes by a unit square when the generator changes.

Consequently `B_y` is free for every attained value `y in F(X)`. Together with
the omitted-values theorem,

```text
Supp(Delta_F) ⊆ O_F ⊆ Sing(S_F),
```

where `O_F` is the omitted set and `S_F` is the reduced nonproperness set.
There is no source point above a defect value, so “apply source splitting
again” is not a local strategy. Any further source input must pass through the
boundary, conductor, duality, or monodromy.

### 3. The quadratic resolvent carries exactly the same defect

Let `T` be the normalization in the `S_3` Galois closure, let `N=A_3`, and let
`H` be the transposition subgroup corresponding to the cubic field. Then

```text
B = T^H,
Q = T^N = R[w]/(w^2-d),
T = Q ⊕ L ⊕ L^[2],
L^[3] = Q.
```

The corrected divisorial list `U0/U1/U2/B` implies that `T/Q` is unramified in
codimension one. Taking `H`-invariants gives an exact `R`-module
identification

```text
E ≅ L,       ell |-> ell + sigma(ell).
```

Therefore

```text
Delta_F = Ext^1_R(L,R),
B flat over R  <=>  L locally free over R  <=>  L MCM over Q.
```

This is an equivalence, not merely the former one-way MCM criterion.

### 4. A completed defect branch is genuinely non-Galois cubic

At `y in Supp(Delta_F)`, completion over `A=R_y^` decomposes the normalization
into normal local factors of total rank three. Rank-one factors equal `A`.
Rank-two normal factors are free because their trace-zero summands are
rank-one reflexive modules over the regular local UFD `A`. A cyclic rank-three
factor is also free by its `C_3` character decomposition.

Hence a defect has one rank-three normal local factor, and that cubic field is
non-Galois with `S_3` closure. The normalization fibre is supported at one
point and has scheme length

```text
length(B tensor_R k(y)) = b + 3 >= 4.
```

Length four is exactly the one-generator complete-intersection stratum.

### 5. Dao detection localizes every remaining class on singular curves

For a three-dimensional normal local hypersurface `Q0`, Dao’s punctured-Picard
theorem gives

```text
Cl(Q0)[3] -> direct_sum_{height-two singular p} Cl((Q0)_p)[3]
```

injectively. Thus a nonzero defect requires a height-two singular prime of the
quadratic resolvent carrying a nonzero localization of `[L]`. For

```text
Q = R[w]/(w^2-d),
```

the singular locus is cut out by

```text
(w, d_y1, d_y2, d_y3).
```

An isolated resolvent singularity cannot carry the defect.

## New finite transverse filter

Assume, only for this subsection, that the generic transverse surface type at
each singular curve is a split rational double point. Three-torsion occurs
only for

```text
A_(3r-1)  and  E6.
```

Each curve contributes at most one coordinate in `F_3`.

For `A_(3r-1)` with equation `uv-z^(3r)`, the two nonzero classes are

```text
I_r=(u,z^r),   I_2r=(u,z^(2r)).
```

They have explicit two-by-two matrix factorizations. Their degree-three cyclic
cover has equation `UV-z^r`, so the transverse cover type is `A_(r-1)`.

For `E6` with equation `x^2+y^3+z^4`, put

```text
a=x+i z^2,   b=x-i z^2,
J+=(a,y),    J-=(b,y).
```

These are the two nonzero classes in `Z/3` and have explicit two-by-two matrix
factorizations. The associated cyclic cover is

```text
s^3+t^3-2 i z^2 = 0,
```

which is a `D4` singularity, with invariant coordinates

```text
x=(s^3-t^3)/2,   y=s*t,   z=z.
```

Thus every coordinate in the conditional ADE vector has an explicit generic
transverse MCM representative. The unresolved step is extending and gluing
those factorizations through the closed threefold point.

## Useful deliverable

### Exact live problem

The remaining unknown at a candidate omitted value is the following finite
package:

1. the square class `d` defining the normal quadratic resolvent;
2. every height-two prime in its singular locus;
3. a fractional-ideal or finite-presentation representative of `L`;
4. the local class vector `([L_p])_p`;
5. a matrix factorization or other depth-three certificate extending the
   explicit transverse models through the closed point, or a Keller-specific
   argument excluding every nonzero vector.

A useful returned result must state whether it is local, completed, formal,
divisorial, or global, and identify the exact boundary or conductor data it
uses.

## Recommended work order

### P1-T1A — Extract the exact resolvent carrier

**Status:** ready.

**Input:** the actual Keller normalization and boundary, not a schematic
elliptic picture.

**Done when:** `d`, the singular height-two primes, a presentation of `L`, the
conductor/different, and the local class vector are explicit and checkable.

### P1-T1B — Extend the transverse MCM models

**Status:** blocked on P1-T1A.

**Attack:** build a matrix factorization over the three-dimensional resolvent
whose generic restrictions are the displayed `A_(3r-1)` or `E6` templates;
alternatively prove a Keller-specific vanishing of the class vector.

**Done when:** the resulting module has depth three and its codimension-two
classes agree with `L` at every singular curve.

### P1-T2 — Compute the finite class/intersection obstruction

**Status:** blocked on P1-T1A.

Do not invent the lattice. Its intersection matrix, discrepancy vector, and
class coordinates must be derived from the actual resolvent model and then
hash-pinned for exact replay.

### P1-T3 — Keep boundary completeness separate

Finite flatness gives a binary-cubic/marked-root finite cover. Identifying the
original affine source inside it still requires a separate theorem specifying
all deleted ramified and unramified sheets.

## Do not do

- Do not state that normal `S_3` cubic covers are automatically flat.
- Do not replace `Delta_F` by an unnamed defect or treat reflexivity as local freeness.
- Do not use the old `U1/U2/B` list; the complete list is `U0/U1/U2/B`.
- Do not call the quadratic generator in source splitting canonical.
- Do not infer a global MCM module from a smooth cubic-axis picture without a
  matrix factorization and codimension-two comparison.
- Do not run an exceptional-lattice computation before the actual primes and
  eigensheaf class are known.
- Do not infer boundary completeness from flatness.

## Proof access

The accompanying repair appendix supplies the conventional proofs. Existing
Program 1 text sources remain necessary for the corrected divisorial
classification and omitted-values theorem. Optional PDFs may predate this
repair.

[Back to the portfolio hub](state-of-the-program.md)
