# Lane 1 collision-saturation packet: integration notes

This is an AI-assisted source-level research packet. It is not a regenerated
public release and has not undergone independent specialist review.

## Main new theorem

Let `T` be the `S_3`-Galois normalization of a generic-degree-three Keller
extension at an omitted value `y`. The attained part of `Spec(T)` is covered
by the three conjugate source charts `U_1,U_2,U_3`. Their pair and triple
intersections are explicit affine collision spaces.

For a divided-difference matrix

```text
F(X)-F(X') = M(X,X')(X-X')
```

put `q=det(M)` and `c=det(JF)`. In `S tensor_R S`,

```text
q(q-c)=0,
e_Delta=q/c,
e_Delta^2=e_Delta.
```

Thus `e_Delta` cuts out the diagonal and `1-e_Delta` cuts out the smooth
off-diagonal collision component. Pairwise-distinct triples are selected by

```text
e_dist=(1-e_12)(1-e_13)(1-e_23).
```

Form the three-chart affine Cech complex and write

```text
K_y = ker(d_1),
I_y = im(d_0),
I_y^sat = I_y :_(K_y) m_y^infinity.
```

Then

```text
I_y^sat/I_y = MatlisDual(Delta_y) tensor V_std
```

as an `A[S_3]`-module. Consequently

```text
B_y is flat  <=>  I_y^sat=I_y,
length(I_y^sat/I_y)=2 length(Delta_y).
```

A minimal defect is exactly one copy of the two-dimensional standard
representation, killed by the closed-point ideal.

## Product and standard-root consequences

If the complete Galois opening and all three source charts are formally
constant along a carrier parameter, the product vector field acts on the Cech
complex and eliminates every punctual submodule. Hence the normalization is
flat.

For the standard ordered-root triple collision, with

```text
u=r_1-r_2,
v=r_2-r_3,
```

the chart-complement ideal is

```text
(u(u+v),uv,v(u+v))=(u,v)^2.
```

Its collision cohomology is transverse local cohomology tensored with the
smooth-axis ring, so the saturation quotient vanishes. Therefore a defect
requires a genuinely non-product deformation of the complete source-chart
gluing, not merely the universal triple-root arrangement.

## Exact checks

- `verify_collision_idempotent.py` constructs the divided-difference matrix
  for the announced cubic map and verifies the fibre-ideal certificate for
  `q(q-c)` exactly over `Q`.
- `verify_standard_collision_model.py` verifies the ordered-root ideal
  identity exactly.
- Existing exact scripts continue to check the equivariant weights,
  transverse ADE matrix factorizations, and the minimal nine-cusp formulas.

## Suggested repository placement

- replace
  `data/model-handoffs-v14-20260801a/cubic-flatness-normalization-defects.md`;
- add
  `data/manuscript-sources-v1-20260801b/sources/01-cubic-incidence/appendices/flatness-defect-repairs.tex`;
- add `\input{appendices/flatness-defect-repairs}` after the current cubic
  resolvent appendix in Program 1 `main.tex`;
- place the exact scripts in a scoped Lane 1 research-tools directory;
- retain `lane1-collision-saturation-v8.pdf` only as an optional reading copy.

## Required regeneration

The selected site release is hash-pinned. After accepting the mathematics,
regenerate the manuscript-source manifest and proof pages, the Program 1
entrypoint, the handoff manifest, generated docs, release metadata, and
`site-state.json`. Then rerun source, privacy, strict MkDocs, PDF, browser,
and deployed-site checks.

## Scope

The packet gives an exact necessary-and-sufficient collision-saturation
criterion and proves it for product/equisingular collision families and the
standard triple-root model. It does not prove saturation for every
non-equivariant Keller boundary. The unresolved calculation is now the
closed-point standard-isotypic saturation of the actual pair/triple collision
rings.
