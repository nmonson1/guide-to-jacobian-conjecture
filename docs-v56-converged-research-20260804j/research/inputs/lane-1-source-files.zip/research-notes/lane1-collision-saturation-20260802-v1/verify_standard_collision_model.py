#!/usr/bin/env python3
"""Exact algebra for the standard ordered-root triple-collision model."""
from __future__ import annotations
import hashlib
from pathlib import Path
import sympy as sp
u,v=sp.symbols('u v')
f1=sp.expand(u*(u+v)); f2=sp.expand(u*v); f3=sp.expand(v*(u+v))
assert sp.expand(f1-f2-u**2)==0
assert sp.expand(f3-f2-v**2)==0
# Conversely f1,f3 are in (u^2,uv,v^2), so the ideals are equal.
G1=sp.groebner([f1,f2,f3],u,v,order='lex')
G2=sp.groebner([u**2,u*v,v**2],u,v,order='lex')
assert G1==G2
print('collision generators =',f1,f2,f3)
print('Groebner basis =',list(G1.polys))
print('verified (u(u+v),uv,v(u+v)) = (u,v)^2')
print('the common complement is the triple-root axis V(u,v)')
print('a formal axis parameter t acts injectively on H^2_(u,v)(C[[u,v,t]])')
print('therefore the closed-point collision saturation quotient vanishes')
print('script_sha256 =',hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
