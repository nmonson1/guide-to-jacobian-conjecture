#!/usr/bin/env python3
"""Exact bounded benchmark for the normalized marked-root cubic example.

This checks the polynomial map with ``A(c)=c`` and ``B(c)=-2``, the marked
root and Jacobian identities, the discriminant and its pullback, and the
normalization/conductor identities on the repeated-root divisor.  It does
not construct the integral quadratic-resolvent algebra or its eigensheaf.
"""

from __future__ import annotations

import hashlib
import json

import sympy as sp


def main() -> int:
    x, y, z, root = sp.symbols("x y z root")

    # The canonical pole-cancelling representative for A(c)=c, B(c)=-2.
    w = 2 * x - 3 * x**2 * y
    c = sp.expand(w - x**3 * z)
    t = y + 1 / x
    r = 2 / x
    b = sp.factor(sp.cancel(r - 3 * c * t**2 + 4 * t))
    a = sp.factor(sp.cancel(t / x - c * t**3 + t**2))

    for coordinate in (a, b, c):
        if not sp.denom(coordinate) == 1:
            raise AssertionError("pole cancellation did not produce a polynomial")

    expected_a = (
        x**3 * y**3 * z
        + 3 * x**2 * y**4
        + 3 * x**2 * y**2 * z
        + 7 * x * y**3
        + 3 * x * y * z
        + 4 * y**2
        + z
    )
    expected_b = (
        3 * x**3 * y**2 * z
        + 9 * x**2 * y**3
        + 6 * x**2 * y * z
        + 12 * x * y**2
        + 3 * x * z
        + y
    )
    expected_c = -x**3 * z - 3 * x**2 * y + 2 * x
    if any(
        sp.expand(left - right) != 0
        for left, right in zip((a, b, c), (expected_a, expected_b, expected_c))
    ):
        raise AssertionError("explicit normalized map changed")

    jacobian = sp.factor(sp.Matrix([a, b, c]).jacobian([x, y, z]).det())
    if jacobian != -2:
        raise AssertionError(f"Jacobian changed: {jacobian}")

    inverse_cubic = c * root**3 - 2 * root**2 + b * root - 2 * a
    if sp.factor(sp.cancel(inverse_cubic.subs(root, t))) != 0:
        raise AssertionError("marked-root identity failed")
    if sp.factor(sp.cancel(sp.diff(inverse_cubic, root).subs(root, t) - r)) != 0:
        raise AssertionError("marked-slope identity failed")

    discriminant = sp.factor(sp.discriminant(inverse_cubic, root))
    expected_discriminant = sp.expand(
        4 * b**2 - 4 * c * b**3 - 64 * a + 72 * a * c * b - 108 * a**2 * c**2
    )
    if sp.expand(discriminant - expected_discriminant) != 0:
        raise AssertionError("cubic discriminant formula failed")
    residual = sp.expand((3 * c * t - 2) ** 2 - 4 * c * r)
    if sp.factor(sp.cancel(discriminant - r**2 * residual)) != 0:
        raise AssertionError("marked Vandermonde factorization failed")

    # Parametrize the repeated-root divisor by setting r=0.
    s = sp.symbols("s")
    branch_b = -3 * c * s**2 + 4 * s
    branch_a = -c * s**3 + s**2
    h = 3 * c * s - 2
    conductor_generator_1 = sp.expand(4 - 3 * c * branch_b)
    conductor_generator_2 = sp.expand(18 * c * branch_a - 2 * branch_b)
    if sp.expand(conductor_generator_1 - h**2) != 0:
        raise AssertionError("first discriminant-conductor identity failed")
    if sp.expand(conductor_generator_2 + 2 * s * h**2) != 0:
        raise AssertionError("second discriminant-conductor identity failed")

    result = {
        "schema_version": 1,
        "name": "Lane 1 normalized marked-root benchmark",
        "status": "pass",
        "frame": {"A(c)": "c", "B(c)": "-2", "alpha": "0"},
        "map": {"a": str(sp.expand(a)), "b": str(sp.expand(b)), "c": str(c)},
        "coordinate_degrees": {
            name: sp.Poly(value, x, y, z).total_degree()
            for name, value in (("a", a), ("b", b), ("c", c))
        },
        "jacobian": str(jacobian),
        "inverse_cubic": "c*T^3-2*T^2+b*T-2*a",
        "generic_quadratic_resolvent": "K(sqrt(Delta))/K",
        "discriminant": "4*b^2-4*c*b^3-64*a+72*a*c*b-108*a^2*c^2",
        "marked_pullback": "Delta=r^2*((3*c*t-2)^2-4*c*r)",
        "finite_completion": {
            "equation": "c*T^3-2*S*T^2+b*S^2*T-2*a*S^3=0",
            "flat_rank": 3,
            "smoothness_check": (
                "d/da=-2*S^3; on S=0 the derivative d/dS=-2*T^2 is a unit"
            ),
            "ext_defect": "zero because the displayed completion is finite flat",
        },
        "different": (
            "On the finite marked-root chart the monogenic different is generated "
            "by P'(t)=r; globally the ramification Cartier divisor is r=0."
        ),
        "discriminant_conductor": {
            "normalization_parameter": "(c,s)",
            "H": "3*c*s-2",
            "target_generators": ["4-3*c*b", "18*c*a-2*b"],
            "pullbacks": ["H^2", "-2*s*H^2"],
            "normalization_conductor": "(H^2)",
        },
        "does_not_establish": [
            "an integral presentation or normalization of the quadratic resolvent",
            "the rank-one cubic eigensheaf on that resolvent",
            "a flatness theorem for an arbitrary degree-three Keller normalization",
            "recovery of the affine opening from the finite completion",
        ],
    }
    canonical = json.dumps(result, sort_keys=True, separators=(",", ":")).encode()
    result["certificate_sha256"] = hashlib.sha256(canonical).hexdigest()
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
