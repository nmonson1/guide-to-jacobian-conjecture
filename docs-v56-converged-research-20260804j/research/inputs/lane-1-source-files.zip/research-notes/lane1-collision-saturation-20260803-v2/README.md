# Recovered complete Lane 1 proof source

This packet restores the complete `flatness-defect-repairs.tex` supplied by
the Lane 1 collision-saturation contribution. The earlier tracked packet
retained a 562-line excerpt and the original unified patch, but its manifest
described an 85,987-byte, 2,336-line proof source that was not materialized as
a standalone file.

`flatness-defect-repairs-full.tex` was extracted mechanically from the
`/dev/null` addition in
`research-notes/lane1-collision-saturation-20260802-v1/lane1-collision-v8.patch`.
Its SHA-256 is
`4b468e00f6c83f158c89e90a8819858b91a1d1f4dfd7c582915204236efdb60c`,
exactly the digest recorded for `flatness-defect-repairs.tex` in the original
packet manifest.

The collision-saturation theorem and proof begin at label
`thm:collision-cech-saturation`. In that theorem, `I_y` is the image of the
first differential inside the kernel of the second differential in a
three-chart affine Cech complex; it is not a source-chart ideal. Its
saturation is closed-point saturation by `m_y^infinity` inside that kernel.

This recovery establishes access to the supplied proof body. It does not add
an independent proof of the theorem or strengthen its mathematical scope.
