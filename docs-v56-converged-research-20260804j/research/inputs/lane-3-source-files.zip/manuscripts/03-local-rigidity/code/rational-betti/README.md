# Exact rational Koszul ranks

This directory contains a second, exact route to the characteristic-zero
Betti table of the length-584 transverse local algebra.

The existing calculation gives identical torus-refined Betti tables over
three good finite fields.  Those values are upper bounds for the Betti
numbers over `QQ`.  The programs here row-reduce the same weight blocks
directly over `QQ`, using the exact rational multiplication matrices rather
than their modular reductions.

## Files

- `export_exact_koszul_multiplier.py` converts the reviewed JSON matrices
  and basis metadata to a compact deterministic binary file.
- `koszul_rank_q.cpp` constructs one torus-weight block of a Koszul
  differential and computes its rank using exact GMP rationals.
- `build_rational_betti_queue.py` creates a deterministic block queue from
  the stored modular rank records.
- `run_rational_betti_block.sh` runs one queue entry, verifies its exact rank
  against the modular value, and hashes the result.
- `program3_rational_betti.slurm` is a bounded CPU-only Slurm-array wrapper.
- `aggregate_rational_beta2.py` verifies all degree-2 and degree-3 block
  outputs and certifies the weight-refined value of `beta_2` over `QQ`.

The first production queue covers differentials `d_2` and `d_3`.  Completing
that queue certifies `beta_2=354` over `QQ`.  Later queues can use the same
engine for the remaining homological degrees.

## Exactness

No numerical approximation or random search is used.  The binary exporter
stores every rational structure constant as its exact numerator and
denominator.  The C++ engine uses canonical GMP rational arithmetic and
reports coefficient growth and resource use for each block.

The output directories are write-once.  The queue, executable, source data,
and every task result are SHA-256 pinned.
