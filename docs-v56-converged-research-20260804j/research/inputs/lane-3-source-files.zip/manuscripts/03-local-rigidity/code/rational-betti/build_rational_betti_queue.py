#!/usr/bin/env python3
"""Build a deterministic queue of exact Koszul-rank blocks."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def parse_degrees(text: str) -> set[int]:
    output: set[int] = set()
    for item in text.split(","):
        if "-" in item:
            start_text, end_text = item.split("-", 1)
            output.update(range(int(start_text), int(end_text) + 1))
        else:
            output.add(int(item))
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("modular_rank_directory", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--degrees", default="2-3")
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite {args.output}")
    degrees = parse_degrees(args.degrees)
    records = []
    for path in sorted(args.modular_rank_directory.glob("*.json")):
        record = json.loads(path.read_text(encoding="utf-8"))
        if int(record["hom"]) not in degrees:
            continue
        records.append(
            {
                "hom": int(record["hom"]),
                "weight": int(record["weight"]),
                "expected_rank": int(record["rank"]),
                "rows": int(record["rows"]),
                "cols": int(record["cols"]),
                "cells": int(record["rows"]) * int(record["cols"]),
            }
        )
    records.sort(
        key=lambda item: (
            item["cells"],
            item["hom"],
            item["weight"],
        )
    )
    lines = ["task_id\thom\tweight\texpected_rank\trows\tcols\tcells"]
    for task_id, record in enumerate(records):
        lines.append(
            "\t".join(
                str(value)
                for value in (
                    task_id,
                    record["hom"],
                    record["weight"],
                    record["expected_rank"],
                    record["rows"],
                    record["cols"],
                    record["cells"],
                )
            )
        )
    args.output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {
                "degrees": sorted(degrees),
                "tasks": len(records),
                "maximum_cells": max(
                    (record["cells"] for record in records), default=0
                ),
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
