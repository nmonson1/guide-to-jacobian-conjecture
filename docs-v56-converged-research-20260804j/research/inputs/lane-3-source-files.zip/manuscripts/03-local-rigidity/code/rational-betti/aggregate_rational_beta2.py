#!/usr/bin/env python3
"""Aggregate exact degree-2 and degree-3 Koszul ranks into beta_2 over QQ."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("queue", type=Path)
    parser.add_argument("run_directory", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--expected-beta2", type=int, default=354)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite {args.output}")

    queue_rows = []
    for line in args.queue.read_text(encoding="utf-8").splitlines()[1:]:
        if not line:
            continue
        (
            task_id,
            hom,
            weight,
            expected_rank,
            rows,
            cols,
            cells,
        ) = map(int, line.split("\t"))
        queue_rows.append(
            {
                "task_id": task_id,
                "hom": hom,
                "weight": weight,
                "expected_rank": expected_rank,
                "rows": rows,
                "cols": cols,
                "cells": cells,
            }
        )

    exact_ranks: dict[tuple[int, int], int] = {}
    task_hashes = []
    for record in queue_rows:
        task_directory = (
            args.run_directory / f"task-{record['task_id']}"
        )
        rank_path = task_directory / "rank.json"
        if not rank_path.is_file():
            raise FileNotFoundError(rank_path)
        payload = json.loads(rank_path.read_text(encoding="utf-8"))
        for key in ("hom", "weight", "rows", "cols", "rank"):
            expected = (
                record["expected_rank"]
                if key == "rank"
                else record[key]
            )
            if int(payload[key]) != expected:
                raise ValueError(
                    f"task {record['task_id']} mismatch for {key}: "
                    f"{payload[key]} != {expected}"
                )
        exact_ranks[(record["hom"], record["weight"])] = int(
            payload["rank"]
        )
        task_hashes.append(
            {
                "task_id": record["task_id"],
                "rank_json_sha256": sha256(rank_path),
            }
        )

    rows_by_key = {
        (record["hom"], record["weight"]): record
        for record in queue_rows
    }
    weights = sorted(
        {
            record["weight"]
            for record in queue_rows
            if record["hom"] in {2, 3}
        }
    )
    beta2_by_weight = {}
    for weight in weights:
        degree2 = rows_by_key.get((2, weight))
        degree3 = rows_by_key.get((3, weight))
        chain_dimension = degree2["cols"] if degree2 else 0
        if degree3 and degree3["rows"] != chain_dimension:
            raise ValueError(
                f"chain dimensions disagree at weight {weight}"
            )
        homology = (
            chain_dimension
            - exact_ranks.get((2, weight), 0)
            - exact_ranks.get((3, weight), 0)
        )
        if homology:
            beta2_by_weight[str(weight)] = homology

    beta2 = sum(beta2_by_weight.values())
    if beta2 != args.expected_beta2:
        raise AssertionError(
            f"beta_2 over QQ is {beta2}, expected {args.expected_beta2}"
        )
    output = {
        "format": 1,
        "coefficient_domain": "QQ",
        "certified_betti_index": 2,
        "beta2": beta2,
        "beta2_by_weight": beta2_by_weight,
        "queue_sha256": sha256(args.queue),
        "task_count": len(task_hashes),
        "task_hashes": task_hashes,
        "interpretation": (
            "Every degree-2 and degree-3 Koszul differential block was "
            "row-reduced using exact rational arithmetic; the ranks agree "
            "with the stored modular ranks and give beta_2 over QQ."
        ),
    }
    args.output.write_text(
        json.dumps(output, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({"beta2": beta2, "tasks": len(task_hashes)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
