#include <algorithm>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include <gmpxx.h>

using std::cerr;
using std::cout;
using std::ifstream;
using std::runtime_error;
using std::string;
using std::unordered_map;
using std::vector;

struct Entry {
    int index;
    mpq_class value;
};

using SparseVector = vector<Entry>;

static int variable_weights[10];
static int quotient_dimensions[13];
static vector<SparseVector> multiplication[10][13];

template <typename T>
void read_exact(ifstream& input, T& value) {
    input.read(reinterpret_cast<char*>(&value), sizeof(T));
    if (!input) {
        throw runtime_error("unexpected end of binary input");
    }
}

string read_string(ifstream& input) {
    uint32_t length;
    read_exact(input, length);
    string value(length, '\0');
    input.read(value.data(), length);
    if (!input) {
        throw runtime_error("unexpected end of binary string");
    }
    return value;
}

void load_multiplication(const string& path) {
    ifstream input(path, std::ios::binary);
    if (!input) {
        throw runtime_error("cannot open exact multiplier file");
    }
    char magic[8];
    input.read(magic, 8);
    if (string(magic, 8) != "KMRAT001") {
        throw runtime_error("bad exact multiplier magic");
    }
    input.read(reinterpret_cast<char*>(variable_weights), 40);
    input.read(reinterpret_cast<char*>(quotient_dimensions), 52);
    if (!input) {
        throw runtime_error("truncated exact multiplier header");
    }
    for (int variable = 0; variable < 10; ++variable) {
        for (int weight_index = 0; weight_index < 13; ++weight_index) {
            uint32_t column_count;
            read_exact(input, column_count);
            if (column_count !=
                static_cast<uint32_t>(quotient_dimensions[weight_index])) {
                throw runtime_error("column count disagrees with header");
            }
            multiplication[variable][weight_index].resize(column_count);
            for (uint32_t column = 0; column < column_count; ++column) {
                uint32_t nonzero_count;
                read_exact(input, nonzero_count);
                auto& entries =
                    multiplication[variable][weight_index][column];
                entries.reserve(nonzero_count);
                int previous_index = -1;
                for (uint32_t item = 0; item < nonzero_count; ++item) {
                    uint32_t target_index;
                    read_exact(input, target_index);
                    const string numerator = read_string(input);
                    const string denominator = read_string(input);
                    if (static_cast<int>(target_index) <= previous_index) {
                        throw runtime_error(
                            "multiplication entries are not strictly sorted"
                        );
                    }
                    previous_index = static_cast<int>(target_index);
                    mpq_class value{
                        mpz_class(numerator), mpz_class(denominator)
                    };
                    value.canonicalize();
                    if (value == 0) {
                        throw runtime_error("stored zero multiplication entry");
                    }
                    entries.push_back(
                        {static_cast<int>(target_index), std::move(value)}
                    );
                }
            }
        }
    }
    if (input.peek() != ifstream::traits_type::eof()) {
        throw runtime_error("trailing bytes in exact multiplier file");
    }
}

vector<vector<int>> combinations(int size, int choose) {
    vector<vector<int>> output;
    vector<int> current;
    std::function<void(int, int)> recurse =
        [&](int start, int remaining) {
            if (remaining == 0) {
                output.push_back(current);
                return;
            }
            for (int value = start; value <= size - remaining; ++value) {
                current.push_back(value);
                recurse(value + 1, remaining - 1);
                current.pop_back();
            }
        };
    recurse(0, choose);
    return output;
}

int weight_sum(const vector<int>& indices) {
    int total = 0;
    for (const int index : indices) {
        total += variable_weights[index];
    }
    return total;
}

string combination_key(const vector<int>& indices) {
    string result;
    for (const int index : indices) {
        result.push_back(static_cast<char>(index + 1));
    }
    return result;
}

SparseVector subtract_multiple(
    const SparseVector& vector,
    const SparseVector& pivot,
    const mpq_class& coefficient
) {
    SparseVector output;
    output.reserve(vector.size() + pivot.size());
    size_t left = 0;
    size_t right = 0;
    while (left < vector.size() || right < pivot.size()) {
        if (
            right == pivot.size() ||
            (
                left < vector.size() &&
                vector[left].index < pivot[right].index
            )
        ) {
            output.push_back(vector[left++]);
        } else if (
            left == vector.size() ||
            pivot[right].index < vector[left].index
        ) {
            mpq_class value = -coefficient * pivot[right].value;
            if (value != 0) {
                output.push_back(
                    {pivot[right].index, std::move(value)}
                );
            }
            ++right;
        } else {
            mpq_class value =
                vector[left].value - coefficient * pivot[right].value;
            if (value != 0) {
                output.push_back(
                    {vector[left].index, std::move(value)}
                );
            }
            ++left;
            ++right;
        }
    }
    return output;
}

bool insert_vector(
    SparseVector candidate,
    vector<SparseVector>& pivots,
    bool use_minimum_pivot
) {
    while (!candidate.empty()) {
        const int position =
            use_minimum_pivot ? 0 : static_cast<int>(candidate.size()) - 1;
        const int pivot_index = candidate[position].index;
        const mpq_class coefficient = candidate[position].value;
        if (pivots[pivot_index].empty()) {
            for (auto& entry : candidate) {
                entry.value /= coefficient;
            }
            pivots[pivot_index] = std::move(candidate);
            return true;
        }
        candidate = subtract_multiple(
            candidate, pivots[pivot_index], coefficient
        );
    }
    return false;
}

struct Result {
    long long rows;
    long long columns;
    long long rank;
    long long initial_nonzeros;
    long long pivot_nonzeros;
    double seconds;
    size_t maximum_numerator_bits;
    size_t maximum_denominator_bits;
};

Result differential_rank(
    int homological_degree,
    int total_weight,
    bool use_minimum_pivot
) {
    const auto row_subsets = combinations(10, homological_degree - 1);
    const auto column_subsets = combinations(10, homological_degree);
    unordered_map<string, int> offsets;
    long long row_dimension = 0;
    for (const auto& subset : row_subsets) {
        const int quotient_weight = total_weight - weight_sum(subset);
        offsets[combination_key(subset)] = static_cast<int>(row_dimension);
        if (-7 <= quotient_weight && quotient_weight <= 5) {
            row_dimension += quotient_dimensions[quotient_weight + 7];
        }
    }
    vector<SparseVector> pivots(row_dimension);
    long long column_dimension = 0;
    long long initial_nonzeros = 0;
    const auto started = std::chrono::steady_clock::now();
    auto last_report = started;

    for (const auto& subset : column_subsets) {
        const int quotient_weight = total_weight - weight_sum(subset);
        const int quotient_dimension =
            (-7 <= quotient_weight && quotient_weight <= 5)
                ? quotient_dimensions[quotient_weight + 7]
                : 0;
        for (
            int basis_index = 0;
            basis_index < quotient_dimension;
            ++basis_index
        ) {
            SparseVector candidate;
            size_t capacity = 0;
            for (const int variable : subset) {
                capacity +=
                    multiplication[variable][quotient_weight + 7]
                                  [basis_index]
                                      .size();
            }
            candidate.reserve(capacity);
            for (
                int position = 0;
                position < homological_degree;
                ++position
            ) {
                const int variable = subset[position];
                    vector<int> row_subset = subset;
                row_subset.erase(row_subset.begin() + position);
                const int offset = offsets[combination_key(row_subset)];
                const int sign = position % 2 == 0 ? 1 : -1;
                for (
                    const auto& entry :
                    multiplication[variable][quotient_weight + 7]
                                  [basis_index]
                ) {
                    candidate.push_back(
                        {
                            offset + entry.index,
                            sign == 1 ? entry.value : -entry.value,
                        }
                    );
                }
            }
            std::sort(
                candidate.begin(),
                candidate.end(),
                [](const Entry& left, const Entry& right) {
                    return left.index < right.index;
                }
            );
            SparseVector combined;
            combined.reserve(candidate.size());
            for (auto& entry : candidate) {
                if (
                    !combined.empty() &&
                    combined.back().index == entry.index
                ) {
                    combined.back().value += entry.value;
                    if (combined.back().value == 0) {
                        combined.pop_back();
                    }
                } else if (entry.value != 0) {
                    combined.push_back(std::move(entry));
                }
            }
            initial_nonzeros += combined.size();
            insert_vector(
                std::move(combined), pivots, use_minimum_pivot
            );
            ++column_dimension;
            if (column_dimension % 250 == 0) {
                const auto now = std::chrono::steady_clock::now();
                if (
                    std::chrono::duration<double>(now - last_report).count()
                    > 5
                ) {
                    long long rank = 0;
                    long long pivot_nonzeros = 0;
                    for (const auto& pivot : pivots) {
                        if (!pivot.empty()) {
                            ++rank;
                            pivot_nonzeros += pivot.size();
                        }
                    }
                    cerr
                        << "columns " << column_dimension
                        << " rank " << rank
                        << " pivot_nnz " << pivot_nonzeros
                        << " elapsed "
                        << std::chrono::duration<double>(
                               now - started
                           ).count()
                        << "\n";
                    last_report = now;
                }
            }
        }
    }

    long long rank = 0;
    long long pivot_nonzeros = 0;
    size_t maximum_numerator_bits = 0;
    size_t maximum_denominator_bits = 0;
    for (const auto& pivot : pivots) {
        if (pivot.empty()) {
            continue;
        }
        ++rank;
        pivot_nonzeros += pivot.size();
        for (const auto& entry : pivot) {
            maximum_numerator_bits = std::max(
                maximum_numerator_bits,
                mpz_sizeinbase(
                    entry.value.get_num().get_mpz_t(), 2
                )
            );
            maximum_denominator_bits = std::max(
                maximum_denominator_bits,
                mpz_sizeinbase(
                    entry.value.get_den().get_mpz_t(), 2
                )
            );
        }
    }
    const double seconds = std::chrono::duration<double>(
        std::chrono::steady_clock::now() - started
    ).count();
    return {
        row_dimension,
        column_dimension,
        rank,
        initial_nonzeros,
        pivot_nonzeros,
        seconds,
        maximum_numerator_bits,
        maximum_denominator_bits,
    };
}

int main(int argc, char** argv) {
    if (argc < 4 || argc > 5) {
        cerr
            << "usage: koszul_rank_q exact-multiplier.bin hom weight "
            << "[min|max]\n";
        return 2;
    }
    load_multiplication(argv[1]);
    const int homological_degree = std::stoi(argv[2]);
    const int total_weight = std::stoi(argv[3]);
    if (
        homological_degree < 1 ||
        homological_degree > 10
    ) {
        throw runtime_error("homological degree must be between 1 and 10");
    }
    const bool use_minimum_pivot =
        argc < 5 || string(argv[4]) != "max";
    const auto result = differential_rank(
        homological_degree, total_weight, use_minimum_pivot
    );
    cout
        << "{"
        << "\"domain\":\"QQ\","
        << "\"hom\":" << homological_degree << ","
        << "\"weight\":" << total_weight << ","
        << "\"rows\":" << result.rows << ","
        << "\"cols\":" << result.columns << ","
        << "\"rank\":" << result.rank << ","
        << "\"initial_nnz\":" << result.initial_nonzeros << ","
        << "\"pivot_nnz\":" << result.pivot_nonzeros << ","
        << "\"max_numerator_bits\":"
        << result.maximum_numerator_bits << ","
        << "\"max_denominator_bits\":"
        << result.maximum_denominator_bits << ","
        << "\"seconds\":" << std::fixed << std::setprecision(6)
        << result.seconds
        << "}\n";
    return 0;
}
