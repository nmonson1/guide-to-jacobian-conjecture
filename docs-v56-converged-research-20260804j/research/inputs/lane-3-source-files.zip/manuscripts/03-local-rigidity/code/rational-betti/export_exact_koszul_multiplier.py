#!/usr/bin/env python3
"""Export exact rational multiplication matrices to a compact binary format."""

from __future__ import annotations

import argparse
import hashlib
import json
import struct
from fractions import Fraction
from pathlib import Path


MAGIC = b"KMRAT001"


def write_new(path: Path, payload: bytes) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite {path}")
    path.write_bytes(payload)


def pack_u32(value: int) -> bytes:
    return struct.pack("<I", value)


def pack_i32(value: int) -> bytes:
    return struct.pack("<i", value)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("matrices", type=Path)
    parser.add_argument("basis", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite {args.output}")

    matrices = json.loads(args.matrices.read_text(encoding="utf-8"))
    basis = json.loads(args.basis.read_text(encoding="utf-8"))
    weights = [int(value) for value in basis["weights"]]
    weight_values = list(range(-7, 6))
    qdim = [
        len(basis["basis_by_weight"][str(weight)])
        for weight in weight_values
    ]
    if weights != [-1, 2, -3, -2, -1, 0, 1, 1, 2, 3]:
        raise ValueError("unexpected variable weights")
    if qdim != matrices["qdim"] or sum(qdim) != 584:
        raise ValueError("basis dimensions do not match matrix metadata")

    columns: list[list[list[list[tuple[int, Fraction]]]]] = [
        [
            [[] for _ in range(qdim[weight_index])]
            for weight_index in range(13)
        ]
        for _ in range(10)
    ]
    seen: set[tuple[int, int, int, int]] = set()
    for key, coefficient_text in matrices["entries"]:
        variable, source_weight, source_index, target_index = map(int, key)
        tuple_key = (
            variable,
            source_weight,
            source_index,
            target_index,
        )
        if tuple_key in seen:
            raise ValueError(f"duplicate multiplication entry {tuple_key}")
        seen.add(tuple_key)
        weight_index = source_weight + 7
        if not 0 <= weight_index < 13:
            raise ValueError(f"source weight out of range: {source_weight}")
        target_weight = source_weight + weights[variable]
        if not -7 <= target_weight <= 5:
            raise ValueError(f"target weight out of range: {target_weight}")
        if not 0 <= source_index < qdim[weight_index]:
            raise ValueError(f"source index out of range: {tuple_key}")
        if not 0 <= target_index < qdim[target_weight + 7]:
            raise ValueError(f"target index out of range: {tuple_key}")
        coefficient = Fraction(coefficient_text)
        if not coefficient:
            raise ValueError(f"stored zero entry: {tuple_key}")
        columns[variable][weight_index][source_index].append(
            (target_index, coefficient)
        )

    if len(seen) != matrices["entry_count"]:
        raise ValueError("entry count does not match matrix metadata")

    chunks = [MAGIC]
    chunks.extend(pack_i32(value) for value in weights)
    chunks.extend(pack_u32(value) for value in qdim)
    for variable in range(10):
        for weight_index in range(13):
            chunks.append(pack_u32(len(columns[variable][weight_index])))
            for column in columns[variable][weight_index]:
                column.sort(key=lambda item: item[0])
                chunks.append(pack_u32(len(column)))
                for target_index, coefficient in column:
                    numerator = str(coefficient.numerator).encode("ascii")
                    denominator = str(coefficient.denominator).encode("ascii")
                    chunks.append(pack_u32(target_index))
                    chunks.append(pack_u32(len(numerator)))
                    chunks.append(numerator)
                    chunks.append(pack_u32(len(denominator)))
                    chunks.append(denominator)

    payload = b"".join(chunks)
    write_new(args.output, payload)
    print(
        json.dumps(
            {
                "format": MAGIC.decode("ascii"),
                "bytes": len(payload),
                "entries": len(seen),
                "sha256": hashlib.sha256(payload).hexdigest(),
                "source_matrices_sha256": hashlib.sha256(
                    args.matrices.read_bytes()
                ).hexdigest(),
                "source_basis_sha256": hashlib.sha256(
                    args.basis.read_bytes()
                ).hexdigest(),
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
