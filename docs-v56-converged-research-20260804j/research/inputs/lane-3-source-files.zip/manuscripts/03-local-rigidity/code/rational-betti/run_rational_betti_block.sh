#!/usr/bin/env bash
set -euo pipefail

if [[ "$#" -ne 5 ]]; then
  echo "usage: $0 exact-rank-executable multiplier.bin queue.tsv TASK_ID OUTPUT_ROOT" >&2
  exit 2
fi

program3_rank_bin="$1"
program3_multiplier="$2"
program3_queue="$3"
program3_task_id="$4"
program3_output_root="$5"

if [[ ! -x "$program3_rank_bin" ]]; then
  echo "rank executable is not executable: $program3_rank_bin" >&2
  exit 2
fi
if [[ ! -f "$program3_multiplier" || ! -f "$program3_queue" ]]; then
  echo "multiplier or queue is missing" >&2
  exit 2
fi

program3_line_number=$((program3_task_id + 2))
program3_queue_line="$(sed -n "${program3_line_number}p" "$program3_queue")"
if [[ -z "$program3_queue_line" ]]; then
  echo "task id is absent from queue: $program3_task_id" >&2
  exit 2
fi
IFS=$'\t' read -r \
  program3_recorded_task_id \
  program3_hom \
  program3_weight \
  program3_expected_rank \
  program3_rows \
  program3_cols \
  program3_cells \
  <<< "$program3_queue_line"
if [[ "$program3_recorded_task_id" != "$program3_task_id" ]]; then
  echo "queue task id mismatch" >&2
  exit 2
fi

program3_task_dir="$program3_output_root/task-$program3_task_id"
if [[ -e "$program3_task_dir" ]]; then
  echo "refusing to overwrite: $program3_task_dir" >&2
  exit 2
fi
mkdir -p "$program3_task_dir"

printf '%s\n' "$program3_queue_line" > "$program3_task_dir/queue-row.tsv"
/usr/bin/time -v \
  "$program3_rank_bin" \
  "$program3_multiplier" \
  "$program3_hom" \
  "$program3_weight" \
  min \
  > "$program3_task_dir/rank.json" \
  2> "$program3_task_dir/rank.stderr.txt"

program3_actual_rank="$(jq -r .rank "$program3_task_dir/rank.json")"
if [[ "$program3_actual_rank" != "$program3_expected_rank" ]]; then
  echo \
    "exact rank $program3_actual_rank does not match expected modular rank $program3_expected_rank" \
    >&2
  exit 1
fi

sha256sum \
  "$program3_task_dir/queue-row.tsv" \
  "$program3_task_dir/rank.json" \
  "$program3_task_dir/rank.stderr.txt" \
  > "$program3_task_dir/SHA256SUMS"
