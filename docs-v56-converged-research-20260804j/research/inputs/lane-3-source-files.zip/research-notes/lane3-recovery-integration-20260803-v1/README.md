# Lane 3 recovery integration audit

This package closes the Lane 3 recovery audit without changing the retained
claim graph, handoff manifests, or any site source.  It records three distinct
evidence boundaries: the recovered direct order-five row spaces, the generated
formal-effectivity reports, and the already completed order-six weight and
sextic computations.

## Direct order five

Commit `f1b6ed8` reached `main` while this isolated branch was being prepared.
It already adds the producer and prose package at
`research-notes/lane3-order5-recovery-20260803-v1/`; those files are not
duplicated here.

The audited public archive has SHA-256
`48ae426de30743ad270b52299e633725153a27ceef20b131d657c682236c78cd`.
Its restricted-loader input cache has SHA-256
`2790e24c2d5ec803b1b00454d96add7c2b781095a6d2431d0ee0c563ac697033`,
and its exact replay certificate has SHA-256
`91aa952ea40b80a6d9c848e7aba51a9924cedb2d5b5b7caf4f7dd544b7d990e4`.
The exact replay gives

| parameter degree | initial rank | Hilbert value | new minimal generators |
| ---: | ---: | ---: | ---: |
| 2 | 11 | 44 | 11 |
| 3 | 112 | 108 | 13 |
| 4 | 558 | 157 | 11 |
| 5 | 1857 | 145 | 0 |

At degree five, `rank(mI)=2503` and `rank(I)=2538`.  Every rational upper
rank bound in the certificate is checked against every reconstructed row.
A nonzero pivot minor modulo `1000003` supplies each matching lower bound.

This is an exact replay of recovered direct-coordinate residual equations.
It is not the independent reconstruction from the displayed degree-seven map
and transverse slice requested by `P3-L3A0`, and it does not expose a
marked-root contracting homotopy.

## Formal-effectivity report retention

The three JSON files under `raw-formal-effectivity-reports/` are byte-for-byte
copies of the untracked reports inspected in the main checkout.  They also
match the reports preserved in
`runs/assimilation-replay-20260802-v1/lane3-formal-effectivity/`.
`manifest.json` pins every report and its producer.

The executable evidence retained from those reports is deliberately narrow:

- exact symbolic root-translation identities and finite residual samples;
- finite ramification, compatibility, degree, affine-frame, and formal-series
  sample grids;
- an independent sparse-`Fraction` replay of the finite staircase grid; and
- finite monomial counts, coefficient-variable counts, equation-degree
  bookkeeping, inequalities, and numerical asymptotic samples.

The status strings do not independently prove the Program 4 stable
`q`-classification, generic-fibre emptiness, the generic-combination lemma,
the parametric Nullstellensatz, the unrestricted double-logarithmic lower
bound, or the algebraic-stack corollary.  Those theorem-level conclusions
remain dependent on the hand proof and the inputs listed in `manifest.json`.
In particular, the asymptotic samples are consistency checks, not numerical
proofs of a limit.

The external bound was checked against D'Andrea--Krick--Sombra, Theorem 0.5,
which gives the parameter-degree estimate used after reduction to `N+1`
equations ([DOI 10.24033/asens.2196](https://doi.org/10.24033/asens.2196)).
The reduction itself is a separate argument in
`formal_effectivity_theorem.md` and is not executed by the report producer.

## Weights +2 through +15 and the sextic

The requested order-six inputs are complete and the calculations have already
finished.  Rerunning them as new Slurm jobs would duplicate verified work.

- Weights `+2..+5` are deficient, so the full-rank driver is the wrong
  command for that range.  Exact FLINT certificates give ranks/nullities
  `553/62`, `545/41`, `523/23`, and `473/7`, respectively, and verify every
  rational relation against every original row.
- Weights `+6..+15` are full column rank.  Two-prime maximal-minor
  certificates, modulo `1000003` and `1000033`, cover the larger completed
  range `+6..+18` and therefore cover the requested range.
- The exact weight-three sextic reconstruction is runnable and already has a
  completed certificate.  It gives `rank(mI)=542`, `rank(I)=545`, sextic
  initial ranks `341` and `342`, and one primitive four-term class.

All of these computations use the same recovered order-six cache, SHA-256
`2fb4548d3c274f3216617c3815dceff7c1a0877832e99839816e2785ba4c3d82`.
The producer scripts refuse to replace a nonidentical output.  Fresh replays
must use new versioned output paths.  Representative commands are:

```bash
uv run --with python-flint python \
  manuscripts/03-local-rigidity/code/order-six/certify_deficient_block_flint.py \
  /path/to/direct_order6_residual_series.pkl.gz \
  /new/versioned/output/weight-2.json \
  --cache-sha256 2fb4548d3c274f3216617c3815dceff7c1a0877832e99839816e2785ba4c3d82 \
  --weight 2

uv run python \
  manuscripts/03-local-rigidity/code/order-six/certify_full_rank_blocks.py \
  /path/to/direct_order6_residual_series.pkl.gz \
  /new/versioned/output/full-rank-weights-6-15-p1000003.json \
  --cache-sha256 2fb4548d3c274f3216617c3815dceff7c1a0877832e99839816e2785ba4c3d82 \
  --prime 1000003 \
  --weights 6:15

uv run --with python-flint python \
  manuscripts/03-local-rigidity/code/order-six/extract_sextic_generator_flint.py \
  /path/to/direct_order6_residual_series.pkl.gz \
  /new/versioned/output/primitive-weight-three-sextic.json \
  --cache-sha256 2fb4548d3c274f3216617c3815dceff7c1a0877832e99839816e2785ba4c3d82
```

Do not run `certify_full_rank_blocks.py --weights 2:15` unchanged: it is
known to stop at weight `+2` because that block is genuinely deficient.

## Audit replay

The repository-only check validates the copied reports, their producer
hashes, the finite sample grids, and the theorem-source hashes:

```bash
uv run python \
  research-notes/lane3-recovery-integration-20260803-v1/check_lane3_recovery.py
```

On the workspace that holds the materialized evidence, add both optional
arguments:

```bash
uv run python \
  research-notes/lane3-recovery-integration-20260803-v1/check_lane3_recovery.py \
  --order5-archive \
  /path/to/versioned-artifact \
  --runs-root /path/to/versioned-artifact
```

The checker is read-only.  No canonical retained-graph selector is changed by
this package.
