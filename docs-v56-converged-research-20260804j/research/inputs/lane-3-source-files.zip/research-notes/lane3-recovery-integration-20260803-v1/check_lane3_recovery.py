#!/usr/bin/env python3
"""Check the retained Lane 3 reports and optional materialized artifacts."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
import zipfile
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
MANIFEST = HERE / "manifest.json"


def digest_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def digest(path: Path) -> str:
    return digest_bytes(path.read_bytes())


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(f"expected JSON object: {path}")
    return value


def assert_hash(path: Path, expected: str) -> None:
    actual = digest(path)
    if actual != expected:
        raise AssertionError(
            f"SHA-256 mismatch for {path}: expected {expected}, found {actual}"
        )


def check_formal_reports(manifest: dict[str, Any]) -> None:
    formal = manifest["formal_effectivity"]
    reports: dict[str, dict[str, Any]] = {}
    for item in formal["reports"]:
        report_path = HERE / item["path"]
        producer_path = REPO / item["producer_path"]
        if report_path.stat().st_size != item["bytes"]:
            raise AssertionError(f"byte-size mismatch: {report_path}")
        assert_hash(report_path, item["sha256"])
        assert_hash(producer_path, item["producer_sha256"])
        reports[report_path.name] = load_json(report_path)

    theorem = formal["theorem_source"]
    assert_hash(REPO / theorem["path"], theorem["sha256"])
    program4 = formal["external_inputs_not_reproved_by_reports"][0]
    assert_hash(REPO / "manuscripts/04-stable-moduli/main.tex", program4["sha256"])

    symbolic = reports["formal_effectivity_report.json"]
    if symbolic["status"] != "ALL FORMAL-EFFECTIVITY CHECKS PASSED":
        raise AssertionError("unexpected symbolic report status")
    residuals = symbolic["universal_residual_checks"]
    if [item["D"] for item in residuals] != list(range(11)):
        raise AssertionError("unexpected universal residual sample range")
    expected_degrees = [-1, *range(1, 11)]
    if [item["phi_c_degree"] for item in residuals] != expected_degrees:
        raise AssertionError("unexpected residual translation degrees")

    ramification = symbolic["ramification_samples"]
    expected_pairs = [
        (modulus, order)
        for modulus in range(2, 15)
        for order in range(1, min(5, modulus))
    ]
    if [(item["M"], item["e"]) for item in ramification] != expected_pairs:
        raise AssertionError("unexpected symbolic ramification grid")
    for item in ramification:
        expected = max(0, math.ceil(item["M"] / item["e"]) - 2)
        if item["minimal_c_degree"] != expected:
            raise AssertionError(f"bad ramification degree: {item}")

    compatibility = symbolic["unramified_compatibility"]
    if [item["M"] for item in compatibility] != list(range(1, 15)):
        raise AssertionError("unexpected compatibility range")
    for item in compatibility:
        modulus = item["M"]
        expected_degree = max(0, modulus - 2)
        expected_source = 1 if modulus <= 2 else 4 * expected_degree
        expected_target = 1 if modulus <= 2 else modulus - 1
        observed = (
            item["c_degree"],
            item["source_degree"],
            item["target_degree"],
        )
        if observed != (expected_degree, expected_source, expected_target):
            raise AssertionError(f"bad compatibility row: {item}")

    canonical = symbolic["canonical_degree_checks"]
    if [item["M"] for item in canonical] != list(range(3, 11)):
        raise AssertionError("unexpected canonical degree range")
    for item in canonical:
        degree = item["M"] - 2
        if (
            item["D"],
            item["source_degree"],
            item["target_degree"],
            item["target_inverse_degree"],
        ) != (degree, 4 * degree, degree + 1, degree + 1):
            raise AssertionError(f"bad canonical degree row: {item}")

    affine = symbolic["affine_frame_checks"]
    if [item["M"] for item in affine] != list(range(3, 13)):
        raise AssertionError("unexpected affine sample range")
    if any(item["h_c_degree"] != item["M"] - 2 for item in affine):
        raise AssertionError("affine sample lowers the expected degree")

    formal_coefficients = symbolic["formal_limit_coefficients"]
    if [item["s_power"] for item in formal_coefficients] != list(range(2, 13)):
        raise AssertionError("unexpected formal coefficient range")
    if any(item["c_degree"] != item["s_power"] - 1 for item in formal_coefficients):
        raise AssertionError("unexpected formal coefficient degree")

    independent = reports["formal_effectivity_independent_report.json"]
    if independent["status"] != "INDEPENDENT EFFECTIVITY STAIRCASE CHECKS PASSED":
        raise AssertionError("unexpected independent report status")
    expected_samples = [
        {
            "M": modulus,
            "e": order,
            "D": max(0, math.ceil(modulus / order) - 2),
            "sharp": True,
        }
        for modulus in range(2, 31)
        for order in range(1, min(modulus, 8))
    ]
    if independent["samples"] != expected_samples:
        raise AssertionError("independent staircase samples do not match the grid")
    if independent["sample_count"] != len(expected_samples):
        raise AssertionError("independent sample count mismatch")

    bound = reports["effective_unframed_bound_report.json"]
    if bound["status"] != "ALL EFFECTIVE UNFRAMED BOUND CHECKS PASSED":
        raise AssertionError("unexpected bound report status")
    enumerations = bound["enumeration_checks"]
    expected_enumerations = [
        {"n": n, "b": degree, "count": math.comb(n + degree, n)}
        for n in range(1, 5)
        for degree in range(5)
    ]
    if enumerations != expected_enumerations:
        raise AssertionError("monomial enumeration checks do not match formulas")
    for item in bound["degree_checks"]:
        degree = item["b"]
        if item != {
            "b": degree,
            "coefficient_degree": max(degree + 1, 11),
            "parameter_degree": 2 * degree,
        }:
            raise AssertionError(f"bad equation-degree row: {item}")
    if [item["b"] for item in bound["degree_checks"]] != list(range(1, 21)):
        raise AssertionError("unexpected equation-degree sample range")
    for item in bound["exact_samples"]:
        n = item["ambient_dimension"]
        degree = item["b"]
        monomials = math.comb(n + degree, n)
        if item["monomials_per_coordinate"] != monomials:
            raise AssertionError(f"bad monomial count: {item}")
        if item["coefficient_variables"] != 4 * n * monomials:
            raise AssertionError(f"bad coefficient-variable count: {item}")
    if len(bound["exact_samples"]) != 20:
        raise AssertionError("unexpected exact bound sample count")
    for item in bound["fixed_n_asymptotics"]:
        if not math.isclose(
            item["target_coefficient"],
            4 / math.factorial(item["n"] - 1),
        ):
            raise AssertionError(f"bad fixed-n target: {item}")
    for item in bound["unrestricted_asymptotics"]:
        if not math.isclose(item["target"], math.log(4)):
            raise AssertionError(f"bad unrestricted target: {item}")


def check_order5_archive(path: Path, manifest: dict[str, Any]) -> None:
    order5 = manifest["order5_evidence"]
    assert_hash(path, order5["archive_sha256"])
    with zipfile.ZipFile(path) as archive:
        cache = archive.read(order5["cache_name"])
        certificate_payload = archive.read(order5["certificate_name"])
        producer = archive.read(Path(manifest["order5_overlap"]["producer_path"]).name)
    if digest_bytes(cache) != order5["cache_sha256"]:
        raise AssertionError("order-five cache digest mismatch")
    if digest_bytes(certificate_payload) != order5["certificate_sha256"]:
        raise AssertionError("order-five certificate digest mismatch")
    if digest_bytes(producer) != manifest["order5_overlap"]["producer_sha256"]:
        raise AssertionError("order-five producer digest mismatch")
    certificate = json.load(io.TextIOWrapper(io.BytesIO(certificate_payload)))
    if certificate["cache"]["sha256"] != order5["cache_sha256"]:
        raise AssertionError("certificate names a different order-five cache")
    final = certificate["degrees"][-1]
    retained = order5["retained_result"]
    observed = {
        "initial_rank": final["initial_rank"],
        "hilbert_value": final["hilbert_value"],
        "new_minimal_generators": final["new_minimal_generators"],
        "rank_mI_over_Q": final["rank_mI_over_Q"],
        "rank_I_over_Q": final["rank_I_over_Q"],
    }
    if observed != retained:
        raise AssertionError(f"order-five retained result mismatch: {observed}")
    for degree in certificate["degrees"]:
        for block in degree["blocks"]:
            for key in ("maximal_ideal_multiple", "ideal"):
                if not block[key]["upper_bound"]["all_rows_verified"]:
                    raise AssertionError(
                        "order-five upper bound is not all-row verified"
                    )


def check_order6_artifacts(runs_root: Path, manifest: dict[str, Any]) -> None:
    order6 = manifest["order6_evidence"]
    for relative, expected in order6["producer_sha256"].items():
        assert_hash(REPO / relative, expected)
    loaded: dict[str, dict[str, Any]] = {}
    for relative, expected in order6["artifacts"].items():
        path = runs_root / relative
        assert_hash(path, expected)
        loaded[relative] = load_json(path)

    positive_paths = [
        "program3-order6-positive-v2/full-rank-blocks-p1000003.json",
        "program3-order6-positive-v2/full-rank-blocks-p1000033.json",
    ]
    for expected_prime, relative in zip((1_000_003, 1_000_033), positive_paths):
        data = loaded[relative]
        if data["prime"] != expected_prime:
            raise AssertionError(f"unexpected prime in {relative}")
        if data["cache"]["sha256"] != order6["cache_sha256"]:
            raise AssertionError(f"cache mismatch in {relative}")
        if [item["weight"] for item in data["blocks"]] != list(range(6, 19)):
            raise AssertionError(f"unexpected positive-weight coverage in {relative}")
        for block in data["blocks"]:
            if not block["full_column_rank_over_Q"]:
                raise AssertionError(f"non-full block in {relative}")
            if block["rank"] != block["column_count"]:
                raise AssertionError(f"rank mismatch in {relative}")
            if block["echelon_pivot_product_mod_prime"] == 0:
                raise AssertionError(f"zero pivot product in {relative}")

    for weight in range(1, 6):
        relative = f"program3-order6-deficient-v3/weight-{weight}.json"
        data = loaded[relative]
        if data["weight"] != weight:
            raise AssertionError(f"wrong deficient weight in {relative}")
        if data["cache"]["sha256"] != order6["cache_sha256"]:
            raise AssertionError(f"cache mismatch in {relative}")
        if data["rank_over_Q"] + data["nullity_over_Q"] != data["column_count"]:
            raise AssertionError(f"rank-nullity mismatch in {relative}")
        if not data["upper_bound_certificate"]["all_rational_rows_verified"]:
            raise AssertionError(f"upper bound is not all-row verified in {relative}")
        if data["lower_bound_certificate"]["echelon_pivot_product_mod_prime"] == 0:
            raise AssertionError(f"zero deficient pivot product in {relative}")

    sextic_relative = "program3-order6-sextic-v1/primitive-weight-three-sextic.json"
    sextic = loaded[sextic_relative]
    if sextic["cache"]["sha256"] != order6["cache_sha256"]:
        raise AssertionError("sextic cache mismatch")
    expected = order6["sextic_result"]
    observed = {
        "target_weight": sextic["target_weight"],
        "rank_mI_over_Q": sextic["rank_mI_over_Q"],
        "rank_I_over_Q": sextic["rank_I_over_Q"],
        "sextic_initial_rank_mI_over_Q": sextic["sextic_initial_rank_mI_over_Q"],
        "sextic_initial_rank_I_over_Q": sextic["sextic_initial_rank_I_over_Q"],
        "new_sextic_dimension": sextic["new_sextic_dimension"],
        "primitive_term_count": sextic["primitive_sextic"]["term_count"],
    }
    if observed != expected:
        raise AssertionError(f"sextic result mismatch: {observed}")
    upper = sextic["upper_bound_certificates"]
    if not upper["mI_all_rational_rows_verified"]:
        raise AssertionError("sextic mI upper bound is not all-row verified")
    if not upper["I_all_rational_rows_verified"]:
        raise AssertionError("sextic I upper bound is not all-row verified")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--order5-archive", type=Path)
    parser.add_argument("--runs-root", type=Path)
    args = parser.parse_args()
    manifest = load_json(MANIFEST)
    check_formal_reports(manifest)
    print("FORMAL REPORT RETENTION CHECKS PASSED")
    if args.order5_archive is not None:
        check_order5_archive(args.order5_archive.resolve(), manifest)
        print("ORDER-FIVE ARCHIVE CHECKS PASSED")
    if args.runs_root is not None:
        check_order6_artifacts(args.runs_root.resolve(), manifest)
        print("ORDER-SIX ARTIFACT CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
