# Recovery and publication audit

The source cache and the historical summary were recovered from the reviewed
Program 3 artifact intake.  The cache has SHA-256
`2790e24c2d5ec803b1b00454d96add7c2b781095a6d2431d0ee0c563ac697033`.

The replay does not trust the historical rank summary.  It reconstructs the
filtered coefficient equations from the cache, constructs the Macaulay row
spaces with a declared monomial order, and certifies the rational ranks.  The
historical summary and modular discovery table are included in the public
archive only as lineage checks.

The public exporter must omit intake identifiers, recovery-tree paths,
conversation metadata, and the original pickle rank certificate.  It may
publish the residual cache because the restricted loader audits its exact
class vocabulary before admitting it, and because the public archive pins
its digest.
