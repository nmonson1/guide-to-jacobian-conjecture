# Lane 3 direct order-five recovery

This packet restores and replays the recovered direct-coordinate Kuranishi
calculation through parameter order five.  The recovered cache contains the
filtered rational residual equations in the ten tangent parameters; it is
not an independent reconstruction from the displayed base map and transverse
slice.

The replay rebuilds the weighted Macaulay blocks in parameter degrees two
through five.  For every block, a nonzero pivot minor modulo a good prime
gives the rank lower bound.  Exact FLINT row reduction supplies the rational
column relations for the matching upper bound, and those relations are
checked against every original row.

The expected exact output is

| parameter degree | initial rank | Hilbert value | new minimal generators |
| ---: | ---: | ---: | ---: |
| 2 | 11 | 44 | 11 |
| 3 | 112 | 108 | 13 |
| 4 | 558 | 157 | 11 |
| 5 | 1857 | 145 | 0 |

Through order five, the ideal rank is `2538`, the maximal-ideal multiple has
rank `2503`, and the cumulative minimal-generator dimension is `35`.

## Replay

The public bundle places the recovered cache beside the verifier.  From its
root, run

```bash
uv run --with python-flint --with sympy==1.14.0 \
  python verify_order5_recovery.py \
  direct_order5_residual_series.pkl.gz \
  /tmp/lane3-order5-replay.json \
  --cache-sha256 2790e24c2d5ec803b1b00454d96add7c2b781095a6d2431d0ee0c563ac697033
cmp /tmp/lane3-order5-replay.json order5_exact_replay_certificate.json
```

The verifier refuses to overwrite an existing output.  The pickle loader is
restricted to audited builtin containers, `Fraction`, `defaultdict`, and
SymPy rational numbers.

## Boundary

This packet verifies the recovered direct-coordinate row spaces and their
exact ranks.  It does not reconstruct the order-five equations independently
from the published map, expose the marked-root contracting homotopy, compare
the direct and marked-root complexes in order five, or establish any
degree-eight orbit-saturation statement.
