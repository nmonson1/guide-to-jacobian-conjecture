#!/usr/bin/env python3
"""Rebuild and certify the recovered direct order-five Macaulay ranks.

The recovered cache is loaded with a restricted unpickler.  Each rational
rank is proved by a modular pivot minor and exact FLINT nullspace relations
that are checked against every row.  The output is deterministic and the
destination must not already exist.
"""

from __future__ import annotations

import argparse
import builtins
import collections
import fractions
import gzip
import hashlib
import itertools
import json
import math
import pickle
from collections.abc import Iterable
from pathlib import Path
from typing import Any

import sympy as sp
from flint import fmpq_mat


WEIGHTS = (-1, 2, -3, -2, -1, 0, 1, 1, 2, 3)
EXPECTED_CACHE_KEYS = {
    "weights",
    "pairs",
    "triples",
    "quads",
    "quints",
    "residuals",
    "k5corr",
    "block_summary5",
}
ALLOWED_PICKLE_CLASSES = {
    ("builtins", name): getattr(builtins, name)
    for name in ("dict", "list", "tuple", "set", "frozenset")
}
ALLOWED_PICKLE_CLASSES.update(
    {
        ("collections", "defaultdict"): collections.defaultdict,
        ("fractions", "Fraction"): fractions.Fraction,
        ("sympy.core.numbers", "Rational"): sp.Rational,
    }
)


class RestrictedUnpickler(pickle.Unpickler):
    """Unpickler limited to the audited cache's data classes."""

    def find_class(self, module: str, name: str) -> Any:
        try:
            return ALLOWED_PICKLE_CLASSES[(module, name)]
        except KeyError as error:
            raise pickle.UnpicklingError(
                f"forbidden pickle global {module}.{name}"
            ) from error


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_cache(path: Path) -> dict[str, Any]:
    with gzip.open(path, "rb") as handle:
        value = RestrictedUnpickler(handle).load()
    if not isinstance(value, dict):
        raise TypeError("order-five cache is not a dictionary")
    if set(value) != EXPECTED_CACHE_KEYS:
        raise ValueError(
            f"unexpected cache keys: {sorted(set(value) ^ EXPECTED_CACHE_KEYS)}"
        )
    if tuple(value["weights"]) != WEIGHTS:
        raise ValueError("unexpected tangent-weight convention")
    if sorted(value["residuals"]) != [2, 3, 4, 5]:
        raise ValueError("cache does not contain residual orders two through five")
    expected_counts = {
        "pairs": math.comb(11, 2),
        "triples": math.comb(12, 3),
        "quads": math.comb(13, 4),
        "quints": math.comb(14, 5),
    }
    for key, expected in expected_counts.items():
        if len(value[key]) != expected:
            raise ValueError(f"unexpected {key} count")
    return value


def as_fraction(value: Any) -> fractions.Fraction:
    if isinstance(value, fractions.Fraction):
        return value
    if isinstance(value, sp.Rational):
        return fractions.Fraction(int(value.p), int(value.q))
    if isinstance(value, int):
        return fractions.Fraction(value)
    raise TypeError(f"unexpected coefficient type {type(value).__name__}")


def parameter_weight(monomial: Iterable[int]) -> int:
    return sum(WEIGHTS[index] for index in monomial)


def parameter_monomials(
    minimum_degree: int, maximum_degree: int
) -> list[tuple[int, ...]]:
    return [
        monomial
        for degree in range(minimum_degree, maximum_degree + 1)
        for monomial in itertools.combinations_with_replacement(
            range(len(WEIGHTS)), degree
        )
    ]


def filtered_equations(
    cache: dict[str, Any],
) -> dict[
    tuple[int, tuple[int, ...]],
    dict[tuple[int, ...], fractions.Fraction],
]:
    equations: dict[
        tuple[int, tuple[int, ...]],
        dict[tuple[int, ...], fractions.Fraction],
    ] = {}
    for order, blocks in sorted(cache["residuals"].items()):
        for weight, residuals in sorted(blocks.items()):
            for parameter_monomial, polynomial in residuals.items():
                if len(parameter_monomial) != order:
                    raise ValueError("parameter order mismatch")
                if parameter_weight(parameter_monomial) != weight:
                    raise ValueError("parameter weight mismatch")
                for output_monomial, coefficient in polynomial.items():
                    equation = equations.setdefault(
                        (weight, tuple(output_monomial)), {}
                    )
                    rational = as_fraction(coefficient)
                    previous = equation.get(parameter_monomial)
                    if previous is not None and previous != rational:
                        raise ValueError("conflicting filtered coefficient")
                    equation[tuple(parameter_monomial)] = rational
    return equations


def macaulay_rows(
    equations: dict[
        tuple[int, tuple[int, ...]],
        dict[tuple[int, ...], fractions.Fraction],
    ],
    target_weight: int,
    maximum_degree: int,
) -> tuple[
    list[tuple[int, ...]],
    list[dict[int, fractions.Fraction]],
    list[dict[int, fractions.Fraction]],
]:
    columns = [
        monomial
        for monomial in parameter_monomials(2, maximum_degree)
        if parameter_weight(monomial) == target_weight
    ]
    column_index = {monomial: index for index, monomial in enumerate(columns)}
    multipliers: dict[tuple[int, int], list[tuple[int, ...]]] = (
        collections.defaultdict(list)
    )
    for monomial in parameter_monomials(0, maximum_degree - 2):
        multipliers[(len(monomial), parameter_weight(monomial))].append(
            monomial
        )

    maximal_ideal_rows: list[dict[int, fractions.Fraction]] = []
    total_rows: list[dict[int, fractions.Fraction]] = []
    for (equation_weight, _), polynomial in sorted(equations.items()):
        leading_degree = min(len(monomial) for monomial in polynomial)
        for multiplier_degree in range(maximum_degree - leading_degree + 1):
            for multiplier in multipliers[
                (multiplier_degree, target_weight - equation_weight)
            ]:
                row: dict[int, fractions.Fraction] = {}
                for monomial, coefficient in polynomial.items():
                    product = tuple(sorted(monomial + multiplier))
                    if len(product) > maximum_degree:
                        continue
                    if parameter_weight(product) != target_weight:
                        raise AssertionError("constructed row has wrong weight")
                    index = column_index[product]
                    row[index] = row.get(index, fractions.Fraction()) + coefficient
                row = {index: value for index, value in row.items() if value}
                if not row:
                    continue
                total_rows.append(row)
                if multiplier_degree:
                    maximal_ideal_rows.append(row)
    return columns, maximal_ideal_rows, total_rows


def coefficient_mod_prime(value: fractions.Fraction, prime: int) -> int:
    denominator = value.denominator % prime
    if not denominator:
        raise ZeroDivisionError(f"denominator is divisible by {prime}")
    return value.numerator % prime * pow(denominator, -1, prime) % prime


def modular_basis(
    rows: list[dict[int, fractions.Fraction]], prime: int
) -> tuple[list[int], list[int], int]:
    basis: dict[int, dict[int, int]] = {}
    selected_rows: list[int] = []
    pivot_columns: list[int] = []
    pivot_product = 1
    for row_index, rational_row in enumerate(rows):
        row = {
            column: coefficient_mod_prime(coefficient, prime)
            for column, coefficient in rational_row.items()
        }
        row = {column: value for column, value in row.items() if value}
        while row:
            pivot = min(row)
            if pivot not in basis:
                pivot_value = row[pivot]
                pivot_product = pivot_product * pivot_value % prime
                inverse = pow(pivot_value, -1, prime)
                basis[pivot] = {
                    column: value * inverse % prime
                    for column, value in row.items()
                }
                selected_rows.append(row_index)
                pivot_columns.append(pivot)
                break
            factor = row[pivot]
            for column, value in basis[pivot].items():
                updated = (row.get(column, 0) - factor * value) % prime
                if updated:
                    row[column] = updated
                else:
                    row.pop(column, None)
    return selected_rows, pivot_columns, pivot_product


def as_flint_text(value: fractions.Fraction) -> str:
    if value.denominator == 1:
        return str(value.numerator)
    return f"{value.numerator}/{value.denominator}"


def selected_matrix(
    rows: list[dict[int, fractions.Fraction]],
    selected_rows: list[int],
    column_count: int,
) -> fmpq_mat:
    entries = []
    for row_index in selected_rows:
        row = rows[row_index]
        entries.extend(
            as_flint_text(row.get(column, fractions.Fraction()))
            for column in range(column_count)
        )
    return fmpq_mat(len(selected_rows), column_count, entries)


def exact_relations(
    matrix: fmpq_mat,
) -> tuple[list[int], list[int], list[list[fractions.Fraction]]]:
    rref, rank = matrix.rref()
    pivot_columns: list[int] = []
    pivot_rows: dict[int, int] = {}
    for row in range(rank):
        pivot = next(
            (column for column in range(matrix.ncols()) if rref[row, column]),
            None,
        )
        if pivot is None:
            raise AssertionError("nonzero RREF row has no pivot")
        pivot_columns.append(pivot)
        pivot_rows[pivot] = row
    free_columns = [
        column for column in range(matrix.ncols()) if column not in pivot_rows
    ]
    relations = []
    for free_column in free_columns:
        relations.append(
            [
                fractions.Fraction(
                    int((-rref[pivot_rows[pivot], free_column]).numerator),
                    int((-rref[pivot_rows[pivot], free_column]).denominator),
                )
                for pivot in pivot_columns
            ]
        )
    return pivot_columns, free_columns, relations


def verify_relations(
    rows: list[dict[int, fractions.Fraction]],
    pivot_columns: list[int],
    free_columns: list[int],
    relations: list[list[fractions.Fraction]],
) -> None:
    pivot_position = {column: index for index, column in enumerate(pivot_columns)}
    free_position = {column: index for index, column in enumerate(free_columns)}
    for row_index, row in enumerate(rows):
        totals = [fractions.Fraction() for _ in free_columns]
        for column, coefficient in row.items():
            if column in pivot_position:
                position = pivot_position[column]
                for relation_index, relation in enumerate(relations):
                    value = relation[position]
                    if value:
                        totals[relation_index] += coefficient * value
            else:
                totals[free_position[column]] += coefficient
        if any(totals):
            raise AssertionError(f"relation failed on row {row_index}")


def relation_digest(
    pivot_columns: list[int],
    free_columns: list[int],
    relations: list[list[fractions.Fraction]],
) -> str:
    value = {
        "pivots": pivot_columns,
        "free": free_columns,
        "relations": [
            [[entry.numerator, entry.denominator] for entry in relation]
            for relation in relations
        ],
    }
    payload = json.dumps(value, separators=(",", ":"), sort_keys=True).encode()
    return hashlib.sha256(payload).hexdigest()


def certify_rows(
    rows: list[dict[int, fractions.Fraction]],
    column_count: int,
    prime: int,
) -> dict[str, Any]:
    if not column_count:
        if rows:
            raise AssertionError("rows exist without columns")
        return {
            "row_count": 0,
            "column_count": 0,
            "rank_over_Q": 0,
            "nullity_over_Q": 0,
            "lower_bound": {"prime": prime, "selected_rows": [], "pivots": []},
            "upper_bound": {"all_rows_verified": True, "relation_sha256": None},
        }
    selected, modular_pivots, pivot_product = modular_basis(rows, prime)
    matrix = selected_matrix(rows, selected, column_count)
    exact_pivots, free_columns, relations = exact_relations(matrix)
    if len(exact_pivots) != len(modular_pivots):
        raise AssertionError("exact and modular ranks disagree")
    verify_relations(rows, exact_pivots, free_columns, relations)
    return {
        "row_count": len(rows),
        "column_count": column_count,
        "rank_over_Q": len(exact_pivots),
        "nullity_over_Q": len(free_columns),
        "lower_bound": {
            "prime": prime,
            "selected_rows": selected,
            "pivots": modular_pivots,
            "pivot_product_mod_prime": pivot_product,
        },
        "upper_bound": {
            "engine": "python-flint exact fmpq_mat.rref",
            "all_rows_verified": True,
            "relation_sha256": relation_digest(
                exact_pivots, free_columns, relations
            ),
        },
    }


def write_new(path: Path, value: dict[str, Any]) -> None:
    payload = (
        json.dumps(value, indent=2, sort_keys=True, separators=(",", ": ")) + "\n"
    ).encode()
    if path.exists():
        raise FileExistsError(f"refusing to overwrite {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(payload)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("cache", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cache-sha256", required=True)
    parser.add_argument("--prime", type=int, default=1_000_003)
    args = parser.parse_args()

    cache_path = args.cache.resolve()
    actual_sha256 = sha256(cache_path)
    if actual_sha256 != args.cache_sha256:
        raise ValueError(
            f"cache digest mismatch: expected {args.cache_sha256}, "
            f"found {actual_sha256}"
        )
    cache = load_cache(cache_path)
    equations = filtered_equations(cache)
    degrees = []
    previous_quotient = 11
    previous_generators = 0
    for maximum_degree in range(2, 6):
        blocks = []
        total_rank = 0
        maximal_rank = 0
        weights = range(-3 * maximum_degree, 3 * maximum_degree + 1)
        for weight in weights:
            columns, maximal_rows, total_rows = macaulay_rows(
                equations, weight, maximum_degree
            )
            maximal = certify_rows(maximal_rows, len(columns), args.prime)
            total = certify_rows(total_rows, len(columns), args.prime)
            maximal_rank += maximal["rank_over_Q"]
            total_rank += total["rank_over_Q"]
            blocks.append(
                {
                    "weight": weight,
                    "maximal_ideal_multiple": maximal,
                    "ideal": total,
                }
            )
            print(
                f"degree {maximum_degree}, weight {weight}: "
                f"rank(mI)={maximal['rank_over_Q']}, "
                f"rank(I)={total['rank_over_Q']}",
                flush=True,
            )
        ambient = math.comb(10 + maximum_degree, maximum_degree)
        quotient = ambient - total_rank
        hilbert = quotient - previous_quotient
        degree_monomials = math.comb(9 + maximum_degree, maximum_degree)
        initial_rank = degree_monomials - hilbert
        generators = total_rank - maximal_rank
        new_generators = generators - previous_generators
        degrees.append(
            {
                "maximum_parameter_degree": maximum_degree,
                "ambient_cumulative_dimension": ambient,
                "rank_I_over_Q": total_rank,
                "rank_mI_over_Q": maximal_rank,
                "quotient_cumulative_dimension": quotient,
                "hilbert_value": hilbert,
                "initial_rank": initial_rank,
                "cumulative_minimal_generators": generators,
                "new_minimal_generators": new_generators,
                "blocks": blocks,
            }
        )
        previous_quotient = quotient
        previous_generators = generators

    expected = {
        2: (11, 44, 11),
        3: (112, 108, 13),
        4: (558, 157, 11),
        5: (1857, 145, 0),
    }
    for degree in degrees:
        observed = (
            degree["initial_rank"],
            degree["hilbert_value"],
            degree["new_minimal_generators"],
        )
        if observed != expected[degree["maximum_parameter_degree"]]:
            raise AssertionError((degree["maximum_parameter_degree"], observed))
    final = degrees[-1]
    if (
        final["rank_mI_over_Q"],
        final["rank_I_over_Q"],
        final["cumulative_minimal_generators"],
    ) != (2503, 2538, 35):
        raise AssertionError("unexpected order-five cumulative ranks")

    output = {
        "schema_version": 1,
        "claim": (
            "The recovered direct-coordinate filtered Kuranishi ideal has "
            "Hilbert value 145 in parameter order five and no new minimal "
            "quintic generator."
        ),
        "scope": (
            "Exact replay of the recovered residual cache; not an independent "
            "reconstruction from the base map and transverse slice."
        ),
        "cache": {
            "path_name": cache_path.name,
            "sha256": actual_sha256,
            "restricted_unpickler": True,
        },
        "parameter_weights": list(WEIGHTS),
        "monomial_order": (
            "total parameter degree, then lexicographic combinations-with-"
            "replacement order on zero-based parameter indices"
        ),
        "degrees": degrees,
    }
    write_new(args.output.resolve(), output)
    print("order-five exact replay certificate written", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
