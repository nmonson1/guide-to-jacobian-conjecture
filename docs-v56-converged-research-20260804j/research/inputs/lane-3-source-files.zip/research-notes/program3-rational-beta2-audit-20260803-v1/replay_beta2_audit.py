#!/usr/bin/env python3
"""Replay the 49-task exact-QQ beta2 aggregate into a write-once receipt."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys


EXPECTED_BETA2 = 354
EXPECTED_TASKS = 49


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command_output(argv: list[str], cwd: Path) -> str:
    completed = subprocess.run(
        argv,
        cwd=cwd,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def hashed_file(path: Path) -> dict[str, object]:
    return {
        "path": str(path.resolve()),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("queue", type=Path)
    parser.add_argument("task_run_directory", type=Path)
    parser.add_argument("output_directory", type=Path)
    args = parser.parse_args()

    script = Path(__file__).resolve()
    repository = script.parents[2]
    source_directory = (
        repository / "manuscripts" / "03-local-rigidity" / "code" / "rational-betti"
    )
    aggregate_source = source_directory / "aggregate_rational_beta2.py"

    queue = args.queue.resolve()
    task_run_directory = args.task_run_directory.resolve()
    output_directory = args.output_directory.resolve()
    if output_directory.exists():
        raise FileExistsError(f"refusing to overwrite {output_directory}")
    if not queue.is_file() or not task_run_directory.is_dir():
        raise FileNotFoundError("queue or task run directory is absent")

    rank_paths = sorted(
        task_run_directory.glob("task-*/rank.json"),
        key=lambda path: int(path.parent.name.removeprefix("task-")),
    )
    if len(rank_paths) != EXPECTED_TASKS:
        raise ValueError(
            f"expected {EXPECTED_TASKS} rank outputs, found {len(rank_paths)}"
        )

    output_directory.mkdir(parents=False)
    aggregate_output = output_directory / "beta2.json"
    aggregate_command = [
        sys.executable,
        str(aggregate_source),
        str(queue),
        str(task_run_directory),
        str(aggregate_output),
        "--expected-beta2",
        str(EXPECTED_BETA2),
    ]
    completed = subprocess.run(
        aggregate_command,
        cwd=repository,
        check=True,
        capture_output=True,
        text=True,
    )

    aggregate = json.loads(aggregate_output.read_text(encoding="utf-8"))
    if aggregate["beta2"] != EXPECTED_BETA2:
        raise AssertionError("aggregate beta2 mismatch")
    if aggregate["task_count"] != EXPECTED_TASKS:
        raise AssertionError("aggregate task-count mismatch")

    upstream_directory = queue.parent
    upstream_names = [
        "exact-multiplier.bin",
        "export-metadata.json",
        "koszul_rank_q",
        "queue-beta2.tsv",
        "queue-metadata.json",
    ]
    upstream_inputs = [
        hashed_file(upstream_directory / name) for name in upstream_names
    ]
    source_names = [
        "aggregate_rational_beta2.py",
        "build_rational_betti_queue.py",
        "export_exact_koszul_multiplier.py",
        "koszul_rank_q.cpp",
        "program3_rational_betti.slurm",
        "run_rational_betti_block.sh",
    ]
    source_inputs = [hashed_file(source_directory / name) for name in source_names]
    source_inputs.append(hashed_file(script))

    replay_command = [
        "uv",
        "run",
        "python",
        str(script),
        str(queue),
        str(task_run_directory),
        str(output_directory),
    ]
    receipt = {
        "schema_version": 1,
        "run_id": output_directory.name,
        "recorded_utc": datetime.now(timezone.utc).isoformat(),
        "claim": {
            "coefficient_domain": "QQ",
            "certified_betti_index": 2,
            "beta2": EXPECTED_BETA2,
            "task_count": EXPECTED_TASKS,
        },
        "commands": {
            "replay": replay_command,
            "aggregate": aggregate_command,
            "aggregate_stdout": completed.stdout.strip(),
            "aggregate_stderr": completed.stderr.strip(),
            "working_directory": str(repository),
        },
        "versions": {
            "python": sys.version,
            "python_implementation": platform.python_implementation(),
            "platform": platform.platform(),
            "uv": command_output(["uv", "--version"], repository),
            "git_head": command_output(["git", "rev-parse", "HEAD"], repository),
        },
        "inputs": {
            "queue": hashed_file(queue),
            "task_run_directory": str(task_run_directory),
            "rank_outputs": [hashed_file(path) for path in rank_paths],
            "upstream_exact_inputs": upstream_inputs,
        },
        "sources": source_inputs,
        "outputs": {"aggregate": hashed_file(aggregate_output)},
        "scope": {
            "establishes": [
                "The 49 stored exact-rational degree-2 and degree-3 "
                "Koszul ranks give beta_2=354 over QQ.",
                "Every exact rank equals the queue's corresponding stored "
                "good-prime rank.",
            ],
            "does_not_establish": [
                "This replay does not rerun the 49 exact row reductions.",
                "No exact-QQ value of beta_3 through beta_9 is certified.",
                "Finite-field agreement alone is not used as a "
                "characteristic-zero conclusion.",
            ],
            "remaining_open_betti_indices": list(range(3, 10)),
        },
    }
    receipt_path = output_directory / "audit-receipt.json"
    receipt_path.write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    sums_path = output_directory / "SHA256SUMS"
    sums_path.write_text(
        "".join(
            f"{sha256(path)}  {path.name}\n"
            for path in (receipt_path, aggregate_output)
        ),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "beta2": EXPECTED_BETA2,
                "output_directory": str(output_directory),
                "tasks": EXPECTED_TASKS,
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
