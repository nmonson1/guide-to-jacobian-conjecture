# Exact rational beta2 audit replay

This packet turns the existing 49 exact-rational Koszul block results into a
new, write-once audit receipt. It does not rerun the expensive block row
reductions. It independently replays the maintained aggregate over every
stored `rank.json`, records the command and tool versions, and pins the queue,
all 49 task outputs, the upstream exact multiplier and executable, the
aggregation sources, and the new aggregate output by SHA-256.

Run from the repository root:

```text
uv run python \
  research-notes/program3-rational-beta2-audit-20260803-v1/replay_beta2_audit.py \
  /path/to/versioned-artifact \
  /path/to/versioned-artifact \
  /path/to/versioned-artifact
```

The replay refuses an existing output path. Verify a completed receipt with
`verify_beta2_audit.py RECEIPT_DIRECTORY`.

## Scope

The receipt proves only that the 49 stored exact-QQ ranks of the degree-two
and degree-three Koszul differentials give `beta_2 = 354` over `QQ`. It does
not certify `beta_3` through `beta_9`, rerun any block computation, or promote
the three finite-field Betti tables to characteristic zero in the remaining
degrees.
