#!/usr/bin/env python3
"""Verify a versioned exact-rational beta2 audit receipt."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("receipt_directory", type=Path)
    args = parser.parse_args()
    directory = args.receipt_directory.resolve()

    sums = {}
    for line in (directory / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        sums[name] = digest
    for name, digest in sums.items():
        if sha256(directory / name) != digest:
            raise AssertionError(f"receipt checksum mismatch: {name}")

    aggregate_path = directory / "beta2.json"
    receipt_path = directory / "audit-receipt.json"
    aggregate = json.loads(aggregate_path.read_text(encoding="utf-8"))
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    if aggregate["beta2"] != 354 or aggregate["task_count"] != 49:
        raise AssertionError("unexpected aggregate claim")
    if receipt["claim"] != {
        "beta2": 354,
        "certified_betti_index": 2,
        "coefficient_domain": "QQ",
        "task_count": 49,
    }:
        raise AssertionError("unexpected receipt claim")
    if receipt["scope"]["remaining_open_betti_indices"] != list(range(3, 10)):
        raise AssertionError("incorrect open-degree boundary")
    if receipt["outputs"]["aggregate"]["sha256"] != sha256(aggregate_path):
        raise AssertionError("aggregate output hash mismatch")
    if receipt["inputs"]["queue"]["sha256"] != aggregate["queue_sha256"]:
        raise AssertionError("queue hash mismatch")

    rank_inputs = receipt["inputs"]["rank_outputs"]
    expected_task_hashes = {
        int(item["task_id"]): item["rank_json_sha256"]
        for item in aggregate["task_hashes"]
    }
    if len(rank_inputs) != 49 or set(expected_task_hashes) != set(range(49)):
        raise AssertionError("task coverage mismatch")
    for item in rank_inputs:
        path = Path(item["path"])
        task_id = int(path.parent.name.removeprefix("task-"))
        digest = sha256(path)
        if digest != item["sha256"] or digest != expected_task_hashes[task_id]:
            raise AssertionError(f"rank hash mismatch for task {task_id}")

    for item in receipt["inputs"]["upstream_exact_inputs"]:
        if sha256(Path(item["path"])) != item["sha256"]:
            raise AssertionError(f"input hash mismatch: {item['path']}")
    for item in receipt["sources"]:
        if sha256(Path(item["path"])) != item["sha256"]:
            raise AssertionError(f"source hash mismatch: {item['path']}")

    print(
        json.dumps(
            {"beta2": 354, "status": "verified", "tasks": 49},
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
