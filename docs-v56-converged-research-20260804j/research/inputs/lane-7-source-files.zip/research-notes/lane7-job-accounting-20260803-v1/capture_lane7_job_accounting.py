#!/usr/bin/env python3
"""Capture a bounded Slurm/log snapshot for the existing Lane 7 jobs."""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import re
import subprocess


RUNS = Path("/path/to/versioned-artifact")
CAMPAIGNS = {
    "v1": "lane7-projective-kernel-five-chart-20260803-v1",
    "v2": "lane7-projective-kernel-five-chart-20260803-v2",
    "v3": "lane7-projective-kernel-five-chart-20260803-v3",
    "v4": "lane7-projective-kernel-five-chart-20260803-v4",
}
JOBS = [
    *(("v1", "QQ", chart, 89854 + chart) for chart in range(5)),
    *(("v1", "F_1009", chart, 89859 + chart) for chart in range(5)),
    *(("v2", "QQ", chart, 89864 + chart) for chart in range(5)),
    ("v3", "F_1009", 0, 89871),
    ("v3", "F_1009", 1, 89872),
    ("v3", "QQ", 0, 89873),
    ("v3", "F_1009", 3, 89874),
    ("v3", "QQ", 2, 89875),
    ("v3", "QQ", 3, 89876),
    ("v3", "QQ", 1, 89877),
    ("v3", "F_1009", 2, 89878),
    ("v3", "QQ", 4, 89879),
    ("v3", "F_1009", 4, 89880),
    ("v4", "QQ", 1, 89883),
    ("v4", "QQ", 0, 89884),
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def file_snapshot(path: Path, mutable: bool) -> dict[str, object]:
    if not path.is_file():
        return {"path": str(path), "exists": False, "mutable": mutable}
    return {
        "path": str(path),
        "exists": True,
        "mutable": mutable,
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def command_output(argv: list[str], cwd: Path) -> str:
    return subprocess.run(
        argv,
        cwd=cwd,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError(f"refusing to overwrite {output}")

    script = Path(__file__).resolve()
    repository = script.parents[2]
    job_ids = [str(job_id) for _, _, _, job_id in JOBS]
    fields = [
        "JobIDRaw",
        "JobName",
        "State",
        "ExitCode",
        "Elapsed",
        "Timelimit",
        "Start",
        "End",
    ]
    sacct_command = [
        "sacct",
        "-P",
        "-X",
        "-j",
        ",".join(job_ids),
        "--format=" + ",".join(fields),
    ]
    raw_accounting = command_output(sacct_command, repository)
    lines = raw_accounting.splitlines()
    rows = {}
    for line in lines[1:]:
        values = line.split("|")
        if values and values[0] in job_ids:
            rows[int(values[0])] = dict(zip(fields, values, strict=True))

    records = []
    for version, field, chart, job_id in JOBS:
        row = rows.get(job_id)
        state = row["State"] if row else "UNKNOWN"
        exit_code = row["ExitCode"] if row else "UNKNOWN"
        campaign = RUNS / CAMPAIGNS[version]
        field_directory = "exact-q" if field == "QQ" else "prime-1009"
        chart_directory = campaign / field_directory / f"chart-{chart}"
        stdout = chart_directory / f"slurm-{job_id}.stdout.txt"
        stderr = chart_directory / f"slurm-{job_id}.stderr.txt"
        stdout_text = (
            stdout.read_text(encoding="utf-8", errors="replace")
            if stdout.is_file()
            else ""
        )
        stderr_text = (
            stderr.read_text(encoding="utf-8", errors="replace")
            if stderr.is_file()
            else ""
        )
        field_token = "QQ" if field == "QQ" else "CHAR_1009"
        pattern = re.compile(
            rf"KERNEL_CHART_{chart}_{field_token}_MACAULAY2_CODIM="
            rf"(?:EMPTY|[0-9]+)"
        )
        markers = pattern.findall(stdout_text)
        accepted = state == "COMPLETED" and exit_code == "0:0" and len(markers) == 1
        mutable = state in {"PENDING", "RUNNING", "REQUEUED"}
        diagnostics = []
        if "Too many heap sections" in stderr_text:
            diagnostics.append("boehm_gc_heap_sections")
        if state == "TIMEOUT":
            diagnostics.append("slurm_timeout")
        if mutable:
            diagnostics.append("nonterminal_at_snapshot")
        records.append(
            {
                "campaign": CAMPAIGNS[version],
                "field": field,
                "chart": chart,
                "job_id": job_id,
                "accounting": row,
                "result_markers": markers,
                "accepted_result": accepted,
                "interpretation": (
                    "exact_Q_chart_result"
                    if accepted and field == "QQ"
                    else "finite_field_cross_check"
                    if accepted
                    else "no_mathematical_result"
                ),
                "diagnostics": diagnostics,
                "evidence": {
                    "input": file_snapshot(chart_directory / "input.m2", False),
                    "stdout": file_snapshot(stdout, mutable),
                    "stderr": file_snapshot(stderr, mutable),
                    "resource_usage": file_snapshot(
                        chart_directory / "resource-usage.txt", mutable
                    ),
                },
            }
        )

    state_counts = Counter(
        record["accounting"]["State"] if record["accounting"] else "UNKNOWN"
        for record in records
    )
    report = {
        "schema_version": 1,
        "snapshot_id": "lane7-job-accounting-20260803-v1",
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "commands": {
            "accounting": sacct_command,
            "working_directory": str(repository),
        },
        "versions": {
            "python": platform.python_version(),
            "sacct": command_output(["sacct", "--version"], repository),
            "git_head": command_output(["git", "rev-parse", "HEAD"], repository),
        },
        "sources": [
            {"path": str(script), "sha256": sha256(script)},
            {
                "path": str(script.with_name("verify_lane7_job_accounting.py")),
                "sha256": sha256(script.with_name("verify_lane7_job_accounting.py")),
            },
        ],
        "summary": {
            "job_count": len(records),
            "states": dict(sorted(state_counts.items())),
            "exact_Q_accepted_results": sum(
                item["accepted_result"] and item["field"] == "QQ" for item in records
            ),
            "finite_field_accepted_cross_checks": sum(
                item["accepted_result"] and item["field"] == "F_1009"
                for item in records
            ),
            "no_mathematical_result": sum(
                not item["accepted_result"] for item in records
            ),
        },
        "jobs": records,
        "scope": {
            "accepted_exact_Q_rule": (
                "State COMPLETED, exit 0:0, and exactly one matching "
                "KERNEL_CHART_*_QQ_MACAULAY2_CODIM marker."
            ),
            "finite_field_rule": (
                "The same success gate is used, but characteristic 1009 "
                "is a cross-check only."
            ),
            "does_not_establish": [
                "Failed, timed-out, and nonterminal jobs supply no "
                "mathematical conclusion.",
                "A chart marker alone does not establish global grade, "
                "purity, component decomposition, Pluecker openness, or "
                "a first-normal obstruction.",
            ],
        },
    }
    output.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report["summary"], sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
