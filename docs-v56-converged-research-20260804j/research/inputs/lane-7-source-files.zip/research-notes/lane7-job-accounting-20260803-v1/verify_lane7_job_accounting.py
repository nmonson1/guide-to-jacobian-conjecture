#!/usr/bin/env python3
"""Verify Lane 7 accounting claim gates and optional evidence hashes."""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("report", type=Path)
    parser.add_argument("--check-files", action="store_true")
    parser.add_argument("--check-mutable-snapshots", action="store_true")
    args = parser.parse_args()
    report = json.loads(args.report.read_text(encoding="utf-8"))
    jobs = report["jobs"]
    if len(jobs) != 27 or len({item["job_id"] for item in jobs}) != 27:
        raise AssertionError("expected 27 unique Lane 7 jobs")

    for item in jobs:
        row = item["accounting"]
        state = row["State"] if row else "UNKNOWN"
        exit_code = row["ExitCode"] if row else "UNKNOWN"
        token = "QQ" if item["field"] == "QQ" else "CHAR_1009"
        pattern = re.compile(
            rf"^KERNEL_CHART_{item['chart']}_{token}_MACAULAY2_CODIM="
            rf"(?:EMPTY|[0-9]+)$"
        )
        if any(not pattern.fullmatch(marker) for marker in item["result_markers"]):
            raise AssertionError(f"marker mismatch for job {item['job_id']}")
        expected_acceptance = (
            state == "COMPLETED"
            and exit_code == "0:0"
            and len(item["result_markers"]) == 1
        )
        if item["accepted_result"] != expected_acceptance:
            raise AssertionError(f"claim-gate mismatch for job {item['job_id']}")
        expected_interpretation = (
            "exact_Q_chart_result"
            if expected_acceptance and item["field"] == "QQ"
            else "finite_field_cross_check"
            if expected_acceptance
            else "no_mathematical_result"
        )
        if item["interpretation"] != expected_interpretation:
            raise AssertionError(f"interpretation mismatch for job {item['job_id']}")
        if args.check_files:
            for evidence in item["evidence"].values():
                if not evidence["exists"]:
                    continue
                if evidence["mutable"] and not args.check_mutable_snapshots:
                    continue
                path = Path(evidence["path"])
                if sha256(path) != evidence["sha256"]:
                    raise AssertionError(f"evidence hash mismatch: {path}")

    states = Counter(
        item["accounting"]["State"] if item["accounting"] else "UNKNOWN"
        for item in jobs
    )
    expected_summary = {
        "job_count": 27,
        "states": dict(sorted(states.items())),
        "exact_Q_accepted_results": sum(
            item["accepted_result"] and item["field"] == "QQ" for item in jobs
        ),
        "finite_field_accepted_cross_checks": sum(
            item["accepted_result"] and item["field"] == "F_1009" for item in jobs
        ),
        "no_mathematical_result": sum(not item["accepted_result"] for item in jobs),
    }
    if report["summary"] != expected_summary:
        raise AssertionError("summary mismatch")
    print(json.dumps({"status": "verified", **expected_summary}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
