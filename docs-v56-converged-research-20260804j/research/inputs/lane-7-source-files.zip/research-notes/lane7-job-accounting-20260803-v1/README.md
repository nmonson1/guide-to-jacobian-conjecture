# Lane 7 job-accounting snapshot

This packet preserves one bounded accounting and log-marker snapshot for all
27 available jobs in the four Lane 7 five-chart campaigns. It submits and
retries nothing.

`capture_lane7_job_accounting.py` queries only the listed Slurm job IDs and
scans their existing stdout/stderr files for the exact Macaulay2 result
marker declared by each input. A characteristic-zero result is accepted only
when the top-level job is `COMPLETED` with exit code `0:0` and stdout contains
exactly one matching `KERNEL_CHART_*_QQ_MACAULAY2_CODIM` marker. The same gate
is applied to characteristic 1009, whose accepted values remain cross-checks
only.

The checked-in `report.json` is a historical snapshot. Logs belonging to a
job that was running at capture time are explicitly marked mutable. The
verifier checks all logical claim gates and can re-hash terminal evidence;
`--check-mutable-snapshots` additionally checks the running-log bytes against
the capture-time snapshot and is expected to fail after those logs grow.

## Scope

The report accounts for job state and available result markers. A failed,
timed-out, or still-running job supplies no mathematical conclusion. Even a
successful affine-chart codimension marker would not alone prove global
grade, purity, component decomposition, Pluecker openness, or a first-normal
obstruction.
