#!/usr/bin/env python3
"""Generate one exact or prime-field Lane 7 kernel chart for Macaulay2.

The retained packet already has an exact-Q Singular generator, but the pinned
project toolchain contains Macaulay2 rather than the Singular command-line
driver.  This independent renderer uses the same hash-pinned matrix and row
units while emitting a self-contained Macaulay2 dimension calculation.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import sympy as sp

from generate_kernel_chart_input import parse_integral_polynomial, render_polynomial
from generate_kernel_chart_singular import render_integer_polynomial
from generate_macaulay2_input import ROW_DENOMINATOR_LCMS


def render_chart(
    entries: list[list[str]],
    determinant: str,
    chart: int,
    characteristic: int,
) -> str:
    """Return a complete Macaulay2 program for one affine kernel chart."""
    if chart not in range(5):
        raise ValueError("chart must be between zero and four")
    if characteristic < 0 or (
        characteristic != 0 and not sp.isprime(characteristic)
    ):
        raise ValueError("characteristic must be zero or prime")
    if characteristic and any(
        scale % characteristic == 0 for scale in ROW_DENOMINATOR_LCMS
    ):
        raise ValueError("chosen characteristic kills a denominator-clearing row unit")
    if len(entries) != 10 or any(len(row) != 5 for row in entries):
        raise ValueError("expected a 10 by 5 residual matrix")

    parameters = sp.symbols("a0:7")
    kernel_variables = sp.symbols("x0:4")
    z = sp.Symbol("z")
    local_symbols = {str(variable): variable for variable in parameters}
    free_coordinates = iter(kernel_variables)
    kernel_coordinates: list[sp.Expr] = [
        sp.Integer(1) if index == chart else next(free_coordinates)
        for index in range(5)
    ]
    all_chart_variables = (*parameters, *kernel_variables)

    equations: list[str] = []
    for scale, row in zip(ROW_DENOMINATOR_LCMS, entries):
        parsed = [
            parse_integral_polynomial(entry, scale, parameters, local_symbols)
            for entry in row
        ]
        expression = sum(
            polynomial.as_expr() * coordinate
            for polynomial, coordinate in zip(parsed, kernel_coordinates)
        )
        if characteristic:
            polynomial = sp.Poly(
                expression, *all_chart_variables, modulus=characteristic
            )
            equations.append(render_polynomial(polynomial, characteristic))
        else:
            polynomial = sp.Poly(expression, *all_chart_variables, domain=sp.ZZ)
            equations.append(render_integer_polynomial(polynomial))

    determinant_expression = sp.sympify(determinant, locals=local_symbols)
    if characteristic:
        determinant_poly = sp.Poly(
            determinant_expression, *parameters, modulus=characteristic
        )
        determinant_text = render_polynomial(determinant_poly, characteristic)
        coefficient_ring = f"ZZ/{characteristic}"
        field_tag = f"CHAR_{characteristic}"
    else:
        determinant_poly = sp.Poly(
            determinant_expression, *parameters, domain=sp.QQ
        )
        if any(coefficient.q != 1 for coefficient in determinant_poly.coeffs()):
            raise ValueError("determinant has an uncleared rational coefficient")
        determinant_text = render_integer_polynomial(
            sp.Poly(determinant_poly.as_expr(), *parameters, domain=sp.ZZ)
        )
        coefficient_ring = "QQ"
        field_tag = "QQ"

    variables = [str(variable) for variable in (*all_chart_variables, z)]
    tag = f"KERNEL_CHART_{chart}_{field_tag}_MACAULAY2"
    equation_block = ",\n  ".join([*equations, "z*d-1"])
    lines = [
        "-- Generated from the hash-pinned Lane 7 source packet.",
        "-- The ten matrix rows were multiplied by nonzero integer row units.",
        f"R = {coefficient_ring}[{','.join(variables)}, MonomialOrder => GRevLex];",
        f"d = {determinant_text};",
        "I = ideal(\n  " + equation_block + "\n);",
        "assert(numgens I == 11);",
        f'print "{tag}_BEGIN";',
        "G = gb I;",
        "unitI = (I == 1);",
        f'print("{tag}_UNIT=" | toString unitI);',
        "if unitI then (",
        f'  print "{tag}_DIM=EMPTY";',
        f'  print "{tag}_CODIM=EMPTY";',
        ") else (",
        "  dimI = dim I;",
        "  codimI = codim I;",
        f'  print("{tag}_DIM=" | toString dimI);',
        f'  print("{tag}_CODIM=" | toString codimI);',
        ");",
        "GB = gens G;",
        "gbSize = numgens source GB;",
        f'print("{tag}_GB_SIZE=" | toString gbSize);',
        f'print "{tag}_END";',
    ]
    return "\n\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_directory", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--chart", type=int, required=True, choices=range(5))
    parser.add_argument(
        "--characteristic",
        type=int,
        required=True,
        help="0 for QQ; otherwise a good prime",
    )
    args = parser.parse_args()

    residual = json.loads(
        (args.source_directory / "collision_residual_matrix_M.json").read_text(
            encoding="utf-8"
        )
    )
    factorization = json.loads(
        (args.source_directory / "Hv10_split_matrix_factorization.json").read_text(
            encoding="utf-8"
        )
    )
    entries = residual.get("entries")
    determinant = factorization.get("d")
    if not isinstance(entries, list):
        raise ValueError("residual artifact has no entries array")
    if not isinstance(determinant, str):
        raise ValueError("factorization artifact does not contain determinant d")

    program = render_chart(entries, determinant, args.chart, args.characteristic)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(program, encoding="utf-8")
    field_name = "QQ" if args.characteristic == 0 else f"F_{args.characteristic}"
    print(f"wrote Macaulay2 chart {args.chart} over {field_name} to {args.output}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, json.JSONDecodeError, sp.SympifyError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(2)
