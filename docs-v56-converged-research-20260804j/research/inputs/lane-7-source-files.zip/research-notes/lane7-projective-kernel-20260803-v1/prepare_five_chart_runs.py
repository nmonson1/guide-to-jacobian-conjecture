#!/usr/bin/env python3
"""Prepare immutable exact-Q and good-prime Lane 7 Slurm run directories."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import stat

from generate_kernel_chart_macaulay2 import render_chart


ROOT = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_new(path: Path, content: str, executable: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        handle.write(content)
    if executable:
        path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP)


def slurm_program(
    *,
    chart: int,
    field_name: str,
    chart_directory: Path,
    toolchain_launcher: Path,
    cpus: int,
    memory: str,
    walltime: str,
) -> str:
    input_path = chart_directory / "input.m2"
    return f"""#!/usr/bin/env bash
#SBATCH --job-name=l7-{field_name}-c{chart}
#SBATCH --partition=research
#SBATCH --cpus-per-task={cpus}
#SBATCH --mem={memory}
#SBATCH --time={walltime}
#SBATCH --chdir={chart_directory}
#SBATCH --output={chart_directory}/slurm-%j.stdout.txt
#SBATCH --error={chart_directory}/slurm-%j.stderr.txt

set -euo pipefail
cd {chart_directory}
date --utc --iso-8601=seconds
sha256sum {input_path}
{toolchain_launcher} --version
/usr/bin/time -v -o resource-usage.txt {toolchain_launcher} --script {input_path}
date --utc --iso-8601=seconds
"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_directory", type=Path)
    parser.add_argument("run_root", type=Path)
    parser.add_argument("toolchain_launcher", type=Path)
    parser.add_argument("toolchain_image", type=Path)
    parser.add_argument("--prime", type=int, default=1009)
    parser.add_argument("--repository-commit", required=True)
    args = parser.parse_args()

    if args.run_root.exists():
        raise FileExistsError(f"refusing to overwrite existing run root: {args.run_root}")
    for path in (
        args.source_directory,
        args.toolchain_launcher,
        args.toolchain_image,
    ):
        if not path.exists():
            raise FileNotFoundError(path)
    if len(args.repository_commit) != 40:
        raise ValueError("repository commit must be a full 40-hex identifier")

    residual_path = args.source_directory / "collision_residual_matrix_M.json"
    factorization_path = (
        args.source_directory / "Hv10_split_matrix_factorization.json"
    )
    toolchain_root = args.toolchain_launcher.parent.parent
    dependency_paths = [
        toolchain_root / name
        for name in (
            "PACKAGE_SHA256SUMS",
            "PACKAGE_VERSIONS.tsv",
            "TOOLCHAIN_SHA256SUMS",
        )
    ]
    for path in dependency_paths:
        if not path.is_file():
            raise FileNotFoundError(path)
    residual = json.loads(residual_path.read_text(encoding="utf-8"))
    factorization = json.loads(factorization_path.read_text(encoding="utf-8"))
    entries = residual["entries"]
    determinant = factorization["d"]

    args.run_root.mkdir(parents=True, exist_ok=False)
    jobs: list[dict[str, object]] = []
    profiles = (
        ("exact-q", 0, 4, "48G", "12:00:00"),
        (f"prime-{args.prime}", args.prime, 1, "12G", "02:00:00"),
    )
    for field_name, characteristic, cpus, memory, walltime in profiles:
        for chart in range(5):
            chart_directory = args.run_root / field_name / f"chart-{chart}"
            chart_directory.mkdir(parents=True, exist_ok=False)
            input_path = chart_directory / "input.m2"
            sbatch_path = chart_directory / "run.sbatch"
            write_new(
                input_path,
                render_chart(entries, determinant, chart, characteristic),
            )
            write_new(
                sbatch_path,
                slurm_program(
                    chart=chart,
                    field_name=field_name,
                    chart_directory=chart_directory,
                    toolchain_launcher=args.toolchain_launcher,
                    cpus=cpus,
                    memory=memory,
                    walltime=walltime,
                ),
                executable=True,
            )
            jobs.append(
                {
                    "field": "Q" if characteristic == 0 else f"F_{characteristic}",
                    "chart": chart,
                    "characteristic": characteristic,
                    "resources": {
                        "partition": "research",
                        "cpus": cpus,
                        "memory": memory,
                        "walltime": walltime,
                    },
                    "input": str(input_path),
                    "input_sha256": sha256(input_path),
                    "sbatch": str(sbatch_path),
                    "sbatch_sha256": sha256(sbatch_path),
                    "submit_command": f"sbatch {sbatch_path}",
                    "does_not_establish": (
                        "A finite-field result is a discovery cross-check only."
                        if characteristic
                        else "A chart dimension does not prove global component purity, "
                        "the Pluecker-open condition, or a first-normal obstruction."
                    ),
                }
            )

    manifest = {
        "schema_version": 1,
        "repository_commit": args.repository_commit,
        "generator": str(ROOT / "generate_kernel_chart_macaulay2.py"),
        "generator_sha256": sha256(ROOT / "generate_kernel_chart_macaulay2.py"),
        "source_files": [
            {"path": str(residual_path), "sha256": sha256(residual_path)},
            {"path": str(factorization_path), "sha256": sha256(factorization_path)},
        ],
        "toolchain": {
            "launcher": str(args.toolchain_launcher),
            "launcher_sha256": sha256(args.toolchain_launcher),
            "image": str(args.toolchain_image),
            "image_sha256": sha256(args.toolchain_image),
            "dependency_manifests": [
                {"path": str(path), "sha256": sha256(path)}
                for path in dependency_paths
            ],
        },
        "prime": args.prime,
        "jobs": jobs,
        "global_does_not_establish": [
            "I_4(M):d^infinity=(1)",
            "grade or purity of I_5(M):d^infinity",
            "characteristic-zero component decomposition",
            "generic nonvanishing of a Pluecker coordinate on each component",
            "componentwise first-normal obstruction",
        ],
    }
    manifest_path = args.run_root / "manifest.json"
    write_new(manifest_path, json.dumps(manifest, indent=2) + "\n")
    write_new(
        args.run_root / "SUBMIT_COMMANDS.txt",
        "\n".join(str(job["submit_command"]) for job in jobs) + "\n",
    )
    print(f"prepared {len(jobs)} immutable job directories at {args.run_root}")
    print(f"manifest_sha256={sha256(manifest_path)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
