# Lane 7 exact projective-kernel chart packet

This packet preserves the useful new machinery from public site PR 7 at
exact head 4c488f26a510271aa73cf1cd8a5fc2cf3446ad69. It is an extension of the
canonical split-incidence packet in
../lane7-split-incidence-20260802-v1/, not a replacement for it.

## Mathematical interface

Let M(a) be the stored 10 by 5 residual matrix, let d(a) be the determinant
used to define the accepted open set D(d), and let [u] lie in P^4. The
projective kernel incidence is

    I = {(a,[u]) : M(a)u=0 and d(a) is nonzero}.

The five affine charts u_i=1 cover P^4. On each chart the packet writes the
ten exact equations M(a)u=0 together with z*d(a)-1. Therefore exact
dimensions of all five localized chart ideals determine the dimension of I.
The generators do not themselves compute those dimensions.

The already-retained Pluecker transport theorem explains how the marked
two-plane data are reconstructed from this kernel incidence. Its proof and
source matrices remain in ../lane7-split-incidence-20260802-v1/.

## Harvested programs

- generate_macaulay2_input.py reconstructs the pinned residual matrix and
  optional localization over Q or a prime field.
- generate_kernel_chart_input.py emits any affine chart for Macaulay2 over a
  prime field.
- generate_kernel_chart_singular.py independently emits the same charts for
  Singular, over a prime field or exactly over Q by modular reconstruction.
- generate_kernel_chart_macaulay2.py emits the same five charts over either
  Q or a good prime.  It is the exact-Q route for the pinned project
  Macaulay2 1.26.06 Apptainer toolchain when no Singular executable is
  available.
- test_plucker_transport.py checks the five Pluecker relations, all ten
  normalized two-plane charts, and the transport identity.
- test_kernel_chart_macaulay2.py checks all ten Q/F_1009 renderings and rejects
  characteristics that kill a denominator-clearing row unit.
- prepare_five_chart_runs.py creates a new run root with ten immutable chart
  directories, the requested separate exact-Q/good-prime Slurm profiles,
  hash-pinned inputs and scripts, a source/toolchain manifest, and explicit
  does-not-establish boundaries.  It refuses an existing run root and does
  not submit jobs.  Each script sets its persistent chart directory as the
  Slurm working directory, so execution does not depend on a submit-side
  worktree being mounted on the compute node.  The manifest pins the package
  versions, package hashes, and complete toolchain hash manifest in addition
  to the launcher and SIF.

The four copied source files have SHA-256 digests:

    5e417707876d39efc5f780ba95cff9f33c9f209b8b14b76a9484e70c12eaef01  generate_macaulay2_input.py
    3a5c8dd3c3aa5d57f2cbb139dad970f96c7c0eaf247b7978fef4d6c3db28dc87  generate_kernel_chart_input.py
    290697bd851eecc2509b09cf440966874cf51fc9c011dc1bd9fcc7fa69af5de7  generate_kernel_chart_singular.py
    22ca784d94dee019eee780909e1e615b6311b4e668e140847a2f8d37f6d39e30  test_plucker_transport.py

## Honest result boundary

At harvest time the PR 7 packet/interface job, finite-field chart job, exact
Q chart job, and disposable Singular-rootfs job were still pending in GitHub
Actions. No chart dimension, codimension, carrier grade, or corank conclusion
is promoted here.

An earlier fixed-row corank assertion in PR 7 was false. A shell pipeline had
also allowed the failed CAS assertion to be masked by tee. Later commits made
pipeline failures propagate and removed the false test. Neither the
withdrawn assertion nor output from that workflow is evidence.

## Local replay

The generators can be replayed against the canonical source packet:

    uv run --with sympy==1.14.0 python \
      research-notes/lane7-projective-kernel-20260803-v1/test_plucker_transport.py

    uv run --with sympy==1.14.0 python \
      research-notes/lane7-projective-kernel-20260803-v1/generate_kernel_chart_singular.py \
      research-notes/lane7-split-incidence-20260802-v1 \
      /tmp/lane7-kernel-chart-0.sing --chart 0 --characteristic 0

Neither Singular nor Macaulay2 is installed on the current host, so local
validation stops after exact source reconstruction and generated-input
inspection. CAS output becomes reusable mathematics only when its logs and
artifacts are preserved and independently checked.

The project also has a hash-pinned rootless Macaulay2 toolchain outside this
repository.  A run using it must record the launcher, SIF and package-manifest
hashes, generated input hash, exact command, scheduler resources, and complete
log.  The exact-Q and good-prime results remain separate evidence: a prime
result is a discovery cross-check, not a characteristic-zero certificate.
