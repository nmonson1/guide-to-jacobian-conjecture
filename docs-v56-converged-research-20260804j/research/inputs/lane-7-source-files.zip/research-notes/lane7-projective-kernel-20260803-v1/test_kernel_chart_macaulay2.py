#!/usr/bin/env python3
"""Regression tests for the exact/prime Macaulay2 chart renderer."""

from __future__ import annotations

import json
from pathlib import Path

import sympy as sp

from generate_kernel_chart_macaulay2 import render_chart
from generate_macaulay2_input import ROW_DENOMINATOR_LCMS


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "lane7-split-incidence-20260802-v1"


def main() -> int:
    residual = json.loads(
        (SOURCE / "collision_residual_matrix_M.json").read_text(encoding="utf-8")
    )
    factorization = json.loads(
        (SOURCE / "Hv10_split_matrix_factorization.json").read_text(encoding="utf-8")
    )
    entries = residual["entries"]
    determinant = factorization["d"]

    assert sp.isprime(1009)
    assert all(scale % 1009 for scale in ROW_DENOMINATOR_LCMS)
    for chart in range(5):
        exact = render_chart(entries, determinant, chart, 0)
        prime = render_chart(entries, determinant, chart, 1009)
        assert f"KERNEL_CHART_{chart}_QQ_MACAULAY2_BEGIN" in exact
        assert f"KERNEL_CHART_{chart}_CHAR_1009_MACAULAY2_BEGIN" in prime
        assert "R = QQ[" in exact
        assert "R = ZZ/1009[" in prime
        assert exact.count("z*d-1") == 1
        assert prime.count("z*d-1") == 1
        assert "assert(numgens I == 11);" in exact
        assert "assert(numgens I == 11);" in prime
        assert "_GB_SIZE=" in exact
        assert "_GB_SIZE=" in prime

    for bad_characteristic in (2, 3, 6):
        try:
            render_chart(entries, determinant, 0, bad_characteristic)
        except ValueError:
            pass
        else:
            raise AssertionError(f"accepted bad characteristic {bad_characteristic}")

    print("verified five exact-Q and five F_1009 Macaulay2 chart renderings")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
