#!/usr/bin/env python3
"""Build the self-contained exact input bundle for Lane 7 component work."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import sympy as sp


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "lane7-split-incidence-20260802-v1"
sys.path.insert(0, str(SOURCE))

from reconstruct_matrices import a, decode_coeff_matrix, transformed  # noqa: E402


def parse_entries(path: Path) -> sp.Matrix:
    data = json.loads(path.read_text(encoding="utf-8"))
    local_symbols = {str(variable): variable for variable in a}
    return sp.Matrix(
        [
            [sp.sympify(entry, locals=local_symbols) for entry in row]
            for row in data["entries"]
        ]
    )


def matrix_strings(matrix: sp.Matrix) -> list[list[str]]:
    return [[str(sp.expand(entry)) for entry in row] for row in matrix.tolist()]


def theorem_matrices() -> tuple[
    sp.Expr, sp.Matrix, sp.Matrix, sp.Matrix, sp.Matrix, sp.Matrix
]:
    _, _, determinant, _, matrix_u, _, matrix_v = transformed()
    matrix_a = matrix_u[:10, :]
    matrix_h = matrix_v[:10, :]

    left_inverse_v = decode_coeff_matrix(SOURCE / "Hv_left_inverse.json")
    extension = sp.zeros(15, 10)
    for index in range(10):
        extension[index, index] = 1
    for index, sign in enumerate((1, 1, -1, 1, 1)):
        extension[10 + index, index] = sp.Rational(3, 2) * sign
    matrix_c = (left_inverse_v * extension).applyfunc(sp.expand)

    matrix_q = parse_entries(SOURCE / "Hv10_syzygies_exact.json")
    matrix_r = parse_entries(SOURCE / "Hv10_right_inverse_exact.json")
    return determinant, matrix_a, matrix_h, matrix_c, matrix_q, matrix_r


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite existing output: {args.output}")

    determinant, matrix_a, matrix_h, matrix_c, matrix_q, matrix_r = theorem_matrices()
    matrix_ca = (matrix_c * matrix_a).applyfunc(sp.expand)
    stored_residual = parse_entries(SOURCE / "collision_residual_matrix_M.json")
    stored_factorization = json.loads(
        (SOURCE / "Hv10_split_matrix_factorization.json").read_text(encoding="utf-8")
    )
    local_symbols = {str(variable): variable for variable in a}
    stored_determinant = sp.sympify(stored_factorization["d"], locals=local_symbols)
    stored_h = sp.Matrix(
        [
            [sp.sympify(entry, locals=local_symbols) for entry in row]
            for row in stored_factorization["H"]
        ]
    )
    stored_c = sp.Matrix(
        [
            [sp.sympify(entry, locals=local_symbols) for entry in row]
            for row in stored_factorization["C"]
        ]
    )
    assert sp.expand(determinant - stored_determinant) == 0
    assert matrix_h == stored_h
    assert matrix_c == stored_c

    bundle = {
        "schema_version": 1,
        "ring": "Q[a0,...,a6]",
        "parameters": [str(variable) for variable in a],
        "kernel_coordinates": [f"u{index}" for index in range(5)],
        "definitions": {
            "carrier": "V(I_5(M)) intersect D(d)",
            "second_marking": "v = -d^(-1) * CA * u",
            "plucker_numerator": "eta_ij = u_i*(CA*u)_j - u_j*(CA*u)_i",
            "independent_marking_open": "some eta_ij != 0",
            "corank_two_locus": "V(I_4(M)) intersect D(d)",
        },
        "d": str(sp.expand(determinant)),
        "matrices": {
            "M": {"shape": [10, 5], "entries": matrix_strings(stored_residual)},
            "A": {"shape": [10, 5], "entries": matrix_strings(matrix_a)},
            "CA": {"shape": [5, 5], "entries": matrix_strings(matrix_ca)},
            "H": {"shape": [10, 5], "entries": matrix_strings(matrix_h)},
            "C": {"shape": [5, 10], "entries": matrix_strings(matrix_c)},
            "Q": {"shape": [5, 10], "entries": matrix_strings(matrix_q)},
            "R": {"shape": [10, 5], "entries": matrix_strings(matrix_r)},
        },
        "factorization_identities": [
            "C*H = d*I_5",
            "Q*H = 0",
            "C*R = 0",
            "Q*R = d*I_5",
            "H*C + R*Q = d*I_10",
        ],
        "does_not_establish": [
            "grade six or Cohen--Macaulayness of I_5(M) on D(d)",
            "I_4(M):d^infinity = (1)",
            "component decomposition or purity",
            "generic Plucker nonvanishing on any component",
            "a first-normal obstruction",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as handle:
        json.dump(bundle, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(f"wrote {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
