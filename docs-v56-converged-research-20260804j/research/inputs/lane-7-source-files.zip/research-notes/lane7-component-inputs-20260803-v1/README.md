# Lane 7 self-contained component and Plücker inputs

This packet closes a source-access gap in the Lane 7 research handoff. The
older split-incidence directory contains every exact dependency used by its
checker, but its factorization JSON refers to `Q` and `R` by filename and it
does not store either `A` or the product `CA` directly. A reader given only a
selective rendering of that directory therefore cannot reconstruct the second
marking or test the Plücker open without first recovering the large upstream
certificate chain.

`lane7_exact_component_bundle.json` is the compact research interface. Over

\[
A_0=\mathbf Q[a_0,\ldots,a_6]
\]

it stores, as expanded exact polynomial strings:

- the quartic `d`;
- the residual matrix `M` of shape \(10\times5\);
- the matrices `H,C,Q,R` in the determinant-boundary factorization;
- the top source block `A` of shape \(10\times5\);
- the directly usable product `CA` of shape \(5\times5\).

Thus a component calculation needs only the bundle. For
\(u=(u_0,\ldots,u_4)^t\), put

\[
w=(CA)u,\qquad
\eta_{ij}=u_iw_j-u_jw_i.
\]

On \(D(d)\), the second marking is \(v=-d^{-1}w\). A component of
\(V(I_5(M))\cap D(d)\) meets the independent-marking locus exactly when not
all ten \(\eta_{ij}\) vanish identically on its projective-kernel incidence.

## Reproduction and verification

The bundle was deterministically regenerated from the maintained exact
split-incidence sources:

```text
uv run python -B \
  research-notes/lane7-component-inputs-20260803-v1/build_component_bundle.py \
  research-notes/lane7-component-inputs-20260803-v1/lane7_exact_component_bundle.json
```

The builder refuses to overwrite an existing output. The verifier checks the
manifest hashes, reconstructs `A`, `H`, and `C` from the original certificate,
checks the five matrix-factorization identities, checks `CA=C*A`, checks the
stored residual matrix, and checks the sign convention in the Plücker
transport:

```text
uv run python -B \
  research-notes/lane7-component-inputs-20260803-v1/verify_component_bundle.py
```

`manifest.json` pins both the compact bundle and every source file required to
reconstruct it. The successful verification report is retained in the
immutable run directory
`/path/to/versioned-artifact`.

## Exact scope

This packet supplies the inputs needed to study grade, corank, components,
and the componentwise Plücker open. It proves no grade-six, purity,
decomposition, corank-two exclusion, or componentwise nonvanishing result by
itself.
