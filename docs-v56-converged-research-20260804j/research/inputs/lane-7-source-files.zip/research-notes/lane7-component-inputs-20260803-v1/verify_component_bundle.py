#!/usr/bin/env python3
"""Verify the Lane 7 compact component bundle against its exact sources."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

import sympy as sp


ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[1]
SOURCE = ROOT.parent / "lane7-split-incidence-20260802-v1"
sys.path.insert(0, str(ROOT))

from build_component_bundle import parse_entries, theorem_matrices  # noqa: E402


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_bundle_matrix(
    data: dict, name: str, symbols: tuple[sp.Symbol, ...]
) -> sp.Matrix:
    item = data["matrices"][name]
    rows, columns = item["shape"]
    entries = item["entries"]
    assert len(entries) == rows
    assert all(len(row) == columns for row in entries)
    local_symbols = {str(variable): variable for variable in symbols}
    return sp.Matrix(
        [[sp.sympify(entry, locals=local_symbols) for entry in row] for row in entries]
    )


def zero(matrix: sp.Matrix) -> bool:
    return all(sp.expand(entry) == 0 for entry in matrix)


def main() -> int:
    manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
    hash_checks: dict[str, bool] = {}
    for entry in manifest["files"]:
        path = REPOSITORY / entry["path"]
        hash_checks[entry["path"]] = path.is_file() and sha256(path) == entry["sha256"]
    if not all(hash_checks.values()):
        raise SystemExit(f"manifest hash failure: {hash_checks}")

    bundle = json.loads(
        (ROOT / "lane7_exact_component_bundle.json").read_text(encoding="utf-8")
    )
    parameters = sp.symbols("a0:7")
    local_symbols = {str(variable): variable for variable in parameters}
    determinant = sp.sympify(bundle["d"], locals=local_symbols)
    matrix_m = parse_bundle_matrix(bundle, "M", parameters)
    matrix_a = parse_bundle_matrix(bundle, "A", parameters)
    matrix_ca = parse_bundle_matrix(bundle, "CA", parameters)
    matrix_h = parse_bundle_matrix(bundle, "H", parameters)
    matrix_c = parse_bundle_matrix(bundle, "C", parameters)
    matrix_q = parse_bundle_matrix(bundle, "Q", parameters)
    matrix_r = parse_bundle_matrix(bundle, "R", parameters)

    source_d, source_a, source_h, source_c, source_q, source_r = theorem_matrices()
    source_m = parse_entries(SOURCE / "collision_residual_matrix_M.json")
    checks = {
        "bundle_d_matches_source": sp.expand(determinant - source_d) == 0,
        "bundle_M_matches_source": matrix_m == source_m,
        "bundle_A_matches_reconstruction": matrix_a == source_a,
        "bundle_H_matches_reconstruction": matrix_h == source_h,
        "bundle_C_matches_reconstruction": matrix_c == source_c,
        "bundle_Q_matches_source": matrix_q == source_q,
        "bundle_R_matches_source": matrix_r == source_r,
        "bundle_CA_is_C_times_A": zero(matrix_ca - matrix_c * matrix_a),
        "C_H_is_dI5": zero(matrix_c * matrix_h - determinant * sp.eye(5)),
        "Q_H_is_zero": zero(matrix_q * matrix_h),
        "C_R_is_zero": zero(matrix_c * matrix_r),
        "Q_R_is_dI5": zero(matrix_q * matrix_r - determinant * sp.eye(5)),
        "H_C_plus_R_Q_is_dI10": zero(
            matrix_h * matrix_c + matrix_r * matrix_q - determinant * sp.eye(10)
        ),
    }

    kernel = sp.Matrix(sp.symbols("u0:5"))
    second_numerator = matrix_ca * kernel
    plucker_checks = {}
    for i in range(5):
        for j in range(i + 1, 5):
            eta = sp.expand(
                kernel[i] * second_numerator[j] - kernel[j] * second_numerator[i]
            )
            reconstructed_minor = sp.cancel(
                kernel[i] * (-second_numerator[j] / determinant)
                - kernel[j] * (-second_numerator[i] / determinant)
            )
            plucker_checks[f"eta_{i}{j}"] = (
                sp.cancel(determinant * reconstructed_minor + eta) == 0
            )
    checks["all_ten_plucker_transport_signs"] = all(plucker_checks.values())
    if not all(checks.values()):
        raise SystemExit(f"exact check failure: {checks}")

    report = {
        "schema_version": 1,
        "status": "pass",
        "checks": checks,
        "manifest_hashes_checked": len(hash_checks),
        "matrix_shapes": {
            name: bundle["matrices"][name]["shape"]
            for name in ("M", "A", "CA", "H", "C", "Q", "R")
        },
        "does_not_establish": bundle["does_not_establish"],
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
