from __future__ import annotations
import json,sys
from pathlib import Path
import sympy as sp
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
from reconstruct_matrices import transformed, decode_coeff_matrix, a
def parse_matrix(path,key='entries'):
    o=json.load(open(path));loc={str(x):x for x in a}
    return sp.Matrix([[sp.sympify(s,locals=loc) for s in row] for row in o[key]])
U,V,d,Ku,Hu,Kv,Hv=transformed()
Q=parse_matrix(BASE/'Hv10_syzygies_exact.json')
R=parse_matrix(BASE/'Hv10_right_inverse_exact.json')
Cv=decode_coeff_matrix(BASE/'Hv_left_inverse.json')
E=sp.zeros(15,10)
for i in range(10):E[i,i]=1
for i,sgn in enumerate([1,1,-1,1,1]):E[10+i,i]=sp.Rational(3,2)*sgn
C=(Cv*E).applyfunc(sp.expand);H=Hv[:10,:]
S=H.row_join(R);T=C.col_join(Q)
assert all(sp.expand(x)==0 for x in S*T-d*sp.eye(10))
assert all(sp.expand(x)==0 for x in T*S-d*sp.eye(10))
fac=sp.factor_list(d,*a)
assert len(fac[1])==1 and fac[1][0][1]==1
pts=[
 [1,0,0,0,0,0,1],
 [1,2,3,4,5,6,7],
]
vals=[]
for pt in pts:
 sub=dict(zip(a,pt));dv=sp.Rational(d.subs(sub))
 ds=sp.Matrix(S.subs(sub)).det();dt=sp.Matrix(T.subs(sub)).det()
 vals.append({'point':pt,'d':str(dv),'detS':str(ds),'detT':str(dt)})
possible=[]
for k in range(11):
 r0=sp.Rational(vals[0]['detS'])/sp.Rational(vals[0]['d'])**k
 r1=sp.Rational(vals[1]['detS'])/sp.Rational(vals[1]['d'])**k
 if r0==r1:possible.append((k,r0))
assert possible==[(2,sp.Rational(-256,243))]
k,c=possible[0]
# detS detT=d^10 from the matrix factorization.
ct=sp.cancel(1/c)
assert ct==sp.Rational(-243,256)
report={
 'd_factorization_over_Q':str(fac),
 'specializations':vals,
 'deduction':{
  'detS':str(c)+' * d^'+str(k),
  'detT':str(ct)+' * d^'+str(10-k),
  'reason':'ST=dI and irreducibility of d force both determinants to be unit multiples of powers of d; two exact specializations determine the exponent and unit.'
 }
}
(BASE/'verify_split_determinants_report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
