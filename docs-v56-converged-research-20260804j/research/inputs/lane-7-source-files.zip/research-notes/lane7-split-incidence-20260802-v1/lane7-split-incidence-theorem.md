# Lane 7 progress: split incidence and a determinant-boundary matrix factorization

**Status:** exact characteristic-zero theorem, computer-assisted by explicit
polynomial identities over \(\mathbf Q[a_0,\ldots,a_6]\).  This note does not
claim the remaining corank-two exclusion, global component decomposition, or
global first-normal obstruction.

## Setup

Let
\[
A_0=\mathbf Q[a_0,\ldots,a_6],
\qquad d=\det T.
\]
After the published normalization \(a_7=1\) and after restoring the homogeneous
marking coordinate \(v_4\), the fifteen quintics are linear in the ten marking
coordinates:
\[
\Theta(a)\binom uv=0,
\qquad
u=(u_0,\ldots,u_4)^t,\quad v=(v_0,\ldots,v_4)^t.
\]
The previously verified quadratic reduction writes
\[
\Theta=[\,\mathsf U\mid\mathsf V\,],
\qquad
\mathsf U,\mathsf V\in\operatorname{Mat}_{15\times5}(A_0).
\]

Write
\[
A=\mathsf U_{0:10},\quad H=\mathsf V_{0:10},
\quad B=\mathsf U_{10:15}.
\]
There is a constant matrix \(L\in\operatorname{Mat}_{5\times10}(\mathbf Q)\)
such that
\[
\mathsf V_{10:15}=LH.
\]
Explicitly, the only nonzero entries of \(L\) are
\[
L_{ii}=\frac32(1,1,-1,1,1)_i,\qquad 0\le i<5.
\]
Put
\[
G=B-LA\in\operatorname{Mat}_{5\times5}(A_0).
\]

## Theorem A — global split incidence

There is an explicit polynomial matrix
\[
C_u\in\operatorname{Mat}_{5\times15}(A_0),
\qquad \deg C_u\le3,
\]
such that
\[
C_u\mathsf U=I_5.
\]
Consequently, with
\[
F=C_u\mathsf V,\qquad
\mathcal R=(I_{15}-\mathsf U C_u)\mathsf V,
\]
the polynomial source change
\[
(u,v)\longmapsto (u+Fv,v)
\]
identifies the complete homogeneous marking incidence scheme with
\[
\mathcal R(a)v=0,\qquad u=-F(a)v.
\]
In particular,
\[
\ker\Theta(a)\simeq\ker\mathcal R(a)
\]
over every field specialization for which the displayed coefficients are
defined.

### Proof

The transformation gives
\[
\mathsf Uu+\mathsf Vv
 =\mathsf U(u+Fv)+(I-\mathsf U C_u)\mathsf Vv
 =\mathsf Uu'+\mathcal Rv.
\]
Applying \(C_u\) gives \(u'=0\), because
\(C_u\mathsf U=I_5\) and \(C_u\mathcal R=0\).  The remaining equation is
\(\mathcal Rv=0\), and the inverse reconstruction is \(u=-Fv\).
\(\square\)

### Consequence: a certified chart cover

A nonzero marking in \(\ker\Theta(a)\) cannot have \(v=0\), because then
\(u=-Fv=0\).  Hence the projectivized marking incidence is covered by the five
intrinsic affine charts
\[
D(v_0),\ldots,D(v_4).
\]
The currently published normalization \(v_4=1\) is one member of this
five-chart cover; it is not by itself a global chart.

## Theorem B — determinant-boundary matrix factorization

There are explicit matrices
\[
C,Q\in\operatorname{Mat}_{5\times10}(A_0),
\qquad
R\in\operatorname{Mat}_{10\times5}(A_0)
\]
with row-degree bounds
\[
\deg Q_{\text{rows}}\le(3,3,5,5,5),
\qquad \deg R\le3,
\]
such that
\[
CH=dI_5,\qquad QH=0,\qquad CR=0,\qquad QR=dI_5
\]
and
\[
HC+RQ=dI_{10}.
\]
Equivalently, the two square matrices
\[
S=[\,H\mid R\,],
\qquad
T=\begin{bmatrix}C\\Q\end{bmatrix}
\]
form an exact matrix factorization
\[
ST=TS=dI_{10}.
\]

Therefore, over \(A_0[d^{-1}]\), \(H\) is a split rank-five summand of
\(A_0[d^{-1}]^{10}\), \(Q\) is the quotient projection, and
\[
S^{-1}=d^{-1}T.
\]

### Exact determinant corollary

The quartic \(d\) is irreducible over \(\mathbf Q\), and the exact identities
imply
\[
\det S=-\frac{256}{243}d^2,
\qquad
\det T=-\frac{243}{256}d^8.
\]
Thus the matrix factorization degenerates on precisely the determinant
boundary \(d=0\).

## Theorem C — reduction to a \(10\times5\) determinantal matrix

Define
\[
M(a)=
\begin{bmatrix}
G(a)\\
Q(a)A(a)
\end{bmatrix}
\in\operatorname{Mat}_{10\times5}(A_0).
\]
On the intrinsic regular open \(D(d)\), the complete fifteen-equation marking
system is scheme-theoretically equivalent to
\[
M(a)u=0,
\qquad
v=-d^{-1}C(a)A(a)u.
\]
Moreover,
\[
\operatorname{rank}\Theta(a)
 =5+\operatorname{rank}M(a),
\qquad
\ker\Theta(a)\simeq\ker M(a).
\]

### Proof

Subtracting \(L\) times the top ten equations from the bottom five turns the
system into
\[
Au+Hv=0,\qquad Gu=0.
\]
Multiplication of the first equation by \(C\) and \(Q\) is invertible on
\(D(d)\), by Theorem B, and gives
\[
CAu+dv=0,\qquad QAu=0.
\]
The first equation reconstructs \(v\); the remaining equations are exactly
\(M(a)u=0\).  The block reduction also gives the rank formula.
\(\square\)

## Determinantal consequences

The regular parameter carrier is
\[
\mathcal D
 =V(I_5(M))\cap D(d).
\]
Put
\[
 w=C(a)A(a)u,
 \qquad
 \eta_{ij}(a,u)=u_iw_j-u_jw_i.
\]
Since \(v=-d^{-1}w\), the Pluecker minors of the two recovered collision
vectors satisfy
\[
 u_iv_j-u_jv_i=-d^{-1}\eta_{ij}(a,u).
\]
Consequently the genuine independent-marking incidence is the open subset
\[
 \left\{(a,[u]):M(a)u=0,\quad
 \eta_{ij}(a,u)\ne0\text{ for some }i<j\right\}
 \subset \mathbf P(\ker M).
\]
The determinantal carrier \(\mathcal D\) alone may contain components on
which every recovered marking is collinear; any component or obstruction
calculation must retain this Pluecker-open condition or prove that it is
generically nonempty on the components being used.

On
\[
\mathcal D\setminus V(I_4(M)),
\]
the kernel is a line, so the marking is unique up to scalar and is reconstructed
by the displayed formula.

The unresolved nonuniqueness locus is now exactly
\[
V(I_4(M))\cap D(d).
\]
Thus the former certificate
\(I_9([H_u\mid H_v]):d^\infty=(1)\) is equivalent to the much smaller
certificate
\[
\boxed{I_4(M):d^\infty=(1).}
\]

The expected codimension of \(V(I_5(M))\) is
\[
(10-4)(5-4)=6,
\]
so its expected dimension in the seven-dimensional parameter space is one.
Expected dimension is not used as a proof of purity.

## Smooth characteristic-zero branch

At the published point
\[
a=(8,7,1,7,2,9,0)\in\mathbf F_{11}^7
\]
one has \(d=1\), \(\operatorname{rank}M=4\), and the determinantal normal map
\[
T_a\mathbf A^7\longrightarrow
\operatorname{Hom}(\ker M(a),\operatorname{coker}M(a))
\]
has rank six.  Hence \(V(I_5(M))\) is smooth of dimension one at this point.
The tangent line is generated by
\[
(8,6,5,4,3,10,1)\pmod {11}.
\]
Formal smoothness gives a one-dimensional \(\mathbf Z_{11}\)-smooth germ and
therefore a characteristic-zero component through its generic fiber.

## What remains

This theorem removes the marking variables and proves the exact determinantal
architecture.  It does **not** prove:

1. \(I_4(M):d^\infty=(1)\);
2. height six or Cohen--Macaulayness of \(I_5(M):d^\infty\);
3. the absolute component decomposition, with its Pluecker-open marking
   incidence;
4. nowhere-solvability of the first-normal equation.

The next sharp algebraic targets are therefore
\[
I_4(M):d^\infty=(1)
\quad\text{and}\quad
\operatorname{grade} I_5(M)=6
\ \text{on }D(d).
\]
If the grade condition holds, Eagon--Northcott makes the regular carrier a
pure Cohen--Macaulay curve before radical decomposition.
