from __future__ import annotations
import json, time
from pathlib import Path
import sympy as sp
BASE=Path(__file__).resolve().parent
import sys
sys.path.insert(0,str(BASE))
from reconstruct_matrices import transformed, decode_coeff_matrix, a

def parse_matrix(path,key='entries'):
    obj=json.load(open(path))
    rows=obj[key]
    loc={str(x):x for x in a}
    return sp.Matrix([[sp.sympify(s,locals=loc) for s in row] for row in rows])

def zero(M):
    return all(sp.expand(x)==0 for x in M)

t0=time.time()
U,V,d,Ku,Hu,Kv,Hv=transformed()
Cu=decode_coeff_matrix(BASE/'Hu_left_inverse_exact.json')
Cv=decode_coeff_matrix(BASE/'Hv_left_inverse.json')
Q=parse_matrix(BASE/'Hv10_syzygies_exact.json')
R=parse_matrix(BASE/'Hv10_right_inverse_exact.json')
H=Hv[:10,:]
A=Hu[:10,:]
s=[1,1,-1,1,1]
E=sp.zeros(15,10)
for i in range(10): E[i,i]=1
for i,sgn in enumerate(s): E[10+i,i]=sp.Rational(3,2)*sgn
C=(Cv*E).applyfunc(sp.expand)
L=sp.zeros(5,10)
for i,sgn in enumerate(s): L[i,i]=sp.Rational(3,2)*sgn
G=(Hu[10:,:]-L*A).applyfunc(sp.expand)
M=G.col_join((Q*A).applyfunc(sp.expand))
stored=json.load(open(BASE/'collision_residual_matrix_M.json'))
Mstored=sp.Matrix([[sp.sympify(x,locals={str(z):z for z in a}) for x in row] for row in stored['entries']])

checks={
 'Cu_Hu_I5': zero(Cu*Hu-sp.eye(5)),
 'C_H_dI5': zero(C*H-d*sp.eye(5)),
 'Q_H_0': zero(Q*H),
 'C_R_0': zero(C*R),
 'Q_R_dI5': zero(Q*R-d*sp.eye(5)),
 'H_C_plus_R_Q_dI10': zero(H*C+R*Q-d*sp.eye(10)),
 'lower_v_relation': zero(Hv[10:,:]-L*H),
 'stored_M_matches': zero(M-Mstored),
}
if not all(checks.values()):
    raise SystemExit('FAILED: '+repr(checks))
def stats(X):
    vals=list(X)
    non=[x for x in vals if x!=0]
    return {
      'shape':[X.rows,X.cols],
      'nonzero_entries':len(non),
      'max_total_degree':max((sp.Poly(x,*a).total_degree() for x in non),default=-1),
      'monomial_terms':sum(len(sp.Poly(x,*a).terms()) for x in non),
    }
report={
 'checks':checks,
 'elapsed_seconds':time.time()-t0,
 'stats':{
   'Cu':stats(Cu),'H':stats(H),'C':stats(C),'Q':stats(Q),'R':stats(R),
   'G':stats(G),'M':stats(M),
 },
 'theorem':[
   'Over Q[a0,...,a6,1/d], [C;Q] and [H R] are inverse up to the scalar d.',
   'The regular collision incidence is isomorphic to M(a)u=0 with v=-d^{-1}CAu.',
   'rank([Hu|Hv]) = 5 + rank(M) on D(d).'
 ]
}
(BASE/'verify_split_incidence_report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
