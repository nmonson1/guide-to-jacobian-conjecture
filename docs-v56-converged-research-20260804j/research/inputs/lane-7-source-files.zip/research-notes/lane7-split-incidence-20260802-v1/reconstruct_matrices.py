"""Reconstruct the Lane 7 polynomial matrices from the original certificate.

This is the reconstruction helper used in the source conversation.  It is
included here, together with its four data dependencies, so that the final
split-incidence checkers are standalone rather than dependent on ephemeral
notebook state.
"""

from __future__ import annotations

import json
from pathlib import Path

import sympy as sp


BASE = Path(__file__).resolve().parent
a = sp.symbols("a0:7")
u = sp.symbols("u0:5")
v = sp.symbols("v0:5")


def _load_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def collision_matrices():
    data = _load_json(BASE / "collision-system.json")
    local_symbols = {str(x): x for x in (*a, *u, *v)}
    equations = [
        sp.sympify(entry["polynomial"], locals=local_symbols)
        for entry in data["equations"]
    ]
    matrix_u = sp.Matrix(
        [[sp.expand(equation).coeff(x) for x in u] for equation in equations]
    )
    affine_zero = {x: 0 for x in (*u, *v[:4])}
    matrix_v = sp.Matrix(
        [
            [sp.expand(equation).coeff(x) for x in v[:4]]
            + [sp.expand(equation).subs(affine_zero)]
            for equation in equations
        ]
    )
    determinant = sp.sympify(
        data["chart"]["open_polynomial_factors"]["det_T"],
        locals={str(x): x for x in a},
    )
    return matrix_u, matrix_v, sp.expand(determinant)


def _polynomial_list(vector, monomials, polynomial_count):
    monomial_basis = [
        sp.prod(a[i] ** exponent[i] for i in range(7)) for exponent in monomials
    ]
    coefficients = [
        sp.Rational(value[0], value[1])
        if isinstance(value, list)
        else sp.Rational(value)
        for value in vector
    ]
    basis_size = len(monomial_basis)
    return [
        sp.expand(
            sum(
                coefficients[j * basis_size + k] * monomial_basis[k]
                for k in range(basis_size)
            )
        )
        for j in range(polynomial_count)
    ]


def syzygy_matrices(filename: str, coefficient_rows: int):
    data = _load_json(BASE / filename)
    left_columns = []
    right_columns = []
    for vector in data["basis"]:
        polynomials = _polynomial_list(
            vector, data["monomials"], coefficient_rows + 15
        )
        left_columns.append(polynomials[:coefficient_rows])
        right_columns.append(polynomials[coefficient_rows:])
    left = sp.Matrix(
        coefficient_rows,
        len(left_columns),
        lambda i, j: left_columns[j][i],
    )
    right = sp.Matrix(15, len(right_columns), lambda i, j: right_columns[j][i])
    return left, right


def transformed():
    matrix_u, matrix_v, determinant = collision_matrices()
    coefficient_u, transformed_u = syzygy_matrices("quadratic_syzygies.json", 9)
    assert coefficient_u[5:9, :] == sp.zeros(4, 5)
    coefficient_v, transformed_v = syzygy_matrices(
        "V_quadratic_syzygies.json", 5
    )
    return (
        matrix_u,
        matrix_v,
        determinant,
        coefficient_u[:5, :],
        transformed_u,
        coefficient_v,
        transformed_v,
    )


def decode_coeff_matrix(path: Path):
    data = _load_json(path)
    monomial_basis = [
        sp.prod(a[i] ** exponent[i] for i in range(7))
        for exponent in data["monomials"]
    ]
    rows, columns = data["matrix_shape"]
    if rows != len(data["coefficients"]):
        raise ValueError("coefficient row count does not match matrix_shape")
    decoded_rows = []
    basis_size = len(monomial_basis)
    for flat_row in data["coefficients"]:
        coefficients = [
            sp.Rational(value[0], value[1])
            if isinstance(value, list)
            else sp.Rational(value)
            for value in flat_row
        ]
        if len(coefficients) != columns * basis_size:
            raise ValueError("flattened coefficient row has the wrong length")
        decoded_rows.append(
            [
                sp.expand(
                    sum(
                        coefficients[j * basis_size + k] * monomial_basis[k]
                        for k in range(basis_size)
                    )
                )
                for j in range(columns)
            ]
        )
    return sp.Matrix(decoded_rows)
