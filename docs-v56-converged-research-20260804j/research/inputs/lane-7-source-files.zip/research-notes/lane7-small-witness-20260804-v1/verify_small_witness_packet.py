#!/usr/bin/env python3
"""Verify the Lane 7 small-witness strategy and rendered CAS inputs."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

import sympy as sp


ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[1]
sys.path.insert(0, str(ROOT))

from build_small_witness_packet import (  # noqa: E402
    PRIME,
    ROW_DENOMINATOR_LCMS,
    build_outputs,
    matrix_rank_mod_p,
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
    if manifest["packet"] != "lane7-small-witness-20260804-v1":
        raise AssertionError("unexpected packet identity")
    checked_hashes = {}
    for item in manifest["files"]:
        path = REPOSITORY / item["path"]
        checked_hashes[item["path"]] = path.is_file() and sha256(path) == item["sha256"]
    if not all(checked_hashes.values()):
        raise AssertionError(f"manifest hash failure: {checked_hashes}")

    expected_outputs = build_outputs()
    rendered_checks = {
        name: (ROOT / name).read_text(encoding="utf-8") == content
        for name, content in expected_outputs.items()
    }
    if not all(rendered_checks.values()):
        raise AssertionError(f"rendered packet drift: {rendered_checks}")

    strategy = json.loads((ROOT / "strategy.json").read_text(encoding="utf-8"))
    assert strategy["field"] == "F_11"
    assert strategy["parameter_point"] == [8, 7, 1, 7, 2, 9, 0]
    assert strategy["d_value"] == 1
    assert strategy["matrix_rank"] == 4
    assert strategy["kernel_chart"] == 0
    assert strategy["kernel_vector"] == [1, 5, 2, 1, 5]
    assert strategy["pivot_rows"] == [0, 1, 2, 3]
    assert strategy["pivot_columns"] == [1, 2, 3, 4]
    assert strategy["pivot_minor_value_F11"] == 2
    assert strategy["witness_row_sets"] == [
        [0, 1, 2, 3, row] for row in range(4, 10)
    ]
    assert strategy["witness_minor_values_F11"] == [0] * 6
    assert matrix_rank_mod_p(strategy["witness_jacobian_F11"]) == 6
    assert strategy["tangent_is_in_witness_kernel"] is True

    if any(scale % PRIME == 0 for scale in ROW_DENOMINATOR_LCMS):
        raise AssertionError("F_11 kills a row-scaling unit")
    component_bundle = json.loads(
        (
            ROOT.parent
            / "lane7-component-inputs-20260803-v1"
            / "lane7_exact_component_bundle.json"
        ).read_text(encoding="utf-8")
    )
    for row in component_bundle["matrices"]["CA"]["entries"]:
        for expression in row:
            for coefficient in sp.Poly(
                sp.sympify(expression), *sp.symbols("a0:7"), domain=sp.QQ
            ).coeffs():
                if int(coefficient.q) % PRIME == 0:
                    raise AssertionError("F_11 kills a CA coefficient denominator")

    grade_q = expected_outputs["grade_witness_QQ.m2"]
    corank_q = expected_outputs["corank_block_filter_QQ.m2"]
    collinear_q = expected_outputs["collinearity_atlas_QQ.m2"]
    assert "assert(#witnessMinors == 6)" in grade_q
    assert "assert(numgens J4block == 50)" in corank_q
    for chart in range(5):
        assert f"assert(#collinear{chart} == 4)" in collinear_q
        assert f"LANE7_COLLINEAR_CHART_{chart}_QQ_BEGIN" in collinear_q

    report = {
        "status": "pass",
        "packet": manifest["packet"],
        "hashes_checked": len(checked_hashes),
        "rendered_outputs_checked": len(rendered_checks),
        "finite_field_local_witness": {
            "prime": 11,
            "matrix_rank": 4,
            "witness_jacobian_rank": 6,
            "local_dimension": 1,
        },
        "exact_Q_outputs": [
            "grade_witness_QQ.m2",
            "corank_block_filter_QQ.m2",
            "collinearity_atlas_QQ.m2",
        ],
        "does_not_establish": manifest["does_not_establish"],
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
