#!/usr/bin/env python3
"""Build the fail-closed Lane 7 small-witness CAS packet."""

from __future__ import annotations

import argparse
from itertools import combinations
import json
from pathlib import Path
import sys

import sympy as sp


ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[1]
COMPONENTS = ROOT.parent / "lane7-component-inputs-20260803-v1"
SPLIT = ROOT.parent / "lane7-split-incidence-20260802-v1"
KERNEL = ROOT.parent / "lane7-projective-kernel-20260803-v1"
sys.path.insert(0, str(KERNEL))

from generate_macaulay2_input import (  # noqa: E402
    ROW_DENOMINATOR_LCMS,
    m2_expression,
    m2_matrix,
    scaled_rows,
)


PRIME = 11


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def mod_p(value: sp.Expr, prime: int = PRIME) -> int:
    rational = sp.Rational(value)
    numerator = int(rational.p) % prime
    denominator = int(rational.q) % prime
    if denominator == 0:
        raise ZeroDivisionError(f"denominator vanishes modulo {prime}")
    return numerator * pow(denominator, -1, prime) % prime


def matrix_rank_mod_p(rows: list[list[int]], prime: int = PRIME) -> int:
    matrix = [[value % prime for value in row] for row in rows]
    if not matrix:
        return 0
    row_count = len(matrix)
    column_count = len(matrix[0])
    pivot_row = 0
    for column in range(column_count):
        pivot = next(
            (row for row in range(pivot_row, row_count) if matrix[row][column]),
            None,
        )
        if pivot is None:
            continue
        matrix[pivot_row], matrix[pivot] = matrix[pivot], matrix[pivot_row]
        inverse = pow(matrix[pivot_row][column], -1, prime)
        matrix[pivot_row] = [value * inverse % prime for value in matrix[pivot_row]]
        for row in range(row_count):
            if row == pivot_row or not matrix[row][column]:
                continue
            multiplier = matrix[row][column]
            matrix[row] = [
                (left - multiplier * right) % prime
                for left, right in zip(matrix[row], matrix[pivot_row], strict=True)
            ]
        pivot_row += 1
        if pivot_row == row_count:
            break
    return pivot_row


def determinant_mod_p(rows: list[list[int]], prime: int = PRIME) -> int:
    if not rows:
        return 1
    size = len(rows)
    if any(len(row) != size for row in rows):
        raise ValueError("determinant requires a square matrix")
    matrix = [[value % prime for value in row] for row in rows]
    determinant = 1
    for column in range(size):
        pivot = next(
            (row for row in range(column, size) if matrix[row][column]), None
        )
        if pivot is None:
            return 0
        if pivot != column:
            matrix[column], matrix[pivot] = matrix[pivot], matrix[column]
            determinant = -determinant
        pivot_value = matrix[column][column]
        determinant = determinant * pivot_value % prime
        inverse = pow(pivot_value, -1, prime)
        for row in range(column + 1, size):
            multiplier = matrix[row][column] * inverse % prime
            for index in range(column, size):
                matrix[row][index] = (
                    matrix[row][index] - multiplier * matrix[column][index]
                ) % prime
    return determinant % prime


def solve_square_mod_p(
    matrix: list[list[int]], right_hand_side: list[int], prime: int = PRIME
) -> list[int]:
    size = len(matrix)
    if len(right_hand_side) != size or any(len(row) != size for row in matrix):
        raise ValueError("modular solve requires a square system")
    augmented = [
        [*(value % prime for value in row), right_hand_side[index] % prime]
        for index, row in enumerate(matrix)
    ]
    for column in range(size):
        pivot = next(
            (row for row in range(column, size) if augmented[row][column]), None
        )
        if pivot is None:
            raise ValueError("singular modular system")
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        inverse = pow(augmented[column][column], -1, prime)
        augmented[column] = [value * inverse % prime for value in augmented[column]]
        for row in range(size):
            if row == column or not augmented[row][column]:
                continue
            multiplier = augmented[row][column]
            augmented[row] = [
                (left - multiplier * right) % prime
                for left, right in zip(augmented[row], augmented[column], strict=True)
            ]
    return [augmented[index][-1] for index in range(size)]


def parse_matrix(entries: list[list[str]], parameters: tuple[sp.Symbol, ...]) -> sp.Matrix:
    local_symbols = {str(variable): variable for variable in parameters}
    return sp.Matrix(
        [[sp.sympify(entry, locals=local_symbols) for entry in row] for row in entries]
    )


def evaluated_matrix_and_derivatives(
    matrix: sp.Matrix,
    parameters: tuple[sp.Symbol, ...],
    point: list[int],
) -> tuple[list[list[int]], list[list[list[int]]]]:
    substitutions = dict(zip(parameters, point, strict=True))
    values = [
        [mod_p(matrix[row, column].subs(substitutions)) for column in range(matrix.cols)]
        for row in range(matrix.rows)
    ]
    derivatives = []
    for parameter in parameters:
        derivatives.append(
            [
                [
                    mod_p(sp.diff(matrix[row, column], parameter).subs(substitutions))
                    for column in range(matrix.cols)
                ]
                for row in range(matrix.rows)
            ]
        )
    return values, derivatives


def determinant_derivative_mod_p(
    values: list[list[int]], derivatives: list[list[int]]
) -> int:
    """Differentiate a determinant at a possibly singular matrix."""
    size = len(values)
    answer = 0
    for row in range(size):
        for column in range(size):
            complementary = [
                [values[i][j] for j in range(size) if j != column]
                for i in range(size)
                if i != row
            ]
            cofactor = determinant_mod_p(complementary)
            if (row + column) % 2:
                cofactor = -cofactor
            answer += cofactor * derivatives[row][column]
    return answer % PRIME


def submatrix(
    matrix: list[list[int]], rows: tuple[int, ...], columns: tuple[int, ...]
) -> list[list[int]]:
    return [[matrix[row][column] for column in columns] for row in rows]


def choose_strategy(
    matrix: sp.Matrix,
    parameters: tuple[sp.Symbol, ...],
    point_a: list[int],
) -> dict:
    values, derivatives = evaluated_matrix_and_derivatives(matrix, parameters, point_a)
    if matrix_rank_mod_p(values) != 4:
        raise AssertionError("recorded F_11 matrix does not have rank four")

    all_columns = tuple(range(5))
    for kernel_chart in range(5):
        pivot_columns = tuple(index for index in all_columns if index != kernel_chart)
        for pivot_rows in combinations(range(10), 4):
            delta = determinant_mod_p(submatrix(values, pivot_rows, pivot_columns))
            if delta == 0:
                continue
            pivot_matrix = submatrix(values, pivot_rows, pivot_columns)
            solved = solve_square_mod_p(
                pivot_matrix,
                [-values[row][kernel_chart] for row in pivot_rows],
            )
            point_u = [0] * 5
            point_u[kernel_chart] = 1
            for column, value in zip(pivot_columns, solved, strict=True):
                point_u[column] = value
            kernel_value = [
                sum(values[row][column] * point_u[column] for column in range(5))
                % PRIME
                for row in range(10)
            ]
            if any(kernel_value):
                raise AssertionError("pivot-derived vector is not in the full kernel")
            complement_rows = tuple(index for index in range(10) if index not in pivot_rows)
            witness_rows = [tuple(sorted((*pivot_rows, row))) for row in complement_rows]
            witness_values = [
                determinant_mod_p(submatrix(values, rows, all_columns))
                for rows in witness_rows
            ]
            if any(witness_values):
                raise AssertionError("rank-four point does not kill a maximal minor")
            jacobian: list[list[int]] = []
            for rows in witness_rows:
                minor_values = submatrix(values, rows, all_columns)
                gradient = []
                for parameter_index in range(7):
                    minor_derivatives = submatrix(
                        derivatives[parameter_index], rows, all_columns
                    )
                    gradient.append(
                        determinant_derivative_mod_p(minor_values, minor_derivatives)
                    )
                jacobian.append(gradient)
            if matrix_rank_mod_p(jacobian) != 6:
                continue
            return {
                "kernel_chart": kernel_chart,
                "kernel_vector_F11": point_u,
                "kernel_chart_value_F11": 1,
                "pivot_rows": list(pivot_rows),
                "pivot_columns": list(pivot_columns),
                "pivot_minor_value_F11": delta,
                "complement_rows": list(complement_rows),
                "witness_row_sets": [list(rows) for rows in witness_rows],
                "witness_minor_values_F11": witness_values,
                "witness_jacobian_F11": jacobian,
                "witness_jacobian_rank_F11": 6,
            }
    raise AssertionError("no deterministic six-minor smooth witness was found")


def common_m2_prelude(
    residual: dict,
    determinant: str,
    characteristic: int,
    extra_variables: list[str],
) -> list[str]:
    coefficient_ring = "QQ" if characteristic == 0 else f"ZZ/{characteristic}"
    variables = [f"a{index}" for index in range(7)] + extra_variables
    entries = scaled_rows(residual["entries"], clear_denominators=True)
    return [
        "-- Generated by build_small_witness_packet.py; do not edit by hand.",
        "-- Rows of M are scaled by nonzero rational constants.",
        f"R = {coefficient_ring}[{','.join(variables)}, MonomialOrder => GRevLex];",
        f"d = {m2_expression(determinant)};",
        f"M = {m2_matrix(entries)};",
        "assert(numrows M == 10 and numcols M == 5);",
    ]


def render_grade_program(
    residual: dict, determinant: str, strategy: dict, characteristic: int
) -> str:
    rows = strategy["witness_row_sets"]
    row_lists = ",".join("{" + ",".join(map(str, row)) + "}" for row in rows)
    field = "QQ" if characteristic == 0 else f"F{characteristic}"
    lines = common_m2_prelude(residual, determinant, characteristic, ["z"])
    lines.extend(
        [
            f"witnessRows = {{{row_lists}}};",
            "allColumns = {0,1,2,3,4};",
            "witnessMinors = apply(witnessRows, rows -> det submatrix(M, rows, allColumns));",
            "assert(#witnessMinors == 6);",
            "J = ideal witnessMinors + ideal(z*d-1);",
            f'print "LANE7_SMALL_WITNESS_{field}_BEGIN";',
            "GJ = gb J;",
            "unitJ = (J == 1);",
            f'print("LANE7_SMALL_WITNESS_{field}_UNIT=" | toString unitJ);',
            "if unitJ then (",
            f'  print "LANE7_SMALL_WITNESS_{field}_DIM=EMPTY";',
            ") else (",
            f'  print("LANE7_SMALL_WITNESS_{field}_DIM=" | toString dim J);',
            f'  print("LANE7_SMALL_WITNESS_{field}_CODIM=" | toString codim J);',
            ");",
            f'print("LANE7_SMALL_WITNESS_{field}_GB_SIZE=" | toString numgens source gens GJ);',
            f'print "LANE7_SMALL_WITNESS_{field}_END";',
        ]
    )
    return "\n\n".join(lines) + "\n"


def render_corank_program(residual: dict, determinant: str, characteristic: int) -> str:
    entries = scaled_rows(residual["entries"], clear_denominators=True)
    g_entries = entries[:5]
    qa_entries = entries[5:]
    field = "QQ" if characteristic == 0 else f"F{characteristic}"
    lines = common_m2_prelude(residual, determinant, characteristic, ["z"])
    lines.extend(
        [
            f"Gblock = {m2_matrix(g_entries)};",
            f"QAblock = {m2_matrix(qa_entries)};",
            "J4block = minors(4,Gblock) + minors(4,QAblock);",
            "assert(numgens J4block == 50);",
            "J = J4block + ideal(z*d-1);",
            f'print "LANE7_CORANK_FILTER_{field}_BEGIN";',
            "GJ = gb J;",
            "unitJ = (J == 1);",
            f'print("LANE7_CORANK_FILTER_{field}_UNIT=" | toString unitJ);',
            "if unitJ then (",
            f'  print "LANE7_CORANK_FILTER_{field}_DIM=EMPTY";',
            ") else (",
            f'  print("LANE7_CORANK_FILTER_{field}_DIM=" | toString dim J);',
            f'  print("LANE7_CORANK_FILTER_{field}_CODIM=" | toString codim J);',
            ");",
            f'print("LANE7_CORANK_FILTER_{field}_GB_SIZE=" | toString numgens source gens GJ);',
            f'print "LANE7_CORANK_FILTER_{field}_END";',
        ]
    )
    return "\n\n".join(lines) + "\n"


def render_collinearity_program(
    bundle: dict, residual: dict, determinant: str, characteristic: int
) -> str:
    field = "QQ" if characteristic == 0 else f"F{characteristic}"
    ca_entries = bundle["matrices"]["CA"]["entries"]
    lines = common_m2_prelude(
        residual,
        determinant,
        characteristic,
        ["x0", "x1", "x2", "x3", "z"],
    )
    lines.append(f"CA = {m2_matrix(ca_entries)};")
    for chart in range(5):
        free = iter(["x0", "x1", "x2", "x3"])
        coordinates = ["1" if index == chart else next(free) for index in range(5)]
        second_coordinates = [
            "(" + "+".join(
                f"({m2_expression(ca_entries[row][column])})*({coordinates[column]})"
                for column in range(5)
            ) + ")"
            for row in range(5)
        ]
        collinearity_equations = [
            (
                f"({coordinates[chart]})*({second_coordinates[index]})"
                f"-({coordinates[index]})*({second_coordinates[chart]})"
            )
            for index in range(5)
            if index != chart
        ]
        lines.extend(
            [
                f"u{chart} = transpose matrix {{{{{','.join(coordinates)}}}}};",
                f"w{chart} = CA*u{chart};",
                f"kernel{chart} = flatten entries(M*u{chart});",
                f"collinear{chart} = {{{','.join(collinearity_equations)}}};",
                f"assert(#collinear{chart} == 4);",
                f"J{chart} = ideal(kernel{chart} | collinear{chart}) + ideal(z*d-1);",
                f'print "LANE7_COLLINEAR_CHART_{chart}_{field}_BEGIN";',
                f"GJ{chart} = gb J{chart};",
                f"unitJ{chart} = (J{chart} == 1);",
                f'print("LANE7_COLLINEAR_CHART_{chart}_{field}_UNIT=" | toString unitJ{chart});',
                f"if unitJ{chart} then (",
                f'  print "LANE7_COLLINEAR_CHART_{chart}_{field}_DIM=EMPTY";',
                ") else (",
                f'  print("LANE7_COLLINEAR_CHART_{chart}_{field}_DIM=" | toString dim J{chart});',
                ");",
                f'print "LANE7_COLLINEAR_CHART_{chart}_{field}_END";',
            ]
        )
    return "\n\n".join(lines) + "\n"


def build_outputs() -> dict[str, str]:
    if len(ROW_DENOMINATOR_LCMS) != 10:
        raise AssertionError("the pinned row-scaling table no longer matches M")
    bundle = read_json(COMPONENTS / "lane7_exact_component_bundle.json")
    residual = read_json(SPLIT / "collision_residual_matrix_M.json")
    collision = read_json(SPLIT / "collision-system.json")
    parameters = sp.symbols("a0:7")
    matrix = parse_matrix(residual["entries"], parameters)
    base_coordinates = collision["base_point_F11"]["coordinates"]
    point_a = base_coordinates[:7]
    strategy = choose_strategy(matrix, parameters, point_a)
    substitutions = dict(zip(parameters, point_a, strict=True))
    determinant = bundle["d"]
    determinant_F11 = mod_p(sp.sympify(determinant, locals={str(x): x for x in parameters}).subs(substitutions))
    if determinant_F11 == 0:
        raise AssertionError("the recorded point is outside D(d)")
    tangent = [8, 6, 5, 4, 3, 10, 1]
    tangent_image = [
        sum(row[index] * tangent[index] for index in range(7)) % PRIME
        for row in strategy["witness_jacobian_F11"]
    ]
    if any(tangent_image):
        raise AssertionError("published tangent does not kill the witness Jacobian")
    strategy_document = {
        "schema_version": 1,
        "packet": "lane7-small-witness-20260804-v1",
        "field": "F_11",
        "parameter_point": point_a,
        "kernel_vector": strategy["kernel_vector_F11"],
        "d_value": determinant_F11,
        "matrix_rank": 4,
        **strategy,
        "tangent_generator": tangent,
        "tangent_is_in_witness_kernel": True,
        "interpretation": (
            "The six selected maximal minors cut a smooth one-dimensional "
            "local germ at the recorded F_11 point. This is a local finite-field "
            "witness and does not determine the global characteristic-zero saturation."
        ),
    }
    return {
        "strategy.json": json.dumps(strategy_document, indent=2, sort_keys=True) + "\n",
        "grade_witness_QQ.m2": render_grade_program(residual, determinant, strategy, 0),
        "grade_witness_F11.m2": render_grade_program(residual, determinant, strategy, 11),
        "corank_block_filter_QQ.m2": render_corank_program(residual, determinant, 0),
        "corank_block_filter_F11.m2": render_corank_program(residual, determinant, 11),
        "collinearity_atlas_QQ.m2": render_collinearity_program(
            bundle, residual, determinant, 0
        ),
        "collinearity_atlas_F11.m2": render_collinearity_program(
            bundle, residual, determinant, 11
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output_directory", type=Path)
    args = parser.parse_args()
    output_directory = args.output_directory.resolve()
    output_directory.mkdir(parents=True, exist_ok=True)
    outputs = build_outputs()
    existing = [name for name in outputs if (output_directory / name).exists()]
    if existing:
        raise FileExistsError(f"refusing to overwrite packet outputs: {existing}")
    for name, content in outputs.items():
        (output_directory / name).write_text(content, encoding="utf-8")
        print(f"wrote {output_directory / name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
