# Lane 7 small-witness, corank-filter, and collinearity packet

This packet turns three lower-cost Lane 7 strategies into exact, reproducible
CAS inputs.  It uses the compact matrices in
`../lane7-component-inputs-20260803-v1/` and does not change the canonical
mathematics or claim a completed characteristic-zero computation.

## Six-minor grade witness

Let

\[
M=\begin{bmatrix}G\\ QA\end{bmatrix}\in
\operatorname{Mat}_{10\times5}(\mathbf Q[a_0,\ldots,a_6])
\]

and let \(d\) define the maintained regular open.  At the known point

\[
a=(8,7,1,7,2,9,0)\in\mathbf F_{11}^{7}
\]

the packet independently checks \(d(a)=1\), \(\operatorname{rank}M(a)=4\),
and obtains the normalized kernel vector

\[
u=(1,5,2,1,5).
\]

The rows \(0,1,2,3\) and columns \(1,2,3,4\) give a \(4\times4\) pivot
\(\delta\) with value \(2\) modulo 11.  Adjoining each of rows
\(4,\ldots,9\) produces six maximal minors

\[
f_r=\det M_{\{0,1,2,3,r\},\{0,1,2,3,4\}},
\qquad 4\le r\le9.
\]

`strategy.json` records their exact indices and their \(6\times7\) Jacobian
at the point.  The verifier recomputes that the minors vanish and that this
Jacobian has rank six.  Thus these six equations cut a smooth
one-dimensional **local** germ over \(\mathbf F_{11}\).  The recorded tangent
generator is also checked.

Put \(J=(f_4,\ldots,f_9)\).  Since \(J\subset I_5(M)\), a successful exact
calculation

\[
\dim \bigl(\mathbf Q[a_0,\ldots,a_6]/J\bigr)\big|_{D(d)}\le1
\]

would force the same upper dimension bound for the carrier.  The
determinantal height bound gives \(\operatorname{ht} I_5(M)\le6\); hence a
nonempty one-dimensional result gives height and grade six on the regular
open.  Eagon--Northcott would then give the desired pure Cohen--Macaulay
curve.  `grade_witness_QQ.m2` is the fail-closed exact input for this test;
`grade_witness_F11.m2` is only a finite-field diagnostic.

On \(D(\delta)\), the six displayed minors generate the maximal-minor ideal:
set \(u_0=1\), solve the first four rows for the other kernel coordinates,
and the remaining six rows are the Schur-complement equations.  This
explains the selection.  It does **not** permit a result on \(D(d\delta)\) to
be reported globally on \(D(d)\).  A pivot-elimination implementation must
either cover the residual locus \(V(\delta)\cap D(d)\) by other pivots or
prove that locus contributes nothing.  The global six-minor saturation above
does not require this extra localization.

## Fifty-minor corank filter

The two \(5\times5\) blocks \(G\) and \(QA\) supply 25 four-minors apiece.
The resulting 50-generator ideal

\[
J_{\mathrm{block}}=I_4(G)+I_4(QA)\subset I_4(M)
\]

is much smaller than the full 1,050-generator presentation.  Therefore

\[
J_{\mathrm{block}}:d^\infty=(1)
\quad\Longrightarrow\quad
I_4(M):d^\infty=(1).
\]

`corank_block_filter_QQ.m2` implements this sufficient exact test.  A
non-unit answer is inconclusive.  The next fail-closed choices are to add
mixed four-minors in deterministic batches, or to cover
\(\operatorname{Gr}(2,5)\) by its ten standard Pluecker-pivot charts.  On
each Grassmann chart, normalize the corresponding \(2\times2\) rows of a
\(5\times2\) kernel matrix to the identity and test the twenty equations
\(MU=0\) together with \(zd-1\).  Corank-two emptiness is established only
when all ten charts are certified empty.  One pivot chart alone is not a
global certificate.

## Four collinearity equations per projective-kernel chart

For \(w=CAu\), define

\[
\eta_{ij}=u_iw_j-u_jw_i.
\]

On the chart \(u_i=1\), the four equations \(\eta_{ij}=0\), \(j\ne i\),
imply all ten Pluecker equations.  `collinearity_atlas_QQ.m2` renders the ten
kernel equations \(Mu=0\), these four equations, and \(zd-1\) on each of the
five charts covering \(\mathbf P^4\).  The characteristic-11 companion is a
diagnostic only.

If grade six has already made the carrier a pure curve and the corank-two
locus has been excluded, proving that every collinearity chart has dimension
at most zero shows that no one-dimensional component is contained in the
collinear locus.  Every component then meets the independent-marking open.
An exhaustive primary decomposition is not needed for that conclusion.  It
remains an optional, separately useful structural calculation.

## Reproduction

The checked-in CAS inputs are deterministic renderings.  Regenerate them only
into a new empty directory:

```text
uv run python -B \
  research-notes/lane7-small-witness-20260804-v1/build_small_witness_packet.py \
  /tmp/lane7-small-witness-rebuild-v1
```

Verify the source hashes, exact finite-field witness, and byte-for-byte
rendering:

```text
uv run python -B \
  research-notes/lane7-small-witness-20260804-v1/verify_small_witness_packet.py
```

No Macaulay2 or Singular executable is installed on this host, so the CAS
inputs were generated and checked but not executed here.  A retained CAS
result must record the program hash, exact command, toolchain versions,
complete log, exit state, and the matching result marker.

## Exact result boundary

This packet establishes the explicit minor selection and the smooth local
\(\mathbf F_{11}\) witness.  It does not establish the global dimension of
the six-minor saturation over any field, characteristic-zero grade six,
corank-two emptiness, purity, global Pluecker openness, component
decomposition, or a first-normal obstruction.
