#!/usr/bin/env python3
"""Replay the bounded Lane 6 quadratic-target cleanup pilot."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[2]
PROGRAM = (
    ROOT
    / "manuscripts/05-homogeneous-descendants/computational-supplement"
    / "continuation/attack11_target_cleanup.py"
)


def main() -> int:
    run = subprocess.run(
        [sys.executable, str(PROGRAM)],
        cwd=PROGRAM.parent,
        check=False,
        capture_output=True,
        text=True,
    )
    if run.returncode != 0:
        raise AssertionError(f"target-cleanup replay failed:\n{run.stdout}{run.stderr}")
    required = (
        "the exact conjugate has cubic span 6 and quartic span 2",
        "ten low-output quadratic target corrections have independent quartic images",
        "D4_z and D4_c are outside that image",
        "D4_a is uniquely killed by -Y_d^2, which restores cubic span 7",
    )
    if any(marker not in run.stdout for marker in required):
        raise AssertionError("target-cleanup output contract changed")

    result = {
        "schema_version": 1,
        "name": "Lane 6 bounded moving-target pilot",
        "status": "pass",
        "program_sha256": hashlib.sha256(PROGRAM.read_bytes()).hexdigest(),
        "model": (
            "All ten quadratic target corrections in the four exact output "
            "coordinates d,q,h,k of degree at most two."
        ),
        "findings": [
            "The ten quartic images are linearly independent.",
            "D4_z and D4_c are outside their span.",
            "D4_a has the unique correction -Y_d^2.",
            "That correction restores cubic-coordinate span seven.",
        ],
        "stdout": run.stdout.strip().splitlines(),
        "does_not_establish": [
            "the full moving quadratic or cubic target quotient",
            "target operations outside the low-output d,q,h,k model",
            "stable-coordinate invariance",
            "a global 19-to-18 noncompression theorem",
            "a result on the separate residual rational branch of RMU-5C6E0010",
        ],
    }
    canonical = json.dumps(result, sort_keys=True, separators=(",", ":")).encode()
    result["certificate_sha256"] = hashlib.sha256(canonical).hexdigest()
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
