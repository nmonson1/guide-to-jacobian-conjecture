#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
import sympy as sp
from sympy.polys.matrices import DomainMatrix
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import core_model as m
from verify_uniform_middle_stratum import normal,block_solve_components
# Fourteen-parameter base locus on the deepest row stratum.
base_symbols=sp.symbols("s6:20")
base_values={i:z for i,z in zip(range(6,20),base_symbols)}
base_values[2]=sp.Rational(-2)
base_values[0]=4*base_values[19]+sp.Rational(4,3)
S=sum((co*m.row[i] for i,co in base_values.items()),sp.zeros(115,1))
Y0=(m.M0+m.variation(S))[m.base_rows,:]
e25=sp.eye(30)[:,25]
P1=m.solveZ(m.Rvec(e25,Y0))+sp.Rational(32,3)*m.row[0]-4*m.row[1]+8*m.row[2]
# K and fixed tangent-effect data.
K=sp.Matrix.hstack(*[m.projZ(m.Rvec(sp.eye(30)[:,j],Y0)) for j in range(30)])
cp=list(DomainMatrix.from_Matrix(K,fmt='sparse').rref()[1]);rp=list(DomainMatrix.from_Matrix(K.T,fmt='sparse').rref()[1]);nc=[j for j in range(30) if j not in cp];Km=K[rp,cp]
def solveK(rhs):
 co=block_solve_components(Km,rhs[rp,:]);h=sp.zeros(30,rhs.cols)
 for ii,j in enumerate(cp):
  for c in range(rhs.cols):h[j,c]=normal(co[ii,c])
 assert (K*h-rhs).applyfunc(normal)==sp.zeros(K.rows,rhs.cols);return h
def projK(v):
 co=block_solve_components(Km,v[rp,:]);return (v-K[:,cp]*co).applyfunc(normal)
corr=[]
for j in nc:
 dh=sp.eye(30)[:,j];dp=m.solveZ(m.Rvec(dh,Y0));corr.append((f'h{j}',dh,dp))
for j,rj in enumerate(m.row):corr.append((f'row{j}',sp.zeros(30,1),rj))
effect=[projK(m.projZ(m.Rvec(dh,m.Yof(P1))+m.Rvec(e25,m.Yof(dp)))) for _,dh,dp in corr]
active=sorted({i for c in effect for i,e in enumerate(c) if e});E=sp.Matrix([[c[i] for c in effect] for i in active]);assert DomainMatrix.from_Matrix(E,fmt='sparse').rank()==5
# Order two particular.
R2=m.Rvec(e25,m.Yof(P1));H2=solveK(-m.projZ(R2));P2=m.solveZ(m.Rvec(H2,Y0)+R2)
# Cubic compatibility, choose zero coordinates in the 17-dimensional kernel.
Q3=-projK(m.projZ(m.Rvec(H2,m.Yof(P1))+m.Rvec(e25,m.Yof(P2))));rhs3=sp.Matrix([Q3[i] for i in active]);sol3=next(iter(sp.linsolve((E,rhs3))));free3=sorted(set().union(*(e.free_symbols for e in sol3)),key=str);c2=sp.Matrix([normal(e.subs({x:0 for x in free3})) for e in sol3]);assert E*c2==rhs3
for coeff,(_,dh,dp) in zip(c2,corr):
 if coeff:H2+=coeff*dh;P2+=coeff*dp
R3=m.Rvec(H2,m.Yof(P1))+m.Rvec(e25,m.Yof(P2));assert projK(m.projZ(R3))==sp.zeros(m.Z.rows,1)
H3=solveK(-m.projZ(R3));P3=m.solveZ(m.Rvec(H3,Y0)+R3)
# Quartic compatibility, solve the required homogeneous order-three correction.
R4=m.Rvec(H3,m.Yof(P1))+m.Rvec(H2,m.Yof(P2))+m.Rvec(e25,m.Yof(P3));Q4=-projK(m.projZ(R4));assert all(Q4[i]==0 for i in range(Q4.rows) if i not in active);rhs4=sp.Matrix([Q4[i] for i in active]);sol4=next(iter(sp.linsolve((E,rhs4))));free4=sorted(set().union(*(e.free_symbols for e in sol4)),key=str);c3=sp.Matrix([normal(e.subs({x:0 for x in free4})) for e in sol4]);assert E*c3==rhs4
for coeff,(_,dh,dp) in zip(c3,corr):
 if coeff:H3+=coeff*dh;P3+=coeff*dp
assert projK(m.projZ(m.Rvec(H3,m.Yof(P1))+m.Rvec(H2,m.Yof(P2))+m.Rvec(e25,m.Yof(P3))))==sp.zeros(m.Z.rows,1)
# The fourteen-dimensional row subspace invisible to E_(k,y).
Wbasis=[m.row[i] for i in range(6,19)]+[4*m.row[0]+m.row[19]]
assert sp.Matrix.hstack(*Wbasis).rank()==14
assert all(m.Z*w==sp.zeros(m.Z.rows,1) for w in Wbasis)
assert all(m.Rvec(e25,m.Yof(w))==sp.zeros(m.Z.rows,1) for w in Wbasis)
# The closed form inferred from the exact coefficients.
assert H2==e25 and H3==e25
Avec=((4*P2-P3)/3).applyfunc(normal)
Bvec=((P3-P2)/3).applyfunc(normal)
t=sp.symbols('t')
Delta=(t*P1 + t**2/(1-t)*Avec + t**2/(1-4*t)*Bvec).applyfunc(normal)
Hseries=t/(1-t)*e25
res=(m.Z*Delta-m.Rvec(Hseries,Y0+m.Yof(Delta))).applyfunc(normal)
# Clear the expected denominator and verify every coefficient exactly.
cleared=(res*(1-t)**2*(1-4*t)).applyfunc(lambda e:sp.factor(sp.cancel(e)))
assert cleared==sp.zeros(cleared.rows,1)
# Verify first coefficients and recurrence P_n=A+4^(n-2)B.
assert ((Avec+Bvec)-P2).applyfunc(normal)==sp.zeros(115,1)
assert ((Avec+4*Bvec)-P3).applyfunc(normal)==sp.zeros(115,1)
# A fixed active 6-by-6 minor is generically nonzero.  It is enough to
# specialize the fourteen inert base parameters to zero, since the incidence
# identity already holds uniformly over them.
Mcurve=m.M0+m.variation(S+Delta)
minor_det=sp.factor(sp.cancel(Mcurve[m.base_rows,m.pivot_columns].det().subs({z:0 for z in base_symbols})))
expected_minor=sp.factor(6*(12*t**2-5*t+2)*(40448*t**5+18784*t**4-15984*t**3+2896*t**2-721*t+45)/((t-1)*(4*t-1)**2))
assert sp.factor(minor_det-expected_minor)==0
assert normal(minor_det.subs(t,0))==-540
# The transverse normal is genuinely nonzero.
assert Hseries!=sp.zeros(30,1)

def sparse(v):return [{'index':i,'label':m.labels[i],'coefficient':str(normal(e))} for i,e in enumerate(v) if normal(e)!=0]
resj={
 'schema_version':1,
 'name':'Fourteen-parameter family of exact transverse rational rank-six incidence curves',
 'base_row_parameters':{'s2':'-2','s0':'4*s19+4/3','s1=s3=s4=s5':'0','s6,...,s19':'arbitrary'},
 'parameter':'t',
 'excluded_denominators':['1-t','1-4*t'],
 'normal_relation':'H(t)=t/(1-t) E_(k,y)',
 'invisible_row_subspace':{'dimension':14,'basis':['xi_6', 'xi_7', 'xi_8', 'xi_9', 'xi_10', 'xi_11', 'xi_12', 'xi_13', 'xi_14', 'xi_15', 'xi_16', 'xi_17', 'xi_18', '4*xi_0+xi_19'],'property':'Z(W)=0 and E_(k,y)Y(W)=0'},
 'superposition':'Any W-valued rational R(t) regular at t=0 may be added to Delta P(t) without changing the incidence identity.',
 'source_field_curve':'Delta P(t)=t P1 + t^2/(1-t) A + t^2/(1-4t) B',
 'identity':'Z(Delta P(t)) = H(t) (Y0 + Y(Delta P(t)))',
 'clearing_factor':'(1-t)^2(1-4*t)',
 'generic_rank_six_minor':str(minor_det),
 'minor_value_at_t0':'-540',
 'P1':sparse(P1),'A':sparse(Avec),'B':sparse(Bvec),
 'conclusion':'The affine 115-dimensional source-field slice contains an exact rational curve through every base of a 14-dimensional deepest-row subfamily; arbitrary W-valued rational row motion can be superposed whose cubic-coordinate matrix has rank at most six and whose tangent is transverse to the row-killing family.',
 'boundary':'This is a curve of quadratic source-field parameters in the fixed rank-six incidence model. It does not show that the fields integrate to polynomial automorphisms, satisfy the separate compression functional, survive moving target/stable quotients, or produce an 18-variable realization.'
}
payload=json.dumps(resj,sort_keys=True,separators=(',',':')).encode();resj['certificate_sha256']=hashlib.sha256(payload).hexdigest();(HERE/'exact_transverse_rational_curve.json').write_text(json.dumps(resj,indent=2,sort_keys=True)+'\n')
print('P1/A/B nonzero',len(resj['P1']),len(resj['A']),len(resj['B']))
print(json.dumps({k:v for k,v in resj.items() if k not in ('P1','A','B')},indent=2,sort_keys=True))
