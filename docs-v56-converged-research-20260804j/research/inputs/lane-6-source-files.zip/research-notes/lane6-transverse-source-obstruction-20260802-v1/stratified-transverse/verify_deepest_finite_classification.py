#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
import sympy as sp
from sympy.polys.matrices import DomainMatrix
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import core_model as m
from verify_uniform_middle_stratum import normal,block_solve_components,raw_functional,bilinear_matrix,functional_on_HY0
# General deepest-row base.
r,s2=sp.symbols('r s2')
base_extra=sp.symbols('s6:20')
base={2:s2}
for z,i in zip(base_extra,range(6,20)):base[i]=z
base[0]=(12*base[19]-2*s2)/3
S=sum((co*m.row[i] for i,co in base.items()),sp.zeros(115,1))
Y0=(m.M0+m.variation(S))[m.base_rows,:]
h1=sp.zeros(30,1);h1[13]=r;h1[25]=1
N=m.solveZ(m.Rvec(h1,Y0))
# General order-two-compatible first derivative.  The free coordinates span W.
a2=sp.symbols('a2');aextra=sp.symbols('a6:20')
a={2:a2}
for z,i in zip(aextra,range(6,20)):a[i]=z
g=4*s2*r-18*s2+12
a[0]=(g-2*a2+12*a[19])/3
a[1]=-24-s2*(r+30)/3
a[3]=0;a[4]=r;a[5]=0
P1=N+sum((co*m.row[i] for i,co in a.items()),sp.zeros(115,1))
# Incidence map K and exact order-two solve.
K=sp.Matrix.hstack(*[m.projZ(m.Rvec(sp.eye(30)[:,j],Y0)) for j in range(30)])
zero_sub={s2:0,**{z:0 for z in base_extra}}
K0=K.subs(zero_sub)
cp=list(DomainMatrix.from_Matrix(K0,fmt='sparse').rref()[1]);rp=list(DomainMatrix.from_Matrix(K0.T,fmt='sparse').rref()[1]);nc=[j for j in range(30) if j not in cp];A=K[rp,cp]
assert nc==[13,25]
def solveK(rhs):
 co=block_solve_components(A,rhs[rp,:]);h=sp.zeros(30,rhs.cols)
 for ii,j in enumerate(cp):
  for c in range(rhs.cols):h[j,c]=normal(co[ii,c])
 assert (K*h-rhs).applyfunc(normal)==sp.zeros(K.rows,rhs.cols);return h
def projK(v):
 co=block_solve_components(A,v[rp,:]);return (v-K[:,cp]*co).applyfunc(normal)
q2=-m.projZ(m.Rvec(h1,m.Yof(P1)));h2=solveK(q2);p2=m.solveZ(m.Rvec(h2,Y0)+m.Rvec(h1,m.Yof(P1)))
# Complete homogeneous order-two freedom and cubic system.
corr=[]
for j in nc:
 dh=sp.eye(30)[:,j];dp=m.solveZ(m.Rvec(dh,Y0));corr.append((f'h{j}',dh,dp))
for j,rj in enumerate(m.row):corr.append((f'row{j}',sp.zeros(30,1),rj))
base3=projK(m.projZ(m.Rvec(h2,m.Yof(P1))+m.Rvec(h1,m.Yof(p2))))
cols=[projK(m.projZ(m.Rvec(dh,m.Yof(P1))+m.Rvec(h1,m.Yof(dp)))) for _,dh,dp in corr]
active=sorted({i for i,e in enumerate(base3) if e}|{i for c in cols for i,e in enumerate(c) if e})
E=sp.Matrix([[c[i] for c in cols] for i in active]);rhs=sp.Matrix([-base3[i] for i in active])
# Polynomial generic witness: (3/2)[q:adq] + r[k:bds].
wpoly=sp.Matrix([[sp.Rational(3,2) if gi==760 else (r if gi==1361 else 0) for gi in active]])
assert (wpoly*E).applyfunc(normal)==sp.zeros(1,E.cols)
pairpoly=normal((wpoly*rhs)[0]);assert normal(pairpoly-r*(r**2+24*s2+48)/2)==0
# Specialized r=0 witness: (3/2)[k:adq]+[k:bds].
E0=E.subs(r,0);rhs0=rhs.subs(r,0)
w0=sp.Matrix([[sp.Rational(3,2) if gi==1332 else (1 if gi==1361 else 0) for gi in active]])
assert (w0*E0).applyfunc(normal)==sp.zeros(1,E.cols)
pair0=normal((w0*rhs0)[0]);assert normal(pair0-12*(s2+2))==0
# Sparse q-row recurrence for every r != 0.
lam=raw_functional([('q',m.a*m.d*m.y,1)])
mu=raw_functional([('q',m.a*m.d*m.q,1)])
omega=raw_functional([('q',m.a*m.d*m.q,1),('q',m.d**2*m.y,-1)])
ell=raw_functional([('d',m.a*m.x*m.y,-1),('d',m.d**3,sp.Rational(1,2)),('q',m.d**2*m.q,sp.Rational(-1,2)),('h',m.a*m.x**2,sp.Rational(1,2)),('h',m.d**2*m.h,sp.Rational(-1,2))])
for f in (lam,mu,omega,ell):assert functional_on_HY0(f,Y0)==sp.zeros(1,30)
Bl,Bm,Bo,Be=map(bilinear_matrix,(lam,mu,omega,ell))
xc=sp.zeros(1,115);xc[0,77]=1
dc=sp.zeros(1,115);dc[0,10]=1;dc[0,68]=-1;dc[0,80]=-1
bc=sp.zeros(1,115);bc[0,68]=-1;bc[0,78]=1;bc[0,80]=-1
tau=Be[13,:]
assert Bl[13,:]==-xc and all(Bl[i,j]==0 for i in range(30) for j in range(115) if i!=13)
assert Bm[13,:]==dc and all(Bm[i,j]==0 for i in range(30) for j in range(115) if i!=13)
assert Bo[13,:]==bc and all(Bo[i,j]==0 for i in range(30) for j in range(115) if i!=13)
assert all(Be[i,j]==0 for i in range(30) for j in range(115) if i!=13)
assert normal((xc*P1)[0])==0 and normal((dc*P1)[0])==0 and normal((bc*P1)[0])==0
assert normal((tau*P1)[0]-r/2)==0
res={
 'schema_version':1,
 'name':'Deepest-stratum finite-normal cubic/quartic classification',
 'base':'s1=s3=s4=s5=0, gamma=3*s0+2*s2-12*s19=0; all remaining base parameters arbitrary',
 'finite_normal':'H1=r E_(q,y)+E_(k,y)',
 'order_two_first_derivative':{
  'a3':'0','a4':'r','a5':'0','3*a0+2*a2-12*a19':'4*s2*r-18*s2+12','a1':'-24-s2*(r+30)/3','free_subspace':'a2 and a6,...,a19 (dimension 15)'},
 'cubic':{
  'active_rows':active,'generic_polynomial_pairing':'r*(r^2+24*s2+48)/2','for_r_nonzero_obstruction_factor':'(r^2+24*s2+48)/2','r_zero_pairing':'12*(s2+2)'},
 'r_nonzero_quartic_recurrence':[
  'lower lambda/mu/omega equations give x(P1)=d(P1)=b(P1)=x(P2)=b(P2)=0',
  'ell at order two gives rho(P2)=r*tau(P1)=r^2/2',
  'hence d(P2)=r^2/2 and mu at order three gives x(P3)=r^3/2',
  'lambda at order four gives 0=-r*x(P3)=-r^4/2'],
 'only_unresolved_by_these_obstructions':'r=0, s2=-2; its quartic scalar is treated by the residual-curve certificate',
 'boundary':'Pinned 115-dimensional source-field rank-six incidence model only.'}
payload=json.dumps(res,sort_keys=True,separators=(',',':')).encode();res['certificate_sha256']=hashlib.sha256(payload).hexdigest();(HERE/'deepest_finite_classification.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n');print(json.dumps(res,indent=2,sort_keys=True))
