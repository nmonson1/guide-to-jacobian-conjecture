# Lane 6 stratified transverse theorem bundle

This bundle proves an exact stratified theorem for the pinned Program 5
115-dimensional quadratic source-field incidence model.

## Principal result

Every transverse first jet along the exact twenty-dimensional row-killing
family is either:

1. obstructed by parameter order at most four; or
2. contained in the explicitly integrated residual family described by
   `STRATIFIED_TRANSVERSE_CLASSIFICATION.md`.

The residual family has the exact rational parameterization

\[
\Delta P(t)=tP_1+\frac{t^2}{1-t}A+\frac{t^2}{1-4t}B,
\qquad
H(t)=\frac{t}{1-t}E_{k,y},
\]

and satisfies

\[
Z(\Delta P(t))=H(t)(Y_0+Y(\Delta P(t)))
\]

coefficient by coefficient.  A fourteen-dimensional invisible row subspace
may be superposed freely.

The stored quartic compression functional remains identically one on this
curve family.

## Environment

- Python 3.13.5
- SymPy 1.14.0

## Reproduction

Run from this directory:

```bash
python verify_uniform_middle_stratum.py
python verify_deepest_finite_classification.py
python verify_deepest_r0_residual.py
python verify_exact_residual_rational_curve.py
python evaluate_compression_functional_on_curve_family.py
```

The scripts reconstruct the source formulas directly in `core_model.py`; no
network access is required.

## Main files

- `STRATIFIED_TRANSVERSE_CLASSIFICATION.md`: theorem, proof, explicit fields,
  and mathematical boundary.
- `stratified_transverse_theorem_certificate.json`: component hashes and
  headline conclusion.
- `exact_transverse_rational_curve.json`: full sparse coefficients of
  \(P_1,A,B\), exact incidence identity, and generic rank-six minor.
- `curve_family_compression_functional.json`: exact computation
  \(\Lambda_4=1\).

## Boundary

The result concerns the fixed source-field rank-six incidence model.  It does
not classify polynomial automorphisms, the full moving target/stable quotient,
the separate global compression problem, or an eighteen-variable realization.
