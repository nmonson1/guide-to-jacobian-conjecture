#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import sympy as sp
from sympy.polys.matrices import DomainMatrix

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import core_model as m


def normal(e: sp.Expr) -> sp.Expr:
    return sp.factor(sp.cancel(e))


def sparse_support(vec: sp.Matrix) -> list[tuple[int, str]]:
    return [(i, str(normal(e))) for i, e in enumerate(vec) if normal(e) != 0]


def block_solve_components(A: sp.Matrix, b: sp.Matrix) -> sp.Matrix:
    unseen = set(range(A.rows))
    x = sp.zeros(A.cols, b.cols)
    while unseen:
        rows = {unseen.pop()}
        cols: set[int] = set()
        changed = True
        while changed:
            changed = False
            new_cols = {j for i in rows for j in range(A.cols) if A[i, j] != 0}
            if not new_cols <= cols:
                cols |= new_cols
                changed = True
            new_rows = {i for j in cols for i in range(A.rows) if A[i, j] != 0}
            if not new_rows <= rows:
                rows |= new_rows
                unseen -= new_rows
                changed = True
        rr, cc = sorted(rows), sorted(cols)
        Ab = A[rr, cc]
        bb = b[rr, :]
        if all(e == 0 for e in bb):
            continue
        assert Ab.rows == Ab.cols
        sol = Ab.inv() * bb
        for ii, j in enumerate(cc):
            for k in range(b.cols):
                x[j, k] = normal(sol[ii, k])
    return x


def coordinate(row_name: str, monomial: sp.Expr) -> int:
    rr = m.V.index(sp.Symbol(row_name))
    lr = m.selected_rows.index(rr)
    return lr * len(m.cubics) + m.mon_index(monomial)


def raw_functional(entries: list[tuple[str, sp.Expr, sp.Rational]]) -> sp.Matrix:
    out = sp.zeros(1, 5 * len(m.cubics))
    for row_name, monomial, coeff in entries:
        out[0, coordinate(row_name, monomial)] = coeff
    return out


def bilinear_matrix(functional: sp.Matrix) -> sp.Matrix:
    B = sp.zeros(30, 115)
    for hi in range(30):
        zr, ar = divmod(hi, 6)
        for pj, M in enumerate(m.variation_matrices):
            value = 0
            offset = zr * len(m.cubics)
            for c in range(len(m.cubics)):
                fc = functional[0, offset + c]
                if fc and M[m.base_rows[ar], c]:
                    value += fc * M[m.base_rows[ar], c]
            B[hi, pj] = normal(value)
    return B


def functional_on_HY0(functional: sp.Matrix, Y0: sp.Matrix) -> sp.Matrix:
    out = sp.zeros(1, 30)
    for hi in range(30):
        zr, ar = divmod(hi, 6)
        value = 0
        offset = zr * len(m.cubics)
        for c in range(len(m.cubics)):
            if functional[0, offset + c]:
                value += functional[0, offset + c] * Y0[ar, c]
        out[0, hi] = normal(value)
    return out


def main() -> int:
    s = sp.symbols("s0:20")
    alpha = s[5]
    beta = s[1]
    gamma = 3 * s[0] + 2 * s[2] - 12 * s[19]

    S = sp.zeros(115, 1)
    for i in range(20):
        if i not in (3, 4):
            S += s[i] * m.row[i]
    Y0 = (m.M0 + m.variation(S))[m.base_rows, :]

    h1 = sp.zeros(30, 1)
    h1[13] = 1
    N = m.solveZ(m.Rvec(h1, Y0))

    key_ops = {
        "e_y*a*y": 10,
        "e_d*a*d": 68,
        "e_q*a*y": 77,
        "e_q*d*y": 78,
        "e_q*a*q": 80,
        "e_q*a*k": 81,
        "e_z*q*y": 20,
        "e_c*q*y": 51,
        "e_d*b*y": 65,
    }
    assert all(m.labels[i] == name for name, i in key_ops.items())
    assert all(normal(N[i]) == 0 for i in (10, 68, 77, 78, 80))
    assert normal(N[81] + alpha) == 0
    assert normal(N[20]) == 0
    assert normal(N[51] - sp.Rational(1, 3)) == 0
    assert normal(N[65]) == 0

    # Four sparse raw functionals.
    lam = raw_functional([("q", m.a * m.d * m.y, sp.Rational(1))])
    mu = raw_functional([("q", m.a * m.d * m.q, sp.Rational(1))])
    omega = raw_functional([
        ("q", m.a * m.d * m.q, sp.Rational(1)),
        ("q", m.d**2 * m.y, sp.Rational(-1)),
    ])
    adk = raw_functional([("q", m.a * m.d * m.k, sp.Rational(1))])
    bqy = raw_functional([("k", m.b * m.q * m.y, sp.Rational(1))])

    # Exact dual functional ell with ell Z = rho.
    ell = raw_functional([
        ("d", m.a * m.x * m.y, sp.Rational(-1)),
        ("d", m.d**3, sp.Rational(1, 2)),
        ("q", m.d**2 * m.q, sp.Rational(-1, 2)),
        ("h", m.a * m.x**2, sp.Rational(1, 2)),
        ("h", m.d**2 * m.h, sp.Rational(-1, 2)),
    ])
    rho = sp.zeros(1, 115)
    rho[0, 10] = 1
    for i in (68, 78, 80):
        rho[0, i] = -sp.Rational(1, 2)
    assert (ell * m.Z - rho) == sp.zeros(1, 115)

    # Support identities.
    assert lam * m.Z == sp.zeros(1, 115)
    assert omega * m.Z == sp.zeros(1, 115)
    assert adk * m.Z == sp.zeros(1, 115)
    assert bqy * m.Z == sp.zeros(1, 115)
    assert mu * m.Z == sp.eye(1, 115)[:, :] * 0 + sp.Matrix([[1 if j == 77 else 0 for j in range(115)]])

    B_lam = bilinear_matrix(lam)
    B_mu = bilinear_matrix(mu)
    B_omega = bilinear_matrix(omega)
    B_adk = bilinear_matrix(adk)
    B_bqy = bilinear_matrix(bqy)
    B_ell = bilinear_matrix(ell)

    expected_lam = sp.zeros(30, 115); expected_lam[13, 77] = -1
    expected_mu = sp.zeros(30, 115)
    expected_mu[13, 10] = 1; expected_mu[13, 68] = -1; expected_mu[13, 80] = -1
    expected_omega = sp.zeros(30, 115)
    expected_omega[13, 68] = -1; expected_omega[13, 78] = 1; expected_omega[13, 80] = -1
    expected_adk = sp.zeros(30, 115); expected_adk[13, 81] = -1
    expected_bqy = sp.zeros(30, 115)
    expected_bqy[25, 20] = -2; expected_bqy[25, 51] = -1; expected_bqy[25, 65] = -1
    assert B_lam == expected_lam
    assert B_mu == expected_mu
    assert B_omega == expected_omega
    assert B_adk == expected_adk
    assert B_bqy == expected_bqy

    # Functional values on the moving row-family base.
    assert functional_on_HY0(lam, Y0) == sp.zeros(1, 30)
    assert functional_on_HY0(adk, Y0) == sp.zeros(1, 30)
    assert functional_on_HY0(ell, Y0) == sp.zeros(1, 30)
    omega_Y0 = functional_on_HY0(omega, Y0)
    mu_Y0 = functional_on_HY0(mu, Y0)
    bqy_Y0 = functional_on_HY0(bqy, Y0)
    assert normal(omega_Y0[0, 13]) == 0  # s3 was set to zero in S.
    assert normal(mu_Y0[0, 13]) == 0
    assert normal(bqy_Y0[0, 25]) == 0  # s4 was set to zero in S.
    assert all(omega_Y0[0, j] == 0 for j in range(30))
    assert all(mu_Y0[0, j] == 0 for j in range(30))
    assert all(bqy_Y0[0, j] == 0 for j in range(30))

    # Values of the sparse operation covectors on N and the row basis.
    xcov = sp.zeros(1, 115); xcov[0, 77] = 1
    dcov = sp.zeros(1, 115); dcov[0, 10] = 1; dcov[0, 68] = -1; dcov[0, 80] = -1
    bcov = sp.zeros(1, 115); bcov[0, 68] = -1; bcov[0, 78] = 1; bcov[0, 80] = -1
    assert normal((xcov * N)[0]) == 0
    assert normal((dcov * N)[0]) == 0
    assert normal((bcov * N)[0]) == 0
    assert [(j, normal((dcov * r)[0])) for j, r in enumerate(m.row) if normal((dcov * r)[0]) != 0] == [(3, 1)]
    assert [(j, normal((bcov * r)[0])) for j, r in enumerate(m.row) if normal((bcov * r)[0]) != 0] == [(3, 2)]
    assert all(normal((xcov * r)[0]) == 0 for r in m.row)

    ell_N = normal((ell * m.Rvec(h1, m.Yof(N)))[0])
    ell_rows = [normal((ell * m.Rvec(h1, m.Yof(r)))[0]) for r in m.row]
    assert ell_N == 0
    assert [(j, v) for j, v in enumerate(ell_rows) if v != 0] == [(4, sp.Rational(1, 2))]

    # The order-two normal incidence equations after eliminating the 28 fixed
    # pivot H-coordinates. This calculation keeps all eighteen middle-stratum
    # row-base parameters symbolic.
    Kfull = sp.Matrix.hstack(*[m.projZ(m.Rvec(sp.eye(30)[:, j], Y0)) for j in range(30)])
    active = sorted({i for j in range(30) for i, e in enumerate(Kfull[:, j]) if e != 0})
    K = Kfull[active, :]
    K0 = K.subs({x: 0 for x in s})
    cp = list(DomainMatrix.from_Matrix(K0, fmt="sparse").rref()[1])
    rp = list(DomainMatrix.from_Matrix(K0.T, fmt="sparse").rref()[1])
    nc = [j for j in range(30) if j not in cp]
    nr = [i for i in range(K.rows) if i not in rp]
    assert nc == [13, 25]
    A = K[rp, cp]
    B = K[rp, nc]
    C = K[nr, cp]
    D = K[nr, nc]
    X = block_solve_components(A, B)
    Mred = (D - C * X).applyfunc(normal)

    def reduce_forcing(qfull: sp.Matrix) -> sp.Matrix:
        q = qfull[active, :]
        xp = block_solve_components(A, q[rp, :])
        return (q[nr, :] - C * xp).applyfunc(normal)

    qN = reduce_forcing(-m.projZ(m.Rvec(h1, m.Yof(N))))
    q3 = reduce_forcing(-m.projZ(m.Rvec(h1, m.Yof(m.row[3]))))
    q4 = reduce_forcing(-m.projZ(m.Rvec(h1, m.Yof(m.row[4]))))
    a3, a4 = sp.symbols("a3 a4")
    qord2 = (qN + a3 * q3 + a4 * q4).applyfunc(normal)

    # Locate the two reduced normal equations by expression, not by a fragile
    # row number.  The independent a3 equation is the raw omega functional
    # below rather than a row of this secondary Schur reduction.
    eq_first = []
    eq_second = []
    for i in range(Mred.rows):
        m13, m25 = normal(Mred[i, 0]), normal(Mred[i, 1])
        rhs = normal(qord2[i, 0])
        if m13 == 0 and normal(m25 - (beta + 2 * gamma) / 2) == 0 and normal(rhs - (1 + 9 * a3 - a4) / 6) == 0:
            eq_first.append(i)
        if m13 == 0 and normal(m25 - (3 * beta + 4 * gamma) / 6) == 0 and normal(rhs - (1 + 9 * a3 - a4) / 6) == 0:
            eq_second.append(i)
    assert len(eq_first) == len(eq_second) == 1

    # The raw omega equation at order two is exactly 2*a3=0.
    p1_symbolic = N + a3 * m.row[3] + a4 * m.row[4]
    omega_order_two = normal((omega * m.Rvec(h1, m.Yof(p1_symbolic)))[0])
    assert normal(omega_order_two - 2 * a3) == 0

    # q:adk at order two is the pure equation alpha=0.
    assert normal((adk * m.Rvec(h1, m.Yof(N)))[0] - alpha) == 0
    assert all(normal((adk * m.Rvec(h1, m.Yof(r)))[0]) == 0 for r in m.row)

    # On gamma=0, the remaining cubic raw equation is the exact square.
    # From the reduced order-two equations, t=(1-a4)/(3 beta).
    t = sp.symbols("t")
    p1_key = N + a4 * m.row[4]
    combo = normal(-2 * p1_key[20] - p1_key[51] - p1_key[65])
    combo_gamma0 = normal(combo.subs({alpha: 0, gamma: 0}))
    assert normal(combo_gamma0 - (a4 - 1) / 3) == 0
    cubic_square = normal(((1 - a4) / (3 * beta)) * combo_gamma0)
    assert normal(cubic_square + (a4 - 1) ** 2 / (9 * beta)) == 0

    # Formal recurrence certificate. Once lower compatibility forces a3=0 and
    # a4=1, the identities imply x(P3)=1/2 while q:ady at order four requires
    # x(P3)=0.
    recurrence = {
        "order2": {
            "q_adk": "alpha = 0",
            "omega": "a3 = 0",
            "normal_equations": [
                "3*(beta+2*gamma)*t = 1-a4",
                "(3*beta+4*gamma)*t = 1-a4",
            ],
        },
        "gamma_nonzero": "a4 = 1 at order two",
        "gamma_zero_beta_nonzero": "k:b*q*y = -(a4-1)^2/(9*beta), hence a4=1 at order three",
        "deepest_qy_specialization": "at alpha=beta=gamma=0 the two reduced order-two equations directly give a4=1",
        "quartic_chain": [
            "rho(P2)=a4/2",
            "b(P2)=0",
            "d(P2)=rho(P2)+b(P2)/2=a4/2",
            "x(P3)=d(P2)=a4/2",
            "q:a*d*y at order four gives 0=-x(P3)=-1/2",
        ],
    }

    result = {
        "schema_version": 1,
        "name": "Uniform no-transverse-arc theorem on the tangent-excess-one row stratum",
        "source_sha256": "a2ec1fb45cc42b527958f3c881b8a9bb8c0ce093aa553c846806ab868513a2d8",
        "middle_stratum": "s3=s4=0 and (alpha,beta,gamma)!=(0,0,0)",
        "coordinates": {
            "alpha": "s5",
            "beta": "s1",
            "gamma": "3*s0+2*s2-12*s19",
            "normal_H1": "E_(q,y)",
        },
        "exact_dual_functional_ell": {
            "support": [
                ["d:a*x*y", "-1"],
                ["d:d^3", "1/2"],
                ["q:d^2*q", "-1/2"],
                ["h:a*x^2", "1/2"],
                ["h:d^2*h", "-1/2"],
            ],
            "operation_covector": "e_y*a*y - (e_d*a*d + e_q*d*y + e_q*a*q)/2",
        },
        "order_two_reduced_rows": {
            "a3_equation": "raw omega functional gives 2*a3=0",
            "beta_plus_2gamma_row_index": eq_first[0],
            "3beta_plus_4gamma_row_index": eq_second[0],
        },
        "recurrence": recurrence,
        "conclusion": (
            "For every row-family base in the tangent-excess-one stratum, "
            "every first-order transverse formal incidence arc is obstructed "
            "by parameter order at most four. The same q-normal proof extends "
            "to the deepest specialization alpha=beta=gamma=0. If alpha is nonzero it fails at "
            "order two; otherwise lower compatibility forces a4=1, while the "
            "sparse q:a*d*y recurrence gives the contradiction 0=-1/2 at "
            "order four."
        ),
        "boundary": (
            "This is exact in the pinned 115-dimensional source-field "
            "rank-six incidence model. It does not include moving target or "
            "stable-presentation operations, the separate compression "
            "functional, convergence, or the non-q-normal directions in the tangent-excess-two stratum."
        ),
    }
    payload = json.dumps(result, sort_keys=True, separators=(",", ":")).encode()
    result["certificate_sha256"] = hashlib.sha256(payload).hexdigest()
    out = HERE / "uniform_middle_stratum_certificate.json"
    out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
