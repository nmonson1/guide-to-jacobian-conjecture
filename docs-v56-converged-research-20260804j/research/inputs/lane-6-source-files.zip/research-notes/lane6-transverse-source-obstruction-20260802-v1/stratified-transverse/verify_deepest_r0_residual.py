#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,sys,time
from pathlib import Path
import sympy as sp
from sympy.polys.matrices import DomainMatrix
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import core_model as m
from verify_uniform_middle_stratum import raw_functional,bilinear_matrix,functional_on_HY0,normal,block_solve_components
start=time.time()
# General deepest base with s2=-2, gamma=0, and arbitrary s6,...,s19.
zs=sp.symbols('s6:20')
vals={2:sp.Rational(-2)}
for z,i in zip(zs,range(6,20)):vals[i]=z
vals[0]=(12*vals[19]-2*vals[2])/3
S=sum((v*m.row[i] for i,v in vals.items()),sp.zeros(115,1))
Y0=(m.M0+m.variation(S))[m.base_rows,:]
h1=sp.zeros(30,1);h1[25]=1
N1=m.solveZ(m.Rvec(h1,Y0))
# exact independence of canonical first-order lift
assert all(not (set(normal(e).free_symbols)&set(zs)) for e in N1)
afree_names=['a2']+[f'a{i}' for i in range(6,20)]
afree=sp.symbols(' '.join(afree_names))
avals={2:afree[0]}
for z,i in zip(afree[1:],range(6,20)):avals[i]=z
avals[0]=16-sp.Rational(2,3)*avals[2]+4*avals[19]
avals[1]=sp.Rational(-4)
P1=N1+sum((v*m.row[i] for i,v in avals.items()),sp.zeros(115,1))
# K with pivots pinned at zero inert parameters
K=sp.Matrix.hstack(*[m.projZ(m.Rvec(sp.eye(30)[:,j],Y0)) for j in range(30)])
zero_sub={z:0 for z in zs};K0=K.subs(zero_sub)
cp=list(DomainMatrix.from_Matrix(K0,fmt='sparse').rref()[1]);rp=list(DomainMatrix.from_Matrix(K0.T,fmt='sparse').rref()[1]);nc=[j for j in range(30) if j not in cp];A=K[rp,cp]
assert nc==[13,25]
def solveK(rhs):
 co=block_solve_components(A,rhs[rp,:]);h=sp.zeros(30,rhs.cols)
 for ii,j in enumerate(cp):
  for c in range(rhs.cols):h[j,c]=normal(co[ii,c])
 err=(K*h-rhs).applyfunc(normal)
 if any(e!=0 for e in err):raise AssertionError('K solve failed')
 return h
def projectK(v):
 co=block_solve_components(A,v[rp,:]);return (v-K[:,cp]*co).applyfunc(normal)
q2=-m.projZ(m.Rvec(h1,m.Yof(P1)));h2b=solveK(q2);p2b=m.solveZ(m.Rvec(h2b,Y0)+m.Rvec(h1,m.Yof(P1)))
corr=[]
for j in nc:
 dh=sp.eye(30)[:,j];dp=m.solveZ(m.Rvec(dh,Y0));corr.append((f'h{j}',dh,dp))
for j,rj in enumerate(m.row):corr.append((f'row{j}',sp.zeros(30,1),rj))
base3=projectK(m.projZ(m.Rvec(h2b,m.Yof(P1))+m.Rvec(h1,m.Yof(p2b))))
cols3=[projectK(m.projZ(m.Rvec(dh,m.Yof(P1))+m.Rvec(h1,m.Yof(dp)))) for _,dh,dp in corr]
active=sorted({i for i,e in enumerate(base3) if e!=0}|{i for c in cols3 for i,e in enumerate(c) if e!=0})
print('active',active,'elapsed',time.time()-start)
E=sp.Matrix([[c[i] for c in cols3] for i in active]);rhs=sp.Matrix([-base3[i] for i in active])
# psi/sigma/f
psi=raw_functional([('k',m.d**2*m.y,sp.Rational(-1,2)),('k',m.a*m.b*m.c,-1),('k',m.a*m.d*m.q,sp.Rational(3,2)),('k',m.b*m.d*m.s,1)])
assert psi*m.Z==sp.zeros(1,115);assert functional_on_HY0(psi,Y0)==sp.zeros(1,30)
Bpsi=bilinear_matrix(psi);sigma=Bpsi[25,:]
assert all(Bpsi[i,j]==0 for i in range(30) for j in range(115) if i!=25)
valsdual=sigma[:,m.cpZ]*m.invZ;f=sp.zeros(1,m.Z.rows)
for ii,row in enumerate(m.rpZ):f[0,row]=normal(valsdual[0,ii])
assert f*m.Z==sigma;assert functional_on_HY0(f,Y0)==sp.zeros(1,30)
assert normal((sigma*P1)[0])==0
sig2b=normal((sigma*p2b)[0]);sig2cols=[normal((sigma*dp)[0]) for _,_,dp in corr]
assert sig2b==0 and all(e==0 for e in sig2cols)
L0=normal((f*(m.Rvec(h2b,m.Yof(P1))+m.Rvec(h1,m.Yof(p2b))))[0])
l=sp.Matrix([[normal((f*(m.Rvec(dh,m.Yof(P1))+m.Rvec(h1,m.Yof(dp))))[0]) for _,dh,dp in corr]])
# Fixed multiplier from the rational base, indexed by global residual row.
wm={1240:sp.Rational(-18),1243:sp.Rational(3),1332:sp.Rational(19,2),1354:sp.Rational(-6),1396:sp.Rational(6)}
w=sp.Matrix([[wm.get(i,0) for i in active]])
err=(w*E-l).applyfunc(normal)
if any(e!=0 for e in err):
 print('multiplier error',[(corr[i][0],e) for i,e in enumerate(err) if e]);raise AssertionError
constant=normal(L0+(w*rhs)[0])
print('L0',L0,'constant',constant,'elapsed',time.time()-start)
assert normal(constant+12*(afree[0]-8))==0
# Generic rank profile can be checked after zero specialization; exact identities above prove compatibility implication uniformly.
E0=E.subs(zero_sub);r0=rhs.subs(zero_sub)
assert (DomainMatrix.from_Matrix(E0,fmt='sparse').rank(),DomainMatrix.from_Matrix(E0.row_join(r0),fmt='sparse').rank())==(5,5)
res={'schema_version':1,'name':'Uniform classification of the deepest r=0 quartic residual','base':'s2=-2, gamma=s1=s3=s4=s5=0, arbitrary s6,...,s19 (and s0=(12*s19+4)/3); arbitrary 15-dimensional order-two-compatible first-order row fibre','normal_direction':'E_(k,y)','cubic_active_rows':active,'fixed_cubic_row_multiplier':{str(k):str(v) for k,v in wm.items()},'sigma_P1':'0','sigma_P2':'0','sigma_P3':'96-12*a2','conclusion':'Every cubic-compatible correction satisfies sigma(P3)=96-12*a2. Thus order four is impossible unless a2=8; the complete a2=8 residual fibre is integrated by the exact rational-curve certificate.','boundary':'Pinned 115-dimensional source-field incidence model only.'}
payload=json.dumps(res,sort_keys=True,separators=(',',':')).encode();res['certificate_sha256']=hashlib.sha256(payload).hexdigest();(HERE/'deepest_r0_residual_classification.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n');print(json.dumps(res,indent=2,sort_keys=True))
