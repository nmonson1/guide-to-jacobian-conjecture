from __future__ import annotations

from functools import lru_cache
from itertools import combinations_with_replacement
import sympy as sp
from sympy.polys.matrices import DomainMatrix

x,y,z,a,b,c,d,q,s,h,k = sp.symbols('x y z a b c d q s h k')
V = (x,y,z,a,b,c,d,q,s,h,k)
Phi = sp.Matrix([
-a*c-a*d*z-3*a*y**2-2*a*z-c*d**2+d**2*z-d*s+7*d*y**2+s*x*y+3*x*y*z+4*y**2+z,
-b*c-b*d*z-3*b*y**2-2*b*z-3*c*d*x-d*q+q*x*y+12*x*y**2+3*x*z+y,
-h*k-h*x*z+k*x**2-3*x**2*y+2*x,
a-d**2+2*d*x*y,
b+3*x**2*y,
c+x*y*z+3*y**2+2*z,
d-x*y,
b*z+3*c*x+q,
s+a*z+c*x*y-x*y*z-7*y**2+c*d-d*z,
h-x**2,
k+x*z])
zero = {v:0 for v in V}
Lin = Phi.jacobian(V).subs(zero)
Kmap = Lin.inv()*Phi

def hpart(f: sp.Expr, degree: int) -> sp.Expr:
    p=sp.Poly(sp.expand(f),*V)
    return sp.Add(*[
        coeff*sp.prod(v**e for v,e in zip(V,mon))
        for mon,coeff in p.terms() if sum(mon)==degree
    ])
Q=sp.Matrix([hpart(f,2) for f in Kmap])
C=sp.Matrix([hpart(f,3) for f in Kmap])
weights=dict(zip(V,(1,-1,-2,0,1,-2,0,-1,-2,2,-1)))

def wt(mon: sp.Expr) -> int:
    ex=sp.Poly(mon,*V).monoms()[0]
    return sum(ex[i]*weights[V[i]] for i in range(11))

quad=[sp.prod(V[i] for i in I) for I in combinations_with_replacement(range(11),2)]
cubics=[sp.prod(V[i] for i in I) for I in combinations_with_replacement(range(11),3)]
operation_basis=[]
for rr,var in enumerate(V):
    for mon in quad:
        if wt(mon)==weights[var]:
            operation_basis.append((rr,mon))
assert len(operation_basis)==115
labels=[f"e_{V[rr]}*{str(mon).replace('**','^').replace(' ','')}" for rr,mon in operation_basis]

JQ=Q.jacobian(V)
variation_matrices=[]
brackets=[]
for op_row,mon in operation_basis:
    field=sp.zeros(11,1); field[op_row,0]=mon
    bracket=sp.Matrix([sp.expand(e) for e in JQ*field-field.jacobian(V)*Q])
    brackets.append(bracket)
    M=sp.zeros(11,len(cubics))
    for rr,expr in enumerate(bracket):
        poly=sp.Poly(expr,*V)
        for cc,cm in enumerate(cubics):
            val=poly.coeff_monomial(cm)
            if val:
                M[rr,cc]=val
    variation_matrices.append(M)

selected_rows=[3,6,7,9,10]
constraint_rows=[]
for out_row in selected_rows:
    polys=[sp.Poly(br[out_row],*V) for br in brackets]
    for cm in cubics:
        coeffs=[p.coeff_monomial(cm) for p in polys]
        if any(coeffs):
            constraint_rows.append(coeffs)
constraint_matrix=sp.Matrix(constraint_rows)
assert DomainMatrix.from_Matrix(constraint_matrix,fmt='sparse').rank()==95
row_kernel=constraint_matrix.nullspace()
assert len(row_kernel)==20

def variation(vec: sp.Matrix) -> sp.Matrix:
    out=sp.zeros(11,len(cubics))
    for coeff,M in zip(vec,variation_matrices):
        if coeff:
            out += coeff*M
    return out

p0=sp.zeros(115,1)
p0_idx=next(i for i,(rr,mon) in enumerate(operation_basis) if rr==3 and sp.expand(mon-d**2)==0)
p0[p0_idx,0]=-1
M0=sp.zeros(11,len(cubics))
for rr,expr in enumerate(C):
    poly=sp.Poly(expr,*V)
    for cc,cm in enumerate(cubics):
        val=poly.coeff_monomial(cm)
        if val:
            M0[rr,cc]=val
M0 += variation(p0)
assert M0.rank()==6
base_rows=[0,1,2,4,5,8]
zero_rows=[3,6,7,9,10]
base_matrix=M0[base_rows,:]
_,piv=base_matrix.rref(); pivot_columns=list(piv)
assert len(pivot_columns)==6
nonpivot_columns=[j for j in range(len(cubics)) if j not in pivot_columns]
A0=M0[base_rows,pivot_columns]
B0=M0[base_rows,nonpivot_columns]
G0=A0.inv()

def block_from_matrix(M: sp.Matrix) -> dict[str,sp.Matrix]:
    return {
        'A':M[base_rows,pivot_columns],
        'B':M[base_rows,nonpivot_columns],
        'C':M[zero_rows,pivot_columns],
        'D':M[zero_rows,nonpivot_columns],
    }

def flatten(M: sp.Matrix) -> sp.Matrix:
    return sp.Matrix([M[i,j] for i in range(M.rows) for j in range(M.cols)])

ambient_blocks=[block_from_matrix(M) for M in variation_matrices]
L=sp.Matrix.hstack(*[flatten(bl['D']-bl['C']*G0*B0) for bl in ambient_blocks])
assert DomainMatrix.from_Matrix(L,fmt='sparse').rank()==93
rank_kernel=L.nullspace()
assert len(rank_kernel)==22

def extend_basis(base,candidates):
    accepted=list(base)
    rank=sp.Matrix.hstack(*accepted).rank() if accepted else 0
    added=[]
    for cand in candidates:
        trial=sp.Matrix.hstack(*accepted,cand)
        r=trial.rank()
        if r>rank:
            accepted.append(cand); added.append(cand); rank=r
    return accepted,added
adapted,comp=extend_basis(row_kernel,rank_kernel)
assert len(adapted)==22 and len(comp)==2
eta0,eta1=comp
row=row_kernel
theta_u=eta0+row[4]
theta_v=eta1+4*row[0]-24*row[1]-4*row[4]

# Full zero-row map and exact projection/right inverse.
Z=sp.Matrix.hstack(*[
    sp.Matrix([M[i,j] for i in selected_rows for j in range(M.cols)])
    for M in variation_matrices
])
cpZ=list(DomainMatrix.from_Matrix(Z,fmt='sparse').rref()[1])
rpZ=list(DomainMatrix.from_Matrix(Z.T,fmt='sparse').rref()[1])
invZ=Z[rpZ,cpZ].inv()

def projZ(v: sp.Matrix) -> sp.Matrix:
    return (v-Z[:,cpZ]*(invZ*v[rpZ,:])).applyfunc(lambda e:sp.factor(sp.cancel(e)))

def solveZ(v: sp.Matrix) -> sp.Matrix:
    r=projZ(v)
    if any(e!=0 for e in r):
        raise AssertionError('forcing not in zero-row image')
    co=invZ*v[rpZ,:]
    p=sp.zeros(115,v.cols)
    for i,j in enumerate(cpZ):
        for ccol in range(v.cols):
            p[j,ccol]=sp.factor(sp.cancel(co[i,ccol]))
    return p

def Hmat(hv: sp.Matrix) -> sp.Matrix:
    return sp.Matrix(5,6,list(hv))

def Rvec(hv: sp.Matrix, Y: sp.Matrix) -> sp.Matrix:
    return flatten(Hmat(hv)*Y)

def Yof(p: sp.Matrix) -> sp.Matrix:
    return variation(p)[base_rows,:]

def blocks(vec:sp.Matrix)->dict[str,sp.Matrix]:
    return block_from_matrix(variation(vec))

def mon_index(mon: sp.Expr) -> int:
    return next(i for i,m in enumerate(cubics) if sp.expand(m-mon)==0)

def op_index(label: str) -> int:
    return labels.index(label)
