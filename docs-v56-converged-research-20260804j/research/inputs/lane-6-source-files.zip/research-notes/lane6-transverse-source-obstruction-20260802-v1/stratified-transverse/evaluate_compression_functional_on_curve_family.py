#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
import sympy as sp
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import core_model as m
from verify_uniform_middle_stratum import normal
curve=json.load(open(HERE/'exact_transverse_rational_curve.json'))
def loadvec(key):
 v=sp.zeros(115,1)
 for item in curve[key]:v[item['index']]=sp.Rational(item['coefficient'])
 return v
P1,A,B=loadvec('P1'),loadvec('A'),loadvec('B')
t=sp.symbols('t')
base_symbols=sp.symbols("s6:20")
base_values={i:z for i,z in zip(range(6,20),base_symbols)}
base_values[2]=sp.Rational(-2)
base_values[0]=4*base_values[19]+sp.Rational(4,3)
S=sum((co*m.row[i] for i,co in base_values.items()),sp.zeros(115,1))
coeff=m.p0+S+t*P1+t**2/(1-t)*A+t**2/(1-4*t)*B
# Build polynomial vector field.
P=sp.zeros(11,1)
for cc,(rr,mon) in zip(coeff,m.operation_basis):
 if cc:P[rr]+=cc*mon
P=P.applyfunc(lambda e:sp.factor(sp.cancel(e)))
JQ=m.Q.jacobian(m.V)

def D2(F,U,W):
 return sp.Matrix([
  sum(sp.diff(F[i],m.V[j],m.V[l])*U[j]*W[l] for j in range(11) for l in range(11))
  for i in range(11)
 ])
O4=(m.C.jacobian(m.V)*P-P.jacobian(m.V)*m.C
    +sp.Rational(1,2)*D2(m.Q,P,P)
    -P.jacobian(m.V)*(JQ*P-P.jacobian(m.V)*m.Q)
    -sp.Rational(1,2)*D2(P,m.Q,m.Q))
terms=[
(3,m.x**2*m.y**2,1),(3,m.x**2*m.a*m.c,4),(3,m.x**2*m.a*m.s,-sp.Rational(20,3)),
(3,m.x**2*m.q*m.k,9),(3,m.x*m.c*m.h*m.k,3),(3,m.x*m.d**2*m.q,-sp.Rational(1,2)),
(3,m.x*m.s*m.h*m.k,-7),(3,m.y**2*m.a*m.h,sp.Rational(4,3)),
(3,m.y*m.b*m.c*m.h,-sp.Rational(1,2)),(3,m.y*m.d*m.h*m.k,-1),
(3,m.z*m.a**2*m.h,sp.Rational(8,3)),(3,m.a*m.q*m.h*m.k,25),(6,m.d*m.q*m.h*m.k,-2)]
Lambda=0
records=[]
for rr,mon,co in terms:
 val=sp.Poly(sp.together(O4[rr]),*m.V).coeff_monomial(mon)
 val=normal(val)
 records.append({'row':str(m.V[rr]),'monomial':str(mon),'weight':str(co),'coefficient':str(val)})
 Lambda+=co*val
Lambda=normal(Lambda)
print('Lambda=',Lambda)
print('factor numerator',sp.factor(sp.together(Lambda).as_numer_denom()[0]))
print('factor denominator',sp.factor(sp.together(Lambda).as_numer_denom()[1]))
num,den=sp.together(Lambda).as_numer_denom()
roots=sp.factor_list(num,t)[1]
res={'schema_version':1,'name':'Quartic compression functional on the 14-parameter transverse curve family','lambda_expression':str(Lambda),'numerator_factorization':str(sp.factor(num)),'denominator_factorization':str(sp.factor(den)),'numerator_factors':[{'factor':str(f),'multiplicity':mult,'degree':sp.degree(f,t)} for f,mult in roots],'value_at_t0':str(normal(Lambda.subs(t,0))),'term_records':records,'interpretation':'Zeros of the numerator away from the curve poles are exact points where the stored quartic functional vanishes along the rank-six curve. This is not yet the full moving-target/stable compression equation.'}
payload=json.dumps(res,sort_keys=True,separators=(',',':')).encode();res['sha256']=hashlib.sha256(payload).hexdigest();(HERE/'curve_family_compression_functional.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in res.items() if k!='term_records'},indent=2,sort_keys=True))
