# Stratified transverse classification for the Program 5 rank-six source-field model

## Setting

Work over \(\mathbf Q\) with the hash-pinned eleven-variable tensor whose
source SHA-256 is

```text
a2ec1fb45cc42b527958f3c881b8a9bb8c0ce093aa553c846806ab868513a2d8
```

Let \(\mathcal E\cong\mathbf A^{115}\) be the space of weight-preserving
quadratic source fields and put

\[
M(P)=C+[Q,P]\in\operatorname{Mat}_{11\times286}.
\]

Split the rows as

\[
Y=(x,y,z,b,c,s),\qquad Z=(a,d,q,h,k).
\]

The rank-six incidence equations are

\[
Z(P)=H\,Y(P),\qquad H\in\operatorname{Mat}_{5\times6}.
\]

Let \(P_0=-d^2e_a\), and let

\[
\mathcal R=P_0+K_{\rm row}
\]

be the exact twenty-dimensional affine row-killing family.  In the retained
basis \(\xi_0,\ldots,\xi_{19}\), write a point of \(\mathcal R\) as
\(P_0+\sum s_i\xi_i\), and set

\[
\alpha=s_5,\qquad \beta=s_1,\qquad
\gamma=3s_0+2s_2-12s_{19}.
\]

## Theorem

### 1. Tangent stratification

The normal tangent dimension of the rank-at-most-six source-field locus along
\(\mathcal R\) is

\[
\dim T_P-20=
\begin{cases}
0,&(s_3,s_4)\ne(0,0),\\
1,&s_3=s_4=0,\ (\alpha,\beta,\gamma)\ne(0,0,0),\\
2,&s_3=s_4=\alpha=\beta=\gamma=0.
\end{cases}
\]

On the middle stratum the normal tangent is represented by \(E_{q,y}\).  On
the deepest stratum the normal plane is
\(\langle E_{q,y},E_{k,y}\rangle\).

### 2. Middle-stratum transverse rigidity

At every point of the tangent-excess-one stratum, every formal incidence arc
whose first derivative has nonzero normal component is obstructed by parameter
order at most four.

The proof is uniform in all row-family parameters.  It uses the sparse
functionals

\[
\lambda=[q:ady],\qquad
\mu=[q:adq],\qquad
\omega=[q:adq]-[q:d^2y]
\]

and the five-coordinate dual functional

\[
\ell=-[d:axy]+\frac12[d:d^3]-\frac12[q:d^2q]
     +\frac12[h:ax^2]-\frac12[h:d^2h].
\]

Lower compatibility forces the distinguished first-order row coefficient
\(a_4=1\).  The exact recurrence then gives

\[
\rho(P_2)=\frac12,\qquad b(P_2)=0,\qquad
x(P_3)=\frac12,
\]

while the order-four \([q:ady]\) equation requires \(x(P_3)=0\).

The same \(E_{q,y}\) argument remains valid at the deepest specialization.

### 3. Deepest-stratum finite normal directions

Normalize a finite normal direction as

\[
H_1=rE_{q,y}+E_{k,y}.
\]

Second-order compatibility forces

\[
a_3=0,\quad a_4=r,\quad a_5=0,
\]

\[
3a_0+2a_2-12a_{19}=4s_2r-18s_2+12,
\qquad
a_1=-24-\frac{s_2(r+30)}3,
\]

and leaves a fifteen-dimensional row fibre.

For \(r\ne0\), a polynomial cubic left-null witness has pairing

\[
\frac{r(r^2+24s_2+48)}2.
\]

Thus the cubic equation fails unless

\[
r^2+24s_2+48=0.
\]

On this exceptional hypersurface the sparse recurrence gives

\[
x(P_3)=\frac{r^3}{2},
\]

and the order-four \([q:ady]\) equation becomes

\[
0=-r x(P_3)=-\frac{r^4}{2},
\]

which is impossible for \(r\ne0\).

For \(r=0\), the specialized cubic pairing is

\[
12(s_2+2).
\]

Hence the only remaining base locus is \(s_2=-2\).  On that locus the exact
quartic scalar is

\[
96-12a_2.
\]

Consequently all remaining first jets are obstructed at order four unless
\(a_2=8\).

### 4. Exact integration of the residual locus

Define the fourteen-dimensional row subspace

\[
W=\left\langle
\xi_6,\ldots,\xi_{18},\ 4\xi_0+\xi_{19}
\right\rangle.
\]

It satisfies

\[
Z(W)=0,\qquad E_{k,y}Y(W)=0.
\]

Put

\[
P_\dagger=P_0+\frac43\xi_0-2\xi_2.
\]

There are explicit quadratic fields \(P_1,A,B\) such that, for every
\(R_0\in W\) and every \(W\)-valued rational function \(R(t)\) regular at
\(t=0\) with \(R(0)=0\),

\[
P(t)=P_\dagger+R_0+R(t)
+tP_1+\frac{t^2}{1-t}A+\frac{t^2}{1-4t}B
\]

satisfies the exact rational identity

\[
\boxed{
Z(P(t))=\frac{t}{1-t}E_{k,y}Y(P(t)).
}
\]

Therefore

\[
\operatorname{rank}M(P(t))\le6
\]

identically over \(\mathbf Q(t)\).  The tangent has nonzero
\(E_{k,y}\)-normal component, so the curve is genuinely transverse to
\(\mathcal R\).

At the specialization \(R_0=R(t)=0\), the fixed active minor equals

\[
\frac{
6(12t^2-5t+2)
(40448t^5+18784t^4-15984t^3+2896t^2-721t+45)
}{(t-1)(4t-1)^2},
\]

whose value at \(t=0\) is \(-540\).  Hence the rank is generically exactly
six.

This integrates the complete residual first-jet locus: the condition
\(a_2=8\) fixes the non-\(W\) row coordinate, while the other fourteen row
coordinates are precisely the freely superposable \(W\)-directions.

## Explicit fields

With \(e_x,\ldots,e_k\) denoting the output coordinate vectors,

\[
P_\dagger=
-d^2e_a+hk\,e_b
+\frac23(ac+2az+ds-4y^2)e_c
-2xz\,e_q.
\]

The transverse first coefficient is

\[
\begin{aligned}
P_1={}&-2hk\,e_x
+4(-bc-2bz-dq+3xz)e_y\\
&+2(-2ac-4az-2ds+dz+11y^2)e_z
-4d^2e_a\\
&+2(-bd+6dx-2hk)e_b
-\frac43(-4ac-8az-4ds+3dz+7y^2)e_c\\
&-4xy\,e_d
+2(bc+4bz+6cx+4xz)e_q
-4x^2e_h\\
&+\frac13(3bc+4bz-6cx+3dq)e_k.
\end{aligned}
\]

The two tail coefficients are

\[
\begin{aligned}
A={}&6hk\,e_x
+12(bc+2bz+dq-3xz)e_y\\
&+12(ac+2az+ds-4y^2)e_z+12d^2e_a\\
&+12(-2ac-4az-2ds+5y^2)e_c+12xy\,e_d\\
&-12(bz+3cx)e_q+12x^2e_h\\
&+\frac13(-bc-8bz+18cx+3dq)e_k,
\end{aligned}
\]

\[
B=12(-cd-2dz+4y^2)e_z
-12b(a-3d)e_b
-12b(c+s+2z)e_q
+\frac43b(4c+11z)e_k.
\]

## Proof of the rational identity

The coefficient sequences reconstructed from exact lifting satisfy

\[
H_n=E_{k,y}\quad(n\ge1),
\]

and

\[
P_n=A+4^{n-2}B\quad(n\ge2).
\]

Summing gives

\[
H(t)=\frac{t}{1-t}E_{k,y},
\qquad
\Delta P(t)=tP_1+\frac{t^2}{1-t}A+\frac{t^2}{1-4t}B.
\]

Direct exact multiplication verifies

\[
Z(\Delta P(t))-H(t)(Y_0+Y(\Delta P(t)))=0.
\]

The verifier multiplies by \((1-t)^2(1-4t)\) and checks every one of the
\(5\cdot286\) coefficients over \(\mathbf Q[t]\).  The identities
\(Z(W)=0\) and \(E_{k,y}Y(W)=0\) prove the stated superposition property.

## Consequence for Lane 6

The source-field rank-six locus is not transversely rigid along the entire
row-killing family.  Rigidity holds on the middle stratum and on all deepest
normal directions except the explicitly described residual locus, but that
locus contains a large exact rational family.

For the canonical subfamily with \(R(t)=0\), uniformly over every base \(R_0\in W\), the stored quartic compression functional does **not** vanish:

\[
\boxed{\Lambda_4\equiv1.}
\]

Thus the curve is a genuine rank-six construction but not, by itself, a
compression solution.

## Boundary

The theorem is exact only in the pinned 115-dimensional quadratic
source-field incidence model.  It does not prove that the source fields
integrate to polynomial automorphisms, does not impose the full moving-target
or stable-presentation quotient, does not solve the separate compression
functional, and does not establish a global \(19\to18\) realization.
