#!/usr/bin/env python3
"""Construct an elementary-shear decomposition of the residual branch jet.

The mathematical lemma implemented here is:

Every divergence-free homogeneous quadratic vector field P on A^n is a sum
of fields c*v*ell^2 with ell(v)=0.  Each map x -> x+c*v*ell(x)^2 is an
elementary determinant-one polynomial automorphism, with inverse obtained by
changing c to -c.  Hence P is the quadratic jet of a finite product of tame
special polynomial automorphisms.

The verifier applies the constructive proof to the exact divergence-free
residual branch representative over Q(t).
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any

import sympy as sp

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import core_model as m  # noqa: E402


def normal(value: sp.Expr) -> sp.Expr:
    return sp.factor(sp.cancel(value))


def load_vector(payload: dict[str, Any], key: str) -> sp.Matrix:
    vector = sp.zeros(115, 1)
    for item in payload[key]:
        vector[item["index"], 0] = sp.Rational(item["coefficient"])
    return vector


def vector_field(vector: sp.Matrix) -> sp.Matrix:
    result = sp.zeros(11, 1)
    for coefficient, (row, monomial) in zip(vector, m.operation_basis):
        if coefficient:
            result[row, 0] += coefficient * monomial
    return result.applyfunc(normal)


def sparse_coordinate_vector(vector: sp.Matrix) -> dict[str, str]:
    return {
        str(m.V[index]): str(normal(value))
        for index, value in enumerate(vector)
        if normal(value) != 0
    }


def main() -> int:
    curve = json.loads((HERE / "exact_transverse_rational_curve.json").read_text())
    P1, A, B = (load_vector(curve, key) for key in ("P1", "A", "B"))
    t = sp.symbols("t")
    P_dagger = m.p0 + sp.Rational(4, 3) * m.row[0] - 2 * m.row[2]

    coefficients = (
        P_dagger
        - sp.Rational(2, 3) * m.row[12]
        + t * (P1 + sp.Rational(8, 3) * m.row[12])
        + t**2 / (1 - t) * A
        + t**2 / (1 - 4 * t) * (B + 12 * m.row[12] - 12 * m.row[14])
    ).applyfunc(normal)
    field = vector_field(coefficients)
    divergence = normal(sum(sp.diff(field[i], m.V[i]) for i in range(11)))
    if divergence != 0:
        raise AssertionError(f"the adjusted branch is not divergence-free: {divergence}")

    records: list[tuple[sp.Expr, sp.Matrix, sp.Matrix, str]] = []
    remainder = field.copy()

    def add_shear(
        scalar: sp.Expr,
        direction: sp.Matrix,
        linear_form: sp.Matrix,
        label: str,
    ) -> None:
        scalar = normal(scalar)
        if scalar == 0:
            return
        if normal((linear_form.T * direction)[0]) != 0:
            raise AssertionError(f"non-elementary shear in {label}")
        records.append((scalar, direction, linear_form, label))

    # Remove every term x_i*x_j e_i together with its divergence-canceling
    # companion.  The key identity is
    #
    # x_i*x_j e_i - 1/2*x_j^2 e_j
    # = -1/4(e_i+e_j)(x_i-x_j)^2
    #   +1/4(e_i-e_j)(x_i+x_j)^2 +1/2 e_j*x_i^2.
    for i, xi in enumerate(m.V):
        polynomial = sp.Poly(remainder[i], *m.V)
        for j, xj in enumerate(m.V):
            if i == j:
                continue
            coefficient = normal(polynomial.coeff_monomial(xi * xj))
            if coefficient == 0:
                continue
            ei = sp.eye(11)[:, i]
            ej = sp.eye(11)[:, j]
            ell_minus = sp.zeros(11, 1)
            ell_minus[i], ell_minus[j] = 1, -1
            ell_plus = sp.zeros(11, 1)
            ell_plus[i], ell_plus[j] = 1, 1
            ell_i = sp.zeros(11, 1)
            ell_i[i] = 1
            add_shear(-coefficient / 4, ei + ej, ell_minus, f"pair({i},{j})-")
            add_shear(coefficient / 4, ei - ej, ell_plus, f"pair({i},{j})+")
            add_shear(coefficient / 2, ej, ell_i, f"pair({i},{j})0")
            remainder[i] -= coefficient * xi * xj
            remainder[j] += coefficient * sp.Rational(1, 2) * xj**2
            remainder = remainder.applyfunc(normal)

    # Divergence-freeness implies that the remaining i-th component is
    # independent of x_i.  Polarize each remaining mixed monomial.
    for i, xi in enumerate(m.V):
        if sp.Poly(remainder[i], *m.V).degree(xi) > 0:
            raise AssertionError(f"remainder component {i} still depends on its coordinate")

    for i, expression in enumerate(remainder):
        ei = sp.eye(11)[:, i]
        for exponents, coefficient in sp.Poly(expression, *m.V).terms():
            if coefficient == 0:
                continue
            indices: list[int] = []
            for j, exponent in enumerate(exponents):
                indices.extend([j] * exponent)
            if len(indices) != 2 or i in indices:
                raise AssertionError("unexpected residual quadratic monomial")
            j, k = indices
            if j == k:
                ell = sp.zeros(11, 1)
                ell[j] = 1
                add_shear(coefficient, ei, ell, f"monomial({i};{j}^2)")
            else:
                ell_plus = sp.zeros(11, 1)
                ell_plus[j], ell_plus[k] = 1, 1
                ell_minus = sp.zeros(11, 1)
                ell_minus[j], ell_minus[k] = 1, -1
                add_shear(coefficient / 4, ei, ell_plus, f"monomial({i};{j}{k})+")
                add_shear(-coefficient / 4, ei, ell_minus, f"monomial({i};{j}{k})-")

    reconstruction = sp.zeros(11, 1)
    for scalar, direction, linear_form, _ in records:
        ell = (linear_form.T * sp.Matrix(m.V))[0]
        reconstruction += scalar * direction * ell**2
    if (reconstruction - field).applyfunc(normal) != sp.zeros(11, 1):
        raise AssertionError("the shear decomposition does not reconstruct the branch field")

    record_json = [
        {
            "scalar": str(normal(scalar)),
            "direction": sparse_coordinate_vector(direction),
            "linear_form": sparse_coordinate_vector(linear_form),
            "orthogonality": "ell(v)=0",
            "label": label,
        }
        for scalar, direction, linear_form, label in records
    ]
    result = {
        "schema_version": 1,
        "name": "Tame special admissibility of the divergence-free residual branch jet",
        "source_sha256": "a2ec1fb45cc42b527958f3c881b8a9bb8c0ce093aa553c846806ab868513a2d8",
        "branch_poles": ["t=1", "t=1/4"],
        "divergence_free_adjustment": {
            "base": "P_dagger-(2/3)xi_12",
            "linear": "P1+(8/3)xi_12",
            "A": "A",
            "B": "B+12xi_12-12xi_14",
            "verified_divergence": "0",
        },
        "general_lemma": (
            "Every divergence-free homogeneous quadratic vector field is a sum "
            "of c*v*ell^2 with ell(v)=0 and is therefore the quadratic jet of a "
            "finite product of elementary determinant-one polynomial shears."
        ),
        "branch_decomposition": {
            "shear_count": len(records),
            "records": record_json,
            "exact_reconstruction": True,
        },
        "consequence": (
            "For every specialization away from t=1 and t=1/4, and after adding "
            "any divergence-free homogeneous quadratic source field, the resulting "
            "quadratic jet is realizable by a tame special polynomial automorphism."
        ),
        "boundary": (
            "This proves admissibility of the quadratic jet. The higher jets of the "
            "chosen shear product are not asserted to preserve the rank-six incidence "
            "identity without the separate Kuranishi analysis."
        ),
    }
    canonical = json.dumps(result, sort_keys=True, separators=(",", ":")).encode()
    result["certificate_sha256"] = hashlib.sha256(canonical).hexdigest()
    (HERE / "tame_residual_quadratic_jet.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n"
    )
    print(
        json.dumps(
            {
                "divergence": "0",
                "shear_count": len(records),
                "certificate_sha256": result["certificate_sha256"],
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
