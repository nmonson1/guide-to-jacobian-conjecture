#!/usr/bin/env python3
"""Verify the residual rank-six branch modulo full quadratic special-source coupling.

The calculation is exact over Q.  It works with all 726 homogeneous quadratic
source fields in eleven variables, not merely the 115-dimensional weight-zero
slice.  Along the exact residual rational branch it constructs the full space

    W_sp = {w : Z(w)=0, E_(k,y)Y(w)=0, div(w)=0},

proves dim W_sp=60, and verifies that two divergence-cokernel functionals are
unchanged by arbitrary W_sp-valued motion.  The same functionals annihilate
all cubic source homological corrections [Q,U_3] and every divergence-free
quartic target jet.

The target conclusion is in a fixed lower-target gauge: any additional target
automorphism is assumed to have no nonlinear terms below degree four.  Moving
quadratic/cubic target jets and stable variables are not included.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path
from typing import Any

import sympy as sp

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import core_model as m  # noqa: E402


def normal(value: sp.Expr) -> sp.Expr:
    return sp.factor(sp.cancel(value))


def load_core_vector(payload: dict[str, Any], key: str) -> sp.Matrix:
    vector = sp.zeros(115, 1)
    for item in payload[key]:
        vector[item["index"], 0] = sp.Rational(item["coefficient"])
    return vector


# Full 726-dimensional homogeneous quadratic operation basis.
QUADRATICS = [
    sp.prod(m.V[index] for index in indices)
    for indices in itertools.combinations_with_replacement(range(11), 2)
]
FULL_OPERATIONS = [(row, monomial) for row in range(11) for monomial in QUADRATICS]
FULL_OPERATION_WEIGHTS = [
    m.wt(monomial) - m.weights[m.V[row]]
    for row, monomial in FULL_OPERATIONS
]
FULL_INDEX = {
    (row, sp.Poly(monomial, *m.V).monoms()[0]): index
    for index, (row, monomial) in enumerate(FULL_OPERATIONS)
}
CUBIC_EXPONENT_INDEX = {
    sp.Poly(monomial, *m.V).monoms()[0]: index
    for index, monomial in enumerate(m.cubics)
}


def full_from_core(vector: sp.Matrix) -> sp.Matrix:
    result = sp.zeros(726, 1)
    for coefficient, (row, monomial) in zip(vector, m.operation_basis):
        if coefficient:
            exponent = sp.Poly(monomial, *m.V).monoms()[0]
            result[FULL_INDEX[(row, exponent)], 0] = coefficient
    return result


def full_vector_field(vector: sp.Matrix) -> sp.Matrix:
    field = sp.zeros(11, 1)
    for coefficient, (row, monomial) in zip(vector, FULL_OPERATIONS):
        if coefficient:
            field[row, 0] += coefficient * monomial
    return field


def core_vector_field(vector: sp.Matrix) -> sp.Matrix:
    field = sp.zeros(11, 1)
    for coefficient, (row, monomial) in zip(vector, m.operation_basis):
        if coefficient:
            field[row, 0] += coefficient * monomial
    return field


def quartic_forcing(field: sp.Matrix) -> sp.Matrix:
    JQ = m.Q.jacobian(m.V)
    JP = field.jacobian(m.V)
    d2_q_pp = sp.Matrix(
        [(field.T * sp.hessian(m.Q[i], m.V) * field)[0] for i in range(11)]
    )
    d2_p_qq = sp.Matrix(
        [(m.Q.T * sp.hessian(field[i], m.V) * m.Q)[0] for i in range(11)]
    )
    return (
        m.C.jacobian(m.V) * field
        - JP * m.C
        + sp.Rational(1, 2) * d2_q_pp
        - JP * (JQ * field - JP * m.Q)
        - sp.Rational(1, 2) * d2_p_qq
    )


ZERO = {variable: 0 for variable in m.V}


def divergence_squarefree_coefficient(
    field: sp.Matrix,
    variables: tuple[sp.Symbol, sp.Symbol, sp.Symbol],
) -> sp.Expr:
    return normal(
        sum(
            sp.diff(field[i], m.V[i], *variables).subs(ZERO)
            for i in range(11)
        )
    )


def chi_values_from_field(field: sp.Matrix) -> sp.Matrix:
    chi_1 = divergence_squarefree_coefficient(field, (m.b, m.s, m.x))
    chi_0 = (
        divergence_squarefree_coefficient(field, (m.d, m.q, m.x))
        - 2 * divergence_squarefree_coefficient(field, (m.h, m.k, m.y))
    )
    return sp.Matrix([normal(chi_1), normal(chi_0)])


def chi_values(vector: sp.Matrix) -> sp.Matrix:
    return chi_values_from_field(quartic_forcing(full_vector_field(vector)))


def sparse_vector(vector: sp.Matrix) -> list[dict[str, Any]]:
    return [
        {"index": index, "coefficient": str(normal(value))}
        for index, value in enumerate(vector)
        if normal(value) != 0
    ]


def build_full_special_invisible_weight_spaces() -> dict[int, list[sp.Matrix]]:
    """Exact weight-block RREF for Z=0, E_(k,y)Y=0, and div=0."""
    selected_rows = [3, 6, 7, 9, 10]
    weights = sorted(set(FULL_OPERATION_WEIGHTS))
    columns: dict[int, list[dict[tuple[Any, ...], sp.Expr]]] = {
        weight: [] for weight in weights
    }
    global_indices: dict[int, list[int]] = {weight: [] for weight in weights}

    for operation_index, (operation_row, monomial) in enumerate(FULL_OPERATIONS):
        weight = FULL_OPERATION_WEIGHTS[operation_index]
        transport = sp.expand(
            sum(sp.diff(monomial, m.V[j]) * m.Q[j] for j in range(11))
        )

        def bracket_row(output_row: int) -> sp.Expr:
            value = sp.expand(
                sp.diff(m.Q[output_row], m.V[operation_row]) * monomial
            )
            if output_row == operation_row:
                value = sp.expand(value - transport)
            return value

        column: dict[tuple[Any, ...], sp.Expr] = {}
        for local_row, output_row in enumerate(selected_rows):
            polynomial = sp.Poly(bracket_row(output_row), *m.V, domain=sp.QQ)
            for exponent, coefficient in polynomial.terms():
                if coefficient and sum(exponent) == 3:
                    column[("Z", local_row, CUBIC_EXPONENT_INDEX[exponent])] = coefficient

        # E_(k,y)Y(w)=0 is exactly the vanishing of the active y row.
        polynomial = sp.Poly(bracket_row(1), *m.V, domain=sp.QQ)
        for exponent, coefficient in polynomial.terms():
            if coefficient and sum(exponent) == 3:
                column[("Y_y", CUBIC_EXPONENT_INDEX[exponent])] = coefficient

        divergence = sp.diff(monomial, m.V[operation_row])
        if divergence:
            polynomial = sp.Poly(divergence, *m.V, domain=sp.QQ)
            for exponent, coefficient in polynomial.terms():
                if coefficient and sum(exponent) == 1:
                    column[("div", exponent.index(1))] = coefficient

        columns[weight].append(column)
        global_indices[weight].append(operation_index)

    spaces: dict[int, list[sp.Matrix]] = {}
    certificate_weights: dict[str, Any] = {}
    for weight in weights:
        row_keys = sorted(
            set().union(*(column.keys() for column in columns[weight])), key=str
        )
        row_index = {key: index for index, key in enumerate(row_keys)}
        entries: dict[tuple[int, int], sp.Expr] = {}
        for local_column, column in enumerate(columns[weight]):
            for key, coefficient in column.items():
                entries[(row_index[key], local_column)] = coefficient
        matrix = sp.SparseMatrix(
            len(row_keys), len(global_indices[weight]), entries
        )
        reduced, pivots = matrix.rref(simplify=False)
        free_columns = [
            column for column in range(matrix.cols) if column not in pivots
        ]
        basis: list[sp.Matrix] = []
        for free_column in free_columns:
            local_vector = sp.zeros(matrix.cols, 1)
            local_vector[free_column, 0] = 1
            for pivot_row, pivot_column in enumerate(pivots):
                local_vector[pivot_column, 0] = -reduced[pivot_row, free_column]
            vector = sp.zeros(726, 1)
            for local_column, operation_index in enumerate(global_indices[weight]):
                vector[operation_index, 0] = sp.factor(local_vector[local_column, 0])
            basis.append(vector)
        spaces[weight] = basis
        certificate_weights[str(weight)] = {
            "columns": matrix.cols,
            "rows": matrix.rows,
            "rank": len(pivots),
            "nullity": len(basis),
            "basis": [sparse_vector(vector) for vector in basis],
        }

    expected_nullities = {
        -6: 0,
        -5: 0,
        -4: 0,
        -3: 0,
        -2: 3,
        -1: 6,
        0: 12,
        1: 11,
        2: 12,
        3: 8,
        4: 5,
        5: 2,
        6: 1,
    }
    observed = {weight: len(basis) for weight, basis in spaces.items()}
    if observed != expected_nullities:
        raise AssertionError(f"full special invisible weight profile changed: {observed}")
    if sum(observed.values()) != 60:
        raise AssertionError("full special invisible space lost dimension 60")

    weight_certificate = {
        "schema_version": 1,
        "name": "Full 726-dimensional special invisible source space by weight",
        "constraints": [
            "Z(w)=0",
            "E_(k,y)Y(w)=0, equivalently the active y row vanishes",
            "div(w)=0",
        ],
        "operation_dimension": 726,
        "dimension": 60,
        "weights": certificate_weights,
    }
    canonical = json.dumps(
        weight_certificate, sort_keys=True, separators=(",", ":")
    ).encode()
    weight_certificate["certificate_sha256"] = hashlib.sha256(canonical).hexdigest()
    (HERE / "full726_special_invisible_weight_space.json").write_text(
        json.dumps(weight_certificate, indent=2, sort_keys=True) + "\n"
    )
    return spaces


def build_divergence_transport_certificate() -> dict[str, Any]:
    """Compute phi -> Q.grad(phi) on Sym^2 and its two sparse dual classes."""
    cubic_monomials = [
        sp.prod(m.V[index] for index in indices)
        for indices in itertools.combinations_with_replacement(range(11), 3)
    ]
    transport = sp.zeros(len(cubic_monomials), len(QUADRATICS))
    for column, phi in enumerate(QUADRATICS):
        expression = sp.expand(
            sum(m.Q[i] * sp.diff(phi, m.V[i]) for i in range(11))
        )
        polynomial = sp.Poly(expression, *m.V, domain=sp.QQ)
        for row, monomial in enumerate(cubic_monomials):
            coefficient = polynomial.coeff_monomial(monomial)
            if coefficient:
                transport[row, column] = coefficient
    rank = transport.rank()
    if rank != 65 or len(transport.nullspace()) != 1:
        raise AssertionError("the divergence transport map changed")
    kernel_generator = sp.factor(
        sum(
            transport.nullspace()[0][index] * QUADRATICS[index]
            for index in range(len(QUADRATICS))
        )
    )
    if kernel_generator != m.b**2:
        raise AssertionError("the unique quadratic first integral changed")

    index = {monomial: position for position, monomial in enumerate(cubic_monomials)}
    chi_1 = sp.zeros(1, len(cubic_monomials))
    chi_1[0, index[m.b * m.s * m.x]] = 1
    chi_0 = sp.zeros(1, len(cubic_monomials))
    chi_0[0, index[m.d * m.q * m.x]] = 1
    chi_0[0, index[m.h * m.k * m.y]] = -2
    if chi_1 * transport != sp.zeros(1, len(QUADRATICS)):
        raise AssertionError("chi_1 left the transport cokernel")
    if chi_0 * transport != sp.zeros(1, len(QUADRATICS)):
        raise AssertionError("chi_0 left the transport cokernel")
    if sp.Matrix.vstack(chi_1, chi_0).rank() != 2:
        raise AssertionError("the two divergence classes became dependent")

    only_raw_support = []
    for phi in QUADRATICS:
        expression = sp.expand(
            sum(m.Q[i] * sp.diff(phi, m.V[i]) for i in range(11))
        )
        polynomial = sp.Poly(expression, *m.V, domain=sp.QQ)
        dqx = polynomial.coeff_monomial(m.d * m.q * m.x)
        hky = polynomial.coeff_monomial(m.h * m.k * m.y)
        if dqx or hky:
            only_raw_support.append(
                {
                    "phi": str(phi),
                    "dqx": str(dqx),
                    "hky": str(hky),
                    "dqx_minus_2_hky": str(dqx - 2 * hky),
                }
            )
    expected = [
        {
            "phi": "x*y",
            "dqx": "-1",
            "hky": "-1/2",
            "dqx_minus_2_hky": "0",
        }
    ]
    if only_raw_support != expected:
        raise AssertionError("the sparse transport support changed")

    return {
        "domain_dimension": 66,
        "rank": rank,
        "kernel_dimension": 1,
        "kernel_generator": str(kernel_generator),
        "cokernel_dimension": 286 - rank,
        "chi_1": "[b*s*x]",
        "chi_0": "[d*q*x]-2[h*k*y]",
        "two_classes_independent": True,
        "only_nonzero_raw_support_for_chi_0": only_raw_support,
    }


def main() -> int:
    curve = json.loads((HERE / "exact_transverse_rational_curve.json").read_text())
    P1, A, B = (load_core_vector(curve, key) for key in ("P1", "A", "B"))
    t = sp.symbols("t")

    P_dagger = m.p0 + sp.Rational(4, 3) * m.row[0] - 2 * m.row[2]
    xi_12 = m.row[12]
    xi_14 = m.row[14]
    core_branch = (
        P_dagger
        - sp.Rational(2, 3) * xi_12
        + t * (P1 + sp.Rational(8, 3) * xi_12)
        + t**2 / (1 - t) * A
        + t**2 / (1 - 4 * t) * (B + 12 * xi_12 - 12 * xi_14)
    ).applyfunc(normal)
    # The divergence correction lies in the exact invisible W-space and
    # therefore preserves the rational E_(k,y) incidence identity.
    original_core_branch = (
        P_dagger
        + t * P1
        + t**2 / (1 - t) * A
        + t**2 / (1 - 4 * t) * B
    ).applyfunc(normal)
    divergence_correction = (core_branch - original_core_branch).applyfunc(normal)
    e_ky = sp.zeros(30, 1)
    e_ky[25, 0] = 1
    if m.Z * divergence_correction != sp.zeros(m.Z.rows, 1):
        raise AssertionError("the divergence correction left the row-killing kernel")
    if m.Rvec(e_ky, m.Yof(divergence_correction)) != sp.zeros(m.Z.rows, 1):
        raise AssertionError("the divergence correction changed E_(k,y)Y")

    branch_field = core_vector_field(core_branch)
    branch_divergence = normal(
        sum(sp.diff(branch_field[i], m.V[i]) for i in range(11))
    )
    if branch_divergence != 0:
        raise AssertionError("the adjusted residual branch is not divergence-free")

    branch = full_from_core(core_branch)
    branch_values = chi_values(branch)
    chi_1 = normal(branch_values[0])
    chi_0 = normal(branch_values[1])
    expected_1 = 12 * t**2 / (4 * t - 1)
    expected_0 = -(
        336 * t**3 - 392 * t**2 + 71 * t - 12
    ) / ((t - 1) * (4 * t - 1))
    if normal(chi_1 - expected_1) or normal(chi_0 - expected_0):
        raise AssertionError("the residual branch divergence obstruction changed")

    # A polynomial Bezout certificate for the unit ideal generated by the
    # denominator-cleared obstruction values.
    cleared_1 = normal((4 * t - 1) * chi_1)
    cleared_0 = normal((t - 1) * (4 * t - 1) * chi_0)
    bezout_1 = 23856 * t**2 - 23800 * t + 337
    bezout_0 = 852 * t + 144
    bezout_value = sp.expand(bezout_1 * cleared_1 + bezout_0 * cleared_0)
    if bezout_value != 1728:
        raise AssertionError("the obstruction unit certificate changed")

    divergence_Q = normal(sum(sp.diff(m.Q[i], m.V[i]) for i in range(11)))
    if divergence_Q != 0:
        raise AssertionError("Q is no longer divergence-free")
    print("[stage] divergence transport", flush=True)
    transport_certificate = build_divergence_transport_certificate()
    print("[stage] full exact weight spaces", flush=True)
    spaces = build_full_special_invisible_weight_spaces()
    print("[stage] obstruction polarizations", flush=True)

    # Grading reduces all possible weight-zero quadratic contributions to:
    # branch x W_0, Sym^2(W_0), W_-1 x W_1, and W_-2 x W_2.
    # A homogeneous source vector of nonzero weight has O4-weights w and 2w,
    # so a weight-zero coefficient functional vanishes on it automatically.
    # Only W_0 needs direct pure evaluation.
    pure_values: dict[int, list[sp.Matrix]] = {
        weight: [sp.zeros(2, 1) for _ in basis]
        for weight, basis in spaces.items()
    }
    pure_values[0] = [chi_values(vector) for vector in spaces[0]]
    if any(any(value != 0 for value in values) for values in pure_values[0]):
        raise AssertionError("a weight-zero pure source value survived")

    checks = {"branch_W0": 0, "W0_W0": 0, "Wm1_Wp1": 0, "Wm2_Wp2": 0}
    for index, vector in enumerate(spaces[0]):
        cross = (
            chi_values(branch + vector)
            - branch_values
            - pure_values[0][index]
        ).applyfunc(normal)
        if cross != sp.zeros(2, 1):
            raise AssertionError(f"branch-W0 polarization survived at index {index}")
        checks["branch_W0"] += 1

    for left, right in itertools.combinations_with_replacement(
        range(len(spaces[0])), 2
    ):
        cross = (
            chi_values(spaces[0][left] + spaces[0][right])
            - pure_values[0][left]
            - pure_values[0][right]
        ).applyfunc(normal)
        if cross != sp.zeros(2, 1):
            raise AssertionError(f"W0-W0 polarization survived at {left},{right}")
        checks["W0_W0"] += 1

    for negative, positive, key in [
        (-1, 1, "Wm1_Wp1"),
        (-2, 2, "Wm2_Wp2"),
    ]:
        for left, left_vector in enumerate(spaces[negative]):
            for right, right_vector in enumerate(spaces[positive]):
                cross = (
                    chi_values(left_vector + right_vector)
                    - pure_values[negative][left]
                    - pure_values[positive][right]
                ).applyfunc(normal)
                if cross != sp.zeros(2, 1):
                    raise AssertionError(
                        f"opposite-weight polarization survived at {negative}:{left}, {positive}:{right}"
                    )
                checks[key] += 1

    if checks != {
        "branch_W0": 12,
        "W0_W0": 78,
        "Wm1_Wp1": 66,
        "Wm2_Wp2": 36,
    }:
        raise AssertionError(f"unexpected polarization ledger: {checks}")

    result = {
        "schema_version": 1,
        "name": "Residual rank-six branch: full quadratic special-source and quartic target obstruction",
        "source_sha256": "a2ec1fb45cc42b527958f3c881b8a9bb8c0ce093aa553c846806ab868513a2d8",
        "branch_parameter": "t",
        "branch_poles": ["t=1", "t=1/4"],
        "divergence_free_adjustment": {
            "base": "P_dagger-(2/3)xi_12",
            "linear": "P1+(8/3)xi_12",
            "A": "A",
            "B": "B+12xi_12-12xi_14",
            "divergence": "0",
        },
        "obstruction_quotient": {
            "description": "Sym^3(V*)/(Q.grad)Sym^2(V*) after quotienting cubic source corrections and divergence-free quartic target jets by divergence",
            **transport_certificate,
        },
        "functionals_on_quartic_vector_fields": {
            "chi_1": "[b*s*x] div(R)",
            "chi_0": "([d*q*x]-2[h*k*y]) div(R)",
        },
        "branch_values": {
            "chi_1": str(chi_1),
            "chi_0": str(chi_0),
            "cleared_chi_1": str(cleared_1),
            "cleared_chi_0": str(cleared_0),
            "bezout_identity": (
                "(23856*t^2-23800*t+337)*cleared_chi_1 + "
                "(852*t+144)*cleared_chi_0 = 1728"
            ),
            "unit_value": str(bezout_value),
            "common_zero_away_from_poles": False,
        },
        "full_quadratic_special_source_coupling": {
            "ambient_dimension": 726,
            "constraints": [
                "Z(w)=0",
                "E_(k,y)Y(w)=0",
                "div(w)=0",
            ],
            "dimension": 60,
            "weight_dimensions": {
                str(weight): len(basis) for weight, basis in spaces.items()
            },
            "polarization_checks": checks,
            "obstruction_values_invariant": True,
        },
        "cubic_source_corrections": {
            "identity": "div(JQ*U3-JU3*Q)=-Q.grad(div(U3)) because div(Q)=0",
            "annihilated_by_chi_0_and_chi_1": True,
        },
        "quartic_target_corrections": {
            "gauge_hypothesis": "additional target automorphism has no nonlinear terms below degree four",
            "constraint": "its quartic jet T4 has div(T4)=0",
            "annihilated_by_chi_0_and_chi_1": True,
        },
        "theorem": (
            "For every t away from 1 and 1/4, and after arbitrary motion in the full "
            "60-dimensional special quadratic source space preserving the exact E_(k,y) "
            "incidence relation, the quartic obstruction survives every cubic source "
            "correction and every additional divergence-free quartic target jet."
        ),
        "boundary": (
            "Moving quadratic or cubic target jets can alter the lower normal form and are "
            "not included. Stabilization can absorb divergence in new coordinates, so this "
            "certificate is not a stable obstruction."
        ),
    }
    canonical = json.dumps(result, sort_keys=True, separators=(",", ":")).encode()
    result["certificate_sha256"] = hashlib.sha256(canonical).hexdigest()
    (HERE / "residual_full_source_target_obstruction.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n"
    )
    print(
        json.dumps(
            {
                "chi_1": str(chi_1),
                "chi_0": str(chi_0),
                "unit_value": str(bezout_value),
                "full_source_dimension": 60,
                "polarization_checks": checks,
                "certificate_sha256": result["certificate_sha256"],
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
