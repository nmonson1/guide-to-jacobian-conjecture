# A tame, full-quadratic source-coupled quartic obstruction on the residual rank-six branch

## Setting

Work over \(\mathbf Q\) with the pinned eleven-variable Keller map

\[
F=X+Q+C
\]

whose public source has SHA-256

```text
a2ec1fb45cc42b527958f3c881b8a9bb8c0ce093aa553c846806ab868513a2d8
```

and with the complete space

\[
\mathcal E_2=V\otimes\operatorname{Sym}^2(V^*)
\]

of homogeneous quadratic source fields.  Thus \(\dim\mathcal E_2=11\binom{12}{2}=726\).
For \(P\in\mathcal E_2\), the cubic change in the conjugacy normal form is

\[
C_P=C+[Q,P],
\qquad
[Q,P]=JQ\,P-JP\,Q.
\]

Split the cubic-coordinate matrix into the six active rows

\[
Y=(x,y,z,b,c,s)
\]

and the five normal rows

\[
Z=(a,d,q,h,k).
\]

The preceding transverse-classification theorem produced an exact rational
rank-six branch satisfying

\[
Z(P(t))=\frac{t}{1-t}E_{k,y}Y(P(t)).
\]

The present theorem addresses two defects left open there:

1. whether this branch is compatible with actual polynomial source
   automorphisms at quadratic order; and
2. whether its quartic obstruction survives source coupling beyond the
   115-dimensional weight-zero slice and survives an arbitrary quartic target
   correction after the lower target jets have been fixed.

## Divergence-free representative

Let \(P_\dagger,P_1,A,B\) be the exact fields in the rational-curve
certificate.  In the retained row basis \(\xi_0,\ldots,\xi_{19}\), set

\[
\begin{aligned}
P^{\mathrm{sp}}(t)={}&P_\dagger-\frac23\xi_{12}
+t\left(P_1+\frac83\xi_{12}\right)
+\frac{t^2}{1-t}A\\
&+\frac{t^2}{1-4t}
  \left(B+12\xi_{12}-12\xi_{14}\right).
\end{aligned}
\]

The difference from the original branch is an invisible row-killing motion:

\[
Z(\Delta P)=0,
\qquad
E_{k,y}Y(\Delta P)=0.
\]

Hence the exact rank-six incidence identity is unchanged.  Direct
calculation gives

\[
\operatorname{div}P^{\mathrm{sp}}(t)=0.
\]

## Lemma: every divergence-free quadratic jet is tame

Let \(P\) be a homogeneous quadratic vector field on \(\mathbf A^n\) with
\(\operatorname{div}P=0\).  Then

\[
P=\sum_j c_jv_j\ell_j^2,
\qquad
\ell_j(v_j)=0.
\]

Each summand is the quadratic jet of the elementary shear

\[
x\longmapsto x+c_jv_j\ell_j(x)^2,
\]

whose inverse is obtained by replacing \(c_j\) by \(-c_j\).  Therefore \(P\)
is the quadratic jet of a finite product of tame determinant-one polynomial
automorphisms.

### Proof

For \(i\ne j\), pair every term \(b_{ij}x_ix_je_i\) with the companion forced
by divergence-freeness.  The elementary identity

\[
\begin{aligned}
x_ix_je_i-\frac12x_j^2e_j
={}&-\frac14(e_i+e_j)(x_i-x_j)^2\\
&+\frac14(e_i-e_j)(x_i+x_j)^2
 +\frac12e_jx_i^2
\end{aligned}
\]

expresses that pair as three required shears.  After all such terms are
removed, the \(i\)-th component is independent of \(x_i\).  Every remaining
mixed monomial is polarized by

\[
x_jx_k=\frac14\big((x_j+x_k)^2-(x_j-x_k)^2\big),
\]

and every square already has the required form.  The verifier implements this
construction and reconstructs \(P^{\mathrm{sp}}(t)\) from 71 exact shear
terms.

## The full special invisible source space

Define

\[
\mathcal W_{\mathrm{sp}}
=
\left\{
W\in\mathcal E_2:
Z(W)=0,
\ E_{k,y}Y(W)=0,
\ \operatorname{div}W=0
\right\}.
\]

The first two equations ensure that adding \(W\) preserves the exact incidence
identity; the third is the first-jet condition for a special polynomial
automorphism.  Exact weight-block row reduction gives

\[
\boxed{\dim\mathcal W_{\mathrm{sp}}=60.}
\]

Its dimensions by operation weight are

\[
\begin{array}{c|rrrrrrrrrrrrr}
w&-6&-5&-4&-3&-2&-1&0&1&2&3&4&5&6\\
\hline
\dim(\mathcal W_{\mathrm{sp}})_w
&0&0&0&0&3&6&12&11&12&8&5&2&1.
\end{array}
\]

By the lemma, every point of

\[
P^{\mathrm{sp}}(t)+\mathcal W_{\mathrm{sp}}
\]

is an admissible quadratic jet of a tame special polynomial source
automorphism.

## The divergence obstruction quotient

For a quadratic source field \(P\), let \(\mathcal O_4(P)\) be the exact
quartic conjugacy forcing

\[
\begin{aligned}
\mathcal O_4(P)={}&JC\,P-JP\,C
+\frac12D^2Q(P,P)\\
&-JP\big(JQ\,P-JP\,Q\big)
-\frac12D^2P(Q,Q).
\end{aligned}
\]

An arbitrary cubic source correction \(U_3\) changes the quartic term by
\([Q,U_3]\).  Since \(\operatorname{div}Q=0\),

\[
\operatorname{div}[Q,U_3]
=-Q\cdot\nabla(\operatorname{div}U_3).
\]

An additional target automorphism whose first nonlinear term is a homogeneous
quartic field \(T_4\) satisfies

\[
\operatorname{div}T_4=0.
\]

Consequently divergence maps the source/target quartic quotient to

\[
\mathcal H_Q
=
\frac{\operatorname{Sym}^3(V^*)}
     {(Q\cdot\nabla)\operatorname{Sym}^2(V^*)}.
\]

The transport map

\[
(Q\cdot\nabla):\operatorname{Sym}^2(V^*)
\longrightarrow\operatorname{Sym}^3(V^*)
\]

has exact rank \(65\), one-dimensional kernel \(\langle b^2\rangle\), and
cokernel dimension \(221\).

Define two dual classes on cubic polynomials by

\[
\chi_1=[bsx],
\qquad
\chi_0=[dqx]-2[hky].
\]

Both annihilate \((Q\cdot\nabla)\operatorname{Sym}^2(V^*)\).  The second
identity has a particularly sparse audit: the only quadratic monomial whose
transport has a nonzero \(dqx\) or \(hky\) coefficient is \(xy\), and

\[
[dqx](Q\cdot\nabla(xy))=-1,
\qquad
[hky](Q\cdot\nabla(xy))=-\frac12.
\]

For a quartic vector field \(R\), use the corresponding divergence
functionals

\[
\widehat\chi_1(R)=[bsx]\operatorname{div}R,
\qquad
\widehat\chi_0(R)=([dqx]-2[hky])\operatorname{div}R.
\]

They annihilate every cubic source correction and every divergence-free
quartic target correction.

## Exact values on the branch

For \(P^{\mathrm{sp}}(t)\),

\[
\boxed{
\widehat\chi_1(\mathcal O_4)
=\frac{12t^2}{4t-1},
}
\]

and

\[
\boxed{
\widehat\chi_0(\mathcal O_4)
=-\frac{336t^3-392t^2+71t-12}
        {(t-1)(4t-1)}.
}
\]

The denominator-cleared values generate the unit ideal.  Explicitly,

\[
\begin{aligned}
&(23856t^2-23800t+337)
 (4t-1)\widehat\chi_1(\mathcal O_4)\\
&\quad +(852t+144)(t-1)(4t-1)
 \widehat\chi_0(\mathcal O_4)
=1728.
\end{aligned}
\]

Thus the two obstruction classes never vanish simultaneously anywhere the
rational branch is defined.

## Uniformity under all 60 source directions

The functionals have weight zero, while \(\mathcal O_4\) is linear plus
quadratic in its source field.  Hence only the following polarizations can
contribute:

\[
P^{\mathrm{sp}}\times(\mathcal W_{\mathrm{sp}})_0,
\quad
\operatorname{Sym}^2(\mathcal W_{\mathrm{sp}})_0,
\quad
(\mathcal W_{\mathrm{sp}})_{-1}\times
(\mathcal W_{\mathrm{sp}})_1,
\quad
(\mathcal W_{\mathrm{sp}})_{-2}\times
(\mathcal W_{\mathrm{sp}})_2.
\]

The exact verifier checks respectively

\[
12,\ 78,\ 66,\ 36
\]

polarizations.  Every value is zero.  All remaining weight combinations
vanish formally by grading.  Therefore

\[
\widehat\chi_i\big(\mathcal O_4(P^{\mathrm{sp}}(t)+W)\big)
=
\widehat\chi_i\big(\mathcal O_4(P^{\mathrm{sp}}(t))\big)
\]

for \(i=0,1\) and every \(W\in\mathcal W_{\mathrm{sp}}\), including
parameter-dependent \(W\).

## Theorem

Let \(t\ne1,\frac14\), and let
\(W(t)\in\mathcal W_{\mathrm{sp}}\otimes\mathbf Q(t)\).  Then:

1. \(P^{\mathrm{sp}}(t)+W(t)\) preserves the exact rational rank-six
   incidence identity;
2. it is the quadratic jet of a tame special polynomial source automorphism;
3. for every cubic source correction \(U_3\) and every divergence-free
   quartic target jet \(T_4\),

   \[
   \mathcal O_4(P^{\mathrm{sp}}(t)+W(t))+[Q,U_3]+T_4\ne0.
   \]

Equivalently, the residual branch is uniformly obstructed at quartic order in
the quotient by the complete 60-dimensional special quadratic source
coupling, arbitrary cubic source corrections, and arbitrary additional
quartic target automorphisms in the fixed lower-target gauge.

## Boundary

This theorem is exact but not stable or global.

- Moving quadratic or cubic target jets can change the lower normal form and
  are not included.
- Adding stable variables can absorb divergence in new coordinates, so the
  two classes are not stable invariants.
- The result concerns the pinned eleven-variable conjugacy/incidence model; it
  does not prove a global \(19\to18\) noncompression theorem.

The theorem nevertheless closes the principal admissibility gap on the exact
residual branch and enlarges the source coupling from the 115-dimensional
weight-zero model to all 726 quadratic fields, with a complete exact
60-dimensional special invisible coupling space.
