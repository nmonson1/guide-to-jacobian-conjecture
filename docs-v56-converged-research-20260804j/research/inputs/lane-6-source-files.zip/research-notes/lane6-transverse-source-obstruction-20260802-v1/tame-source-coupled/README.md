# Lane 6 residual-branch source/target obstruction bundle

Run from this directory with Python and SymPy:

```bash
python verify_exact_residual_rational_curve.py
python verify_tame_quadratic_jet.py
python verify_residual_source_target_obstruction.py
```

The first verifier is inherited from the preceding stratified-transverse
bundle.  The second constructs an exact elementary-shear decomposition of the
divergence-free residual quadratic jet.  The third reconstructs all 726
quadratic source operations, computes the exact 60-dimensional special
invisible coupling space, and verifies the two-function unit obstruction.

Main statement: `TAME_SOURCE_COUPLED_QUARTIC_OBSTRUCTION.md`.

The fixed-lower-target and non-stable boundaries are part of the theorem.
