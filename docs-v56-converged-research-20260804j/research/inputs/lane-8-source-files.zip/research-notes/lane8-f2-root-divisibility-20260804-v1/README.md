# Exact root-divisibility coordinates for the F2 linear descent

Date: 2026-08-04

Scope: an exact replacement for the inherited **linear** coefficient-relation
stage of the denominator-five (F_2) shear.  This packet does not solve the
subsequent nonlinear or support-stratification problems.

## Result

Fix a characteristic-zero coefficient field (K), a nonzero shear parameter
(lambda), and write

\[
c=\lambda^5.
\]

The (586) source coefficients of (P) split into (76) independent
weight blocks.  Terminal admissibility removes (53) Taylor coordinates,
and the resulting source incidence space has dimension (533).  The (1,576)
source coefficients of (Q) split into (126) blocks; (136) Taylor
coordinates are removed and the incidence space has dimension (1,440).

Every block has the explicit form

\[
 C_w(Y)=Y^{j_0}(Y^5-c)^{F_w}E_w(Y^5),
 \qquad \deg E_w<n_w-F_w.
\tag{1}
\]

Here (w=5i-j), the source degrees are
(j_0,j_0+5,\ldots,j_0+5(n_w-1)), and

\[
 F_w=\max\!\left(0,
 \min\!\left(j_{\max}+1,
 \left\lceil\frac{5w-t}{12}\right\rceil\right)\right),
 \qquad
 t=\begin{cases}3&P,\\5&Q.\end{cases}
\tag{2}
\]

Consequently the exact inherited linear descent locus is an affine linear
space with

\[
533+1,440=\boxed{1,973}
\]

coordinates.  Its image in the (4,433+12,340) terminal-allowed output
coordinates has codimension

\[
(4,433-533)+(12,340-1,440)=\boxed{14,800}.
\]

Thus the linear stage does not require a (14,800)-row relation matrix.
The versioned [block manifest](block_manifest.json) gives all (202) blocks,
including (j_0,n_w,F_w), the free dimension, pivot interval, and derived
output interval.

## Proof

### 1. Weight-block form of the source

For (P), the exact source envelope is

\[
0\le i\le15,\qquad 0\le j\le60,\qquad5i-j\le15;
\]

for (Q), it is

\[
0\le i\le25,\qquad0\le j\le100,\qquad5i-j\le25.
\]

At fixed (w=5i-j), the possible (j)'s form one consecutive arithmetic
progression of step five.  Therefore, if (c_{i,j}) denotes the corresponding
source coefficient,

\[
C_w(Y)=\sum_{5i-j=w}c_{i,j}Y^j=Y^{j_0}H_w(Y^5),
\qquad \deg H_w<n_w.
\tag{3}
\]

Direct enumeration gives (76) blocks and (586) coefficients for (P),
and (126) blocks and (1,576) coefficients for (Q).

### 2. The forbidden terminal coordinates are one Taylor jet

Under

\[
y\longmapsto y+\lambda x^{-1/5},
\]

the output polynomial in the fixed block is

\[
D_w(T)=C_w(T+\lambda).
\tag{4}
\]

Indeed its coefficient of (T^J) is

\[
d_{w,J}=\sum_{\substack{5i-j=w\\j\ge J}}
\binom jJ\lambda^{j-J}c_{i,j}.
\]

The terminal inequalities are (5w-12J\le3) for (P) and
(5w-12J\le5) for (Q).  Hence the forbidden output degrees in the block
are exactly the initial interval

\[
J=0,\ldots,F_w-1,
\]

with (F_w) as in (2).  Their vanishing is equivalent to

\[
T^{F_w}\mid D_w(T)
\quad\Longleftrightarrow\quad
(Y-\lambda)^{F_w}\mid C_w(Y).
\tag{5}
\]

Since (lambda\ne0), the derivative of (Y\mapsto Y^5) at (lambda)
is (5\lambda^4\ne0), and the factor (Y^{j_0}) in (3) is a unit in the
local ring at (Y=\lambda).  Thus

\[
\operatorname{ord}_{Y=\lambda}C_w(Y)
=\operatorname{ord}_{u=c}H_w(u).
\]

Equation (5) is therefore equivalent to

\[
H_w(u)=(u-c)^{F_w}E_w(u),
\qquad\deg E_w<n_w-F_w,
\]

which proves (1) and the block dimension (n_w-F_w).

### 3. Full row rank without elimination

At (lambda=1), the forbidden Taylor matrix is

\[
\left[\binom{j_k}{J}\right]_{
0\le J<F_w,\ 0\le k<n_w}.
\]

Its first (F_w) columns have determinant

\[
\det\left[\binom{j_k}{J}\right]_{0\le J,k<F_w}
=\frac{\prod_{0\le r<s<F_w}(j_s-j_r)}
{\prod_{J=0}^{F_w-1}J!}\ne0.
\tag{6}
\]

For general nonzero (lambda), row and column powers of (lambda) are
invertible, so the rank is unchanged.  The checker verifies (6) exactly in
each of the (39) blocks with (F_w>0), rather than relying only on a total
rank count.

### 4. Triangular coordinates and inverse

Expand

\[
E_w(u)=\sum_{k=0}^{n_w-F_w-1}e_{w,k}(u-c)^k.
\]

Then

\[
D_w(T)=(T+\lambda)^{j_0}
\sum_k e_{w,k}
\left((T+\lambda)^5-\lambda^5\right)^{F_w+k}.
\tag{7}
\]

The (k)-th summand starts in degree (T^{F_w+k}), with coefficient

\[
\lambda^{j_0}(5\lambda^4)^{F_w+k}\ne0.
\]

It follows that

\[
(e_{w,0},\ldots,e_{w,n_w-F_w-1})
\longmapsto
(d_{w,F_w},\ldots,d_{w,n_w-1})
\]

is triangular and invertible.  These declared pivot outputs recover all
(e_{w,k}) by forward substitution; equation (7) then produces every later
allowed output coefficient.  This gives both directions of the linear
parametrization, not just a dimension count.

## Leading common-power blocks

The leading (P)-block has (w=15), (n_w=13), and (F_w=6); the leading
(Q)-block has (w=25), (n_w=21), and (F_w=10).  Their free dimensions
are respectively (7) and (11).

When the separate common-power condition

\[
H^P_{15}=\alpha S^3,\qquad H^Q_{25}=\beta S^5
\]

is imposed, a double root of (S) at (c) produces precisely these
multiplicities.  Exact multiplicity additionally requires
(S(u)/(u-c)^2\) to be nonzero at (c).  The common-power condition is a
nonlinear constraint beyond the linear theorem proved here; it is not silently
built into the (202)-block manifest.

It may be imposed efficiently by writing

\[
S(u)=(u-c)^2(s_2u^2+s_1u+s_0)
\]

and retaining the required nonvanishing and normalization factors.  In
particular, (c) must remain related to the shear parameter by
(c=\lambda^5).  This packet does **not** identify (c) with (lambda) or
assert a gauge allowing (lambda=1).

## Quotient-coordinate determinant operator

In the terminal chart, put (u=z^5) and write

\[
A_r(z)=z^\alpha a(u),\qquad B_s(z)=z^\beta b(u),
\qquad0\le\alpha,\beta<5.
\]

Since

\[
\frac d{dz}\left(z^\alpha a(u)\right)
=z^{\alpha-1}\left(\alpha a+5ua'\right),
\]

the contribution of ((A_r,B_s)) to

\[
(3-r)A_rB_s'+(s-5)A_r'B_s
\]

is (z^{\alpha+\beta-1}) times

\[
(3-r)a(\beta b+5ub')
+(s-5)(\alpha a+5ua')b.
\tag{8}
\]

For monomials (a=u^p,b=u^q), the coefficient in (8) is

\[
(3-r)(\beta+5q)+(s-5)(\alpha+5p),
\]

which is exactly the maintained sparse-(z) coefficient

\[
(3-r)B+(s-5)A
\]

for (A=\alpha+5p) and (B=\beta+5q).  The checker exercises this equality
on every supported monomial against the leading blocks.  Thus future
determinant calculations may use dense univariate polynomials in (u) while
preserving the exact (C_5)-character blocks.

## Verification

Run:

```bash
uv run python -B \
  research-notes/lane8-f2-root-divisibility-20260804-v1/verify_f2_root_divisibility.py
```

The checker independently reconstructs the source and terminal supports,
compares the complete committed manifest with the reconstruction, verifies
every forbidden-block rank and Vandermonde witness, verifies every triangular
pivot matrix, checks the leading multiplicities, checks the two dimension
totals, and checks quotient-operator compatibility.  It imports no earlier
Lane 8 implementation.  Optional JSON output is write-once.

## Exact scope boundary

This packet establishes the complete inherited **linear** descent locus for
the fixed denominator-five shear.  It does not establish:

- the common-power, exact-double-root, determinant, normalization, or open
  conditions as one solved constructible locus;
- a finite stratification or uniqueness theorem for actual post-shear
  supports;
- a forward/inverse correspondence for that nonlinear locus;
- an adjacent-chart attachment or a descent theorem;
- any plane Jacobian-conjecture conclusion.

Those are the remaining Lane 8 stages.  They should consume the (1,973)
coordinates in this packet lazily rather than reconstructing (16,773)
allowed output variables and (14,800) linear equations.
