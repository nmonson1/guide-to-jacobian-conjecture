#!/usr/bin/env python3
"""Exact checks for the F2 root-divisibility block parametrization.

The checker reconstructs the source rectangles and the denominator-five
shear directly.  It does not import the earlier support-window checker and
does not use a serialized coefficient matrix.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction
import hashlib
import json
from math import comb, factorial
from pathlib import Path
from typing import Any


PACKET_DIR = Path(__file__).resolve().parent
REPO_ROOT = PACKET_DIR.parents[1]
DEFAULT_MANIFEST = PACKET_DIR / "block_manifest.json"


@dataclass(frozen=True)
class PairData:
    kind: str
    x_max: int
    y_max: int
    initial_weight_max: int
    terminal_weight_max: int


P_DATA = PairData("P", 15, 60, 15, 3)
Q_DATA = PairData("Q", 25, 100, 25, 5)


def ceil_div(numerator: int, denominator: int) -> int:
    assert denominator > 0
    return -((-numerator) // denominator)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_support(data: PairData) -> set[tuple[int, int]]:
    """The exact source rectangle below the initial (5,-1) face."""
    return {
        (i, j)
        for i in range(data.x_max + 1)
        for j in range(data.y_max + 1)
        if 5 * i - j <= data.initial_weight_max
    }


def source_blocks(data: PairData) -> dict[int, list[int]]:
    blocks: dict[int, list[int]] = defaultdict(list)
    for i, j in source_support(data):
        blocks[5 * i - j].append(j)
    return {weight: sorted(js) for weight, js in sorted(blocks.items())}


def terminal_multiplicity(
    *, weight: int, terminal_weight_max: int, source_max_degree: int
) -> int:
    raw = ceil_div(5 * weight - terminal_weight_max, 12)
    return max(0, min(source_max_degree + 1, raw))


def block_record(data: PairData, weight: int, source_js: list[int]) -> dict[str, Any]:
    assert source_js == list(range(source_js[0], source_js[-1] + 1, 5))
    dimension = len(source_js)
    multiplicity = terminal_multiplicity(
        weight=weight,
        terminal_weight_max=data.terminal_weight_max,
        source_max_degree=source_js[-1],
    )
    assert multiplicity <= dimension
    free = dimension - multiplicity
    pivot_last = multiplicity + free - 1
    return {
        "kind": data.kind,
        "weight": weight,
        "source_min_degree": source_js[0],
        "source_max_degree": source_js[-1],
        "source_step": 5,
        "source_dimension": dimension,
        "terminal_multiplicity": multiplicity,
        "free_dimension": free,
        "free_variable": {
            "symbol_pattern": f"e_{data.kind}_{weight}_{{k}}",
            "index_interval": [0, free - 1],
        },
        "forbidden_output_interval": (
            None if multiplicity == 0 else [0, multiplicity - 1]
        ),
        "pivot_output_interval": [multiplicity, pivot_last],
        "derived_output_interval": (
            None if source_js[-1] < dimension else [dimension, source_js[-1]]
        ),
    }


def all_block_records(data: PairData) -> list[dict[str, Any]]:
    return [
        block_record(data, weight, js)
        for weight, js in source_blocks(data).items()
    ]


def shear_supports(
    data: PairData,
) -> tuple[set[tuple[int, int]], set[tuple[int, int]], set[tuple[int, int]]]:
    """Return full, allowed, and forbidden output coordinates (w,J)."""
    full: set[tuple[int, int]] = set()
    allowed: set[tuple[int, int]] = set()
    forbidden: set[tuple[int, int]] = set()
    for i, j in source_support(data):
        weight = 5 * i - j
        for output_degree in range(j + 1):
            coordinate = (weight, output_degree)
            full.add(coordinate)
            terminal_weight = 5 * weight - 12 * output_degree
            if terminal_weight <= data.terminal_weight_max:
                allowed.add(coordinate)
            else:
                forbidden.add(coordinate)
    assert full == allowed | forbidden
    assert not allowed & forbidden
    return full, allowed, forbidden


def exact_rank(matrix: list[list[int]]) -> int:
    if not matrix:
        return 0
    rows = [[Fraction(entry) for entry in row] for row in matrix]
    row_count = len(rows)
    column_count = len(rows[0])
    rank = 0
    for column in range(column_count):
        pivot = next(
            (row for row in range(rank, row_count) if rows[row][column]),
            None,
        )
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        pivot_value = rows[rank][column]
        rows[rank] = [entry / pivot_value for entry in rows[rank]]
        for row in range(rank + 1, row_count):
            if not rows[row][column]:
                continue
            scale = rows[row][column]
            rows[row] = [
                rows[row][index] - scale * rows[rank][index]
                for index in range(column_count)
            ]
        rank += 1
        if rank == row_count:
            break
    return rank


def determinant(matrix: list[list[int]]) -> Fraction:
    if not matrix:
        return Fraction(1)
    rows = [[Fraction(entry) for entry in row] for row in matrix]
    size = len(rows)
    assert all(len(row) == size for row in rows)
    value = Fraction(1)
    for column in range(size):
        pivot = next(
            (row for row in range(column, size) if rows[row][column]),
            None,
        )
        if pivot is None:
            return Fraction(0)
        if pivot != column:
            rows[column], rows[pivot] = rows[pivot], rows[column]
            value *= -1
        pivot_value = rows[column][column]
        value *= pivot_value
        for row in range(column + 1, size):
            if not rows[row][column]:
                continue
            scale = rows[row][column] / pivot_value
            for index in range(column + 1, size):
                rows[row][index] -= scale * rows[column][index]
    return value


def vandermonde_value(degrees: list[int]) -> Fraction:
    value = Fraction(1)
    for right in range(len(degrees)):
        for left in range(right):
            value *= degrees[right] - degrees[left]
    for order in range(len(degrees)):
        value /= factorial(order)
    return value


def shifted_coefficient(
    *, source_min_degree: int, power: int, output_degree: int
) -> int:
    """Coefficient of T^output_degree in

    (T+1)^source_min_degree * ((T+1)^5-1)^power.
    """
    value = 0
    for exponent in range(power + 1):
        coefficient = comb(power, exponent) * (-1) ** (power - exponent)
        y_degree = source_min_degree + 5 * exponent
        if output_degree <= y_degree:
            value += coefficient * comb(y_degree, output_degree)
    return value


def verify_block(data: PairData, record: dict[str, Any]) -> dict[str, int]:
    weight = record["weight"]
    source_js = source_blocks(data)[weight]
    multiplicity = record["terminal_multiplicity"]
    free = record["free_dimension"]

    forbidden_matrix = [
        [comb(degree, order) for degree in source_js]
        for order in range(multiplicity)
    ]
    assert exact_rank(forbidden_matrix) == multiplicity

    witness_columns = source_js[:multiplicity]
    witness = [row[:multiplicity] for row in forbidden_matrix]
    witness_determinant = determinant(witness)
    assert witness_determinant == vandermonde_value(witness_columns)
    assert witness_determinant != 0

    pivot_matrix = [
        [
            shifted_coefficient(
                source_min_degree=source_js[0],
                power=multiplicity + column,
                output_degree=multiplicity + row,
            )
            for column in range(free)
        ]
        for row in range(free)
    ]
    for row in range(free):
        for column in range(free):
            if row < column:
                assert pivot_matrix[row][column] == 0
            if row == column:
                assert pivot_matrix[row][column] == 5 ** (multiplicity + column)
    assert exact_rank(pivot_matrix) == free

    return {
        "forbidden_rank": multiplicity,
        "free_rank": free,
        "vandermonde_witnesses": int(multiplicity > 0),
    }


def terminal_layers(data: PairData) -> dict[int, list[int]]:
    _, allowed, _ = shear_supports(data)
    layers: dict[int, set[int]] = defaultdict(set)
    for weight, output_degree in allowed:
        order = data.terminal_weight_max - (5 * weight - 12 * output_degree)
        layers[order].add(output_degree)
    return {order: sorted(exponents) for order, exponents in sorted(layers.items())}


def quotient_operator_coefficient(
    *,
    p_order: int,
    q_order: int,
    p_residue: int,
    q_residue: int,
    p_u_degree: int,
    q_u_degree: int,
) -> int:
    return (3 - p_order) * (q_residue + 5 * q_u_degree) + (
        q_order - 5
    ) * (p_residue + 5 * p_u_degree)


def verify_quotient_operator() -> dict[str, int]:
    """Check the quotient formula on every supported monomial.

    Each P monomial is paired with the two leading Q monomials, and each Q
    monomial with the two leading P monomials.  This exercises every actual
    order and exponent; the equality checked is the universal monomial
    identity used in the proof note.
    """
    p_layers = terminal_layers(P_DATA)
    q_layers = terminal_layers(Q_DATA)
    p_leading = p_layers[0]
    q_leading = q_layers[0]
    checked = 0

    def check_pair(p_order: int, p_exp: int, q_order: int, q_exp: int) -> None:
        nonlocal checked
        p_residue = p_exp % 5
        q_residue = q_exp % 5
        p_u_degree = (p_exp - p_residue) // 5
        q_u_degree = (q_exp - q_residue) // 5
        direct = (3 - p_order) * q_exp + (q_order - 5) * p_exp
        quotient = quotient_operator_coefficient(
            p_order=p_order,
            q_order=q_order,
            p_residue=p_residue,
            q_residue=q_residue,
            p_u_degree=p_u_degree,
            q_u_degree=q_u_degree,
        )
        assert direct == quotient
        if direct:
            assert p_exp + q_exp - 1 >= 0
        checked += 1

    for p_order, p_exponents in p_layers.items():
        for p_exp in p_exponents:
            for q_exp in q_leading:
                check_pair(p_order, p_exp, 0, q_exp)
    for q_order, q_exponents in q_layers.items():
        for q_exp in q_exponents:
            for p_exp in p_leading:
                check_pair(0, p_exp, q_order, q_exp)

    return {
        "supported_monomial_pair_checks": checked,
        "P_nonempty_terminal_layers": len(p_layers),
        "Q_nonempty_terminal_layers": len(q_layers),
    }


def expected_manifest() -> dict[str, Any]:
    p_blocks = all_block_records(P_DATA)
    q_blocks = all_block_records(Q_DATA)
    return {
        "schema_version": 1,
        "packet_id": "lane8-f2-root-divisibility-20260804-v1",
        "coefficient_ring": (
            "K[lambda,c,lambda^{-1}]/(c-lambda^5), char(K)=0"
        ),
        "coordinates": {
            "source_weight": "w=5*i-j",
            "source_block": "C_w(Y)=Y^j0 H_w(Y^5)",
            "transport": "D_w(T)=C_w(T+lambda)",
            "terminal_test": "5*w-12*J<=t; t=3 for P and t=5 for Q",
        },
        "formulas": {
            "terminal_multiplicity": (
                "F_w=max(0,min(jmax+1,ceil((5*w-t)/12)))"
            ),
            "root_divisibility": "H_w(u)=(u-c)^F_w E_w(u)",
            "free_degree_bound": "deg(E_w)<n_w-F_w",
            "triangular_basis": (
                "C_w(Y)=Y^j0 sum_k e_w,k (Y^5-c)^(F_w+k)"
            ),
            "generic_diagonal": (
                "lambda^j0*(5*lambda^4)^(F_w+k)"
            ),
            "quotient_determinant_operator": (
                "(3-r)*a*(beta*b+5*u*b')+"
                "(s-5)*(alpha*a+5*u*a')*b"
            ),
        },
        "totals": {
            "P": {
                "blocks": 76,
                "source_dimension": 586,
                "terminal_forbidden_dimension": 53,
                "free_dimension": 533,
                "full_shear_coordinates": 4486,
                "terminal_allowed_coordinates": 4433,
                "inherited_linear_relations": 3900,
            },
            "Q": {
                "blocks": 126,
                "source_dimension": 1576,
                "terminal_forbidden_dimension": 136,
                "free_dimension": 1440,
                "full_shear_coordinates": 12476,
                "terminal_allowed_coordinates": 12340,
                "inherited_linear_relations": 10900,
            },
            "blocks": 202,
            "free_dimension": 1973,
            "inherited_linear_relations": 14800,
        },
        "top_blocks": {
            "P": {
                "weight": 15,
                "source_dimension": 13,
                "terminal_multiplicity": 6,
                "free_dimension": 7,
            },
            "Q": {
                "weight": 25,
                "source_dimension": 21,
                "terminal_multiplicity": 10,
                "free_dimension": 11,
            },
        },
        "blocks": {"P": p_blocks, "Q": q_blocks},
        "provenance": [
            {
                "path": (
                    "research-notes/lane8-f2-support-determinacy-audit-"
                    "20260803-v1/README.md"
                ),
                "sha256": (
                    "38c3c52d8deeed6036f0739da5837b98e6eac29b22f82c33f34931ca9c60da84"
                ),
                "role": "prior exact transport and support audit",
            },
            {
                "path": (
                    "research-notes/lane8-f2-support-determinacy-audit-"
                    "20260803-v1/verify_lane8_f2_support_determinacy_audit.py"
                ),
                "sha256": (
                    "c5c5dfe96f3317795cbbc506a0ff4a7d6f14a5c84111778cdd76dc5914e647ab"
                ),
                "role": "prior independent support/rank checker",
            },
            {
                "path": (
                    "manuscripts/06-plane-boundary/computational-supplement/"
                    "terminal-boundary/F2_degree125_boundary_seed.md"
                ),
                "sha256": (
                    "63fb30b6de06df86c9c87e968d4d72e58b9218134a9eaa8cbce978b78901eb5e"
                ),
                "role": "F2 source rectangles, shear, and common-power face",
            },
            {
                "path": (
                    "/path/to/versioned-artifact"
                    "materials-v3-20260803a/06-f2-support-windows-order-"
                    "520-2026-08-03-v1.zip"
                ),
                "sha256": (
                    "a0017d6537021b80098b78349cd7ad5566f6606d053b7e8f3f1dbd634d14ca64"
                ),
                "role": "maintained support-window generator and exact outputs",
            },
        ],
        "scope": {
            "establishes": [
                "an exact block parametrization of all inherited linear terminal descent constraints",
                "full row rank of every forbidden Taylor-jet block in characteristic zero",
                "a triangular inverse from the declared pivot outputs",
                "compatibility with the quotient-coordinate determinant operator",
            ],
            "does_not_establish": [
                "the nonlinear common-power or exact-double-root locus",
                "the determinant equations or their solution set",
                "actual post-shear support uniqueness or its stratification",
                "a gauge equivalence setting lambda to one",
                "an adjacent-chart attachment or a plane Jacobian-conjecture conclusion",
            ],
        },
    }


def verify_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    expected = expected_manifest()
    assert manifest == expected

    summary: dict[str, Any] = {}
    total_witnesses = 0
    for data in (P_DATA, Q_DATA):
        records = manifest["blocks"][data.kind]
        block_results = [verify_block(data, record) for record in records]
        full, allowed, forbidden = shear_supports(data)
        source_dimension = len(source_support(data))
        forbidden_dimension = sum(
            result["forbidden_rank"] for result in block_results
        )
        free_dimension = sum(result["free_rank"] for result in block_results)
        total_witnesses += sum(
            result["vandermonde_witnesses"] for result in block_results
        )
        expected_totals = manifest["totals"][data.kind]
        assert len(records) == expected_totals["blocks"]
        assert source_dimension == expected_totals["source_dimension"]
        assert forbidden_dimension == expected_totals["terminal_forbidden_dimension"]
        assert free_dimension == expected_totals["free_dimension"]
        assert len(full) == expected_totals["full_shear_coordinates"]
        assert len(allowed) == expected_totals["terminal_allowed_coordinates"]
        assert len(forbidden) == forbidden_dimension
        assert len(allowed) - free_dimension == expected_totals[
            "inherited_linear_relations"
        ]
        summary[data.kind] = expected_totals

    for provenance in manifest["provenance"]:
        path = Path(provenance["path"])
        if not path.is_absolute():
            path = REPO_ROOT / path
        if path.exists():
            assert sha256(path) == provenance["sha256"]

    quotient = verify_quotient_operator()
    summary.update(
        {
            "verified": True,
            "blocks": manifest["totals"]["blocks"],
            "free_dimension": manifest["totals"]["free_dimension"],
            "vandermonde_witness_blocks": total_witnesses,
            "top_blocks": manifest["top_blocks"],
            "quotient_operator": quotient,
            "scope": manifest["scope"],
        }
    )
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument(
        "--write-manifest",
        type=Path,
        help="write the reconstructed manifest to a new path before checking it",
    )
    parser.add_argument("--json", type=Path, help="write summary to a new path")
    args = parser.parse_args()

    if args.write_manifest:
        if args.write_manifest.exists():
            raise FileExistsError(f"refusing to overwrite {args.write_manifest}")
        args.write_manifest.parent.mkdir(parents=True, exist_ok=True)
        args.write_manifest.write_text(
            json.dumps(expected_manifest(), indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        manifest_path = args.write_manifest
    else:
        manifest_path = args.manifest

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    summary = verify_manifest(manifest)
    rendered = json.dumps(summary, indent=2, sort_keys=True) + "\n"
    if args.json:
        if args.json.exists():
            raise FileExistsError(f"refusing to overwrite {args.json}")
        args.json.write_text(rendered, encoding="utf-8")
    print(rendered, end="")


if __name__ == "__main__":
    main()
