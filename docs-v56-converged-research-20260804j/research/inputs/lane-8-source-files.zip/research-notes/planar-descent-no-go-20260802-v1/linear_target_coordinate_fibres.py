#!/usr/bin/env python3
"""Structure of generic fibres of every linear target coordinate.

For H=alpha*F1+beta*F2+gamma*F3 of the 2026 three-dimensional Keller map,
write H=A(x,y)z+B(x,y), and put t=1+xy.  The script verifies

    A = alpha*t^3 + 3*beta*x*t^2 - gamma*x^3,

and, on each hyperbola t=rho*x satisfying

    alpha*rho^3 + 3*beta*rho^2 - gamma = 0,

the restriction

    B = alpha*rho^2 + 4*beta*rho + (alpha*rho+2*beta)/x.

These formulas give a short Euler-characteristic proof that no nonzero
linear combination of F1,F2,F3 is a coordinate polynomial.  The one case
whose generic Euler characteristic is 1 is F1 itself; its generic fibre is
A^2 minus the hyperbola 1+xy=0 and has the nonconstant unit 1+xy.
"""
from __future__ import annotations

import sympy as sp

x, y, z, t, rho = sp.symbols("x y z t rho")
alpha, beta, gamma = sp.symbols("alpha beta gamma")
u = 1 + x * y
F1 = sp.expand(u**3 * z + y**2 * u * (4 + 3 * x * y))
F2 = sp.expand(y + 3 * x * u**2 * z + 3 * x * y**2 * (4 + 3 * x * y))
F3 = sp.expand(2 * x - 3 * x**2 * y - x**3 * z)
H = sp.expand(alpha * F1 + beta * F2 + gamma * F3)
A = sp.expand(sp.diff(H, z))
B = sp.expand(H - A * z)

A_t = sp.factor(A.subs(y, (t - 1) / x))
B_t = sp.factor(sp.together(B.subs(y, (t - 1) / x)))
assert A_t == alpha * t**3 + 3 * beta * x * t**2 - gamma * x**3

root_relation = {gamma: alpha * rho**3 + 3 * beta * rho**2}
B_on_component = sp.factor(
    sp.together(B_t.subs(t, rho * x).subs(root_relation))
)
expected = alpha * rho**2 + 4 * beta * rho + (alpha * rho + 2 * beta) / x
assert sp.factor(B_on_component - expected) == 0

# A root component is constant for B exactly when alpha*rho+2*beta=0.
# Such a root is repeated because the derivative of the cubic is
# 3*rho*(alpha*rho+2*beta).
R = alpha * rho**3 + 3 * beta * rho**2 - gamma
assert sp.factor(sp.diff(R, rho)) == 3 * rho * (alpha * rho + 2 * beta)

# Special repeated-root factorizations used in the case split.
b = sp.symbols("b")
assert sp.expand((rho + 2 * b) ** 2 * (rho - b)) == rho**3 + 3 * b * rho**2 - 4 * b**3
assert sp.expand(rho**2 * (rho + 3 * b)) == rho**3 + 3 * b * rho**2

print("A(x,t) = alpha*t^3 + 3*beta*x*t^2 - gamma*x^3")
print("On t=rho*x: B = alpha*rho^2+4*beta*rho+(alpha*rho+2*beta)/x")
print("alpha!=0, not F1: at least one nonconstant G_m component, so chi(generic fibre)>=2")
print("alpha=0,beta!=0: line plus one/two G_m components, so chi(generic fibre)>=2")
print("H=gamma*F3: generic fibre is G_m x A^1")
print("H=alpha*F1: generic fibre has the nonconstant unit 1+x*y")
print("Therefore no nonzero linear target coordinate pulls back to a source coordinate")
