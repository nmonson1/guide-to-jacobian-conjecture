# Planar descent from the known higher-dimensional examples

> **Status: incomplete proof strategy — not a proof of the planar Jacobian
> conjecture.**

This packet tests a possible route to the planar Jacobian conjecture: descend
one of the known higher-dimensional noninjective constant-Jacobian or
constant-Hessian examples to dimension two, then remove the ramification
introduced by the descent.  The supplied calculations rule out several
natural versions of the first step.  They do not supply the missing global
descent theorem or a way to remove the branch factor.

## Proposed proof route

For a minimal plane Keller counterexample, run the normalized Newton reduction
to a terminal complete-chain system.  The desired global theorem would say
that every terminal system has one of two outcomes:

1. it cannot have simultaneous finite polynomial support in the two adjacent
   boundary charts; or
2. it comes from an admissible polynomial approximate-root operation that
   strictly lowers the chosen Newton complexity.

Together with an exhaustive starting reduction and termination, this would
exclude a minimal counterexample.  Lane 8 owns the exhaustive Newton queue and
terminal systems; Lane 9 owns the adjacent-chart correspondence and polynomial
descent step.

## Exact evidence supplied

For the displayed three-dimensional Keller map, the scripts check:

- its invariant quotient has Jacobian `-2*C^2`, and in affine-modification
  coordinates the residual Jacobian is `2*c`;
- no affine source plane followed by a rank-two linear target projection gives
  a planar counterexample—the only Keller restriction is triangular;
- no polynomial graph over any coordinate plane followed by a rank-two linear
  target projection is Keller; and
- no nonzero linear target combination is a source coordinate, using the
  recorded generic-fibre calculation.

For the displayed five-variable constant-Hessian example, the scripts check:

- there is no second constant linear Schur direction;
- no affine hyperplane through the recorded collision yields a four-variable
  nonzero constant-Hessian restriction;
- the birational near-descent is a planar fold with Hessian determinant
  `64*s^2`; and
- the displayed six-parameter square correction cannot make that determinant
  a nonzero constant.

These are exact, sharply bounded no-go calculations.  They show that
noninjectivity can survive while a boundary or fold factor remains.  They do
not show that all possible descents fail.

## Missing proof obligations

- Prove—or replace—the imported reduction from a hypothetical planar Keller
  counterexample to the normalized support queue.
- Prove that the queue routes every saturation complement, coefficient branch,
  and rechart and terminates in the stated systems.
- Construct the actual adjacent complete-chain charts and prove simultaneous
  two-sided finite support is impossible, or identify an admissible
  complexity-lowering operation.
- Show that every possible higher-dimensional descent is covered by an
  invariant class broad enough to matter; the affine-plane, polynomial-graph,
  linear-projection, and displayed square-correction families are not
  exhaustive.
- Verify the literature attributions and the source formulas independently
  before treating the no-go statements as publication-ready results.

## Reproducible checks

- `three_dimensional_descent_no_go.py`
- `affine_plane_linear_projection_no_go.py`
- `y_graph_descent_no_go.py`
- `linear_target_coordinate_fibres.py`
- `hc4_linear_descent_no_go.py`
- `hc4_square_correction_no_go.py`

All six scripts use exact SymPy arithmetic.  A successful replay establishes
only the identities and finite coefficient eliminations encoded in that
script; it does not establish the proposed global proof route.
