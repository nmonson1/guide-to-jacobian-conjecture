#!/usr/bin/env python3
"""Classify all affine-plane / linear-projection descents of the 2026 JC_3 map.

Let F:A^3->A^3 be the explicit Keller counterexample.  Let

    S={m_1 x+m_2 y+m_3 z=d}

be an affine source plane, and let pi:A^3->A^2 be a rank-two linear map with
kernel direction k.  Up to fixed nonzero choices of volume forms, the Jacobian
of pi o F|_S is

    R_{m,k}=m^T adj(JF) k   modulo (m.X-d).

The exact coefficient calculation below proves:

* R_{m,k} cannot be a nonzero constant unless S={x=0};
* on S={x=0}, nonzero constant Jacobian occurs precisely when the target
  projection is nondegenerate on the first two target coordinates;
* every such restriction is a linear target change of
      (y,z) -> (z+4y^2,y),
  hence a polynomial automorphism.

Therefore this entire descent class contains no planar counterexample.
"""
from __future__ import annotations

import sympy as sp

x, y, z = sp.symbols("x y z")
u = 1 + x*y
F1 = sp.expand(u**3*z + y**2*u*(4+3*x*y))
F2 = sp.expand(y + 3*x*u**2*z + 3*x*y**2*(4+3*x*y))
F3 = sp.expand(2*x - 3*x**2*y - x**3*z)
F = (F1,F2,F3)
JF = sp.Matrix([[sp.diff(fi,v) for v in (x,y,z)] for fi in F])
assert sp.factor(JF.det()) == -2
Adj = JF.adjugate()
k1,k2,k3 = sp.symbols("k1 k2 k3")
k = sp.Matrix([k1,k2,k3])

# Case I: m3 != 0.  Normalize m=(a,b,1), z=d-a*x-b*y.
a,b,d = sp.symbols("a b d")
m = sp.Matrix([[a,b,1]])
R = sp.expand((m*Adj*k)[0].subs(z,d-a*x-b*y))
P = sp.Poly(R,x,y)
assert P.coeff_monomial(y**3) == -89*k3
assert sp.expand(P.coeff_monomial(x*y**2).subs(k3,0)) == -6*k2
assert sp.expand(P.coeff_monomial(x*y).subs({k3:0,k2:0})) == -42*k1

# Case II: m3=0,m2 != 0. Normalize m=(a,1,0), y=d-a*x.
a,d = sp.symbols("a d")
m = sp.Matrix([[a,1,0]])
R = sp.expand((m*Adj*k)[0].subs(y,d-a*x))
P = sp.Poly(R,x,z)
assert P.coeff_monomial(z) == 3*k3
assert sp.expand(P.coeff_monomial(x**2*z).subs(k3,0)) == 3*k2
assert sp.expand(P.coeff_monomial(x).subs({k3:0,k2:0})) == 6*k1

# Case III: m3=m2=0. Normalize m=(1,0,0), x=d.
d = sp.symbols("d")
m = sp.Matrix([[1,0,0]])
R = sp.expand((m*Adj*k)[0].subs(x,d))
P = sp.Poly(R,y,z)
assert P.coeff_monomial(y**3*z) == 12*d**5*k3
assert sp.expand(P.coeff_monomial(y**3).subs(k3,0)) == 9*d**5*k2
assert sp.expand(P.coeff_monomial(y).subs({k3:0,k2:0})) == -6*d**4*k1
# At d=0 every nonconstant coefficient vanishes, and the constant is -k3.
for mon,coeff in P.terms():
    if mon != (0,0):
        assert sp.expand(coeff.subs(d,0)) == 0
assert sp.expand(P.coeff_monomial(1).subs(d,0)) == -k3

# The exceptional restriction is triangular.
assert sp.expand(F1.subs(x,0) - (z+4*y**2)) == 0
assert F2.subs(x,0) == y
assert F3.subs(x,0) == 0
assert sp.det(sp.Matrix([
    [sp.diff(F1.subs(x,0),y),sp.diff(F1.subs(x,0),z)],
    [sp.diff(F2.subs(x,0),y),sp.diff(F2.subs(x,0),z)],
])) == -1

print("Case m3!=0: y^3, x*y^2, x*y force k3=k2=k1=0")
print("Case m3=0,m2!=0: z, x^2*z, x force k3=k2=k1=0")
print("Case m=(1,0,0), d!=0: y^3*z, y^3, y force k3=k2=k1=0")
print("Exceptional plane x=0: restriction (z+4*y^2,y,0), triangular automorphism")
