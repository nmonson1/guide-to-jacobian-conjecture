#!/usr/bin/env python3
"""Exact checks for simple planar descents of the 2026 three-dimensional Keller map.

This script proves/checks three sharply scoped statements.

1. The G_m-invariant quotient is a polynomial map A^2 -> A^2 whose
   Jacobian is -2 times the square of the contracted invariant.
2. After a birational monomial simplification it is the cubic cover
       s^3 - 2 s^2 + P s - 2 Q = 0,
   but its planar Jacobian still has the unavoidable branch factor.
3. For every polynomial graph z=h(x,y), and every rank-two linear target
   projection, the induced map A^2 -> A^2 cannot have nonzero constant
   Jacobian.  The proof is degree-theoretic and valid for arbitrary degree h.

The script uses exact symbolic arithmetic only.
"""
from __future__ import annotations

import sympy as sp

x, y, z = sp.symbols("x y z")
u = 1 + x * y
F1 = sp.expand(u**3 * z + y**2 * u * (4 + 3 * x * y))
F2 = sp.expand(y + 3 * x * u**2 * z + 3 * x * y**2 * (4 + 3 * x * y))
F3 = sp.expand(2 * x - 3 * x**2 * y - x**3 * z)

# ---------------------------------------------------------------------------
# 1. Coarse G_m quotient.
# ---------------------------------------------------------------------------
a, b = sp.symbols("a b")
uq = 1 + a
X = sp.expand(uq**3 * b + a**2 * uq * (4 + 3 * a))
C = 2 - 3 * a - b
D = sp.expand(a + 3 * uq**2 * b + 3 * a**2 * (4 + 3 * a))
P = sp.expand(X * C**2)
Q = sp.expand(D * C)
Jquot = sp.factor(sp.det(sp.Matrix([
    [sp.diff(P, a), sp.diff(P, b)],
    [sp.diff(Q, a), sp.diff(Q, b)],
])))
assert sp.expand(Jquot + 2 * C**2) == 0

# A useful affine-modification coordinate.  Set r=a+1 and p=C*r.
r, c, p = sp.symbols("r c p")
Xrc = sp.expand(-c * r**3 + r**2 + r)
Drc = sp.expand(-3 * c * r**2 + 4 * r + 2)
Ppc = sp.expand((c**2 * Xrc).subs(r, p / c))
Qpc = sp.expand((c * Drc).subs(r, p / c))
assert Ppc == -p**3 + p**2 + c * p
assert Qpc == -3 * p**2 + 4 * p + 2 * c
Jpc = sp.factor(sp.det(sp.Matrix([
    [sp.diff(Ppc, p), sp.diff(Ppc, c)],
    [sp.diff(Qpc, p), sp.diff(Qpc, c)],
])))
assert Jpc == 2 * c
s = sp.symbols("s")
c_from_Q = sp.expand((Qpc + 3 * p**2 - 4 * p) / 2)
cubic = sp.expand(p**3 - 2 * p**2 + Qpc * p - 2 * Ppc)
assert cubic == 0

# ---------------------------------------------------------------------------
# 2. Polynomial graph z=h(x,y), arbitrary linear target projection.
# ---------------------------------------------------------------------------
H, Hx, Hy = sp.symbols("H Hx Hy")
hfun = sp.Function("h")(x, y)
Fs = [F1, F2, F3]


def graph_jacobian(i: int, j: int) -> sp.Expr:
    fi = Fs[i].subs(z, hfun)
    fj = Fs[j].subs(z, hfun)
    jac = sp.det(sp.Matrix([
        [sp.diff(fi, x), sp.diff(fi, y)],
        [sp.diff(fj, x), sp.diff(fj, y)],
    ]))
    return sp.expand(jac.subs({
        hfun: H,
        sp.diff(hfun, x): Hx,
        sp.diff(hfun, y): Hy,
    }))


J12 = graph_jacobian(0, 1)
J13 = graph_jacobian(0, 2)
J23 = graph_jacobian(1, 2)

# The unique top-degree quadratic-in-h pieces.  If h_d is the leading
# homogeneous form of a nonconstant h, these become the leading homogeneous
# terms of the restricted Jacobians.
expected_top_12 = -3 * x * (x * y) ** 4 * H * (3 * H + x * Hx)
expected_top_13 = 3 * x**3 * (x * y) ** 2 * H * (3 * H + x * Hx)
expected_top_23 = 6 * x**4 * (x * y) * H * (3 * H + x * Hx)


def quadratic_part(expr: sp.Expr) -> sp.Expr:
    # Degree two when H and either derivative are assigned degree one.
    poly = sp.Poly(expr, H, Hx, Hy)
    out = 0
    for (e_h, e_hx, e_hy), coeff in poly.terms():
        if e_h + e_hx + e_hy == 2:
            out += coeff * H**e_h * Hx**e_hx * Hy**e_hy
    return sp.expand(out)


q12 = quadratic_part(J12)
q13 = quadratic_part(J13)
q23 = quadratic_part(J23)

# Each quadratic part also has lower total (x,y)-degree terms involving Hy;
# extract the highest x,y-degree coefficient to verify the formulas above.
def leading_after_homogeneous_substitution(expr: sp.Expr) -> sp.Expr:
    """Terms of maximal total degree after H->h_d and dH->degree d-1."""
    poly = sp.Poly(expr, x, y, H, Hx, Hy)
    score = lambda mon: mon[0] + mon[1] - mon[3] - mon[4]
    max_score = max(score(mon) for mon, _ in poly.terms())
    out = 0
    for mon, coeff in poly.terms():
        ex, ey, e_h, e_hx, e_hy = mon
        if score(mon) == max_score:
            out += coeff * x**ex * y**ey * H**e_h * Hx**e_hx * Hy**e_hy
    return sp.expand(out)


assert sp.expand(leading_after_homogeneous_substitution(q12) - expected_top_12) == 0
assert sp.expand(leading_after_homogeneous_substitution(q13) - expected_top_13) == 0
assert sp.expand(leading_after_homogeneous_substitution(q23) - expected_top_23) == 0

# Explanation encoded as a check: if h_d=sum c_i x^i y^(d-i), the equation
# x*d_x h_d=-3 h_d has no nonzero polynomial solution because every exponent
# i is a nonnegative integer.  We verify this coefficientwise for a symbolic
# generic degree d up to a representative range; the written proof is uniform.
for degree in range(1, 13):
    coeffs = sp.symbols(f"t0:{degree + 1}")
    hd = sum(coeffs[i] * x**i * y**(degree - i) for i in range(degree + 1))
    relation = sp.Poly(sp.expand(x * sp.diff(hd, x) + 3 * hd), x, y)
    for i in range(degree + 1):
        assert relation.coeff_monomial(x**i * y**(degree-i)) == (i+3)*coeffs[i]
    # Solving the diagonal equations gives all zero.
    diagonal = [sp.expand((i + 3) * coeffs[i]) for i in range(degree + 1)]
    assert sp.solve(diagonal, coeffs, dict=True) == [dict(zip(coeffs, [0] * len(coeffs)))]

# Constant h cannot work either.  The coefficients x^3 y^6, x^3 y^4,
# and x^3 y^3 successively kill the three Pluecker coordinates.
h0, lam12, lam13, lam23, kappa = sp.symbols(
    "h0 lam12 lam13 lam23 kappa"
)
const_combination = sp.Poly(
    sp.expand(
        lam12 * J12.subs({H: h0, Hx: 0, Hy: 0})
        + lam13 * J13.subs({H: h0, Hx: 0, Hy: 0})
        + lam23 * J23.subs({H: h0, Hx: 0, Hy: 0})
        - kappa
    ),
    x,
    y,
)
assert const_combination.coeff_monomial(x**3 * y**6) == -54 * lam12
assert sp.expand(
    const_combination.coeff_monomial(x**3 * y**4).subs(lam12, 0)
) == 54 * lam13
assert sp.expand(
    const_combination.coeff_monomial(x**3 * y**3).subs({lam12: 0, lam13: 0})
) == 108 * lam23

print("3D Keller map determinant: -2 (source formula imported from the paper)")
print(f"Coarse quotient Jacobian: {Jquot}")
print(f"Affine-modification quotient Jacobian: {Jpc}")
print("Fiber cubic: p^3 - 2 p^2 + Q p - 2 P = 0")
print("Polynomial z-graph + linear target projection: NO Keller descent")

# ---------------------------------------------------------------------------
# 3. Polynomial graph x=g(y,z), arbitrary linear target projection.
#    The only Keller case is the trivial plane x=0, where the restriction is
#    the triangular automorphism (y,z)->(z+4y^2,y) up to a linear target map.
# ---------------------------------------------------------------------------
G, Gy, Gz = sp.symbols("G Gy Gz")
gfun = sp.Function("g")(y, z)


def x_graph_jacobian(i: int, j: int) -> sp.Expr:
    fi = Fs[i].subs(x, gfun)
    fj = Fs[j].subs(x, gfun)
    jac = sp.det(sp.Matrix([
        [sp.diff(fi, y), sp.diff(fi, z)],
        [sp.diff(fj, y), sp.diff(fj, z)],
    ]))
    return sp.expand(jac.subs({
        gfun: G,
        sp.diff(gfun, y): Gy,
        sp.diff(gfun, z): Gz,
    }))


K12 = x_graph_jacobian(0, 1)
K13 = x_graph_jacobian(0, 2)
K23 = x_graph_jacobian(1, 2)
expected_k12 = 3 * G**5 * y**4 * z * (G + 3 * z * Gz)
expected_k13 = -3 * G**5 * y**2 * z * (G + 3 * z * Gz)
expected_k23 = -6 * G**5 * y * z * (G + 3 * z * Gz)


def leading_g_degree(expr: sp.Expr) -> sp.Expr:
    """Highest degree after G->g_d, dG->degree d-1, for any d>=1."""
    poly = sp.Poly(expr, y, z, G, Gy, Gz)
    # total after substitution is d*(eG+eGy+eGz)+base-eGy-eGz.
    # Lexicographically maximize slope then intercept, valid uniformly d>=1
    # here because the unique slope-six block also has maximal intercept.
    data = []
    for mon, coeff in poly.terms():
        ey, ez, eG, eGy, eGz = mon
        slope = eG + eGy + eGz
        intercept = ey + ez - eGy - eGz
        data.append((slope, intercept, mon, coeff))
    max_slope = max(item[0] for item in data)
    max_intercept = max(item[1] for item in data if item[0] == max_slope)
    out = 0
    for slope, intercept, mon, coeff in data:
        if slope == max_slope and intercept == max_intercept:
            ey, ez, eG, eGy, eGz = mon
            out += coeff * y**ey * z**ez * G**eG * Gy**eGy * Gz**eGz
    return sp.expand(out)


assert sp.expand(leading_g_degree(K12) - expected_k12) == 0
assert sp.expand(leading_g_degree(K13) - expected_k13) == 0
assert sp.expand(leading_g_degree(K23) - expected_k23) == 0

# The equation g_d+3 z*d_z g_d=0 has no nonzero homogeneous polynomial
# solution: the coefficient of y^(d-j)z^j is multiplied by 1+3j.
for degree in range(1, 13):
    coeffs = sp.symbols(f"q0:{degree + 1}")
    gd = sum(coeffs[j] * y**(degree-j) * z**j for j in range(degree + 1))
    relation = sp.Poly(sp.expand(gd + 3*z*sp.diff(gd,z)), y, z)
    for j in range(degree+1):
        assert relation.coeff_monomial(y**(degree-j)*z**j) == (1+3*j)*coeffs[j]

# Constants: c!=0 is killed successively by y^4 z, y^2 z, yz; c=0
# leaves K12=-1 and K13=K23=0.
g0 = sp.symbols("g0")
assert sp.Poly(K12.subs({G:g0,Gy:0,Gz:0}),y,z).coeff_monomial(y**4*z) == 3*g0**6
assert sp.Poly(K13.subs({G:g0,Gy:0,Gz:0}),y,z).coeff_monomial(y**2*z) == -3*g0**6
assert sp.Poly(K23.subs({G:g0,Gy:0,Gz:0}),y,z).coeff_monomial(y*z) == -6*g0**6
assert K12.subs({G:0,Gy:0,Gz:0}) == -1
assert K13.subs({G:0,Gy:0,Gz:0}) == 0
assert K23.subs({G:0,Gy:0,Gz:0}) == 0
print("Polynomial x-graph + linear target projection: only x=0, a triangular automorphism")
