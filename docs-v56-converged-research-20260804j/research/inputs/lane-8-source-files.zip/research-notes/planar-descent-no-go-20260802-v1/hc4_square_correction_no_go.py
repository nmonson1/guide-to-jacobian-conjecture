#!/usr/bin/env python3
"""Exact no-go for the first natural quadratic correction of the HC4 fold.

In coordinates (s,u,y,z), the polynomial four-variable near-descent is

    Phi = -(13*s^2 - 3*s*u - 13)^2/4
          + (u^2-s^2)*y/2 + 4*u*z,

and det Hess(Phi)=16*s^2.  This script proves that adding

    w^2,  w=(a0+a1*s+a2*u)*y + (b0+b1*s+b2*u)*z,

cannot make the Hessian determinant a nonzero constant.  It is enough to
restrict the Hessian determinant to y=z=0; the displayed coefficient
conditions give a contradiction over every characteristic-zero field.
"""
from __future__ import annotations

import sympy as sp

s, u, y, z = sp.symbols("s u y z")
a0, a1, a2, b0, b1, b2 = sp.symbols("a0 a1 a2 b0 b1 b2")
q = 13 * s**2 - 3 * s * u - 13
Phi = -q**2 / 4 + (u**2 - s**2) * y / 2 + 4 * u * z
assert sp.factor(sp.hessian(Phi, (s, u, y, z)).det()) == 16 * s**2

A = a0 + a1 * s + a2 * u
B = b0 + b1 * s + b2 * u
w = A * y + B * z
F = sp.expand(Phi + w**2)

# At y=z=0, the base-base and mixed corrections from w^2 vanish; only the
# rank-one fibre Hessian 2(A,B)^T(A,B) remains.  Computing this specialization
# is much smaller than expanding the full four-variable determinant.
H = sp.hessian(F, (s, u, y, z)).subs({y: 0, z: 0})
D = sp.Poly(sp.expand(H.det()), s, u)

assert sp.factor(D.coeff_monomial(s**6)) == 9 * b1**2
assert sp.factor(D.coeff_monomial(u**6)) == 9 * b2**2
assert sp.factor(D.coeff_monomial(s)) == -104 * a0 * (104 * a1 + 3 * b0)
assert sp.factor(D.coeff_monomial(u)) == -2704 * a0 * (4 * a2 - b0)
assert D.coeff_monomial(1) == -5408 * a0**2

# If D were a nonzero constant, b1=b2=0 and a0!=0.  The coefficients of s
# and u then force b0=-104*a1/3=4*a2.  Under these relations the u^2
# coefficient is 144*a0^2, a contradiction.
u2_reduced = sp.factor(
    D.coeff_monomial(u**2).subs({b1: 0, b2: 0, b0: 4 * a2})
)
assert u2_reduced == 144 * a0**2

print("det Hess(Phi) = 16*s^2")
print("s^6 and u^6 coefficients force b1=b2=0")
print("nonzero constant term forces a0!=0")
print("s,u coefficients force 104*a1+3*b0=0 and 4*a2-b0=0")
print("then the u^2 coefficient is 144*a0^2: contradiction")
