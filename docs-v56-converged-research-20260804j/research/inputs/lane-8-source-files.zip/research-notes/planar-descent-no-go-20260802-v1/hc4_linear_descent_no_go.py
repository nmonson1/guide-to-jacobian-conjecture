#!/usr/bin/env python3
"""Exact no-go checks for descending the 5-variable Hessian counterexample to HC_4.

The five-variable potential is the Meng--Yang 2026 counterexample

    Psi = A^2 + 13 A + 2 B.

This script verifies three sharply scoped statements:

1. There is no nonzero constant linear direction c for which the second
   directional derivative c^T Hess(Psi)c is constant.  Hence the published
   one-variable Schur descent cannot simply be repeated after a linear change.
2. No affine linear hyperplane containing the two known collision points
   carries a four-variable restriction with nonzero constant Hessian
   determinant.  The four projective cases are exhausted exactly.
3. A birational partial Schur reduction does produce a polynomial
   four-variable near-example with a two-point gradient collision, but its
   Hessian determinant is 64*s^2.  After a linear change this is just the
   doubled planar fold (s,u)->((u^2-s^2)/2,4u); the missing constant-Jacobian
   condition is precisely the remaining planar obstruction.

All calculations are exact over Q.  This does not prove HC_4 or JC_2; it rules
out the most direct linear restriction/second-Schur descent of this particular
HC_5 counterexample.
"""
from __future__ import annotations

import itertools
import sympy as sp
from sympy.polys.domains import QQ
from sympy.polys.rings import ring

# ---------------------------------------------------------------------------
# Source potential and collision.
# ---------------------------------------------------------------------------
x1, x2, y1, y2, y3 = sp.symbols("x1 x2 y1 y2 y3")
u = 1 + x1 * x2
A = y1 * u**3 + 3 * x1 * y2 * u**2 - x1**3 * y3
B = (
    y1 * x2**2 * u * (4 + 3 * x1 * x2)
    + y2 * (x2 + 3 * x1 * x2**2 * (4 + 3 * x1 * x2))
    + y3 * (2 * x1 - 3 * x1**2 * x2)
)
Psi = sp.expand(A**2 + 13 * A + 2 * B)
vars5 = (x1, x2, y1, y2, y3)
P_plus = {x1: 1, x2: -sp.Rational(3, 2), y1: 0, y2: 0, y3: 0}
P_minus = {x1: -1, x2: sp.Rational(3, 2), y1: 0, y2: 0, y3: 0}
grad = [sp.diff(Psi, v) for v in vars5]
assert [g.subs(P_plus) for g in grad] == [g.subs(P_minus) for g in grad]

# ---------------------------------------------------------------------------
# 1. No second constant linear Schur direction.
# ---------------------------------------------------------------------------
H5 = sp.hessian(Psi, vars5)
columns: list[sp.Poly] = []
for i in range(5):
    for j in range(i, 5):
        entry = H5[i, j] if i == j else 2 * H5[i, j]
        columns.append(sp.Poly(entry, *vars5))
all_monomials = sorted(set().union(*(set(p.monoms()) for p in columns)))
nonconstant_monomials = [m for m in all_monomials if any(m)]
coefficient_matrix = sp.Matrix([
    [p.coeff_monomial(m) for p in columns]
    for m in nonconstant_monomials
])
assert coefficient_matrix.shape == (158, 15)
assert coefficient_matrix.rank() == 15

# ---------------------------------------------------------------------------
# Sparse exact determinant helper.
# ---------------------------------------------------------------------------
def permutation_sign(perm: tuple[int, ...]) -> int:
    inversions = sum(
        perm[i] > perm[j]
        for i in range(len(perm))
        for j in range(i + 1, len(perm))
    )
    return -1 if inversions % 2 else 1


def determinant4(R, matrix):
    value = R.zero
    for perm in itertools.permutations(range(4)):
        term = R.one
        for i in range(4):
            term *= matrix[i][perm[i]]
        value += permutation_sign(perm) * term
    return value

# Every affine hyperplane through P_+ and P_- has equation
#   3*s*x1 + 2*s*x2 + n3*y1+n4*y2+n5*y3=0.
# The four cases below cover projective [s:n3:n4:n5].

# Case 1: n5 != 0, normalize n5=1.
R1, X1, X2, Y1, Y2, S, aa, bb = ring(
    "x1,x2,y1,y2,s,a,b", QQ
)
Y3 = -(3 * S * X1 + 2 * S * X2 + aa * Y1 + bb * Y2)
U = 1 + X1 * X2
AA = Y1 * U**3 + 3 * X1 * Y2 * U**2 - X1**3 * Y3
BB = (
    Y1 * X2**2 * U * (4 + 3 * X1 * X2)
    + Y2 * (X2 + 3 * X1 * X2**2 * (4 + 3 * X1 * X2))
    + Y3 * (2 * X1 - 3 * X1**2 * X2)
)
PP = AA**2 + 13 * AA + 2 * BB
V = (X1, X2, Y1, Y2)
HH = [[PP.diff(vi).diff(vj) for vj in V] for vi in V]
det1 = determinant4(R1, HH)
assert len(det1.terms()) == 9397
assert det1[(0, 0, 1, 0, 0, 0, 0)] == -36504

# Case 2: n5=0, n4 != 0, normalize n4=1.
R2, X1, X2, Y1, Y3, S, aa = ring("x1,x2,y1,y3,s,a", QQ)
Y2 = -(3 * S * X1 + 2 * S * X2 + aa * Y1)
U = 1 + X1 * X2
AA = Y1 * U**3 + 3 * X1 * Y2 * U**2 - X1**3 * Y3
BB = (
    Y1 * X2**2 * U * (4 + 3 * X1 * X2)
    + Y2 * (X2 + 3 * X1 * X2**2 * (4 + 3 * X1 * X2))
    + Y3 * (2 * X1 - 3 * X1**2 * X2)
)
PP = AA**2 + 13 * AA + 2 * BB
V = (X1, X2, Y1, Y3)
HH = [[PP.diff(vi).diff(vj) for vj in V] for vi in V]
det2 = determinant4(R2, HH)
assert len(det2.terms()) == 3710
assert det2[(0, 0, 1, 0, 0, 0)] == -512

# Case 3: n5=n4=0, n3 != 0, normalize n3=1.
R3, X1, X2, Y2, Y3, S = ring("x1,x2,y2,y3,s", QQ)
Y1 = -(3 * S * X1 + 2 * S * X2)
U = 1 + X1 * X2
AA = Y1 * U**3 + 3 * X1 * Y2 * U**2 - X1**3 * Y3
BB = (
    Y1 * X2**2 * U * (4 + 3 * X1 * X2)
    + Y2 * (X2 + 3 * X1 * X2**2 * (4 + 3 * X1 * X2))
    + Y3 * (2 * X1 - 3 * X1**2 * X2)
)
PP = AA**2 + 13 * AA + 2 * BB
V = (X1, X2, Y2, Y3)
HH = [[PP.diff(vi).diff(vj) for vj in V] for vi in V]
det3 = determinant4(R3, HH)
assert len(det3.terms()) == 950
assert det3[(1, 1, 0, 0, 0)] == 2688

# Case 4: n3=n4=n5=0, hence s != 0; set 3*x1+2*x2=0.
R4, X1, Y1, Y2, Y3 = ring("x1,y1,y2,y3", QQ)
X2 = -QQ(3, 2) * X1
U = 1 + X1 * X2
AA = Y1 * U**3 + 3 * X1 * Y2 * U**2 - X1**3 * Y3
BB = (
    Y1 * X2**2 * U * (4 + 3 * X1 * X2)
    + Y2 * (X2 + 3 * X1 * X2**2 * (4 + 3 * X1 * X2))
    + Y3 * (2 * X1 - 3 * X1**2 * X2)
)
PP = AA**2 + 13 * AA + 2 * BB
V = (X1, Y1, Y2, Y3)
HH = [[PP.diff(vi).diff(vj) for vj in V] for vi in V]
det4 = determinant4(R4, HH)
assert det4 == R4.zero

# ---------------------------------------------------------------------------
# 3. Birational Schur near-descent: a polynomial four-variable fold.
# ---------------------------------------------------------------------------
s, xx, yy, zz = sp.symbols("s x y z")
Phi = sp.expand(
    (
        -16 * s**4 + 48 * s**3 * xx - 36 * s**2 * xx**2
        + 16 * s**2 * yy + 104 * s**2 + 24 * s * xx * yy
        - 156 * s * xx + 48 * s * zz + 8 * xx**2 * yy
        + 32 * xx * zz - 169
    ) / 4
)
vars4 = (s, xx, yy, zz)
assert sp.factor(sp.hessian(Phi, vars4).det()) == 64 * s**2
q_plus = {s: 1, xx: -sp.Rational(3, 2), yy: 0, zz: 0}
q_minus = {s: -1, xx: sp.Rational(3, 2), yy: 0, zz: 0}
grad4 = [sp.diff(Phi, v) for v in vars4]
assert [g.subs(q_plus) for g in grad4] == [g.subs(q_minus) for g in grad4]

# Phi=phi0(s,x)+y*f(s,x)+z*g(s,x).  Its Hessian determinant is the square
# of the planar Jacobian of (f,g).
f = sp.diff(Phi, yy)
g = sp.diff(Phi, zz)
Jfg = sp.factor(sp.det(sp.Matrix([
    [sp.diff(f, s), sp.diff(f, xx)],
    [sp.diff(g, s), sp.diff(g, xx)],
])))
assert Jfg == -8 * s
assert sp.expand(sp.hessian(Phi, vars4).det() - Jfg**2) == 0
new_u = sp.symbols("u")
assert sp.expand(f.subs(xx, (new_u - 3 * s) / 2) - (new_u**2 - s**2) / 2) == 0
assert sp.expand(g.subs(xx, (new_u - 3 * s) / 2) - 4 * new_u) == 0

print("Directional-second-derivative coefficient matrix: 158 x 15, rank 15")
print("Hyperplane cases: coefficients -36504, -512, 2688; final case determinant 0")
print("No linear hyperplane through the collision yields nonzero constant Hessian")
print("Birational four-variable near-descent: det Hess = 64*s^2")
print("Underlying planar fold: ((u^2-s^2)/2, 4u), Jacobian -8s")
