#!/usr/bin/env python3
"""No planar Keller descent from a polynomial graph y=h(x,z).

For the 2026 three-dimensional Keller counterexample F=(F1,F2,F3), this
script computes the three restricted 2x2 Jacobians on y=h(x,z).  It verifies
the degree argument proving that no nonzero Pluecker combination can be a
nonzero constant, for any polynomial h and any rank-two linear target
projection.

Together with three_dimensional_descent_no_go.py, this covers polynomial
graphs over each of the three coordinate planes.
"""
from __future__ import annotations

import sympy as sp

x, y, z = sp.symbols("x y z")
u = 1 + x * y
F1 = sp.expand(u**3 * z + y**2 * u * (4 + 3 * x * y))
F2 = sp.expand(y + 3 * x * u**2 * z + 3 * x * y**2 * (4 + 3 * x * y))
F3 = sp.expand(2 * x - 3 * x**2 * y - x**3 * z)
Fs = (F1, F2, F3)

G, Gx, Gz = sp.symbols("G Gx Gz")
gfun = sp.Function("g")(x, z)


def restricted_jacobian(i: int, j: int) -> sp.Expr:
    fi = Fs[i].subs(y, gfun)
    fj = Fs[j].subs(y, gfun)
    value = sp.det(sp.Matrix([
        [sp.diff(fi, x), sp.diff(fi, z)],
        [sp.diff(fj, x), sp.diff(fj, z)],
    ]))
    return sp.expand(value.subs({
        gfun: G,
        sp.diff(gfun, x): Gx,
        sp.diff(gfun, z): Gz,
    }))


J12 = restricted_jacobian(0, 1)
J13 = restricted_jacobian(0, 2)
J23 = restricted_jacobian(1, 2)


def highest_g_slope(expr: sp.Expr) -> sp.Expr:
    """Highest degree in G,Gx,Gz; ties by actual base-degree intercept."""
    poly = sp.Poly(expr, x, z, G, Gx, Gz)
    data = []
    for mon, coeff in poly.terms():
        ex, ez, e_g, e_gx, e_gz = mon
        slope = e_g + e_gx + e_gz
        intercept = ex + ez - e_gx - e_gz
        data.append((slope, intercept, mon, coeff))
    max_slope = max(item[0] for item in data)
    max_intercept = max(item[1] for item in data if item[0] == max_slope)
    out = 0
    for slope, intercept, mon, coeff in data:
        if slope == max_slope and intercept == max_intercept:
            ex, ez, e_g, e_gx, e_gz = mon
            out += coeff * x**ex * z**ez * G**e_g * Gx**e_gx * Gz**e_gz
    return sp.expand(out)


assert sp.factor(highest_g_slope(J12)) == -54 * G**6 * Gz * x**3
assert sp.factor(highest_g_slope(J13)) == 54 * G**4 * Gz * x**3
assert sp.factor(highest_g_slope(J23)) == 108 * G**3 * Gz * x**3

# Hence the leading homogeneous form h_d must satisfy d_z h_d=0 whenever
# the corresponding Pluecker coefficient is the first nonzero one.  Thus
# h_d=c*x^d.  Direct substitution gives a nonzero next leading term.  The
# d=1,2 cases are exceptional only in which equal-degree terms tie; d>=3 has
# the uniform monomial listed below.
c = sp.symbols("c", nonzero=True)
expected = {
    1: (
        3 * c**5 * x**10 * z,
        -3 * c**3 * x**8 * z,
        -6 * c**2 * x**7 * z,
    ),
    2: (
        6 * c**5 * x**15 * (3 * c * x + z),
        -6 * c**3 * x**11 * (3 * c * x + z),
        -12 * c**2 * x**9 * (3 * c * x + z),
    ),
}
for degree in (1, 2):
    for expr, target in zip((J12, J13, J23), expected[degree]):
        specialized = sp.Poly(
            sp.expand(expr.subs({
                G: c * x**degree,
                Gx: c * degree * x**(degree - 1),
                Gz: 0,
            })),
            x,
            z,
        )
        top_degree = max(sum(mon) for mon, _ in specialized.terms())
        top = sum(
            coeff * x**mon[0] * z**mon[1]
            for mon, coeff in specialized.terms()
            if sum(mon) == top_degree
        )
        assert sp.expand(top - target) == 0

for degree in range(3, 10):
    targets = (
        9 * degree * c**6 * x**(6 * degree + 4),
        -9 * degree * c**4 * x**(4 * degree + 4),
        -18 * degree * c**3 * x**(3 * degree + 4),
    )
    for expr, target in zip((J12, J13, J23), targets):
        specialized = sp.Poly(
            sp.expand(expr.subs({
                G: c * x**degree,
                Gx: c * degree * x**(degree - 1),
                Gz: 0,
            })),
            x,
            z,
        )
        top_degree = max(sum(mon) for mon, _ in specialized.terms())
        top = sum(
            coeff * x**mon[0] * z**mon[1]
            for mon, coeff in specialized.terms()
            if sum(mon) == top_degree
        )
        assert sp.expand(top - target) == 0

# Constant h: coefficients z, x, and x^2*z successively kill the three
# Pluecker coordinates (the target constant is allowed in the (0,0) term).
h0, l12, l13, l23 = sp.symbols("h0 l12 l13 l23")
combination = sp.Poly(sp.expand(
    l12 * J12.subs({G: h0, Gx: 0, Gz: 0})
    + l13 * J13.subs({G: h0, Gx: 0, Gz: 0})
    + l23 * J23.subs({G: h0, Gx: 0, Gz: 0})
), x, z)
assert combination.coeff_monomial(z) == -3 * l12
assert sp.factor(combination.coeff_monomial(x).subs(l12, 0)) == -6 * l23
assert sp.factor(
    combination.coeff_monomial(x**2 * z).subs({l12: 0, l23: 0})
) == 3 * l13

print("y=h(x,z): every nonconstant leading form is excluded by degree")
print("constant h: z, x, x^2*z coefficients force all Pluecker coordinates zero")
print("No polynomial y-graph with a rank-two linear target projection is Keller")
