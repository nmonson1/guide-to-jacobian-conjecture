#!/usr/bin/env python3
"""Independent exact Hurwitz count for the forced degree-21 Lane 8 face.

The Murnaghan--Nakayama implementation is self-contained and uses no data from
the Program 6 computational supplement.
"""
from __future__ import annotations

from collections import Counter
from fractions import Fraction
from functools import lru_cache
from itertools import permutations
from math import factorial
from typing import Iterable

Partition = tuple[int, ...]


@lru_cache(None)
def partitions_with_bound(n: int, max_part: int) -> tuple[Partition, ...]:
    if n == 0:
        return ((),)
    if max_part <= 0:
        return ()
    result: list[Partition] = []
    for first in range(min(n, max_part), 0, -1):
        for rest in partitions_with_bound(n - first, first):
            result.append((first,) + rest)
    return tuple(result)


def partitions(n: int) -> tuple[Partition, ...]:
    return partitions_with_bound(n, n)


def contains(lam: Partition, mu: Partition) -> bool:
    rows = max(len(lam), len(mu))
    return all(
        (mu[i] if i < len(mu) else 0) <= (lam[i] if i < len(lam) else 0)
        for i in range(rows)
    )


def border_strip_height(lam: Partition, mu: Partition) -> int | None:
    cells = {
        (row, col)
        for row, length in enumerate(lam)
        for col in range(mu[row] if row < len(mu) else 0, length)
    }
    if not cells:
        return None

    seen = {next(iter(cells))}
    stack = list(seen)
    while stack:
        row, col = stack.pop()
        for neighbor in ((row - 1, col), (row + 1, col), (row, col - 1), (row, col + 1)):
            if neighbor in cells and neighbor not in seen:
                seen.add(neighbor)
                stack.append(neighbor)
    if len(seen) != len(cells):
        return None

    for row, col in cells:
        if {
            (row, col),
            (row + 1, col),
            (row, col + 1),
            (row + 1, col + 1),
        } <= cells:
            return None
    return len({row for row, _ in cells}) - 1


@lru_cache(None)
def border_strip_removals(lam: Partition, size: int) -> tuple[tuple[Partition, int], ...]:
    remaining = sum(lam) - size
    if remaining < 0:
        return ()
    result = []
    for mu in partitions(remaining):
        if contains(lam, mu):
            height = border_strip_height(lam, mu)
            if height is not None:
                result.append((mu, height))
    return tuple(result)


@lru_cache(None)
def character(lam: Partition, cycle_type: Partition) -> int:
    if not cycle_type:
        return int(sum(lam) == 0)
    first = cycle_type[0]
    return sum(
        (-1) ** height * character(mu, cycle_type[1:])
        for mu, height in border_strip_removals(lam, first)
    )


def representation_dimension(lam: Partition) -> int:
    n = sum(lam)
    hook_product = 1
    for row, row_length in enumerate(lam):
        for col in range(row_length):
            below = sum(1 for lower_row in lam[row + 1 :] if lower_row > col)
            hook_product *= row_length - col + below
    return factorial(n) // hook_product


def centralizer_size(cycle_type: Iterable[int]) -> int:
    multiplicities = Counter(cycle_type)
    result = 1
    for length, multiplicity in multiplicities.items():
        result *= length**multiplicity * factorial(multiplicity)
    return result


def conjugacy_class_size(cycle_type: Partition) -> int:
    return factorial(sum(cycle_type)) // centralizer_size(cycle_type)


def weighted_hurwitz_number(c0: Partition, c1: Partition, cinfinity: Partition) -> Fraction:
    n = sum(c0)
    assert sum(c1) == n == sum(cinfinity)
    character_sum = Fraction(0)
    for lam in partitions(n):
        character_sum += Fraction(
            character(lam, c0) * character(lam, c1) * character(lam, cinfinity),
            representation_dimension(lam),
        )
    prefactor = Fraction(
        conjugacy_class_size(c0) * conjugacy_class_size(c1) * conjugacy_class_size(cinfinity),
        factorial(n) ** 2,
    )
    return prefactor * character_sum


def compose(left: tuple[int, ...], right: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(left[right[i]] for i in range(len(left)))


def cycle_type(permutation: tuple[int, ...]) -> tuple[int, ...]:
    seen: set[int] = set()
    lengths: list[int] = []
    for start in range(len(permutation)):
        if start in seen:
            continue
        current = start
        length = 0
        while current not in seen:
            seen.add(current)
            length += 1
            current = permutation[current]
        lengths.append(length)
    return tuple(sorted(lengths, reverse=True))


def check_transitivity_obstruction() -> None:
    # Any disconnected degree-21 triple with a 17-cycle and seven 3-cycles
    # would split as 18+3. On the three-point orbit, the cycle types would be
    # (2,1), (3), and identity. No such three permutations multiply to one.
    s3 = tuple(permutations(range(3)))
    identity = (0, 1, 2)
    transpositions = [p for p in s3 if cycle_type(p) == (2, 1)]
    three_cycles = [p for p in s3 if cycle_type(p) == (3,)]
    assert not any(compose(compose(a, b), identity) == identity for a in transpositions for b in three_cycles)


def main() -> None:
    c0 = (2,) * 10 + (1,)
    c1 = (3,) * 7
    cinfinity = (17,) + (1,) * 4
    value = weighted_hurwitz_number(c0, c1, cinfinity)
    assert value == 5
    print(f"weighted Hurwitz number for (2^10 1),(3^7),(17 1^4): {value}")

    check_transitivity_obstruction()
    print("disconnected 18+3 orbit decomposition excluded by an exact S3 check")

    # Parity and block-size conditions used by the stated Jordan argument.
    assert (-1) ** (21 - len(c0)) == 1
    assert (-1) ** (21 - len(c1)) == 1
    assert (-1) ** (21 - len(cinfinity)) == 1
    assert [d for d in range(2, 21) if 21 % d == 0] == [3, 7]
    assert 17 > 7 and 17 > 3 and 17 <= 21 - 3
    print("parity, primitivity block-size, and Jordan prime-cycle hypotheses checked")
    print("PASS: the weighted count is five connected classes; the standard Jordan argument gives monodromy A_21")


if __name__ == "__main__":
    main()
