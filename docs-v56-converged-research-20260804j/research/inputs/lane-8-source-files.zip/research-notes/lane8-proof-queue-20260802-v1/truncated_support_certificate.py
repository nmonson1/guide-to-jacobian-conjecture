#!/usr/bin/env python3
"""Exact independent certificate for the truncated (8,28) Newton root.

The script reconstructs the quintic degree-21 face, solves the complete
truncated normal-layer system over the exact number field, and proves that
the required top P and Q vertex coefficients vanish on every solution.

No Program 6 terminal archive is read.
"""
from __future__ import annotations
from fractions import Fraction
import argparse
import json
from pathlib import Path
import sympy as sp
import quintic_face_reconstruction as qr

class K:
    __slots__=('c',)
    def __init__(self,c=(0,0,0,0,0)):
        if isinstance(c,K): self.c=c.c
        elif isinstance(c,(int,Fraction)): self.c=(Fraction(c),Fraction(0),Fraction(0),Fraction(0),Fraction(0))
        else:
            cc=tuple(Fraction(x) for x in c); self.c=cc+(Fraction(0),)*(5-len(cc))
    @staticmethod
    def from_expr(e):
        e=qr.reduce_field(e); p=sp.Poly(e,qr.s,domain=sp.QQ)
        return K(tuple(Fraction(int(p.nth(i).p),int(p.nth(i).q)) for i in range(5)))
    def expr(self): return sum(sp.Rational(x.numerator,x.denominator)*qr.s**i for i,x in enumerate(self.c))
    def __add__(self,o):
        o=K(o); return K(tuple(a+b for a,b in zip(self.c,o.c)))
    __radd__=__add__
    def __neg__(self):return K(tuple(-a for a in self.c))
    def __sub__(self,o):return self+(-K(o))
    def __rsub__(self,o):return K(o)-self
    def __mul__(self,o):
        o=K(o); conv=[Fraction(0)]*9
        for i,a in enumerate(self.c):
            for j,b in enumerate(o.c):conv[i+j]+=a*b
        # relation L s5 = 688...s4 -640...s3 +292...s2 -655...s +5817...
        L=287548593020928
        rel=[Fraction(5817852446211,L),Fraction(-65563255857792,L),Fraction(292066554895024,L),Fraction(-640652914818432,L),Fraction(688401965085696,L)]
        for d in range(8,4,-1):
            x=conv[d]
            if x:
                conv[d]=0
                for i,r in enumerate(rel):conv[d-5+i]+=x*r
        return K(tuple(conv[:5]))
    __rmul__=__mul__
    def inv(self):
        if not self:raise ZeroDivisionError
        e=sp.invert(sp.Poly(self.expr(),qr.s,domain=sp.QQ),qr.M).as_expr()
        return K.from_expr(e)
    def __truediv__(self,o):return self*K(o).inv()
    def __bool__(self):return any(self.c)
    def __eq__(self,o):return self.c==K(o).c
    def mod(self,p,s0):
        ans=0
        for i,x in enumerate(self.c):ans=(ans+(x.numerator%p)*pow(x.denominator%p,-1,p)*pow(s0,i,p))%p
        return ans
    def __repr__(self):return str(self.expr())
ZERO=K();ONE=K(1)

# parameter polynomial six vars exponents tuple
N=6
def pp_const(c):
 c=K(c);return {} if not c else {(0,)*N:c}
def pp_var(i):
 e=[0]*N;e[i]=1;return {tuple(e):ONE}
def pp_add(*aa):
 out={}
 for a in aa:
  for m,c in a.items():
   v=out.get(m,ZERO)+c
   if v:out[m]=v
   elif m in out:del out[m]
 return out
def pp_neg(a):return {m:-c for m,c in a.items()}
def pp_sub(a,b):return pp_add(a,pp_neg(b))
def pp_scale(a,c):
 c=K(c);return {m:c*v for m,v in a.items() if c*v}
def pp_mul(a,b):
 out={}
 for m,c in a.items():
  for n,d in b.items():
   k=tuple(x+y for x,y in zip(m,n));v=out.get(k,ZERO)+c*d
   if v:out[k]=v
   elif k in out:del out[k]
 return out

def zadd(*aa):
 out={}
 for a in aa:
  for k,v in a.items():
   w=pp_add(out.get(k,{}),v)
   if w:out[k]=w
   elif k in out:del out[k]
 return out
def zscale(a,c):return {k:pp_scale(v,c) for k,v in a.items() if pp_scale(v,c)}
def zder(a):return {k-1:pp_scale(v,k) for k,v in a.items() if k and pp_scale(v,k)}
def zmul(a,b):
 out={}
 for i,x in a.items():
  for j,y in b.items():
   out[i+j]=pp_add(out.get(i+j,{}),pp_mul(x,y))
 return {k:v for k,v in out.items() if v}

def z_from_field(d):return {k:pp_const(v) for k,v in d.items() if v}

def rref_transform(mat):
 m=len(mat);n=len(mat[0]);R=[[K(x) for x in row] for row in mat];T=[[ONE if i==j else ZERO for j in range(m)] for i in range(m)]
 piv=[];row=0
 for col in range(n):
  pr=next((r for r in range(row,m) if R[r][col]),None)
  if pr is None:continue
  R[row],R[pr]=R[pr],R[row];T[row],T[pr]=T[pr],T[row]
  inv=R[row][col].inv();R[row]=[x*inv for x in R[row]];T[row]=[x*inv for x in T[row]]
  for r in range(m):
   if r!=row and R[r][col]:
    c=R[r][col];R[r]=[R[r][j]-c*R[row][j] for j in range(n)];T[r]=[T[r][j]-c*T[row][j] for j in range(m)]
  piv.append(col);row+=1
  if row==m:break
 return R,T,piv

def Dmap(r,A,B,A0,B0):
 return zadd(zscale(zmul(A,zder(B0)),2-r),zscale(zmul(zder(A),B0),-3),zscale(zmul(A0,zder(B)),2),zscale(zmul(zder(A0),B),r-3))
def linear_data(r,ae,be,A0,B0):
 cols=[]
 for e in ae:cols.append(Dmap(r,{e:pp_const(1)},{},A0,B0))
 for e in be:cols.append(Dmap(r,{}, {e:pp_const(1)},A0,B0))
 ds=sorted(set().union(*(x.keys() for x in cols)));degrees=list(range(min(ds),max(ds)+1))
 M=[]
 for d in degrees:
  row=[]
  for col in cols:
   pp=col.get(d,{})
   row.append(pp.get((0,)*N,ZERO))
  M.append(row)
 R,T,piv=rref_transform(M);free=[j for j in range(len(M[0])) if j not in piv]
 ns=[]
 for f in free:
  v=[ZERO]*len(M[0]);v[f]=ONE
  for i,pc in enumerate(piv):v[pc]=-R[i][f]
  ns.append(v)
 return degrees,M,R,T,piv,free,ns

def solve(data,rhs,freepps):
 degrees,M,R,T,piv,free,ns=data
 rv=[rhs.get(d,{}) for d in degrees]
 tr=[]
 for i in range(len(degrees)):
  tr.append(pp_add(*(pp_scale(rv[j],T[i][j]) for j in range(len(degrees)))))
 compat=tr[len(piv):]
 sol=[{} for _ in range(len(M[0]))]
 for i,pc in enumerate(piv):sol[pc]=tr[i]
 for par,v in zip(freepps,ns):
  for j,c in enumerate(v):
   if c:sol[j]=pp_add(sol[j],pp_scale(par,c))
 return sol,compat

def vecpair(vec,ae,be):
 return ({e:vec[i] for i,e in enumerate(ae) if vec[i]},{e:vec[len(ae)+j] for j,e in enumerate(be) if vec[len(ae)+j]})


def rank_mod(rows, prime):
 if not rows:return 0
 a=[[x%prime for x in row] for row in rows];m=len(a);n=len(a[0]);rank=0
 for col in range(n):
  pivot=next((r for r in range(rank,m) if a[r][col]),None)
  if pivot is None:continue
  a[rank],a[pivot]=a[pivot],a[rank]
  inv=pow(a[rank][col],-1,prime)
  a[rank]=[(x*inv)%prime for x in a[rank]]
  for r in range(m):
   if r!=rank and a[r][col]:
    c=a[r][col]
    a[r]=[(a[r][j]-c*a[rank][j])%prime for j in range(n)]
  rank+=1
  if rank==m:break
 return rank

def determinant_mod(matrix, prime):
 a=[[x%prime for x in row] for row in matrix];n=len(a);det=1
 assert all(len(row)==n for row in a)
 for col in range(n):
  pivot=next((r for r in range(col,n) if a[r][col]),None)
  if pivot is None:return 0
  if pivot!=col:
   a[col],a[pivot]=a[pivot],a[col];det=-det
  pv=a[col][col]%prime;det=det*pv%prime;inv=pow(pv,-1,prime)
  for r in range(col+1,n):
   c=a[r][col]*inv%prime
   a[r]=[(a[r][j]-c*a[col][j])%prime for j in range(n)]
 return det%prime

def build_certificate():
 # Exact lower face in Q(s).
 a={i:K.from_expr(v) for i,v in qr.A_RAW.items()}
 reverse_p=[ONE]+[a[i] for i in range(1,8)]
 cube=[]
 for total in range(21):
  c=ZERO
  for i in range(8):
   for j in range(8):
    for k in range(8):
     if i+j+k==total:c=c+reverse_p[i]*reverse_p[j]*reverse_p[k]
  cube.append(c)
 reverse_q=[ONE]
 for total in range(1,11):
  known=ZERO
  for i in range(1,total):known=known+reverse_q[i]*reverse_q[total-i]
  reverse_q.append((cube[total]-known)/K(2))
 face_constant=a[7]*reverse_q[10];inverse_constant=face_constant.inv()
 pcoef={7:ONE};pcoef.update({7-i:a[i] for i in range(1,8)})
 qcoef={10:inverse_constant};qcoef.update({10-i:reverse_q[i]*inverse_constant for i in range(1,11)})
 A0=z_from_field({k+1:v for k,v in pcoef.items()})
 B0=z_from_field({k+2:v for k,v in qcoef.items()})

 X,Y,U,V,W,D=[pp_var(i) for i in range(6)]
 data1=linear_data(1,list(range(1,9)),list(range(2,13)),A0,B0)
 assert len(data1[4])==17 and data1[5]==[17,18]
 sol1,compat1=solve(data1,{},[X,Y]);assert all(not equation for equation in compat1)
 A1,B1=vecpair(sol1,list(range(1,9)),list(range(2,13)))

 forcing2=zadd(zmul(A1,zder(B1)),zscale(zmul(zder(A1),B1),-2))
 data2=linear_data(2,list(range(0,9)),list(range(1,13)),A0,B0)
 assert len(data2[4])==18 and data2[5]==[0,19,20]
 sol2,compat2=solve(data2,zscale(forcing2,-1),[U,V,W])
 assert all(not equation for equation in compat2)
 A2,B2=vecpair(sol2,list(range(0,9)),list(range(1,13)))

 forcing3=zadd(zmul(A1,zder(B2)),zscale(zmul(zder(A1),B2),-1),zscale(zmul(zder(A2),B1),-2))
 data3=linear_data(3,[],list(range(0,13)),A0,B0)
 assert len(data3[4])==12 and data3[5]==[0]
 sol3,compat3=solve(data3,zscale(forcing3,-1),[D])
 _,B3=vecpair(sol3,[],list(range(0,13)))
 assert len(compat3)==7

 E4=zadd(zmul(A1,zder(B3)),zscale(zmul(zder(A2),B2),-1))
 assert sorted(E4)==list(range(2,20)) and len(E4)==18

 # U,D are free origin-vertex coefficients. Compatibility uses only X,Y,V,W.
 for equation in compat3+list(E4.values()):
  assert all(m[2]==0 and m[5]==0 for m in equation)
  weights={sum((m[0],m[1],m[3]*2,m[4]*2)) for m in equation}
  assert len(weights)==1 and next(iter(weights)) in (3,4)

 m4=[
  (4,0,0,0,0,0),(3,1,0,0,0,0),(2,2,0,0,0,0),(1,3,0,0,0,0),(0,4,0,0,0,0),
  (2,0,0,1,0,0),(1,1,0,1,0,0),(0,2,0,1,0,0),
  (2,0,0,0,1,0),(1,1,0,0,1,0),(0,2,0,0,1,0),
  (0,0,0,2,0,0),(0,0,0,1,1,0),(0,0,0,0,2,0),
 ]
 equations=[];labels=[]
 for i,equation in enumerate(compat3):
  equations.extend([pp_mul(X,equation),pp_mul(Y,equation)])
  labels.extend([f'X*layer3[{i}]',f'Y*layer3[{i}]'])
 for degree in sorted(E4):
  equations.append(E4[degree]);labels.append(f'layer4[z^{degree}]')
 kmatrix=[[equation.get(m,ZERO) for m in m4] for equation in equations]

 prime=2053;u_value=216
 num,den=sp.fraction(sp.cancel(qr.S_IN_K0.subs(qr.u,u_value)))
 s_value=int(num)%prime*pow(int(den)%prime,-1,prime)%prime
 assert int(qr.K0_EXPR.subs(qr.u,u_value))%prime==0
 assert int(sp.diff(qr.K0_EXPR,qr.u).subs(qr.u,u_value))%prime!=0
 assert int(qr.M_EXPR.subs(qr.s,s_value))%prime==0
 matrix=[[coefficient.mod(prime,s_value) for coefficient in row] for row in kmatrix]
 selected=[]
 for i,row in enumerate(matrix):
  if rank_mod([matrix[j] for j in selected]+[row],prime)>len(selected):selected.append(i)
  if len(selected)==14:break
 assert len(selected)==14
 determinant=determinant_mod([matrix[i] for i in selected],prime)
 assert determinant

 # Exact top vertices are in the radical (X,Y,V,W).
 for top in (A2[8],B3[12]):
  assert top and (0,0,0,0,0,0) not in top
  assert all(m[2]==0 and m[5]==0 for m in top)

 return {
  'schema_version':1,
  'field':{
   'reconstructed':sp.sstr(qr.M_EXPR),
   'public_model':sp.sstr(qr.K0_EXPR),
  },
  'linear_layers':{
   'D1':{'shape':[18,19],'rank':17,'free_columns':[17,18]},
   'D2':{'shape':[19,21],'rank':18,'free_columns':[0,19,20],'compatibility_zero':True},
   'D3':{'shape':[19,13],'rank':12,'free_columns':[0],'compatibility_count':7},
   'layer4_equation_count':18,
  },
  'effective_parameters':{'names':['X','Y','V','W'],'weights':[1,1,2,2],
                          'free_origin_vertices':['U','D']},
  'degree_four_span':{
   'basis_dimension':14,'equation_rows':32,'rank':14,
   'good_reduction':{'prime':prime,'u':u_value,'s':s_value,
                     'selected_row_indices':selected,
                     'selected_row_labels':[labels[i] for i in selected],
                     'minor_determinant':determinant},
  },
  'conclusion':{
   'P_top_vertex':'A2 coefficient of z^8, exponent (8,16)',
   'Q_top_vertex':'B3 coefficient of z^12, exponent (12,24)',
   'both_vanish_on_geometric_zero_set':True,
   'vertex_saturated_truncated_locus_empty':True,
  },
 }

def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--output',type=Path)
 args=parser.parse_args()
 result=build_certificate()
 if args.output:
  args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
 witness=result['degree_four_span']['good_reduction']
 print('exact layer ranks: D1=17, D2=18, D3=12')
 print('compatibility equations: 7 at weight 3 and 18 at weight 4')
 print('effective parameter weights: X,Y,V,W = 1,1,2,2')
 print(f"weighted-degree-four span: rank 14/14; determinant {witness['minor_determinant']} mod 2053")
 print('required top P and Q vertex coefficients vanish on every solution')
 if args.output:print(f'certificate export: {args.output.name}')
 print('PASS: the vertex-saturated truncated Newton root is empty')

if __name__=='__main__':main()
