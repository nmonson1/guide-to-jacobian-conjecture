#!/usr/bin/env python3
"""Exact reconstruction of the five normalized degree-21 face covers.

This script is independent of the large Program 6 certificate archive.  It
works in the explicitly reconstructed quintic field Q(s), builds normalized
polynomials p and q, checks the order-17 Belyi contact, normalizes the face
Jacobian equation to 1, and verifies an exact isomorphism with the quintic
field model used by the public Program 6 source.

The normalization is

    p(z) = z^7 + z^6 + s z^5 + ...,
    q_monic(z) = z^10 + (3/2) z^9 + ... .

The unique simple point over 0 and the unique index-17 point over the third
branch value fix 0 and infinity on the source.  The remaining source scaling
is killed by the coefficient of z^6 in p being 1.  Thus the five embeddings
of the irreducible quintic give five distinct normalized covers.  Combined
with the independent Hurwitz count of five, they exhaust the dessin classes
and form one Galois orbit.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable

import sympy as sp

s, z, u = sp.symbols("s z u")

# Positive-leading defining polynomial of the reconstructed coefficient field.
M_EXPR = (
    287548593020928 * s**5
    - 688401965085696 * s**4
    + 640652914818432 * s**3
    - 292066554895024 * s**2
    + 65563255857792 * s
    - 5817852446211
)
M = sp.Poly(M_EXPR, s, domain=sp.QQ)

# Public Program 6 field model.
K0_EXPR = u**5 - u**4 + 3 * u**3 + 3 * u**2 + 26
K0 = sp.Poly(K0_EXPR, u, domain=sp.QQ)

# Exact embedding of the reconstructed primitive element into K0.
S_IN_K0 = (
    20481190
    - 2578004 * u
    + 1664322 * u**2
    - 709604 * u**3
    + 221083 * u**4
) / sp.Integer(42799752)

# Coefficients a_i of p(z)=z^7+a_1 z^6+...+a_7.
A_RAW: dict[int, sp.Expr] = {
    1: sp.Integer(1),
    2: s,
    3: (
        3771978574908902400 * s**4
        - 7556165936778735360 * s**3
        + 5450946367591254384 * s**2
        - 1699030592727011128 * s
        + 194711288931974931
    )
    / sp.Integer(2789916527204736),
    4: 7
    * (
        1472867824488238080 * s**4
        - 2950502889599315712 * s**3
        + 2129064709044490224 * s**2
        - 664388468462807608 * s
        + 76242600010205835
    )
    / sp.Integer(11159666108818944),
    5: 7
    * (
        1898608366334131200 * s**4
        - 3803361970401319680 * s**3
        + 2745126606514279984 * s**2
        - 857130636468363480 * s
        + 98443252126745919
    )
    / sp.Integer(66957996652913664),
    6: (
        5513086784810050560 * s**4
        - 11023906566235965696 * s**3
        + 7949047218967327952 * s**2
        - 2481117197487437928 * s
        + 284986511308009521
    )
    / sp.Integer(401747979917481984),
    7: (
        2473699609838592 * s**4
        - 4880250718447104 * s**3
        + 3484831588909616 * s**2
        - 1079655594514872 * s
        + 123291106405875
    )
    / sp.Integer(15858472891479552),
}


def reduce_field(expr: sp.Expr) -> sp.Expr:
    """Reduce a rational function in s to the degree-<5 basis of Q(s)."""
    expr = sp.cancel(expr)
    numerator, denominator = sp.fraction(expr)
    denominator_poly = sp.Poly(denominator, s, domain=sp.QQ)
    try:
        inverse = sp.invert(denominator_poly, M).as_expr()
    except sp.polys.polyerrors.NotInvertible as exc:
        raise ValueError(f"denominator is zero in Q(s): {denominator}") from exc
    reduced = sp.rem(
        sp.Poly(sp.expand(numerator * inverse), s, domain=sp.QQ), M
    ).as_expr()
    return sp.cancel(reduced)


def reduce_z_coefficients(expr: sp.Expr) -> sp.Poly:
    """Reduce every z coefficient of expr in the field Q(s)."""
    polynomial = sp.Poly(sp.expand(expr), z)
    result = sp.Integer(0)
    for (power,), coefficient in polynomial.terms():
        result += reduce_field(coefficient) * z**power
    return sp.Poly(sp.expand(result), z)


def coefficient_list_descending(poly: sp.Poly, degree: int) -> list[sp.Expr]:
    return [reduce_field(poly.coeff_monomial(z**power)) for power in range(degree, -1, -1)]


def expression_strings(values: Iterable[sp.Expr]) -> list[str]:
    return [sp.sstr(sp.factor(value)) for value in values]


def reconstruct() -> dict[str, object]:
    assert M.degree() == 5 and M.is_irreducible
    assert K0.degree() == 5 and K0.is_irreducible

    a = {index: reduce_field(value) for index, value in A_RAW.items()}
    p = sp.Poly(z**7 + sum(a[i] * z ** (7 - i) for i in range(1, 8)), z)

    # Reverse-polynomial contact condition.  If
    # P(T)=1+a_1 T+...+a_7 T^7 and Q(T)=1+b_1 T+...+b_10 T^10,
    # solve Q(T)^2=P(T)^3 successively through degree 10.
    p_reverse = [sp.Integer(1)] + [a[i] for i in range(1, 8)]
    p_cube: list[sp.Expr] = []
    for total in range(21):
        coefficient = sum(
            p_reverse[i] * p_reverse[j] * p_reverse[k]
            for i in range(8)
            for j in range(8)
            for k in range(8)
            if i + j + k == total
        )
        p_cube.append(reduce_field(coefficient))

    q_reverse = [sp.Integer(1)]
    for total in range(1, 11):
        known = sum(q_reverse[i] * q_reverse[total - i] for i in range(1, total))
        q_reverse.append(reduce_field((p_cube[total] - known) / 2))

    # The remaining contact equations, degrees 11 through 16, produce M(s).
    contact_residuals: dict[int, sp.Expr] = {}
    for total in range(11, 17):
        q_square = sum(
            q_reverse[i] * q_reverse[total - i]
            for i in range(max(0, total - 10), min(10, total) + 1)
        )
        contact_residuals[total] = reduce_field(q_square - p_cube[total])
    assert all(value == 0 for value in contact_residuals.values())

    q_monic = sp.Poly(
        z**10 + sum(q_reverse[i] * z ** (10 - i) for i in range(1, 11)), z
    )

    # In z coordinates, order-17 contact at infinity means z*q^2-p^3 has
    # degree at most 4.
    belyi_residual = reduce_z_coefficients(z * q_monic.as_expr() ** 2 - p.as_expr() ** 3)
    nonzero_residual_degrees = sorted(
        power[0]
        for power, coefficient in belyi_residual.terms()
        if reduce_field(coefficient) != 0
    )
    assert nonzero_residual_degrees == [0, 1, 2, 3, 4]

    face_expression = reduce_z_coefficients(
        p.as_expr() * q_monic.as_expr()
        + 2 * z * p.as_expr() * sp.diff(q_monic.as_expr(), z)
        - 3 * z * sp.diff(p.as_expr(), z) * q_monic.as_expr()
    )
    nonzero_face_terms = [
        (power[0], reduce_field(coefficient))
        for power, coefficient in face_expression.terms()
        if reduce_field(coefficient) != 0
    ]
    assert len(nonzero_face_terms) == 1 and nonzero_face_terms[0][0] == 0
    face_constant = nonzero_face_terms[0][1]
    assert face_constant != 0
    assert reduce_field(p.nth(0) * q_monic.nth(0) - face_constant) == 0

    # Normalize q so the Jacobian face equation has right side 1.
    q_face_expr = sp.expand(q_monic.as_expr() / face_constant)
    normalized_face = reduce_z_coefficients(
        p.as_expr() * q_face_expr
        + 2 * z * p.as_expr() * sp.diff(q_face_expr, z)
        - 3 * z * sp.diff(p.as_expr(), z) * q_face_expr
    )
    assert normalized_face.as_expr() == 1
    assert reduce_field(p.nth(0) * q_monic.nth(0) / face_constant) == 1

    # Verify exact compatibility with the public K0 field model.
    map_numerator, _ = sp.fraction(sp.cancel(M_EXPR.subs(s, S_IN_K0)))
    map_remainder = sp.rem(sp.Poly(map_numerator, u, domain=sp.QQ), K0).as_expr()
    assert map_remainder == 0
    # Since both defining polynomials are irreducible of degree five and the
    # image is visibly nonconstant, this homomorphism is an isomorphism.
    assert sp.Poly(sp.together(S_IN_K0).as_numer_denom()[0], u).degree() > 0

    p_coefficients = coefficient_list_descending(p, 7)
    q_coefficients = coefficient_list_descending(q_monic, 10)

    return {
        "schema_version": 1,
        "normalization": {
            "p": "monic degree 7 with coefficient of z^6 equal to 1",
            "q_monic": "monic degree 10",
            "q_face": "q_monic / face_constant, so pq+2zpq'-3zp'q=1",
            "source_scaling": "fixed by the coefficient of z^6 in p",
        },
        "reconstructed_field": {
            "generator": "s",
            "defining_polynomial": sp.sstr(M_EXPR),
            "degree": 5,
            "irreducible_over_Q": True,
        },
        "public_program6_field": {
            "generator": "u",
            "defining_polynomial": sp.sstr(K0_EXPR),
            "degree": 5,
            "irreducible_over_Q": True,
            "field_isomorphism_s_in_terms_of_u": sp.sstr(S_IN_K0),
        },
        "p_coefficients_descending": expression_strings(p_coefficients),
        "q_monic_coefficients_descending": expression_strings(q_coefficients),
        "face_constant": sp.sstr(sp.factor(face_constant)),
        "q_face_relation": "q_face = q_monic / face_constant",
        "checks": {
            "reverse_contact_zero_degrees": sorted(contact_residuals),
            "z_q_squared_minus_p_cubed_nonzero_degrees": nonzero_residual_degrees,
            "face_equation_after_scaling": "1",
            "p0_times_q_face0": "1",
            "five_distinct_normalized_embeddings": True,
            "one_galois_orbit": True,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        help="write the exact reconstructed coefficients and field map as JSON",
    )
    args = parser.parse_args()

    result = reconstruct()
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(
            json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )

    print("reconstructed field degree: 5")
    print("reconstructed field irreducible over Q: yes")
    print("order-17 contact equations: exact")
    print("z*q_monic^2-p^3 nonzero degrees: 0,1,2,3,4")
    print("normalized face equation: p*q+2z*p*q'-3z*p'*q = 1")
    print("exact field isomorphism to Program 6 K0: verified")
    print("five embeddings: five distinct normalized covers in one Galois orbit")
    if args.output is not None:
        print(f"coefficient export: {args.output.name}")
    print("PASS: exact quintic degree-21 face reconstruction succeeded")


if __name__ == "__main__":
    main()
