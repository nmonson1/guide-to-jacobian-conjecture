#!/usr/bin/env python3
"""Validate the Lane 8 proof queue and its emptiness-propagation contract."""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict, deque
from pathlib import Path
from typing import Any

PROOF_STATUSES = {
    "verified_in_packet",
    "audited_external_theorem",
    "verified_in_public_source",
    "source_replay_needed",
    "open",
}
EDGE_TYPES = {
    "external_import",
    "exhaustive_split",
    "forced_initial_form",
    "forced_consequence",
    "classification",
    "coefficient_reconstruction",
    "equivalence",
    "rechart",
    "relaxation",
    "localization",
    "saturation",
    "normalization",
    "finite_cover",
    "quotient",
    "forced_specialization",
    "noncovering_specialization",
    "elimination",
    "terminal_certificate",
    "discard",
}


def unique_ids(items: list[dict[str, Any]], key: str, failures: list[str]) -> set[str]:
    values = [str(item.get(key, "")) for item in items]
    missing = [i for i, value in enumerate(values) if not value]
    if missing:
        failures.append(f"{key}: missing at indices {missing}")
    duplicates = sorted({value for value in values if values.count(value) > 1})
    if duplicates:
        failures.append(f"{key}: duplicate values {duplicates}")
    return set(values)


def topological_check(nodes: set[str], edges: list[dict[str, Any]], failures: list[str]) -> None:
    adjacency: dict[str, set[str]] = defaultdict(set)
    indegree = {node: 0 for node in nodes}
    for edge in edges:
        parent = edge["from"]
        for child in edge["to"]:
            if child not in adjacency[parent]:
                adjacency[parent].add(child)
                indegree[child] += 1
    queue = deque(sorted(node for node, degree in indegree.items() if degree == 0))
    visited = 0
    while queue:
        node = queue.popleft()
        visited += 1
        for child in sorted(adjacency[node]):
            indegree[child] -= 1
            if indegree[child] == 0:
                queue.append(child)
    if visited != len(nodes):
        failures.append("routing graph contains a directed cycle")


def established_nodes(
    starts: set[str], edges: list[dict[str, Any]], accepted: set[str]
) -> set[str]:
    established = set(starts)
    changed = True
    while changed:
        changed = False
        for edge in edges:
            if edge["proof_status"] not in accepted:
                continue
            if edge["coverage"] == "noncovering" or edge["edge_type"] == "noncovering_specialization":
                continue
            if edge["from"] not in established:
                continue
            if not set(edge.get("requires", [])) <= established:
                continue
            before = len(established)
            established.update(edge["to"])
            changed |= len(established) != before
    return established


def empty_nodes(
    assumptions: set[str],
    node_map: dict[str, dict[str, Any]],
    edges: list[dict[str, Any]],
    accepted: set[str],
) -> tuple[set[str], set[str], list[str]]:
    """Return established nodes, proved-empty nodes, and an explanation trace."""
    established = established_nodes(assumptions, edges, accepted)
    empty = {
        node_id
        for node_id, node in node_map.items()
        if node.get("terminal")
        and node.get("proof_status") in accepted
        and node.get("certificate_refs")
    }
    trace = [f"terminal certificate: {node_id}" for node_id in sorted(empty)]

    changed = True
    while changed:
        changed = False
        for edge in edges:
            if edge["proof_status"] not in accepted or not edge.get("propagates_emptiness"):
                continue
            if edge["coverage"] in {"noncovering", "dependency"}:
                continue
            if edge["from"] not in established:
                continue
            if not set(edge.get("requires", [])) <= established:
                continue
            # An exhaustive split excludes its parent only after every child
            # is empty. The same all-children rule is harmless for one-child
            # covers, relaxations, eliminations, and terminal certificates.
            if not set(edge["to"]) <= empty:
                continue
            parent = edge["from"]
            if parent not in empty:
                empty.add(parent)
                trace.append(f"{edge['edge_id']}: all children empty => {parent} empty")
                changed = True
    return established, empty, trace


def target_result(
    target: dict[str, Any], node_map: dict[str, dict[str, Any]], edges: list[dict[str, Any]]
) -> tuple[bool, list[str]]:
    accepted = set(target["accepted_proof_statuses"])
    details: list[str] = []
    if target["kind"] == "routing":
        passed = True
        for requirement in target["requirements"]:
            start = requirement["from_node"]
            reached = established_nodes({start}, edges, accepted)
            if "all_of" in requirement:
                missing = sorted(set(requirement["all_of"]) - reached)
                ok = not missing
                details.append(f"from {start}: all_of missing={missing}")
            else:
                found = sorted(set(requirement["any_of"]) & reached)
                ok = bool(found)
                details.append(f"from {start}: any_of reached={found}")
            passed &= ok
        return passed, details

    established, empty, trace = empty_nodes(
        set(target["assumption_nodes"]), node_map, edges, accepted
    )
    missing = sorted(set(target["prove_empty"]) - empty)
    details.append(f"established nodes: {len(established)}")
    details.append(f"proved-empty nodes: {sorted(empty)}")
    details.append(f"missing emptiness proofs: {missing}")
    details.extend(trace)
    return not missing, details


def validate(data: dict[str, Any], require_global: bool) -> int:
    failures: list[str] = []
    if data.get("schema_version") != 1:
        failures.append("schema_version must be 1")

    node_ids = unique_ids(data.get("nodes", []), "node_id", failures)
    edge_ids = unique_ids(data.get("edges", []), "edge_id", failures)
    source_ids = unique_ids(data.get("sources", []), "source_id", failures)
    obligation_ids = unique_ids(data.get("obligations", []), "obligation_id", failures)
    target_ids = unique_ids(data.get("coverage_targets", []), "target_id", failures)
    del source_ids, obligation_ids, target_ids

    node_pattern = re.compile(r"^L8-[A-Z0-9-]+$")
    edge_pattern = re.compile(r"^L8-E-[A-Z0-9-]+$")
    for node_id in node_ids:
        if not node_pattern.fullmatch(node_id):
            failures.append(f"invalid node id: {node_id}")
    for edge_id in edge_ids:
        if not edge_pattern.fullmatch(edge_id):
            failures.append(f"invalid edge id: {edge_id}")

    node_map = {node["node_id"]: node for node in data.get("nodes", []) if node.get("node_id")}
    edge_map = {edge["edge_id"]: edge for edge in data.get("edges", []) if edge.get("edge_id")}

    for node_id, node in node_map.items():
        if node.get("proof_status") not in PROOF_STATUSES:
            failures.append(f"{node_id}: invalid proof status")
        if node.get("terminal") and not node.get("certificate_refs"):
            failures.append(f"{node_id}: terminal node lacks certificate_refs")
        if not isinstance(node.get("constructible_data", {}).get("inverted_elements"), list):
            failures.append(f"{node_id}: inverted_elements must be an explicit list")

    for edge_id, edge in edge_map.items():
        if edge.get("from") not in node_ids:
            failures.append(f"{edge_id}: unknown parent {edge.get('from')}")
        for key in ("to", "requires"):
            for node_id in edge.get(key, []):
                if node_id not in node_ids:
                    failures.append(f"{edge_id}: unknown {key} node {node_id}")
        if edge.get("edge_type") not in EDGE_TYPES:
            failures.append(f"{edge_id}: invalid edge type {edge.get('edge_type')}")
        if edge.get("proof_status") not in PROOF_STATUSES:
            failures.append(f"{edge_id}: invalid proof status")
        if edge.get("edge_type") == "noncovering_specialization":
            if edge.get("coverage") != "noncovering" or edge.get("propagates_emptiness"):
                failures.append(f"{edge_id}: noncovering specialization has unsafe semantics")
        if edge.get("coverage") == "dependency" and edge.get("propagates_emptiness"):
            failures.append(f"{edge_id}: dependency edge cannot propagate emptiness")
        if edge.get("edge_type") == "terminal_certificate":
            if edge.get("coverage") != "terminal" or not edge.get("propagates_emptiness"):
                failures.append(f"{edge_id}: terminal certificate semantics are malformed")
            for child in edge.get("to", []):
                if child in node_map and not node_map[child].get("terminal"):
                    failures.append(f"{edge_id}: terminal certificate points to nonterminal {child}")
        if edge.get("edge_type") in {"localization", "saturation"}:
            complements = edge.get("complement_edges", [])
            if not complements:
                failures.append(f"{edge_id}: localization/saturation lacks complementary branch")
            for complement in complements:
                if complement not in edge_ids:
                    failures.append(f"{edge_id}: unknown complement edge {complement}")
                elif edge_map[complement].get("from") != edge.get("from"):
                    failures.append(f"{edge_id}: complement {complement} has a different parent")

    for obligation in data.get("obligations", []):
        for edge_id in obligation.get("blocks", []):
            if edge_id not in edge_ids:
                failures.append(f"{obligation['obligation_id']}: blocks unknown edge {edge_id}")

    for target in data.get("coverage_targets", []):
        for status in target.get("accepted_proof_statuses", []):
            if status not in PROOF_STATUSES:
                failures.append(f"{target['target_id']}: invalid accepted proof status {status}")
        references: set[str] = set()
        if target.get("kind") == "routing":
            for req in target.get("requirements", []):
                references.add(req.get("from_node", ""))
                references.update(req.get("all_of", []))
                references.update(req.get("any_of", []))
        elif target.get("kind") == "exclusion":
            references.update(target.get("assumption_nodes", []))
            references.update(target.get("prove_empty", []))
        else:
            failures.append(f"{target['target_id']}: invalid target kind")
        for node_id in references:
            if node_id not in node_ids:
                failures.append(f"{target['target_id']}: unknown node {node_id}")

    topological_check(node_ids, data.get("edges", []), failures)

    if failures:
        print("STRUCTURAL FAIL")
        for failure in failures:
            print(f"- {failure}")
        return 2

    print(
        f"STRUCTURAL PASS: {len(node_ids)} nodes, {len(edge_ids)} edges, "
        f"{len(data.get('obligations', []))} obligations"
    )

    expectation_failures: list[str] = []
    global_incomplete = False
    for target in data["coverage_targets"]:
        actual, details = target_result(target, node_map, data["edges"])
        actual_label = "complete" if actual else "incomplete"
        expected = target["expected"]
        print(f"{target['target_id']}: {actual_label} (expected {expected})")
        for detail in details:
            print(f"  {detail}")
        if actual_label != expected:
            expectation_failures.append(
                f"{target['target_id']}: expected {expected}, got {actual_label}"
            )
        if target["target_id"] == "L8-COVERAGE-SUB125-EXCLUSION" and not actual:
            global_incomplete = True

    if expectation_failures:
        print("EXPECTATION FAIL")
        for failure in expectation_failures:
            print(f"- {failure}")
        return 3
    if require_global and global_incomplete:
        print("GLOBAL FAIL: the standalone below-125 exclusion is not certified")
        return 1

    print("PASS: declared complete targets are complete and declared gaps remain visible")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("queue", nargs="?", default="queue.seed.json")
    parser.add_argument(
        "--require-global",
        action="store_true",
        help="fail unless the standalone below-125 exclusion target is complete",
    )
    args = parser.parse_args()
    path = Path(args.queue)
    data = json.loads(path.read_text(encoding="utf-8"))
    return validate(data, require_global=args.require_global)


if __name__ == "__main__":
    sys.exit(main())
