#!/usr/bin/env python3
"""Independent exact checks for the first certified Lane 8 queue edges.

This script uses only the two Proposition 4.3 Newton polygons and elementary
symbolic algebra. It does not read the Program 6 terminal archive.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Iterable, Sequence

import sympy as sp

Point = tuple[int, int]


@dataclass(frozen=True)
class RootData:
    name: str
    p_vertices: tuple[Point, ...]
    q_vertices: tuple[Point, ...]
    p_count: int
    q_count: int
    p_layers: tuple[int, ...]
    q_layers: tuple[int, ...]


def signed_area2(vertices: Sequence[Point]) -> int:
    return sum(
        vertices[i][0] * vertices[(i + 1) % len(vertices)][1]
        - vertices[(i + 1) % len(vertices)][0] * vertices[i][1]
        for i in range(len(vertices))
    )


def convex_lattice_points(vertices: Sequence[Point]) -> set[Point]:
    """Return all lattice points in a convex polygon, including its boundary."""
    polygon = list(vertices)
    if signed_area2(polygon) < 0:
        polygon.reverse()
    xmin = min(x for x, _ in polygon)
    xmax = max(x for x, _ in polygon)
    ymin = min(y for _, y in polygon)
    ymax = max(y for _, y in polygon)
    answer: set[Point] = set()
    for x in range(xmin, xmax + 1):
        for y in range(ymin, ymax + 1):
            cross_products = []
            for i, (x1, y1) in enumerate(polygon):
                x2, y2 = polygon[(i + 1) % len(polygon)]
                cross_products.append((x2 - x1) * (y - y1) - (y2 - y1) * (x - x1))
            if all(value >= 0 for value in cross_products):
                answer.add((x, y))
    return answer


def layer_profile(points: Iterable[Point], offset: int) -> tuple[int, ...]:
    counts = Counter(y - 2 * x + offset for x, y in points)
    assert min(counts) == 0, counts
    assert set(counts) == set(range(max(counts) + 1)), counts
    return tuple(counts[i] for i in range(max(counts) + 1))


def transform_exponent(point: Point) -> Point:
    """Exponent map for phi(x)=x^-1, phi(y)=x^4 y."""
    a, b = point
    return (-a + 4 * b, b)


def check_roots() -> None:
    roots = (
        RootData(
            name="truncated",
            p_vertices=((0, 0), (1, 0), (8, 14), (8, 16)),
            q_vertices=((0, 0), (2, 1), (12, 21), (12, 24)),
            p_count=25,
            q_count=47,
            p_layers=(8, 8, 9),
            q_layers=(11, 11, 12, 13),
        ),
        RootData(
            name="full",
            p_vertices=((0, 0), (1, 0), (8, 14), (8, 16), (0, 8)),
            q_vertices=((0, 0), (2, 1), (12, 21), (12, 24), (0, 12)),
            p_count=61,
            q_count=125,
            p_layers=(8, 8, 9, 8, 7, 6, 5, 4, 3, 2, 1),
            q_layers=(11, 11, 12, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1),
        ),
    )

    point_sets: dict[str, tuple[set[Point], set[Point]]] = {}
    for root in roots:
        p_points = convex_lattice_points(root.p_vertices)
        q_points = convex_lattice_points(root.q_vertices)
        assert len(p_points) == root.p_count
        assert len(q_points) == root.q_count
        assert layer_profile(p_points, 2) == root.p_layers
        assert layer_profile(q_points, 3) == root.q_layers
        point_sets[root.name] = (p_points, q_points)
        print(
            f"{root.name}: lattice points P/Q={len(p_points)}/{len(q_points)}; "
            f"layer profiles P={root.p_layers}, Q={root.q_layers}"
        )

    truncated_p, truncated_q = point_sets["truncated"]
    full_p, full_q = point_sets["full"]
    assert truncated_p <= full_p
    assert truncated_q <= full_q
    print("truncated windows are subsets of full windows")

    # Vertices immediately before the final Laurent monomial map in the proof
    # of Proposition 4.3. Cases a,b omit the extra vertices; case c includes them.
    pre_p_truncated = {(-1, 0), (0, 0), (56, 16), (48, 14)}
    pre_q_truncated = {(2, 1), (0, 0), (84, 24), (72, 21)}
    pre_p_full = pre_p_truncated | {(32, 8)}
    pre_q_full = pre_q_truncated | {(48, 12)}
    assert {transform_exponent(p) for p in pre_p_truncated} == set(roots[0].p_vertices)
    assert {transform_exponent(p) for p in pre_q_truncated} == set(roots[0].q_vertices)
    assert {transform_exponent(p) for p in pre_p_full} == set(roots[1].p_vertices)
    assert {transform_exponent(p) for p in pre_q_full} == set(roots[1].q_vertices)

    x, y = sp.symbols("x y", nonzero=True)
    jacobian = sp.Matrix(
        [
            [sp.diff(x**-1, x), sp.diff(x**-1, y)],
            [sp.diff(x**4 * y, x), sp.diff(x**4 * y, y)],
        ]
    ).det()
    assert sp.simplify(jacobian + x**2) == 0
    print("final monomial map: all vertices match and Jacobian determinant is -x^2")

    # The minimum-valuation faces are exactly the z-strings claimed in the repair.
    for root in roots:
        p_points, q_points = point_sets[root.name]
        p_min = min(-2 * a + b for a, b in p_points)
        q_min = min(-2 * a + b for a, b in q_points)
        p_face = {(a, b) for a, b in p_points if -2 * a + b == p_min}
        q_face = {(a, b) for a, b in q_points if -2 * a + b == q_min}
        assert p_min == -2
        assert q_min == -3
        assert p_face == {(k + 1, 2 * k) for k in range(8)}
        assert q_face == {(k + 2, 2 * k + 1) for k in range(11)}
    print("both roots force P_face=x p(xy^2), deg p=7, and Q_face=x^2 y q(xy^2), deg q=10")


def check_face_and_belyi_identities() -> None:
    x, y, z = sp.symbols("x y z", nonzero=True)
    zxy = x * y**2
    p = sp.Function("p")
    q = sp.Function("q")
    pxy = p(zxy)
    qxy = q(zxy)
    p_face = x * pxy
    q_face = x**2 * y * qxy
    bracket = sp.diff(p_face, x) * sp.diff(q_face, y) - sp.diff(p_face, y) * sp.diff(q_face, x)
    expected = x**2 * (
        pxy * qxy
        + 2 * zxy * pxy * sp.diff(q(z), z).subs(z, zxy)
        - 3 * zxy * sp.diff(p(z), z).subs(z, zxy) * qxy
    )
    assert sp.simplify(bracket - expected) == 0
    print("face bracket identity verified exactly")

    pz = p(z)
    qz = q(z)
    face_ode = pz * qz + 2 * z * pz * sp.diff(qz, z) - 3 * z * sp.diff(pz, z) * qz
    tau = z * qz**2 / pz**3
    derivative_identity = sp.diff(tau, z) - qz / pz**4 * face_ode
    assert sp.simplify(derivative_identity) == 0
    assert 10 + 14 + 16 == 2 * 21 - 2
    print("Belyi derivative identity and degree-21 Riemann-Hurwitz count verified")


def check_normal_layer_identity() -> None:
    x, y = sp.symbols("x y", nonzero=True)
    zxy = x * y**2
    A = sp.Function("A")
    B = sp.Function("B")
    p_expr = y**-2 * A(zxy, y)
    q_expr = y**-3 * B(zxy, y)
    bracket = sp.diff(p_expr, x) * sp.diff(q_expr, y) - sp.diff(p_expr, y) * sp.diff(q_expr, x)

    z, t = sp.symbols("z t", nonzero=True)
    Az = A(z, t)
    Bz = B(z, t)
    normal_numerator = (
        2 * Az * sp.diff(Bz, z)
        - 3 * sp.diff(Az, z) * Bz
        + t * (sp.diff(Az, z) * sp.diff(Bz, t) - sp.diff(Az, t) * sp.diff(Bz, z))
    )
    converted = sp.simplify((bracket * y**4).subs({x: z / t**2, y: t}) - normal_numerator)
    assert converted == 0
    print("normal-coordinate determinant equation verified exactly")

    # Check the all-r coefficient formula through a nontrivial finite truncation.
    order = 7
    a = [sp.Function(f"A{i}")(z) for i in range(order + 1)]
    b = [sp.Function(f"B{i}")(z) for i in range(order + 1)]
    a_series = sum(t**i * a[i] for i in range(order + 1))
    b_series = sum(t**i * b[i] for i in range(order + 1))
    expression = sp.expand(
        2 * a_series * sp.diff(b_series, z)
        - 3 * sp.diff(a_series, z) * b_series
        + t * (
            sp.diff(a_series, z) * sp.diff(b_series, t)
            - sp.diff(a_series, t) * sp.diff(b_series, z)
        )
    )
    for r in range(order + 1):
        actual = sp.expand(expression).coeff(t, r)
        expected = sum(
            (2 - i) * a[i] * sp.diff(b[j], z)
            + (j - 3) * sp.diff(a[i], z) * b[j]
            for i in range(r + 1)
            for j in [r - i]
        )
        assert sp.simplify(actual - expected) == 0
    print(f"triangular layer recurrence verified for all coefficients r=0,...,{order}")


def main() -> None:
    check_roots()
    check_face_and_belyi_identities()
    check_normal_layer_identity()
    print("PASS: all independent root-to-face checks succeeded")


if __name__ == "__main__":
    main()
