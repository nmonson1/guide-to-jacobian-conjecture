#!/usr/bin/env python3
"""Exact early-layer reduction for the full (8,28) Newton root.

The calculation reconstructs layers 1 through 4 over the quintic field.  The
first three compatibility functionals vanish identically.  The sole layer-4
condition is an exact square a*(W-kappa*Y^2)^2.  Thus the reduced geometric
branch is forced to W=kappa*Y^2, while the scheme-level double structure must
be retained in any elimination proof.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path

import quintic_face_reconstruction as face
import truncated_support_certificate as exact

# Nine early free coordinates:
# layer 1: X,Y; layer 2: U,V,W; layer 3: R,S,T; layer 4: H.
exact.N = 9


def reconstruct_base():
    K, ONE, ZERO = exact.K, exact.ONE, exact.ZERO
    a = {i: K.from_expr(v) for i, v in face.A_RAW.items()}
    reverse_p = [ONE] + [a[i] for i in range(1, 8)]
    cube = []
    for total in range(21):
        value = ZERO
        for i in range(8):
            for j in range(8):
                for k in range(8):
                    if i + j + k == total:
                        value = value + reverse_p[i] * reverse_p[j] * reverse_p[k]
        cube.append(value)
    reverse_q = [ONE]
    for total in range(1, 11):
        known = ZERO
        for i in range(1, total):
            known = known + reverse_q[i] * reverse_q[total - i]
        reverse_q.append((cube[total] - known) / K(2))
    inverse_constant = (a[7] * reverse_q[10]).inv()
    p = {7: ONE}
    p.update({7 - i: a[i] for i in range(1, 8)})
    q = {10: inverse_constant}
    q.update({10 - i: reverse_q[i] * inverse_constant for i in range(1, 11)})
    return (
        exact.z_from_field({degree + 1: value for degree, value in p.items()}),
        exact.z_from_field({degree + 2: value for degree, value in q.items()}),
    )


def a_exponents(layer):
    if layer == 1:
        return list(range(1, 9))
    if layer == 2:
        return list(range(0, 9))
    if 3 <= layer <= 10:
        return list(range(0, 11 - layer))
    return []


def b_exponents(layer):
    if layer == 1:
        return list(range(2, 13))
    if layer == 2:
        return list(range(1, 13))
    if layer == 3:
        return list(range(0, 13))
    if 4 <= layer <= 15:
        return list(range(0, 16 - layer))
    return []


def forcing(layer, A, B):
    pieces = []
    for i in range(1, layer):
        j = layer - i
        if i >= len(A) or j >= len(B) or not A[i] or not B[j]:
            continue
        pieces.append(
            exact.zscale(exact.zmul(A[i], exact.zder(B[j])), 2 - i)
        )
        pieces.append(
            exact.zscale(exact.zmul(exact.zder(A[i]), B[j]), j - 3)
        )
    return exact.zadd(*pieces)


def build_reduction():
    A0, B0 = reconstruct_base()
    X, Y, U, V, W, R, S, T, H = [exact.pp_var(i) for i in range(9)]
    A = [A0]
    B = [B0]
    compatibilities = {}

    free_parameters = {
        1: [X, Y],
        2: [U, V, W],
        3: [R, S, T],
        4: [H],
    }
    expected = {
        1: (17, [17, 18]),
        2: (18, [0, 19, 20]),
        3: (18, [8, 18, 19]),
        4: (18, [17]),
    }

    for layer in range(1, 5):
        data = exact.linear_data(
            layer, a_exponents(layer), b_exponents(layer), A0, B0
        )
        assert (len(data[4]), data[5]) == expected[layer]
        rhs = {} if layer == 1 else exact.zscale(forcing(layer, A, B), -1)
        solution, compatibility = exact.solve(
            data, rhs, free_parameters[layer]
        )
        Ar, Br = exact.vecpair(
            solution, a_exponents(layer), b_exponents(layer)
        )
        A.append(Ar)
        B.append(Br)
        compatibilities[layer] = compatibility

    assert all(not equation for layer in (1, 2, 3)
               for equation in compatibilities[layer])
    assert len(compatibilities[4]) == 1
    equation = compatibilities[4][0]
    expected_support = {
        (0, 0, 0, 0, 2, 0, 0, 0, 0),  # W^2
        (0, 2, 0, 0, 1, 0, 0, 0, 0),  # Y^2 W
        (0, 4, 0, 0, 0, 0, 0, 0, 0),  # Y^4
    }
    assert set(equation) == expected_support
    a = equation[(0, 0, 0, 0, 2, 0, 0, 0, 0)]
    b = equation[(0, 2, 0, 0, 1, 0, 0, 0, 0)]
    c = equation[(0, 4, 0, 0, 0, 0, 0, 0, 0)]
    assert not (b * b - exact.K(4) * a * c)
    kappa = -b / (exact.K(2) * a)
    assert not (c - a * kappa * kappa)

    return {
        "schema_version": 1,
        "field_polynomial": str(face.M_EXPR),
        "early_free_parameters": {
            "layer_1": ["X", "Y"],
            "layer_2": ["U", "V", "W"],
            "layer_3": ["R", "S", "T"],
            "layer_4": ["H"],
        },
        "ranks": {
            "D1": 17,
            "D2": 18,
            "D3": 18,
            "D4": 18,
        },
        "compatibility": {
            "layers_1_to_3_identically_zero": True,
            "layer_4_support": ["W^2", "Y^2*W", "Y^4"],
            "leading_coefficient": str(a.expr()),
            "kappa": str(kappa.expr()),
            "exact_factorization": "a*(W-kappa*Y^2)^2",
        },
        "conclusion": {
            "reduced_geometric_branch": "W=kappa*Y^2",
            "scheme_structure": "double square; do not replace by the reduced branch in scheme-level arguments",
            "all_later_free_parameters": "none after layer 4; see full_layer_rank_profile.json",
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = build_reduction()
    if args.output:
        args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print("exact early ranks: D1=17, D2=18, D3=18, D4=18")
    print("compatibility at layers 1,2,3: identically zero")
    print("layer-4 compatibility: a*(W-kappa*Y^2)^2")
    print("reduced geometric branch: W=kappa*Y^2")
    if args.output:
        print(f"reduction export: {args.output.name}")
    print("PASS: the full-support square branch is independently reconstructed")


if __name__ == "__main__":
    main()
