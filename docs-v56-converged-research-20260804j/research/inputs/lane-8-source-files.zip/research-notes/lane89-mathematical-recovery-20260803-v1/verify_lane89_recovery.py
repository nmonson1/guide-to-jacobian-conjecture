#!/usr/bin/env python3
"""Fail-closed verifier for the Lane 8/9 mathematical recovery packet."""
from __future__ import annotations

import argparse
import hashlib
import json
from fractions import Fraction as F
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tempfile
from typing import Any
from zipfile import ZipFile


PACKET = Path(__file__).resolve().parent
REPOSITORY_ROOT = PACKET.parents[1]
EVIDENCE_PATH = PACKET / "evidence.json"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def sha256_path(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_evidence() -> dict[str, Any]:
    evidence = json.loads(EVIDENCE_PATH.read_text(encoding="utf-8"))
    require(
        evidence["schema"] == "lane89-mathematical-recovery-evidence-v1",
        "unexpected evidence schema",
    )
    require(evidence["base_commit"].startswith("25fd454"), "wrong private base")
    classification = evidence["classification"]
    require(
        classification == {
            "full_root_closure": "lane8",
            "f2_recurrence": "lane9_primary_lane8_connection",
        },
        "lane classification changed",
    )
    assessment = evidence["order530"]["parameter_complete_assessment"]
    require(assessment["runnable"] is False, "parameter-complete scope overstated")
    require(assessment["slurm_job_submitted"] is False, "unexpected Slurm claim")
    require(
        assessment["reasons"]
        == [
            "the maximal support model omits inherited cross-layer descent relations",
            "the retained rational generator assigns unselected RREF kernel coordinates to zero",
            "the adjacent-chart and global descent inputs remain unattached",
        ],
        "parameter-complete boundary changed",
    )
    return evidence


def verify_lane8_summary(path: Path, expected: dict[str, Any]) -> None:
    require(sha256_path(path) == expected["summary_sha256"], "Lane 8 summary SHA-256")
    summary = json.loads(path.read_text(encoding="utf-8"))
    require(summary["schema"] == "lane8-independent-raw-support-replay-v1", "Lane 8 schema")
    require(summary["inputs"]["archived_layers_used"] is False, "Lane 8 used archived layers")
    require(summary["inputs"]["archived_equations_used"] is False, "Lane 8 used archived equations")
    require(summary["truncated"]["macaulay_rank"] == 14, "truncated rank")
    require(
        summary["truncated"]["minor_determinant_sha256"]
        == expected["truncated_minor_sha256"],
        "truncated minor digest",
    )
    require(summary["full"]["weight_four_is_square"] is True, "full layer-four square")
    require(
        summary["full"]["vertex_saturation_forces_t11_nonzero"] is True,
        "full closed complement",
    )
    require(len(summary["full"]["equation_manifest"]) == 15, "full equation count")
    require(
        summary["full"]["final_equation_sha256"]
        == expected["full_fifteen_sha256"],
        "full fifteen digest",
    )
    require(
        summary["full"]["terminal_projection"]["zero_based_indices"]
        == [4, 6, 8, 9, 10, 11],
        "toric projection indices",
    )
    require(
        summary["full"]["terminal_projection"]["sha256"]
        == expected["terminal_projection_sha256"],
        "terminal projection digest",
    )
    require(
        summary["full"]["higher_deficiency_coefficients_projected_away"]
        == {
            "cutoff": 8,
            "P": 3,
            "Q": 28,
            "extra_vertices": {"P_(0,8)": 10, "Q_(0,12)": 15},
        },
        "higher-deficiency projection boundary",
    )


def safe_archive_members(archive: ZipFile) -> dict[str, bytes]:
    members: dict[str, bytes] = {}
    for info in archive.infolist():
        path = PurePosixPath(info.filename)
        require(not path.is_absolute() and ".." not in path.parts, "unsafe ZIP member")
        require(not info.is_dir(), f"unexpected directory member {info.filename}")
        members[info.filename] = archive.read(info)
    return members


def verify_file_manifest(members: dict[str, bytes]) -> None:
    manifest = json.loads(members["FILE_MANIFEST.json"])
    expected_names = {row["path"] for row in manifest["files"]}
    require(expected_names == set(members) - {"FILE_MANIFEST.json"}, "bundle inventory")
    for row in manifest["files"]:
        payload = members[row["path"]]
        require(len(payload) == row["bytes"], f"bundle size {row['path']}")
        require(
            hashlib.sha256(payload).hexdigest() == row["sha256"],
            f"bundle digest {row['path']}",
        )


def expected_window(data: dict[str, Any], order: int) -> dict[str, int] | None:
    metadata = data["metadata"]
    lower = max(
        0,
        -(
            -(
                order
                + 5 * metadata["initial_weight_min"]
                - metadata["terminal_weight_max"]
            )
            // 12
        ),
    )
    upper = min(
        metadata["y_max"],
        (
            order
            + 5 * metadata["initial_weight_max"]
            - metadata["terminal_weight_max"]
        )
        // 12,
    )
    residue = (3 * (order - metadata["terminal_weight_max"])) % 5
    u_min = -(-(lower - residue) // 5)
    u_max = (upper - residue) // 5
    if u_min > u_max:
        return None
    top = residue + 5 * u_max
    numerator = metadata["terminal_weight_max"] + 12 * top - order
    require(numerator % 5 == 0, "window character congruence")
    initial_weight = numerator // 5
    if top > metadata["y_max"] - initial_weight % 5:
        u_max -= 1
    if u_min > u_max:
        return None
    return {
        "J_min": residue + 5 * u_min,
        "J_max": residue + 5 * u_max,
        "dimension": u_max - u_min + 1,
    }


def verify_all_support_windows(windows: dict[str, Any], expected: dict[str, Any]) -> None:
    for label in ("P", "Q"):
        support = windows["support"][label]
        rows = {int(order): row for order, row in windows[f"{label}_windows"].items()}
        require(
            support["propagated_support_size"] == expected[f"{label}_coefficients"],
            f"{label} support size",
        )
        require(
            len(rows) == expected[f"{label}_nonempty_layers"],
            f"{label} layer count",
        )
        require(
            sum(row["dimension"] for row in rows.values())
            == expected[f"{label}_coefficients"],
            f"{label} coefficient total",
        )
        last_order = support["summary"]["last_layer"]
        for order in range(last_order + 1):
            formula = expected_window(support, order)
            serialized = rows.get(order)
            require((formula is None) == (serialized is None), f"{label} window presence {order}")
            if formula is not None and serialized is not None:
                require(
                    {
                        "J_min": serialized["J_min"],
                        "J_max": serialized["J_max"],
                        "dimension": serialized["dimension"],
                    }
                    == formula,
                    f"{label} window formula {order}",
                )
    require(
        len(windows["full_jacobian_output_windows"])
        == expected["determinant_output_layers"],
        "determinant output layer count",
    )


def parse_poly(data: dict[str, str]) -> dict[int, F]:
    return {int(exponent): F(value) for exponent, value in data.items()}


def derivative(poly: dict[int, F]) -> dict[int, F]:
    return {
        exponent - 1: F(exponent) * value
        for exponent, value in poly.items()
        if exponent and value
    }


def add_product(
    output: dict[int, F],
    left: dict[int, F],
    right: dict[int, F],
    scale: F,
) -> None:
    for left_exponent, left_value in left.items():
        for right_exponent, right_value in right.items():
            exponent = left_exponent + right_exponent
            output[exponent] = (
                output.get(exponent, F(0))
                + scale * left_value * right_value
            )


def determinant_layer(
    order: int,
    a_layers: dict[int, dict[int, F]],
    b_layers: dict[int, dict[int, F]],
) -> dict[int, F]:
    output: dict[int, F] = {}
    for left_order in range(order + 1):
        right_order = order - left_order
        a_layer = a_layers.get(left_order, {})
        b_layer = b_layers.get(right_order, {})
        if not a_layer or not b_layer:
            continue
        add_product(output, a_layer, derivative(b_layer), F(3 - left_order))
        add_product(output, derivative(a_layer), b_layer, F(right_order - 5))
    return {exponent: value for exponent, value in output.items() if value}


def allowed_exponents(window: dict[str, Any]) -> set[int]:
    return set(range(window["J_min"], window["J_max"] + 1, 5))


def verify_jet_layers(
    certificate: dict[str, Any],
    windows: dict[str, Any],
    through: int,
) -> None:
    p_windows = {int(order): row for order, row in windows["P_windows"].items()}
    q_windows = {int(order): row for order, row in windows["Q_windows"].items()}
    a_layers = {0: parse_poly(certificate["base"]["A0"])}
    b_layers = {0: parse_poly(certificate["base"]["B0"])}
    seen: set[int] = set()
    for record in certificate["layers"]:
        order = int(record["r"])
        require(order not in seen, f"duplicate jet layer {order}")
        seen.add(order)
        a_layers[order] = parse_poly(record["A"])
        b_layers[order] = parse_poly(record["B"])
        require(
            set(a_layers[order]).issubset(allowed_exponents(p_windows[order])),
            f"P support at order {order}",
        )
        require(
            set(b_layers[order]).issubset(allowed_exponents(q_windows[order])),
            f"Q support at order {order}",
        )
    require(determinant_layer(0, a_layers, b_layers) == {0: F(-1)}, "leading layer")
    for order in range(1, through + 1):
        require(
            determinant_layer(order, a_layers, b_layers) == {},
            f"nonzero determinant layer {order}",
        )


def verify_order520(
    members: dict[str, bytes],
    windows: dict[str, Any],
    expected: dict[str, Any],
) -> None:
    support_payload = members["f2_support_windows.json"]
    require(
        support_payload == members["data/f2_support_windows.json"],
        "two support-window payloads differ",
    )
    require(
        hashlib.sha256(support_payload).hexdigest()
        == expected["support_windows_sha256"],
        "support-window digest",
    )
    certificate_payload = members["f2_omega520_exact_certificate.json"]
    require(
        hashlib.sha256(certificate_payload).hexdigest()
        == expected["order520_certificate_sha256"],
        "order-520 certificate digest",
    )
    certificate = json.loads(certificate_payload)
    require(
        sum(record["free_dim"] for record in certificate["layers"])
        == expected[
            "total_rref_free_slots_in_retained_multiple_of_10_slice_through_520"
        ],
        "retained-slice free-coordinate inventory",
    )
    require(certificate["kuranishi_data"]["verified_omega510"] == "0", "omega510")
    require(certificate["kuranishi_data"]["verified_omega520"] == "0", "omega520")
    require(
        F(certificate["kuranishi_data"]["next_zero-slice_constant_omega530"]),
        "zero-new-coordinate omega530 unexpectedly zero",
    )
    require(
        certificate["mod_1000003_checks"]["omega530"]
        == expected["zero_slice_omega530_mod_1000003"],
        "omega530 modular check",
    )
    verify_jet_layers(certificate, windows, 520)


def verify_order530(
    path: Path,
    windows: dict[str, Any],
    expected: dict[str, Any],
) -> None:
    require(sha256_path(path) == expected["certificate_sha256"], "order-530 certificate digest")
    certificate = json.loads(path.read_text(encoding="utf-8"))
    require(
        certificate["schema"] == "f2-omega530-fresh-order280-certificate-v1",
        "order-530 schema",
    )
    analysis = certificate["fresh_parameter_analysis"]
    require(analysis["free_dimension"] == 5, "order-280 free dimension")
    require(analysis["omega510_kernel_dimension"] == 4, "omega510 kernel dimension")
    require(
        analysis["joint_omega510_omega520_kernel_dimension"] == 3,
        "joint kernel dimension",
    )
    require(F(analysis["zero_new_coordinate_omega530"]), "zero slice vanished")
    require(
        any(F(value) for value in analysis["omega530_values_on_joint_kernel"]),
        "omega530 did not move on the joint kernel",
    )
    require(
        certificate["verified"]
        == {
            "determinant_layers": "0..530",
            "omega510": "0",
            "omega520": "0",
            "omega530": "0",
            "recorded_positive_layers": 53,
        },
        "order-530 verification summary",
    )
    verify_jet_layers(certificate, windows, 530)


def run_checked(command: list[str], cwd: Path, timeout: int) -> str:
    completed = subprocess.run(
        command,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
    )
    require(completed.returncode == 0, completed.stdout[-8000:])
    return completed.stdout


def regenerate_bundle_artifacts(extracted: Path, temporary: Path) -> None:
    support_output = temporary / "support"
    run_checked(
        [
            sys.executable,
            str(extracted / "scripts" / "f2_support_windows.py"),
            "--outdir",
            str(support_output),
        ],
        extracted,
        120,
    )
    require(
        (support_output / "f2_support_windows.json").read_bytes()
        == (extracted / "data" / "f2_support_windows.json").read_bytes(),
        "support-window regeneration differs",
    )
    run_checked(
        [
            sys.executable,
            str(extracted / "scripts" / "f2_kuranishi_linear.py"),
            "--windows",
            str(support_output / "f2_support_windows.json"),
            "--outdir",
            str(support_output),
        ],
        extracted,
        120,
    )
    for name in ("f2_linear_complexes.json", "f2_linear_complexes_summary.json"):
        require(
            (support_output / name).read_bytes()
            == (extracted / "data" / name).read_bytes(),
            f"linear-complex regeneration differs: {name}",
        )
    run_checked(
        [
            sys.executable,
            str(extracted / "verify_f2_omega520_certificate.py"),
            str(extracted / "f2_omega520_exact_certificate.json"),
        ],
        extracted,
        120,
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--metadata-only", action="store_true")
    parser.add_argument("--lane8-summary", type=Path)
    parser.add_argument("--f2-bundle", type=Path)
    parser.add_argument("--order530-certificate", type=Path)
    parser.add_argument("--regenerate", action="store_true")
    args = parser.parse_args()
    evidence = load_evidence()
    if args.metadata_only:
        print("lane89 recovery metadata validation: PASS")
        return 0

    lane8_summary = (
        args.lane8_summary
        or Path(evidence["lane8"]["replay_summary_path"])
    )
    f2_bundle = args.f2_bundle or Path(evidence["f2"]["public_bundle_path"])
    order530_certificate = (
        args.order530_certificate
        or Path(evidence["order530"]["fresh_parameter_certificate_path"])
    )
    verify_lane8_summary(lane8_summary, evidence["lane8"])
    require(sha256_path(f2_bundle) == evidence["f2"]["public_bundle_sha256"], "F2 bundle digest")

    with ZipFile(f2_bundle) as archive:
        members = safe_archive_members(archive)
        verify_file_manifest(members)
        windows = json.loads(members["f2_support_windows.json"])
        verify_all_support_windows(windows, evidence["f2"])
        verify_order520(members, windows, evidence["f2"])
        verify_order530(order530_certificate, windows, evidence["order530"])
        if args.regenerate:
            with tempfile.TemporaryDirectory(prefix="lane89-regenerate-") as directory:
                extracted = Path(directory) / "bundle"
                archive.extractall(extracted)
                regenerate_bundle_artifacts(extracted, Path(directory))

    print("lane89 mathematical recovery validation: PASS")
    print("lane8_roots=truncated_closed,full_closed")
    print("below_125=relative_to_imported_GGHV_and_compact_toric_theorems")
    print("f2_support_windows=exact_maximal_newton_bounded_enlargement")
    print("omega510=0 omega520=0 omega530_fresh_order280_slice=0")
    print("parameter_complete_order530=not_runnable_from_retained_inputs")
    print("classification=lane8_full_root;lane9_f2_recurrence_with_lane8_connection")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
