#!/usr/bin/env python3
"""Extend the retained F2 weighted slice through order 530 exactly.

This is deliberately not a parameter-complete complete-chain calculation.
It reopens only the five RREF-kernel coordinates at order 280, finds the
joint kernel of the order-510 and order-520 functionals, and uses one exact
rational direction in that joint kernel to cancel order 530.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
from types import ModuleType
from zipfile import ZipFile


EXPECTED_BUNDLE_SHA256 = (
    "a0017d6537021b80098b78349cd7ad5566f6606d053b7e8f3f1dbd634d14ca64"
)
GENERATOR_MEMBER = "f2_omega520_kuranishi.py"
WINDOW_MEMBER = "f2_support_windows.json"


def sha256_path(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_generator(bundle: Path, destination: Path) -> tuple[ModuleType, Path]:
    if sha256_path(bundle) != EXPECTED_BUNDLE_SHA256:
        raise ValueError("unexpected F2 public-bundle SHA-256")
    with ZipFile(bundle) as archive:
        names = set(archive.namelist())
        for member in (GENERATOR_MEMBER, WINDOW_MEMBER):
            if member not in names:
                raise ValueError(f"bundle lacks {member}")
        archive.extract(GENERATOR_MEMBER, destination)
        archive.extract(WINDOW_MEMBER, destination)
    generator_path = destination / GENERATOR_MEMBER
    spec = importlib.util.spec_from_file_location("f2_o520_recovered", generator_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load recovered order-520 generator")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, generator_path


def selected_order520_assignments(module: ModuleType) -> tuple[dict, dict]:
    eta = F(1)
    seed = {10: {0: eta}}
    omega510_base = module.omega(510, seed)
    omega510_mu_slope = (
        module.omega(510, {10: {0: eta}, 260: {0: F(1)}})
        - omega510_base
    )
    if not omega510_mu_slope:
        raise AssertionError("order-260 direction does not move omega510")
    mu = -omega510_base / omega510_mu_slope

    nu0_slope = (
        module.omega(510, {10: {0: eta}, 270: {0: F(1)}})
        - omega510_base
    )
    nu1_slope = (
        module.omega(510, {10: {0: eta}, 270: {1: F(1)}})
        - omega510_base
    )
    if not nu1_slope:
        raise AssertionError("second order-270 direction does not move omega510")
    ratio = -nu0_slope / nu1_slope

    def assignments(value: F) -> dict:
        return {
            10: {0: eta},
            260: {0: mu},
            270: {0: value, 1: value * ratio},
        }

    omega520_at_zero = module.omega(520, assignments(F(0)))
    omega520_slope = module.omega(520, assignments(F(1))) - omega520_at_zero
    if not omega520_slope:
        raise AssertionError("order-270 null direction does not move omega520")
    value = -omega520_at_zero / omega520_slope
    selected = assignments(value)
    if module.omega(510, selected) or module.omega(520, selected):
        raise AssertionError("failed to reconstruct the retained order-520 slice")
    audit = {
        "eta": str(eta),
        "mu": str(mu),
        "order270_direction_ratio": str(ratio),
        "lambda": str(value),
    }
    return selected, audit


def combine(vectors: list[list[F]], coefficients: list[F]) -> list[F]:
    return [
        sum(
            (
                coefficient * vector[index]
                for vector, coefficient in zip(vectors, coefficients)
            ),
            F(0),
        )
        for index in range(len(vectors[0]))
    ]


def one_row_kernel(vectors: list[list[F]], values: list[F]) -> list[list[F]]:
    """Return an exact basis for the kernel of one functional on a basis."""
    pivot = next((index for index, value in enumerate(values) if value), None)
    if pivot is None:
        return vectors
    output: list[list[F]] = []
    for index in range(len(vectors)):
        if index == pivot:
            continue
        coefficients = [F(0)] * len(vectors)
        coefficients[index] = F(1)
        coefficients[pivot] = -values[index] / values[pivot]
        output.append(combine(vectors, coefficients))
    return output


def with_order280_direction(
    base: dict,
    vector: list[F],
    scalar: F = F(1),
) -> dict:
    output = {order: dict(values) for order, values in base.items()}
    output[280] = {
        index: scalar * coefficient
        for index, coefficient in enumerate(vector)
        if coefficient
    }
    return output


def fraction_list(values: list[F]) -> list[str]:
    return [str(value) for value in values]


def make_certificate(module: ModuleType) -> dict:
    base, retained_parameters = selected_order520_assignments(module)
    _, _, partial_records = module.solve(base, 280)
    free_dimension = partial_records[-1]["free_dim"]
    if partial_records[-1]["r"] != 280 or free_dimension != 5:
        raise AssertionError("unexpected order-280 RREF kernel")

    standard = [
        [F(index == column) for index in range(free_dimension)]
        for column in range(free_dimension)
    ]
    omega510_values = [
        module.omega(510, with_order280_direction(base, vector))
        for vector in standard
    ]
    kernel510 = one_row_kernel(standard, omega510_values)
    for vector in kernel510:
        if module.omega(510, with_order280_direction(base, vector)):
            raise AssertionError("computed order-510 kernel direction failed")

    omega520_values = [
        module.omega(520, with_order280_direction(base, vector))
        for vector in kernel510
    ]
    joint_kernel = one_row_kernel(kernel510, omega520_values)
    for vector in joint_kernel:
        trial = with_order280_direction(base, vector)
        if module.omega(510, trial) or module.omega(520, trial):
            raise AssertionError("computed joint-kernel direction failed")

    zero_slice_omega530 = module.omega(530, base)
    if not zero_slice_omega530:
        raise AssertionError("retained zero-new-coordinate omega530 unexpectedly vanished")
    omega530_values = [
        module.omega(530, with_order280_direction(base, vector))
        - zero_slice_omega530
        for vector in joint_kernel
    ]
    pivot = next(
        (index for index, value in enumerate(omega530_values) if value),
        None,
    )
    if pivot is None:
        raise AssertionError("omega530 vanishes on the entire computed joint kernel")
    direction = joint_kernel[pivot]
    scalar = -zero_slice_omega530 / omega530_values[pivot]
    final_assignments = with_order280_direction(base, direction, scalar)
    for order in (510, 520, 530):
        if module.omega(order, final_assignments):
            raise AssertionError(f"omega{order} did not cancel")

    a_layers, b_layers, records = module.solve(final_assignments, 530)
    if module.full_layer(0, a_layers, b_layers) != {0: F(-1)}:
        raise AssertionError("leading determinant layer changed")
    for order in range(1, 531):
        if module.full_layer(order, a_layers, b_layers):
            raise AssertionError(f"nonzero determinant layer {order}")

    return {
        "schema": "f2-omega530-fresh-order280-certificate-v1",
        "model": (
            "F2 maximal Newton-bounded independent-coefficient recursion; "
            "C5-invariant weighted slice"
        ),
        "claim": "exact rational weighted-slice jet through order 530",
        "boundary": (
            "Only the five order-280 RREF-kernel coordinates are reopened. "
            "This is not the all-parameter complete-chain recurrence and does "
            "not restore the omitted inherited descent relations."
        ),
        "base": {
            "A0": {str(exponent): str(value) for exponent, value in module.A0.items()},
            "B0": {str(exponent): str(value) for exponent, value in module.B0.items()},
        },
        "retained_order520_parameters": retained_parameters,
        "fresh_parameter_analysis": {
            "order": 280,
            "free_dimension": free_dimension,
            "omega510_values_on_rref_basis": fraction_list(omega510_values),
            "omega510_kernel_dimension": len(kernel510),
            "omega520_values_on_omega510_kernel": fraction_list(omega520_values),
            "joint_omega510_omega520_kernel_dimension": len(joint_kernel),
            "omega530_values_on_joint_kernel": fraction_list(omega530_values),
            "zero_new_coordinate_omega530": str(zero_slice_omega530),
            "cancelling_joint_kernel_index": pivot,
            "cancelling_direction": fraction_list(direction),
            "cancelling_scalar": str(scalar),
            "final_order280_rref_coordinates": {
                str(index): str(value)
                for index, value in sorted(final_assignments[280].items())
            },
        },
        "verified": {
            "determinant_layers": "0..530",
            "omega510": "0",
            "omega520": "0",
            "omega530": "0",
            "recorded_positive_layers": len(records),
        },
        "layers": records,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    bundle = args.bundle.resolve()
    output = args.output_dir.resolve()
    if output.exists():
        raise FileExistsError(f"refusing to overwrite {output}")
    output.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="f2-omega530-generator-") as temporary:
        module, _ = load_generator(bundle, Path(temporary))
        certificate = make_certificate(module)

    output.mkdir()
    script_copy = output / Path(__file__).name
    bundle_copy = output / bundle.name
    certificate_path = output / "f2_omega530_fresh_parameter_certificate.json"
    shutil.copyfile(Path(__file__), script_copy)
    shutil.copyfile(bundle, bundle_copy)
    certificate_path.write_text(
        json.dumps(certificate, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    files = (script_copy, bundle_copy, certificate_path)
    (output / "SHA256SUMS").write_text(
        "".join(f"{sha256_path(path)}  {path.name}\n" for path in files),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "certificate": str(certificate_path),
                "certificate_sha256": sha256_path(certificate_path),
                "omega510": "0",
                "omega520": "0",
                "omega530": "0",
                "joint_kernel_dimension": certificate[
                    "fresh_parameter_analysis"
                ]["joint_omega510_omega520_kernel_dimension"],
                "scope": "order-280 fresh-parameter slice, not parameter-complete",
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
