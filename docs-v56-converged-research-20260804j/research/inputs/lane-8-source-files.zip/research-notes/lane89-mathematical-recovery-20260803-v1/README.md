# Lane 8/9 mathematical recovery

This packet records an independent replay and scope audit of two distinct
pieces of the degree-`125` boundary program. It does not update a canonical
graph, research handoff, release selector, or public site.

## Classification

| result | primary lane | connection |
|---|---|---|
| direct closure of the two normalized `(8,28)` roots | Lane 8 | supplies the terminal Newton-root calculation used in the relative below-`125` assembly |
| `F_2` support windows and normal recurrence | Lane 9 | starts from the degree-`125` Lane 8 boundary seed, but is a chart/recurrence and descent problem |

The second item should therefore be described as **Lane 9 primary, with a
Lane 8 connection**. It is not another proof path for the Lane 8 full root.

## Lane 8 direct closure

The tracked full-root packet was replayed from the raw Newton polygons, the
exact quintic face relations, and the Jacobian coefficient formula. It did
not consume archived layer matrices or obstruction equations.

- The truncated root again has Macaulay rank `14` on the complete set of
  fourteen weight-four monomials. Its selected minor has SHA-256
  `8d495d9c4ef2c6f8843c04a4ba9e2d2473da131a92d81fbfd857c8f187ce4059`.
- The full root again produces a layer-four square, closes the
  `t1_1=0` complement using the two top vertices, and normalizes the open
  child to fifteen equations. Their canonical SHA-256 is
  `d2027973e307d65b782dd41146bc023903630e659ed2c3a2f51daec02194a883`.
- Zero-based equations `4,6,8,9,10,11` are literally a relaxation of those
  fifteen. The selected-six digest is
  `e4bf0e1842fcd0d3d7c403e6a5ec17fb800914f3208887f0b05d8727b563bb6a`.
  Their emptiness remains an imported exact Program 6 toric theorem.
- The stored adjacent-chart terminal remains empty but unattached and is not
  used in either closure path.

The resulting below-`125` statement has exactly the following scope: it is a
proof assembly relative to the inspected GGHV Newton reduction, its exclusion
of the `(9,27)` case, its routing of `(8,28)` to the two normalized roots, the
imported face orbit, and the imported compact toric terminal. It is not an
independent reproof of those inputs and carries no priority claim.

## Exact `F_2` support windows

After the denominator-five shear, write a monomial as `x^(a/5)y^J`, put
`w=a-J`, and use the terminal direction `(25,-17)`. The exact maximal
Newton-bounded supports are

\[
S_P=\{(a,J):-60\le w\le15,\ 0\le J\le60-\langle w\rangle_5,
\ 5a-17J\le3\},
\]

\[
S_Q=\{(a,J):-100\le w\le25,\ 0\le J\le100-\langle w\rangle_5,
\ 5a-17J\le5\}.
\]

In the terminal chart `x=t^-25`, `y=t^17 z`, `u=z^5`, write

\[
P=t^{-3}\sum_r t^rA_r(z),\qquad
Q=t^{-5}\sum_r t^rB_r(z).
\]

The `C_5` characters are

\[
A_r=z^{(1-2r)\bmod5}\bar A_r(u),\qquad
B_r=z^{-2r\bmod5}\bar B_r(u).
\]

For either coordinate, the exact `u` interval is obtained by intersecting the
raw `J` bounds with the required residue class and then applying the single
top sawtooth correction `J_top <= Y-<w_top>_5`. The verifier checks this
closed formula at every order, not only selected rows.

The regenerated inventory is:

| object | exact count |
|---|---:|
| propagated `P` coefficients | 4,433 |
| nonempty `P` layers | 981 |
| propagated `Q` coefficients | 12,340 |
| nonempty `Q` layers | 1,663 |
| determinant-output layers | 2,681 |

The first target coordinate outside the linearized image is the constant
coefficient at order `510`.

## Orders 510, 520, and 530

The retained exact rational generator fixes the order-10 coordinate, uses an
order-260 kernel coordinate to cancel `omega510`, chooses an order-270
direction in the kernel of that functional, and uses its scalar to cancel
`omega520`. The independent determinant verifier checks all layers `0..520`
and all serialized support bounds. Both values are exactly zero.

The old nonzero `omega530` value is obtained only after every unselected RREF
kernel coordinate is assigned zero. The retained multiple-of-10 slice has
`212` free slots across its `52` positive layers through order `520`, while
the generator explicitly selects only the order-10, order-260, and constrained
order-270 values.

The new exact probe reopens the five order-280 RREF coordinates:

- the kernel of `omega510` on that space has dimension `4`;
- the joint kernel of `omega510` and `omega520` has dimension `3`;
- `omega530` is nonzero as a functional on that joint kernel; and
- one displayed exact rational direction cancels `omega530` and verifies the
  determinant identity through order `530`.

Thus the old order-530 value is decisively a **zero-new-coordinate slice** and
not an obstruction. The new order-530 certificate is still a slice: it reopens
only order `280` and sets all other omitted coordinates to zero.

## Why no parameter-complete Slurm run was submitted

A parameter-complete continuation of the actual `F_2` complete-chain chart is
not runnable from the retained inputs. The public support model is explicitly
the maximal Newton-bounded independent-coefficient enlargement and omits the
inherited cross-layer relations needed to identify the actual chart. The
retained rational generator does not construct the full symbolic family of
all RREF coordinates, and the adjacent-chart/global descent data remain
unattached.

Submitting the rational slice as a “parameter-complete” cluster job would
overstate both the input model and the calculation. No Slurm job was submitted.
The exact order-530 slice replay is small enough to run locally and
is retained at the immutable versioned path recorded in `evidence.json`.

## Verification

Metadata-only validation is portable:

```bash
uv run python \
  research-notes/lane89-mathematical-recovery-20260803-v1/verify_lane89_recovery.py \
  --metadata-only
```

On the internal workspace, the full checker verifies both immutable run
paths, every ZIP member digest, every support-window formula, both determinant
certificates, and optionally regenerates the support and linear-rank JSON:

```bash
uv run python \
  research-notes/lane89-mathematical-recovery-20260803-v1/verify_lane89_recovery.py \
  --regenerate
```

The fresh-parameter order-530 result can be reproduced only at a new,
nonexisting output path:

```bash
uv run python \
  research-notes/lane89-mathematical-recovery-20260803-v1/run_f2_omega530_fresh_parameter.py \
  --bundle /path/to/06-f2-support-windows-order-520-2026-08-03-v1.zip \
  --output-dir /path/to/new-versioned-run
```
