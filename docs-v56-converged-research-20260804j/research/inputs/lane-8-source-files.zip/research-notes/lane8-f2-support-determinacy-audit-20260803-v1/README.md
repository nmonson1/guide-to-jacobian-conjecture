> **Current status (4 August 2026).** This is a historical pre-recovery audit. Its statement that inherited linear relations were not supplied is superseded by research-notes/lane8-f2-root-divisibility-20260804-v1/README.md, which gives exact 202-block coordinates and a triangular inverse. It is retained here only for its distinction among complete corner chains, maximal support envelopes, actual transported supports, convex polygons, and normal windows. Do not use its old task-readiness conclusions.

# Lane 8 F2 support-determinacy audit

Date: 2026-08-03

Scope: exact audit and replacement-task contract; no claim of support uniqueness.

## Conclusion

The advertised Lane 8 task does **not** currently have a supplied finite
candidate-generation algorithm for exact post-shear Newton supports.

The cited 2017 complete-chain algorithms do give a finite generator for
**corner chains**. They do not generate coefficient supports, support
polygons after a shear, inherited coefficient relations, or cancellation
branches. For F2 they have already produced the one-edge complete corner
chain

\[
 ((5,20),(1,0)),\qquad (7\mathbin{\wr}5,2),
\]

whose final geometric corner is \((7/5,2)\). Thus there is no ungenerated
intermediate *corner* in this chain. The v7c phrase "intervening normalized
support chain" denotes a new coefficient-level object and is not the output
type of Algorithms 2--8 in the cited paper.

The strongest task supported by the current F2 seed and maximal windows is to
construct the exact inherited coefficient-relation packet for the one
denominator-five shear. Exact-support uniqueness should remain non-ready
until that packet and a support-stratification contract are supplied.

## Material inspected

The audit read and compared:

- `private-source/research-handoff-v7c/lanes/plane-newton-queue-terminal-certificates.md`;
- `private-source/research-handoff-v7c/README.md`;
- `manuscripts/06-plane-boundary/computational-supplement/terminal-boundary/F2_degree125_boundary_seed.md`;
- `manuscripts/06-plane-boundary/computational-supplement/terminal-boundary/terminal_boundary_gluing_program.md`;
- `manuscripts/06-plane-boundary/computational-supplement/terminal-boundary/verify_F2_degree125_seed.py`;
- `manuscripts/06-plane-boundary/computational-supplement/terminal-boundary/terminal_primary_belyi_reduction.md` and its named exact verifiers;
- `research-notes/lane89-mathematical-recovery-20260803-v1/README.md` and `evidence.json`;
- the complete `scripts/f2_support_windows.py` and support-model report in the
  exact bundle with SHA-256
  `a0017d6537021b80098b78349cd7ad5566f6606d053b7e8f3f1dbd634d14ca64`;
- Guccione--Guccione--Horruitiner--Valqui, *Some algorithms related to the
  Jacobian Conjecture*, arXiv:1708.07936v1, including Definitions 2.1, 2.2,
  2.12, 2.15, 2.19, and 2.25; Algorithms 2--8; Theorem 2.20; and the F2 rows
  in Sections 5--6. The downloaded single-file TeX source had SHA-256
  `2afcbe3e6f97eb0d584b097be6ac467b225cbbfd79a4c65c404c40a46d24065e`.

The supplied support generator was replayed in a fresh temporary directory.
It reproduced 4,433 P positions, 12,340 Q positions, 981 and 1,663 nonempty
normal layers, and 2,681 nonempty determinant-output layers ending at order
2,716.

## What the 2017 finite algorithm actually generates

The paper represents a corner by \((a\mathbin{\wr}l,b)\), with geometric
realization \((a/l,b)\). Starting from a valid edge
\(C_0=(\mathcal A,\mathcal A')\):

1. Algorithm 3 enumerates the finitely many generated corners. Its
   non-simple branch loops over the explicit integer interval
   \(b'+1\le b_1\le\gamma_{\max}\); its simple branch has at most one
   generated corner.
2. Algorithm 4 enumerates child edges using finite integer ranges for
   \(\mu\) and \(1\le j\le\lfloor b_1/\operatorname{gap}(\rho_1,l_1)\rfloor\).
3. Algorithm 5 separates child edges from final generated corners.
4. Algorithm 6 performs breadth-first extension, with the exact length bound

   \[
   \operatorname{length}(CH)\le
   \Omega\!\left(\gcd\!\left(b,{b-b'\over\rho}\right)\right)+1,
   \]

   where \(\Omega\) counts prime factors with multiplicity and
   \((\rho,\sigma)=\operatorname{dir}(A-A')\).
5. Algorithm 7 tests the divisibility conditions of Definition 2.25, and
   Algorithm 8 runs the preceding finite procedures under a bound
   \(v_{11}(A_0)\le M\).

For F2, \((\rho,\sigma)=(5,-1)\), \(b=20\), and \(b'=0\), so Algorithm 6's
general bound is

\[
 \Omega(\gcd(20,20/5))+1=\Omega(4)+1=3.
\]

The published admissible-chain table is stronger than that general bound:
F2 is listed among the length-one chains with final corner
\((7\mathbin{\wr}5,2)\). Choosing the family parameter that gives
\((m,n)=(3,5)\) yields maximum degree 125.

Nothing in these algorithms has a coefficient ring, a post-shear support
set, a determinant ideal, or a branch on vanishing transformed
coefficients. They therefore cannot be cited as the missing support-polygon
candidate generator.

## The three objects currently conflated

The current Lane 8 wording treats three distinct finite objects as if they
were one:

1. **Complete corner chain.** Already fixed for F2 and of length one.
2. **Maximal independent support envelope.** Already generated by the
   support-window script. It is an outer bound obtained by allowing every
   terminal-admissible post-shear coefficient independently.
3. **Actual transported coefficient support.** Unknown. It is a point of a
   proper linear descent subspace, further cut by the common-power face and
   the determinant equations. Exact Newton polygons and actual normal
   windows depend on which coordinates vanish on this constructible locus.

If "support polygon" means only the convex hull of the maximal envelope, it
is already computed and unique. If it means the convex hull of an actual
solution, or the complete set of its nonzero coefficients, a candidate
generator needs the inherited relation ideal and explicit zero/nonzero
stratification rules. V7c does not choose among these meanings.

## Exact missing linear descent data

The missing relations can be written without solving the nonlinear Keller
system. Let \(c_{i,j}\) be a source coefficient and apply

\[
 y\longmapsto y+\lambda x^{-1/5},\qquad \lambda\ne0.
\]

For a fixed initial weight \(w=5i-j\), write the coefficient of
\(x^{(w+J)/5}y^J\) after the shear as \(d_{w,J}\). Then

\[
 d_{w,J}=
 \sum_{\substack{(i,j)\text{ in the source envelope}\\5i-j=w,\ j\ge J}}
 \binom jJ\lambda^{j-J}c_{i,j}.
\tag{1}
\]

The source envelopes are

\[
\begin{aligned}
P:&\quad 0\le i\le15,\ 0\le j\le60,\ 5i-j\le15,\\
Q:&\quad 0\le i\le25,\ 0\le j\le100,\ 5i-j\le25.
\end{aligned}
\]

They contain 586 and 1,576 coefficient positions. Their full shear images
have 4,486 and 12,476 positions. Imposing the terminal half-spaces

\[
5(w+J)-17J\le3\quad(P),\qquad
5(w+J)-17J\le5\quad(Q)
\]

sets 53 and 136 full-envelope coordinates to zero and leaves the familiar
4,433 and 12,340 maximal positions.

Over \(K(\lambda)\), \(\lambda\ne0\), the forbidden-coordinate matrices
have ranks 53 and 136. Consequently the linear transported loci inside the
maximal allowed coordinate spaces have dimensions

\[
586-53=533\quad(P),\qquad 1576-136=1440\quad(Q).
\]

Thus the independent-coordinate enlargement omits

\[
(4433-533)+(12340-1440)=3900+10900=\boxed{14800}
\]

independent linear descent relations. This count precedes, and therefore
does not include, additional common-power, exact-double-root, determinant,
normalization, or required-nonzero constraints.

The rank is independent of the chosen nonzero \(\lambda\): each transport
block has entries \(\binom jJ\lambda^{j-J}\), obtained from the
\(\lambda=1\) block by invertible row and column scalings. The checker below
computes the exact \(\lambda=1\) ranks block by block.

## Strongest genuinely startable replacement task

### Ready task L8-T1R — inherited F2 coefficient-relation packet

**Inputs.** The F2 corner data, the two source envelopes above, the exact
shear (1), the terminal half-spaces, the common-power leading face with its
distinguished nonzero double root, and the normalized determinant equation.

**Deliverable.** Produce one self-contained finite coefficient packet that:

1. declares every source coefficient and every post-shear coefficient;
2. exports equation (1) block by block, with the 53 P and 136 Q forbidden
   terminal coordinates explicitly set to zero;
3. eliminates the source coefficients, or exports an equivalent
   presentation, to give all inherited linear relations among the 4,433 P
   and 12,340 Q allowed coordinates;
4. adds the common-power, exact-double-root, determinant, normalization, and
   required-nonzero equations and localization factors;
5. states whether \(\lambda\) is retained, passed to a finite cover, or set
   to one by a proved gauge equivalence;
6. proves the forward and inverse correspondence between the declared
   source-pair locus and the transported constructible locus; and
7. supplies a machine-readable variable order, equation manifest, checksums,
   and a checker that reconstructs every matrix and equation.

This task is finite, begins directly from the supplied formulas, and creates
the actual input required by support determinacy. It does not require
solving the resulting nonlinear constructible system.

### Inputs still needed before full support uniqueness enumeration is ready

After L8-T1R, a separate candidate-generation contract must specify:

1. whether candidates are full nonzero support sets, convex Newton polygons,
   or only two-point normal-window intervals;
2. the required nonzero vertices in every chart and every allowed
   normalization complement;
3. the equivalence relation generated by root choice, source/target scaling,
   and complete-chain recharting;
4. an exhaustive finite stratification rule: for example, enumerate convex
   hulls from the finite allowed lattice, impose zero outside each hull,
   invert its vertices, and decide nonemptiness after saturation by all open
   factors; and
5. a proof that every actual F2 pair lands in one enumerated stratum and that
   every discarded stratum is empty.

Without these items, the current request to "prove uniqueness, or give all
finite alternatives" supplies tests for a proposed support but no declared
generator of all proposals.

## Recommended wording

### Lane 8 live problem

> Construct the exact inherited coefficient-relation system for the
> denominator-five F2 shear inside the terminal half-space. Use it to define
> a finite constructible stratification of possible actual post-shear Newton
> polygons and normal windows. Support uniqueness is the subsequent task,
> not a current input-ready computation.

### Lane 8 ready-task heading and limit

> **Ready task L8-T1 — inherited coefficient-relation packet for F2.**
> Export and verify the complete source-to-sheared coefficient map, terminal
> vanishing equations, inherited relations, common-power face, determinant
> equations, normalizations, and localization factors.

> **Non-ready follow-up — actual support determinacy.** Enumerate and decide
> all exact support strata only after L8-T1 supplies the relation packet and a
> precise candidate-equivalence contract.

### Portfolio row

- **Useful next work:** Export the exact inherited F2 coefficient relations
  for the denominator-five shear.
- **Readiness:** **Task-ready:** finite coefficient-transport packet; actual
  support uniqueness remains blocked on that packet and a support-stratification
  contract.

## Checker

Run:

```bash
uv run python \
  research-notes/lane8-f2-support-determinacy-audit-20260803-v1/verify_lane8_f2_support_determinacy_audit.py \
  --full \
  --json /new/versioned-run/summary.json
```

The checker is self-contained and refuses to overwrite its optional JSON
output. It verifies the two edge directions, the Algorithm 6 length bound,
source/shear/terminal support counts, forbidden-block ranks, the
14,800-relation lower bound, all normal layer counts, C5 characters, and the
2,681 determinant-output layers.
