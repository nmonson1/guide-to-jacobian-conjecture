#!/usr/bin/env python3
"""Exact infinitesimal rigidity of the first lattice-quotient boundary maps.

For the quotient equation

    N p q - m u p q' + n u p' q = 1/g,

the constants p(0),q(0) are fixed and u-scaling remains.  This script forms
the exact linearization on the full coefficient windows, proves surjectivity,
and verifies that its kernel is exactly the scaling vector (u p',u q').
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import sympy as sp

u = sp.symbols("u")


def linearization_record(
    *, label: str, p: sp.Expr, q: sp.Expr, m: int, n: int, g: int, extension: Any = None
) -> dict[str, Any]:
    A, B = int(sp.degree(p, u)), int(sp.degree(q, u))
    N = n // g
    avec = sp.symbols(f"a1:{A+1}")
    bvec = sp.symbols(f"b1:{B+1}")
    alpha = sum(avec[i - 1] * u**i for i in range(1, A + 1))
    beta = sum(bvec[j - 1] * u**j for j in range(1, B + 1))
    Dexpr = sp.expand(
        N * (alpha * q + p * beta)
        - m * u * (alpha * sp.diff(q, u) + p * sp.diff(beta, u))
        + n * u * (sp.diff(alpha, u) * q + sp.diff(p, u) * beta)
    )
    variables = list(avec) + list(bvec)
    rows = A + B - 1
    matrix = sp.Matrix(
        [[sp.expand(Dexpr).coeff(u, degree).coeff(var) for var in variables] for degree in range(1, rows + 1)]
    )
    rank = int(matrix.rank(iszerofunc=lambda x: sp.simplify(x) == 0))
    assert rank == rows
    null = matrix.nullspace(iszerofunc=lambda x: sp.simplify(x) == 0)
    assert len(null) == 1

    scaling_alpha = sp.expand(u * sp.diff(p, u))
    scaling_beta = sp.expand(u * sp.diff(q, u))
    scaling = sp.Matrix(
        [scaling_alpha.coeff(u, i) for i in range(1, A + 1)]
        + [scaling_beta.coeff(u, j) for j in range(1, B + 1)]
    )
    scaling_residual = (matrix * scaling).applyfunc(sp.simplify)
    assert scaling_residual == sp.zeros(rows, 1)
    # Kernel generator and scaling vector must be proportional.
    gen = null[0]
    ratios = [sp.simplify(gen[i] / scaling[i]) for i in range(len(gen)) if scaling[i] != 0]
    assert ratios and all(sp.simplify(r - ratios[0]) == 0 for r in ratios)
    assert all(sp.simplify(gen[i]) == 0 for i in range(len(gen)) if sp.simplify(scaling[i]) == 0)

    _, pivots = matrix.rref(iszerofunc=lambda x: sp.simplify(x) == 0)
    pivot_cols = [int(j) for j in pivots[:rows]]
    minor = sp.simplify(matrix[:, pivot_cols].det())
    assert minor != 0

    return {
        "label": label,
        "degrees": [A, B],
        "domain_dimension_fixed_constants": A + B,
        "target_dimension": rows,
        "rank": rank,
        "kernel_dimension": 1,
        "kernel": "span{(u p'(u), u q'(u))}",
        "pivot_columns_zero_based": pivot_cols,
        "nonzero_maximal_minor": str(minor),
    }


def maps() -> list[dict[str, Any]]:
    sqrt6 = sp.sqrt(6)
    out: list[dict[str, Any]] = []

    out.append(
        dict(
            label="F2_max125",
            p=1 - u,
            q=sp.Rational(1, 5) - sp.Rational(3, 5) * u + sp.Rational(9, 25) * u**2,
            m=3,
            n=5,
            g=5,
        )
    )

    P = u**3 + u**2 + sp.Rational(5, 12) * u + sp.Rational(1, 18)
    Q = (
        u**5
        + sp.Rational(3, 2) * u**4
        + u**3
        + sp.Rational(1, 3) * u**2
        + sp.Rational(5, 96) * u
        + sp.Rational(1, 576)
    )
    out.append(dict(label="one_step_max126", p=18 * P, q=192 * Q, m=2, n=3, g=3))

    out.append(
        dict(
            label="two_step_max126",
            p=1
            + sp.Rational(20, 3) * u
            + 24 * u**2
            + sp.Rational(288, 7) * u**3
            + sp.Rational(288, 7) * u**4,
            q=sp.Rational(1, 2) + 5 * u + 12 * u**2 + 18 * u**3,
            m=3,
            n=2,
            g=2,
        )
    )

    for sign in (-1, 1):
        p = 1 + u + (sp.Rational(1, 3) + sign * sqrt6 / 18) * u**2
        q = (
            sp.Rational(1, 4)
            + sp.Rational(5, 8) * u
            + (sp.Rational(2, 5) + sign * sqrt6 / 40) * u**2
            + (sp.Rational(17, 160) + sign * sp.Rational(11, 480) * sqrt6) * u**3
        )
        out.append(
            dict(
                label=f"F24_max128_{'plus' if sign == 1 else 'minus'}",
                p=p,
                q=q,
                m=3,
                n=4,
                g=4,
                extension=sqrt6,
            )
        )
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    records = [linearization_record(**item) for item in maps()]
    if args.json:
        args.json.write_text(json.dumps(records, indent=2) + "\n")
    print(json.dumps(records, indent=2))
    print("all reduced terminal maps are infinitesimally rigid modulo source scaling")


if __name__ == "__main__":
    main()
