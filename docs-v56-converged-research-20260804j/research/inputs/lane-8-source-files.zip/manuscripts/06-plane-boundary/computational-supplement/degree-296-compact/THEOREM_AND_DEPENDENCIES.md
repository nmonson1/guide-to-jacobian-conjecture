# Exact theorem and dependency boundary

## Unconditional theorem for the six displayed polynomials

Let

\[
K=\mathbf Q(u),\qquad u^5-u^4+3u^3+3u^2+26=0,
\]

and let

\[
\rho=F_4,\qquad (g_1,g_2,g_3,g_4,g_5)=(F_6,F_8,F_9,F_{10},F_{11})
\]

be the six exact polynomials in `inputs/handoff-lite/layer-calculation/full_exact_fivevar_w8.json`.
At the prime `p=2053`, with `u=216`, the five equations `g_1,...,g_5` are
BKK-nondegenerate: every one of the 344 proper faces of the Minkowski sum
has root-free initial system in the algebraic torus.  The mixed volume is 296.
The resulting special algebra is reduced of dimension 296, every coordinate
is invertible, and multiplication by `rho` has determinant 682.

Localizing the coefficient ring at `(2053,u-216)` therefore gives a finite
etale scheme of rank 296, and `rho` is a unit on it.  Consequently

\[
V(\rho,g_1,g_2,g_3,g_4,g_5)(\overline K)=\varnothing.
\]

This characteristic-zero conclusion does not depend on a heuristic modular
lift: the projective toric compactification is proper, the full special fiber
is the reduced 296-point torus scheme, all boundary initial systems are
root-free, and the etale locus containing the special fiber must be the entire
finite scheme over the local DVR.

## Raw-support bridge for the Keller interpretation

The companion program
`../degree-twenty-one/raw-support-reconstruction/rebuild_lower_face_reduction.py`
now audits the bridge that was previously imported. Starting from the two
displayed normalized Newton polygons, it:

1. generates every lattice point and deficiency layer directly from the
   polygon vertices;
2. reconstructs the exact degree-\(21\) lower face and verifies its Jacobian
   equation coefficientwise;
3. performs the complete truncated recursion and verifies the rank-\(14\)
   Macaulay contradiction after vertex saturation;
4. performs the full recursion through order \(8\), verifies the weight-four
   square, and proves that vertex saturation justifies the nonzero parameter
   normalization;
5. regenerates the fifteen normalized compatibility equations, including the
   six used here, and matches the recovered equation list coefficientwise.

Thus the exact six-polynomial theorem above is connected by a reproducible
exact calculation to the two normalized raw `(8,28)` supports. The original
`lower_face_layers.py` file remains unrecovered but is no longer used.

The remaining imported dependency is earlier: the package does not reprove
the published reduction from an arbitrary below-\(125\) Keller pair to these
two normalized support alternatives. It also relies on the separate
degree-\(21\) dessin count to show that the generic quintic orbit exhausts the
normalized lower faces. No conclusion about the full plane Jacobian
conjecture follows from the degree bound alone.
