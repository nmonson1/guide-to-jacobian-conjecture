# Adjacent noncoprime merge packet

This packet resolves the abstract adjacent monomial-merge problem after
distinguishing two operations often called weak transform.

- Removing only a common Cartier factor gives the simultaneous fan in either
  order.
- Saturating by the exceptional divisor gives the two circuit triangulations.
  Their relation is governed by
  \(\Delta=a_0(c_0-1)-d_0(b_0-1)\): equality gives a flop and the sign gives
  the flip direction.

`adjacent-merge-theorem.md` contains the proof. Two independent exact programs
check the fan, saturation, circuit, index, discrepancy, and flop formulas.
`PRS_SPECIALIZATION_CONTRACT.md` lists the additional pivot and convention data
required before this abstract result can be applied to an actual all-rank PRS
packet.

No arbitrary-rank PRS specialization is claimed here.
