#!/usr/bin/env python3
"""Exact verifier for P4-L2A: noncoprime adjacent toric merges.

The verifier checks, for all 1 <= a,b,c,d <= GRID_MAX:

1. the primitive normalized-blowup rays u and v;
2. the canonical-cover exceptional-saturation calculation in both orders;
3. the two exceptional-saturated ordered fans and the Cartier-weak common refinement;
4. the simultaneous-linearity fan from its defining inequalities;
5. the primitive circuit, common lattice index, and common refinement ray w;
6. cone-index formulas;
7. discrepancy difference and the K-flip/flop criterion;
8. the complete parametrization of the crepant locus.

The geometric facts that normalized monomial blowups are the fan subdivisions
of their order functions, and that toric discrepancies are evaluated by the
canonical support function, are conventional proof inputs. Everything
specific to the displayed formulas is checked exactly here.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from fractions import Fraction
from hashlib import sha256
from itertools import combinations, product
from math import gcd
import json
from pathlib import Path
from typing import Iterable, Sequence

import sympy as sp

GRID_MAX = 12
ROOT = Path(__file__).resolve().parent
REPORT_PATH = ROOT / "adjacent_merge_report.json"

Vec = tuple[int, int, int]


def gcd_many(values: Iterable[int]) -> int:
    g = 0
    for value in values:
        g = gcd(g, abs(int(value)))
    return g


def add(*vectors: Vec) -> Vec:
    return tuple(sum(v[i] for v in vectors) for i in range(3))  # type: ignore[return-value]


def scale(k: int, v: Vec) -> Vec:
    return (k * v[0], k * v[1], k * v[2])


def dot(a: Vec, b: Vec) -> int:
    return sum(a[i] * b[i] for i in range(3))


def cross(a: Vec, b: Vec) -> Vec:
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def primitive(v: Vec) -> Vec:
    g = gcd_many(v)
    if g == 0:
        raise ValueError("zero vector has no primitive representative")
    vv = tuple(x // g for x in v)
    for x in vv:
        if x:
            if x < 0:
                vv = tuple(-y for y in vv)
            break
    return vv  # type: ignore[return-value]


def det3(a: Vec, b: Vec, c: Vec) -> int:
    return dot(a, cross(b, c))


def cone_index(rays: Sequence[Vec]) -> int:
    if len(rays) != 3:
        raise ValueError("full-dimensional simplicial cone requires three rays")
    return abs(det3(rays[0], rays[1], rays[2]))


def extreme_rays(inequalities: Sequence[Vec]) -> set[Vec]:
    """Extreme rays of a pointed three-dimensional cone {n: row.n >= 0}.

    In dimension three, every extreme ray is the intersection of two facet
    hyperplanes. The routine is exact and intentionally small.
    """
    rays: set[Vec] = set()
    for i, j in combinations(range(len(inequalities)), 2):
        candidate = cross(inequalities[i], inequalities[j])
        if candidate == (0, 0, 0):
            continue
        for oriented in (candidate, scale(-1, candidate)):
            if all(dot(row, oriented) >= 0 for row in inequalities):
                rays.add(primitive(oriented))
                break
    return rays


def minimal_monomial_generators(gens: Iterable[tuple[int, ...]]) -> tuple[tuple[int, ...], ...]:
    data = sorted(set(gens), key=lambda x: (sum(x), x))
    keep: list[tuple[int, ...]] = []
    for candidate in data:
        if any(all(a <= b for a, b in zip(existing, candidate)) for existing in keep):
            continue
        keep = [
            existing
            for existing in keep
            if not all(a <= b for a, b in zip(candidate, existing))
        ]
        keep.append(candidate)
    return tuple(sorted(keep))


def saturate_monomial_by_variable(
    gens: Iterable[tuple[int, ...]], variable: int
) -> tuple[tuple[int, ...], ...]:
    """Return generators of I:x_variable^infinity for a monomial ideal I."""
    stripped = []
    for exponent in gens:
        row = list(exponent)
        row[variable] = 0
        stripped.append(tuple(row))
    return minimal_monomial_generators(stripped)


@dataclass(frozen=True)
class MergeData:
    a: int
    b: int
    c: int
    d: int
    g1: int
    g2: int
    a0: int
    b0: int
    c0: int
    d0: int
    h: int
    u: Vec
    v: Vec
    w: Vec
    p: int
    q: int
    r: int
    s: int
    delta: int


def merge_data(a: int, b: int, c: int, d: int) -> MergeData:
    if min(a, b, c, d) <= 0:
        raise ValueError("all exponents must be positive")
    g1 = gcd(a, b)
    g2 = gcd(c, d)
    a0, b0 = a // g1, b // g1
    c0, d0 = c // g2, d // g2
    h = gcd(a0, d0)
    u = (b0, a0, 0)
    v = (0, d0, c0)
    w = (b0 * d0 // h, a0 * d0 // h, a0 * c0 // h)
    p = d0 // h
    q = a0 * c0 // h
    r = b0 * d0 // h
    s = a0 // h
    delta = a0 * (c0 - 1) - d0 * (b0 - 1)
    return MergeData(a, b, c, d, g1, g2, a0, b0, c0, d0, h, u, v, w, p, q, r, s, delta)


def check_cover_transforms(m: MergeData) -> None:
    """Check Cartier-factor and exceptional-saturated transforms.

    Exponent order in each tuple is (first chart coordinate, exceptional E,
    second chart coordinate). Only monomial saturation is used.
    """
    # Blow up I first. On cone <e_x,u,e_z>:
    # x = X E^b0, y = E^a0, z = Z.
    n_i = m.g1 * m.a0 * m.b0
    x_a = (m.a, m.a * m.b0, 0)
    y_b = (0, m.b * m.a0, 0)
    assert x_a[1] == y_b[1] == n_i
    j_left = ((0, m.a0 * m.c, 0), (0, 0, m.d))
    assert min(g[1] for g in j_left) == 0  # Cartier weak transform is total.
    assert saturate_monomial_by_variable(j_left, 1) == ((0, 0, 0),)

    # On cone <u,e_y,e_z>: x=E^b0, y=E^a0 Y, z=Z.
    x_a = (0, m.a * m.b0, 0)
    y_b = (m.b, m.b * m.a0, 0)
    assert x_a[1] == y_b[1] == n_i
    j_right = ((m.c, m.a0 * m.c, 0), (0, 0, m.d))
    assert min(g[1] for g in j_right) == 0  # Cartier weak transform is total.
    assert saturate_monomial_by_variable(j_right, 1) == minimal_monomial_generators(
        ((m.c, 0, 0), (0, 0, m.d))
    )

    # Blow up J first. On cone <e_x,e_y,v>:
    # x=X, y=Y F^d0, z=F^c0.
    n_j = m.g2 * m.c0 * m.d0
    y_c = (0, m.c, m.c * m.d0)
    z_d = (0, 0, m.d * m.c0)
    assert y_c[2] == z_d[2] == n_j
    i_left = ((m.a, 0, 0), (0, m.b, m.b * m.d0))
    assert min(g[2] for g in i_left) == 0  # Cartier weak transform is total.
    assert saturate_monomial_by_variable(i_left, 2) == minimal_monomial_generators(
        ((m.a, 0, 0), (0, m.b, 0))
    )

    # On cone <e_x,v,e_z>: x=X, y=F^d0, z=F^c0 Z.
    y_c = (0, m.c * m.d0, 0)
    z_d = (0, m.d * m.c0, m.d)
    assert y_c[1] == z_d[1] == n_j
    i_right = ((m.a, 0, 0), (0, m.b * m.d0, 0))
    assert min(g[1] for g in i_right) == 0  # Cartier weak transform is total.
    assert saturate_monomial_by_variable(i_right, 1) == ((0, 0, 0),)


def check_simultaneous_fan(m: MergeData) -> None:
    ex, ey, ez = (1, 0, 0), (0, 1, 0), (0, 0, 1)
    # Signs: x_win means a0*n_x <= b0*n_y; y_win_J means c0*n_y <= d0*n_z.
    regions = {
        (True, True): {ez, m.v, m.w},
        (True, False): {m.u, ey, m.v, m.w},
        (False, True): {ex, m.w, ez},
        (False, False): {ex, m.u, m.w},
    }
    for (x_win, y_win_j), expected in regions.items():
        rows: list[Vec] = [ex, ey, ez]
        rows.append((-m.a0, m.b0, 0) if x_win else (m.a0, -m.b0, 0))
        rows.append((0, -m.c0, m.d0) if y_win_j else (0, m.c0, -m.d0))
        found = extreme_rays(rows)
        assert found == expected, (m, (x_win, y_win_j), found, expected)


def check_circuit_and_indices(m: MergeData) -> None:
    ex, ey, ez = (1, 0, 0), (0, 1, 0), (0, 0, 1)
    assert primitive(m.u) == m.u
    assert primitive(m.v) == m.v
    assert primitive(m.w) == m.w
    assert add(scale(m.p, m.u), scale(m.q, ez)) == m.w
    assert add(scale(m.r, ex), scale(m.s, m.v)) == m.w
    assert gcd_many((m.p, m.q, m.r, m.s)) == 1

    # Every proper triple is independent: this is a genuine four-ray circuit.
    determinants = {
        "ex_u_ez": abs(det3(ex, m.u, ez)),
        "u_v_ez": abs(det3(m.u, m.v, ez)),
        "ex_u_v": abs(det3(ex, m.u, m.v)),
        "ex_v_ez": abs(det3(ex, m.v, ez)),
    }
    assert determinants == {
        "ex_u_ez": m.a0,
        "u_v_ez": m.b0 * m.d0,
        "ex_u_v": m.a0 * m.c0,
        "ex_v_ez": m.d0,
    }

    plus_indices = (
        cone_index((ex, m.u, ez)),
        cone_index((m.u, ey, m.v)),
        cone_index((m.u, m.v, ez)),
    )
    minus_indices = (
        cone_index((ex, m.u, m.v)),
        cone_index((m.u, ey, m.v)),
        cone_index((ex, m.v, ez)),
    )
    assert plus_indices == (m.a0, m.b0 * m.c0, m.b0 * m.d0)
    assert minus_indices == (m.a0 * m.c0, m.b0 * m.c0, m.d0)

    # The four circuit rays generate Z e_x + Z e_z + h Z e_y.
    index = gcd_many(determinants.values())
    assert index == m.h
    assert gcd(m.a0, m.d0) == m.h

    # The two circuit triangulations are strict coherent subdivisions.
    # Plus heights: H(u)=H(ez)=0, H(ex)=H(v)=1.
    assert Fraction(-m.r, m.s) < 1  # linear extension from <ex,u,ez> at v
    assert Fraction(-m.s, m.r) < 1  # linear extension from <u,v,ez> at ex
    # Minus heights: H(ex)=H(v)=0, H(u)=H(ez)=1.
    assert Fraction(-m.p, m.q) < 1  # extension from <ex,u,v> at ez
    assert Fraction(-m.q, m.p) < 1  # extension from <ex,v,ez> at u

    # Discrepancy difference on the common star subdivision.
    discrepancy_plus = m.p + m.q - 1
    discrepancy_minus = m.r + m.s - 1
    assert discrepancy_plus - discrepancy_minus == m.delta // m.h
    assert m.delta % m.h == 0

    # The four-ray contraction is Q-Gorenstein iff all four rays lie on one
    # affine height-one hyperplane. Values on ex and ez force alpha=gamma=1;
    # the u equation forces beta=(1-b0)/a0, and v then gives delta=0.
    beta = Fraction(1 - m.b0, m.a0)
    q_gorenstein = Fraction(m.d0) * beta + m.c0 == 1
    assert q_gorenstein == (m.delta == 0)

    # Raw-exponent version used by the handoff note.
    G = gcd_many((m.b * m.d, m.a * m.d, m.a * m.c))
    assert G == m.g1 * m.g2 * m.h
    assert m.p == m.d * m.g1 // G
    assert m.q == m.a * m.c // G
    assert m.r == m.b * m.d // G
    assert m.s == m.a * m.g2 // G
    assert scale(m.g1, m.u) == (m.b, m.a, 0)
    assert scale(m.g2, m.v) == (0, m.d, m.c)
    assert scale(G, m.w) == (m.b * m.d, m.a * m.d, m.a * m.c)


def check_flop_parametrization(m: MergeData) -> None:
    if m.delta != 0:
        return
    A = m.a0 // m.h
    D = m.d0 // m.h
    assert gcd(A, D) == 1
    assert (m.b0 - 1) % A == 0
    assert (m.c0 - 1) % D == 0
    t1 = (m.b0 - 1) // A
    t2 = (m.c0 - 1) // D
    assert t1 == t2 and t1 >= 0
    assert m.b0 == 1 + A * t1
    assert m.c0 == 1 + D * t1
    assert gcd(m.h, m.b0) == gcd(m.h, m.c0) == 1


def symbolic_checks() -> None:
    a0, b0, c0, d0, h = sp.symbols("a0 b0 c0 d0 h", positive=True, integer=True)
    ex = sp.Matrix([1, 0, 0])
    ez = sp.Matrix([0, 0, 1])
    u = sp.Matrix([b0, a0, 0])
    v = sp.Matrix([0, d0, c0])
    w = sp.Matrix([b0 * d0 / h, a0 * d0 / h, a0 * c0 / h])
    p, q, r, s = d0 / h, a0 * c0 / h, b0 * d0 / h, a0 / h
    assert sp.simplify(p * u + q * ez - w) == sp.zeros(3, 1)
    assert sp.simplify(r * ex + s * v - w) == sp.zeros(3, 1)
    delta = a0 * (c0 - 1) - d0 * (b0 - 1)
    assert sp.simplify((p + q - 1) - (r + s - 1) - delta / h) == 0


def main() -> None:
    symbolic_checks()
    records: list[dict[str, object]] = []
    total = 0
    crepant = 0
    positive = 0
    negative = 0

    for a, b, c, d in product(range(1, GRID_MAX + 1), repeat=4):
        m = merge_data(a, b, c, d)
        check_cover_transforms(m)
        check_simultaneous_fan(m)
        check_circuit_and_indices(m)
        check_flop_parametrization(m)
        total += 1
        if m.delta == 0:
            crepant += 1
        elif m.delta > 0:
            positive += 1
        else:
            negative += 1
        # Retain one representative for each reduced quadruple.
        if m.g1 == 1 and m.g2 == 1:
            records.append(
                {
                    "a0": m.a0,
                    "b0": m.b0,
                    "c0": m.c0,
                    "d0": m.d0,
                    "h": m.h,
                    "u": m.u,
                    "v": m.v,
                    "w": m.w,
                    "circuit": [m.p, m.q, -m.r, -m.s],
                    "delta": m.delta,
                    "classification": (
                        "flop" if m.delta == 0 else "J_to_I -> I_to_J flip" if m.delta > 0 else "I_to_J -> J_to_I flip"
                    ),
                }
            )

    canonical = json.dumps(records, sort_keys=True, separators=(",", ":")).encode()
    digest = sha256(canonical).hexdigest()
    report = {
        "schema_version": 1,
        "grid_max": GRID_MAX,
        "raw_quadruples_checked": total,
        "crepant_raw_quadruples": crepant,
        "positive_delta_raw_quadruples": positive,
        "negative_delta_raw_quadruples": negative,
        "reduced_records": len(records),
        "reduced_records_sha256": digest,
        "theorem": {
            "cartier_factor_weak_fan": "simultaneous_fan_in_both_orders",
            "saturated_plus_fan": ["<e_x,u,e_z>", "<u,e_y,v>", "<u,v,e_z>"],
            "saturated_minus_fan": ["<e_x,u,v>", "<u,e_y,v>", "<e_x,v,e_z>"],
            "simultaneous_fan": [
                "<e_x,u,w>",
                "<e_x,w,e_z>",
                "<u,e_y,v,w>",
                "<w,v,e_z>",
            ],
            "cartier_factor_weak_criterion": "orders always identical",
            "exceptional_saturation_flop_criterion": "a0*(c0-1) = d0*(b0-1)",
        },
    }
    REPORT_PATH.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    print("P4-L2A exact adjacent-merge verification")
    print(f"grid: 1 <= a,b,c,d <= {GRID_MAX}")
    print(f"raw quadruples checked: {total}")
    print(f"crepant / delta>0 / delta<0: {crepant} / {positive} / {negative}")
    print(f"reduced records: {len(records)}")
    print(f"reduced-record digest: {digest}")
    print("Cartier-factor weak transforms commute: PASS")
    print("canonical-cover exceptional saturations: PASS")
    print("saturated ordered fans: PASS")
    print("simultaneous-linearity fan: PASS")
    print("primitive circuit and lattice-index formulas: PASS")
    print("cone indices, coherent triangulations, and discrepancies: PASS")
    print("Q-Gorenstein/flop criterion and crepant-locus parametrization: PASS")
    print("ALL P4-L2A ADJACENT-MERGE CHECKS PASSED")


if __name__ == "__main__":
    main()
