# PRS specialization contract for P4-L2A

The abstract adjacent-merge problem needs more than four monomial exponents.
It also needs the exact transform convention. Two operations that are both
called a “weak transform” in the literature give different answers for

\[
I=(X^a,Y^b),\qquad J=(Y^c,Z^d).
\]

## Convention gate

A packet must select one of:

```text
cartier_factor_weak
exceptional_saturation
```

### `cartier_factor_weak`

Remove only the largest common exceptional Cartier factor from the pulled-back
second pair. In this adjacent model one generator always has exceptional order
zero. Therefore no exceptional factor is removed, both orders retain the
simultaneous ray, and the normalized models are identical for every positive
`a,b,c,d`.

### `exceptional_saturation`

Replace the pulled-back second ideal `K` by `K:E^\infty` on the canonical
toric cover. This removes an exceptional component and produces the two
circuit triangulations. Their flip/flop type is determined by `delta` below.

The selected convention must be supported by a proof artifact for the actual
PRS graph. A name alone is insufficient.

## Fail-closed rule

A packet is admissible only if it validates against
`prs-adjacent-merge-contract.schema.json` and passes
`validate_prs_contract.py`. Missing data must produce

```text
INSUFFICIENT PRS PIVOT DATA
```

rather than a guessed convention or exponent quadruple.

## Required mathematical content

1. **Transform convention.** The selected operation and a hash-pinned proof
   showing that it is the actual PRS construction.
2. **Toroidal chart.** Primitive parameters `(X,Y,Z)`, their divisor lattice,
   all localizations, and identification of the shared divisor `Y=0`.
3. **Four pivot valuations.** After removing the declared projective common
   monomial factor from each pair, the valuation rows must be

   ```text
   I: (a,0,0), (0,b,0)
   J: (0,c,0), (0,0,d).
   ```

4. **Integral-closure certificate.** A certificate that the actual ideals have
   the same integral closures as `(X^a,Y^b)` and `(Y^c,Z^d)`. This is the
   no-extra-Newton-ray condition.
5. **Transform ledger.** In both orders: the canonical-cover exceptional
   coordinate, exceptional order of every generator, common Cartier factor,
   Cartier weak generators, full saturation, selected operation, the exact
   selected generator list, and retained closed complement. The selected list
   must equal the Cartier-weak list or the saturated list according to the
   top-level convention.
6. **Lattice and characters.** Primitive rays, stacky multiplicities, circuit
   Smith data, simultaneous-ray multiplicity, projective-coordinate
   characters, and relative-Jacobian character.
7. **Transfer data.** Exact transfer matrices in both orders, including
   monomial factors and immutable artifact hashes.

## Computation

From the certified exponents compute

```text
g1 = gcd(a,b),       g2 = gcd(c,d),
a0 = a/g1, b0=b/g1, c0=c/g2, d0=d/g2,
h  = gcd(a0,d0),
delta = a0*(c0-1) - d0*(b0-1).
```

The output is:

```text
cartier_factor_weak:
    commuting_simultaneous, for every delta

exceptional_saturation:
    delta = 0 : flop
    delta > 0 : J_then_I -> I_then_J flip
    delta < 0 : I_then_J -> J_then_I flip
```

The coarse answer does not settle stacky triple-overlap compatibility. The
character and transfer blocks remain load-bearing inputs for P4-L2B.

## Calibration fixtures

`quintic_unit_calibration.json` selects `exceptional_saturation` and records

```text
a=b=c=d=1,
u=(1,1,0), v=(0,1,1), w=(1,1,1),
u+e_z=e_x+v,
classification=flop.
```

`quintic_unit_cartier_weak_calibration.json` uses the same exponents but
selects `cartier_factor_weak`; its classification is
`commuting_simultaneous`.

Both are marked `calibration_only`. Neither substitutes for an arbitrary-rank
PRS pivot packet.
