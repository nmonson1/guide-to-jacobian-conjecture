#!/usr/bin/env python3
"""Independent standard-library replay for the P4-L2A toric theorem.

This implementation intentionally does not import SymPy. It reconstructs the
four simultaneous chambers directly from inequalities, checks the two circuit
triangulations and canonical-cover monomial saturations, and audits the flop
locus through a larger finite grid.
"""
from __future__ import annotations

from hashlib import sha256
from itertools import combinations, product
from math import gcd
import json

GRID_MAX = 16


def gcd_all(xs):
    g = 0
    for x in xs:
        g = gcd(g, abs(x))
    return g


def dot(a, b):
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]


def cross(a, b):
    return (
        a[1]*b[2]-a[2]*b[1],
        a[2]*b[0]-a[0]*b[2],
        a[0]*b[1]-a[1]*b[0],
    )


def neg(a):
    return (-a[0], -a[1], -a[2])


def primitive(v):
    g = gcd_all(v)
    assert g
    w = tuple(x//g for x in v)
    for x in w:
        if x:
            return neg(w) if x < 0 else w
    raise AssertionError


def det(a, b, c):
    return dot(a, cross(b, c))


def extreme_rays(rows):
    ans = set()
    for i, j in combinations(range(len(rows)), 2):
        v = cross(rows[i], rows[j])
        if v == (0,0,0):
            continue
        for w in (v, neg(v)):
            if all(dot(r, w) >= 0 for r in rows):
                ans.add(primitive(w))
                break
    return ans


def monomial_saturate(gens, idx):
    stripped = []
    for g in gens:
        row = list(g)
        row[idx] = 0
        stripped.append(tuple(row))
    minimal = []
    for q in sorted(set(stripped), key=lambda z:(sum(z), z)):
        if any(all(p[i] <= q[i] for i in range(len(q))) for p in minimal):
            continue
        minimal = [p for p in minimal if not all(q[i] <= p[i] for i in range(len(q)))]
        minimal.append(q)
    return tuple(sorted(minimal))


def audit(a,b,c,d):
    ex,ey,ez=(1,0,0),(0,1,0),(0,0,1)
    g1,g2=gcd(a,b),gcd(c,d)
    a0,b0,c0,d0=a//g1,b//g1,c//g2,d//g2
    h=gcd(a0,d0)
    u=(b0,a0,0)
    v=(0,d0,c0)
    w=(b0*d0//h,a0*d0//h,a0*c0//h)
    p,q,r,s=d0//h,a0*c0//h,b0*d0//h,a0//h
    delta=a0*(c0-1)-d0*(b0-1)

    assert tuple(p*u[i]+q*ez[i] for i in range(3)) == w
    assert tuple(r*ex[i]+s*v[i] for i in range(3)) == w
    assert gcd_all((p,q,r,s)) == 1
    assert gcd_all(w) == 1

    # Circuit determinants and the cross-lattice quotient N/L = Z/h.
    minors=(abs(det(ex,u,ez)),abs(det(u,v,ez)),abs(det(ex,u,v)),abs(det(ex,v,ez)))
    assert minors==(a0,b0*d0,a0*c0,d0)
    assert gcd_all(minors)==h

    # Ordered cone indices.
    assert (abs(det(ex,u,ez)),abs(det(u,ey,v)),abs(det(u,v,ez))) == (a0,b0*c0,b0*d0)
    assert (abs(det(ex,u,v)),abs(det(u,ey,v)),abs(det(ex,v,ez))) == (a0*c0,b0*c0,d0)

    # Four domains of simultaneous linearity.
    chambers={
      (1,1):{ez,v,w},
      (1,-1):{u,ey,v,w},
      (-1,1):{ex,w,ez},
      (-1,-1):{ex,u,w},
    }
    for (si,sj),expected in chambers.items():
        rows=[ex,ey,ez]
        rows.append((-a0,b0,0) if si==1 else (a0,-b0,0))
        rows.append((0,-c0,d0) if sj==1 else (0,c0,-d0))
        assert extreme_rays(rows)==expected

    # Cartier-factor weak transforms remove no exceptional power in either
    # order, because one generator has exceptional order zero on every chart.
    assert min(q[1] for q in ((0,a0*c,0),(0,0,d)))==0
    assert min(q[1] for q in ((c,a0*c,0),(0,0,d)))==0
    assert min(q[2] for q in ((a,0,0),(0,b,b*d0)))==0
    assert min(q[1] for q in ((a,0,0),(0,b*d0,0)))==0

    # Canonical-cover exceptional saturation, I then J.
    assert monomial_saturate(((0,a0*c,0),(0,0,d)),1)==((0,0,0),)
    assert monomial_saturate(((c,a0*c,0),(0,0,d)),1)==tuple(sorted(((c,0,0),(0,0,d))))
    # Reverse order.
    assert monomial_saturate(((a,0,0),(0,b,b*d0)),2)==tuple(sorted(((a,0,0),(0,b,0))))
    assert monomial_saturate(((a,0,0),(0,b*d0,0)),1)==((0,0,0),)

    # Coherent triangulations: the nonselected ray lies strictly above each
    # linear extension of the assigned 0/1 height data.
    from fractions import Fraction
    assert Fraction(-r,s)<1 and Fraction(-s,r)<1
    assert Fraction(-p,q)<1 and Fraction(-q,p)<1

    # Discrepancy difference, Q-Gorenstein criterion, and flop parametrization.
    assert (p+q-1)-(r+s-1)==delta//h
    assert delta%h==0
    beta=Fraction(1-b0,a0)
    assert ((d0*beta+c0)==1)==(delta==0)
    G=g1*g2*h
    assert tuple(g1*x for x in u)==(b,a,0)
    assert tuple(g2*x for x in v)==(0,d,c)
    assert tuple(G*x for x in w)==(b*d,a*d,a*c)
    if delta==0:
        A,D=a0//h,d0//h
        assert gcd(A,D)==1
        assert (b0-1)%A==0 and (c0-1)%D==0
        t=(b0-1)//A
        assert t==(c0-1)//D
        assert b0==1+A*t and c0==1+D*t
    return (a0,b0,c0,d0,h,p,q,r,s,delta)


def main():
    counts={"flop":0,"positive":0,"negative":0}
    reduced=set()
    for values in product(range(1,GRID_MAX+1), repeat=4):
        rec=audit(*values)
        reduced.add(rec)
        delta=rec[-1]
        counts["flop" if delta==0 else "positive" if delta>0 else "negative"] += 1
    encoded=json.dumps(sorted(reduced),separators=(",",":"),sort_keys=False).encode()
    digest=sha256(encoded).hexdigest()
    print("Independent P4-L2A replay (Python standard library)")
    print(f"grid: 1 <= a,b,c,d <= {GRID_MAX}")
    print(f"quadruples: {GRID_MAX**4}")
    print(f"class counts: {counts}")
    print(f"distinct reduced records: {len(reduced)}")
    print(f"record digest: {digest}")
    print("inequality reconstruction of simultaneous fan: PASS")
    print("Cartier-factor weak transforms commute: PASS")
    print("canonical-cover monomial saturations: PASS")
    print("circuit, lattice, coherence, and discrepancy formulas: PASS")
    print("Q-Gorenstein criterion and flop parametrization: PASS")
    print("INDEPENDENT P4-L2A CHECKS PASSED")

if __name__ == "__main__":
    main()
