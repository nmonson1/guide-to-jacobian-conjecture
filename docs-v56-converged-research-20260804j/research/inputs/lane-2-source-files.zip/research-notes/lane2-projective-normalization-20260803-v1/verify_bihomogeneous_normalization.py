#!/usr/bin/env python3
"""Exact verification of the bihomogeneous Lane-2 A0 normalization.

This script checks the seven global bihomogeneous relations, their four
standard affine charts, the saturated graph images, the local normality
inputs, and the O(1,1) conductor cover.

It uses exact rational polynomial arithmetic in SymPy 1.14.0.  Serre's
criterion and the depth/Hilbert--Burch deductions are mathematical arguments
recorded in the companion note; the script verifies their polynomial inputs.
"""
from __future__ import annotations

import sympy as sp


def eliminated_saturation(gens, sat, variables):
    """Compute (gens : sat^infinity) by one-variable elimination."""
    aux = sp.Dummy("sat_aux")
    gb = sp.groebner([*gens, 1 - aux * sat], aux, *variables, order="lex")
    return [sp.expand(p.as_expr()) for p in gb.polys if not p.as_expr().has(aux)]


def eliminate_one(gens, variable, remaining):
    gb = sp.groebner(gens, variable, *remaining, order="lex")
    return [sp.expand(p.as_expr()) for p in gb.polys if not p.as_expr().has(variable)]


def ideal_equal(gens_a, gens_b, variables, label):
    ga = sp.groebner(gens_a, *variables, order="lex")
    gb = sp.groebner(gens_b, *variables, order="lex")
    assert all(ga.reduce(sp.expand(f))[1] == 0 for f in gens_b), f"{label}: B not in A"
    assert all(gb.reduce(sp.expand(f))[1] == 0 for f in gens_a), f"{label}: A not in B"


def ideal_intersection(gens_a, gens_b, variables):
    aux = sp.Dummy("mix_aux")
    gb = sp.groebner(
        [*(aux * f for f in gens_a), *((1 - aux) * f for f in gens_b)],
        aux,
        *variables,
        order="lex",
    )
    return [sp.expand(p.as_expr()) for p in gb.polys if not p.as_expr().has(aux)]


def section(title):
    print(f"\n[{title}]")


# ---------------------------------------------------------------------------
# Global Cox-coordinate presentation
# ---------------------------------------------------------------------------
section("global bihomogeneous presentation")
x, y, z, t, U, V, P, Q, Xi = sp.symbols("x y z t U V P Q Xi")
f0 = x * z
g0 = x * t + y * z
h = x + z + t * y
f1 = (x - y**2) * h
g1 = x * t + y * z + 2 * x * y - y**3
A = U**2 - U * V * t + V**2 * z
X = V * x - U * y

R0 = sp.expand(U * g0 - V * f0)
R1 = sp.expand(P * g1 - Q * f1)
R2 = sp.expand(P * (V * z + U * y) + Xi * y - U * Q * h)
R3 = sp.expand(Xi * z - (V * z - U * t) * (Q * h - P * y) - U * P * z)
R4 = sp.expand(
    Xi * X
    + U * Q * (U - V * y) * h
    - U * P * (V * (x + z - y**2) + U * y)
)
R5 = sp.expand(U * Xi * (x - y**2) - A * P * x)
R6 = sp.expand(Xi**2 - A * (P**2 - P * Q * (t + y) + Q**2 * h))
GLOBAL = [R0, R1, R2, R3, R4, R5, R6]
EXPECTED_BIDEGREES = [(1, 0), (0, 1), (1, 1), (1, 1), (2, 1), (2, 1), (2, 2)]

s, r = sp.symbols("s r")
scale = {U: s * U, V: s * V, P: r * P, Q: r * Q, Xi: s * r * Xi}
for poly, (du, dp) in zip(GLOBAL, EXPECTED_BIDEGREES):
    assert sp.expand(poly.xreplace(scale) - s**du * r**dp * poly) == 0
assert sp.Poly(R6, Xi).degree() == 2 and sp.Poly(R6, Xi).LC() == 1
print("seven relations have the declared bidegrees and a monic quadratic: PASS")


# ---------------------------------------------------------------------------
# U=P=1: finite--finite chart
# ---------------------------------------------------------------------------
section("U=P=1 finite--finite chart")
lam, rho, T, w = sp.symbols("lambda rho T w")
t_ff = T + lam * z
alpha = 1 - T * lam
u = T * y + z
xi = x - y**2
v = u + alpha * x
f0_ff = x * z
g0_ff = x * t_ff + y * z
h_ff = x + z + t_ff * y
f1_ff = (x - y**2) * h_ff
g1_ff = x * t_ff + y * z + 2 * x * y - y**3
F0 = sp.expand(T * x + y * z)
F1 = sp.expand(w * u - alpha * z)
F2 = sp.expand(w * xi - alpha * x)
F3 = sp.expand(rho * v - lam * z - (w + 1) * y)
F4 = sp.expand(w**2 - alpha * (1 - T * rho + rho * w * y))
FF = [F0, F1, F2, F3, F4]
GLOBAL_FF = [
    sp.expand(f.subs({U: 1, P: 1, V: lam, Q: rho, Xi: w, t: t_ff}))
    for f in GLOBAL
]
ideal_equal(GLOBAL_FF, FF, [w, rho, lam, T, x, y, z], "finite--finite chart")

# The first six bihomogeneous relations (R0,...,R4,R6) are the closure
# obtained from the V-chart.  On the U=P=1 chart they are strictly too weak
# along V=lambda=0.  Saturating by lambda adds precisely R5.
GLOBAL_FF_WITHOUT_R5 = [GLOBAL_FF[i] for i in (0, 1, 2, 3, 4, 6)]
gb_without_r5 = sp.groebner(
    GLOBAL_FF_WITHOUT_R5, w, rho, lam, T, x, y, z, order="lex"
)
assert gb_without_r5.reduce(GLOBAL_FF[5])[1] != 0
SAT_WITHOUT_R5 = eliminated_saturation(
    GLOBAL_FF_WITHOUT_R5,
    lam,
    [w, rho, lam, T, x, y, z],
)
ideal_equal(
    SAT_WITHOUT_R5,
    GLOBAL_FF,
    [w, rho, lam, T, x, y, z],
    "missing U-chart saturation relation",
)

I_FF = eliminated_saturation(
    [F0, sp.expand(g1_ff - rho * f1_ff)],
    f0_ff * f1_ff,
    [rho, lam, T, x, y, z],
)
E_FF = eliminate_one(FF, w, [rho, lam, T, x, y, z])
ideal_equal(I_FF, E_FF, [rho, lam, T, x, y, z], "finite--finite image")
print("global chart equals the known finite normalization and its saturated image: PASS")


# ---------------------------------------------------------------------------
# U=Q=1: second-projective infinity
# ---------------------------------------------------------------------------
section("U=Q=1 second-projective-infinity chart")
theta, omega = sp.symbols("theta omega")
G0 = F0
G1 = sp.expand(omega * u - alpha * theta * z)
G2 = sp.expand(omega * xi - alpha * theta * x)
G3 = sp.expand(v - lam * theta * z - (omega + theta) * y)
G4 = sp.expand(omega**2 - alpha * (theta**2 - T * theta + omega * y))
UQ = [G0, G1, G2, G3, G4]
GLOBAL_UQ = [
    sp.expand(f.subs({U: 1, Q: 1, V: lam, P: theta, Xi: omega, t: t_ff}))
    for f in GLOBAL
]
ideal_equal(GLOBAL_UQ, UQ, [omega, theta, lam, T, x, y, z], "second-infinity chart")

I_UQ = eliminated_saturation(
    [F0, sp.expand(f1_ff - theta * g1_ff)],
    f0_ff * g1_ff,
    [theta, lam, T, x, y, z],
)
E_UQ = eliminate_one(UQ, omega, [theta, lam, T, x, y, z])
ideal_equal(I_UQ, E_UQ, [theta, lam, T, x, y, z], "second-infinity image")

# These contractions make the domain argument fail-closed: localization at
# theta is the finite--finite normalization, while localization at T is the
# previously established second-infinity normalization.
SAT_UQ_THETA = eliminated_saturation(
    UQ, theta, [omega, theta, lam, T, x, y, z]
)
ideal_equal(
    SAT_UQ_THETA,
    UQ,
    [omega, theta, lam, T, x, y, z],
    "second-infinity theta saturation",
)
SAT_UQ_T = eliminated_saturation(UQ, T, [omega, theta, lam, T, x, y, z])
ideal_equal(
    SAT_UQ_T,
    UQ,
    [omega, theta, lam, T, x, y, z],
    "second-infinity T saturation",
)

# Hilbert--Burch model near T=theta=0.
B = T * (1 - lam * theta) - alpha * y
rr = omega - alpha * theta
qq = omega + theta - T
M = sp.Matrix([[B, T * y, rr], [qq, z, -omega]])
minors = [
    sp.expand(M[:, [0, 1]].det()),
    sp.expand(M[:, [0, 2]].det()),
    sp.expand(M[:, [1, 2]].det()),
]
assert sp.expand(minors[0] - (T * G3 - alpha * G0)) == 0
assert sp.expand(minors[1] + G4) == 0
assert sp.expand(minors[2] + G1) == 0
assert sp.expand(
    (omega - alpha * theta) * G3
    - ((1 - lam * theta) * G1 + alpha * G2 - y * G4)
) == 0
assert sp.gcd(G1, G4) == 1

# Exact central-fiber decomposition.
y0, z0, o0, l0 = sp.symbols("y0 z0 o0 l0")
central = [y0 * z0, o0 * z0, o0 * (o0 - y0)]
central_primes = [[y0, o0], [z0, o0], [z0, o0 - y0]]
inter = ideal_intersection(central_primes[0], central_primes[1], [o0, y0, z0, l0])
inter = ideal_intersection(inter, central_primes[2], [o0, y0, z0, l0])
ideal_equal(inter, central, [o0, y0, z0, l0], "second-infinity central fiber")
print(
    "saturated image, theta/T contractions, height-two determinantal input, "
    "and central fiber: PASS"
)


# ---------------------------------------------------------------------------
# V=P=1: first-projective infinity
# ---------------------------------------------------------------------------
section("V=P=1 first-projective-infinity chart")
eta, psi, rho2 = sp.symbols("eta psi rho2")
Aeta = eta**2 + z - eta * t
Xeta = x - eta * y
K0 = sp.expand(eta * g0 - f0)
K1 = sp.expand(g1 - rho2 * f1)
K2 = sp.expand(z + eta * y + psi * y - eta * rho2 * h)
K3 = sp.expand(psi * z - (z - eta * t) * (rho2 * h - y) - eta * z)
K4 = sp.expand(
    psi * Xeta
    + eta * rho2 * (eta - y) * h
    - eta * (x + z + eta * y - y**2)
)
K5 = sp.expand(psi**2 - Aeta * (1 - rho2 * (t + y) + rho2**2 * h))
VP = [K0, K1, K2, K3, K4, K5]
GLOBAL_VP = [
    sp.expand(f.subs({V: 1, P: 1, U: eta, Q: rho2, Xi: psi}))
    for f in GLOBAL
]
ideal_equal(GLOBAL_VP, VP, [psi, rho2, t, y, x, z, eta], "first-infinity chart")

I_VP = eliminated_saturation(
    [K0, K1],
    g0 * f1,
    [rho2, t, y, x, z, eta],
)
E_VP = eliminate_one(VP, psi, [rho2, t, y, x, z, eta])
ideal_equal(I_VP, E_VP, [rho2, t, y, x, z, eta], "first-infinity image")

SAT_VP = eliminated_saturation(VP, eta, [psi, rho2, t, y, x, z, eta])
ideal_equal(SAT_VP, VP, [psi, rho2, t, y, x, z, eta], "first-infinity eta saturation")

EA = sp.expand((g1 - rho2 * f1).subs(z, 0))
LB = sp.expand(rho2 * y * (t - psi) - (psi + y))
PA = [z, psi, EA]
PB = [x, z + psi * y, LB]
VP0 = [sp.expand(f.subs(eta, 0)) for f in VP]
inter = ideal_intersection(PA, PB, [psi, rho2, t, y, x, z])
ideal_equal(inter, VP0, [psi, rho2, t, y, x, z], "first-infinity eta fiber")
assert sp.gcd((x - y**2) * (x + t * y), x * t + 2 * x * y - y**3) == 1
assert sp.gcd(y * (t - psi), psi + y) == 1
print("saturated image, eta contraction, and reduced two-prime fiber: PASS")


# ---------------------------------------------------------------------------
# V=Q=1: double infinity
# ---------------------------------------------------------------------------
section("V=Q=1 double-infinity chart")
chi, theta2 = sp.symbols("chi theta2")
L0 = K0
L1 = sp.expand(theta2 * g1 - f1)
L2 = sp.expand(theta2 * (z + eta * y) + chi * y - eta * h)
L3 = sp.expand(chi * z - (z - eta * t) * (h - theta2 * y) - eta * theta2 * z)
L4 = sp.expand(
    chi * Xeta
    + eta * (eta - y) * h
    - eta * theta2 * (x + z + eta * y - y**2)
)
L5 = sp.expand(chi**2 - Aeta * (theta2**2 - theta2 * (t + y) + h))
VQ = [L0, L1, L2, L3, L4, L5]
GLOBAL_VQ = [
    sp.expand(f.subs({V: 1, Q: 1, U: eta, P: theta2, Xi: chi}))
    for f in GLOBAL
]
ideal_equal(GLOBAL_VQ, VQ, [chi, theta2, t, y, x, z, eta], "double-infinity chart")

I_VQ = eliminated_saturation(
    [K0, L1],
    g0 * g1,
    [theta2, t, y, x, z, eta],
)
E_VQ = eliminate_one(VQ, chi, [theta2, t, y, x, z, eta])
ideal_equal(I_VQ, E_VQ, [theta2, t, y, x, z, eta], "double-infinity image")

SAT_VQ_ETA = eliminated_saturation(VQ, eta, [chi, theta2, t, y, x, z, eta])
ideal_equal(SAT_VQ_ETA, VQ, [chi, theta2, t, y, x, z, eta], "double-infinity eta saturation")
SAT_VQ_THETA = eliminated_saturation(VQ, theta2, [chi, theta2, t, y, x, z, eta])
ideal_equal(SAT_VQ_THETA, VQ, [chi, theta2, t, y, x, z, eta], "double-infinity theta saturation")

f1z = sp.expand(f1.subs(z, 0))
g1z = sp.expand(g1.subs(z, 0))
AQ = [z, chi, sp.expand(theta2 * g1z - f1z)]
BQ = [
    x,
    sp.expand(chi - z - y * (t - theta2)),
    sp.expand((t - theta2) * y**2 + z * (theta2 + y)),
]
VQ0 = [sp.expand(f.subs(eta, 0)) for f in VQ]
inter = ideal_intersection(AQ, BQ, [chi, theta2, t, y, x, z])
ideal_equal(inter, VQ0, [chi, theta2, t, y, x, z], "double-infinity eta fiber")
assert sp.gcd(f1z, g1z) == 1
assert sp.gcd(z - y**2, y * (t * y + z)) == 1

C1 = [x, y, z - chi]
C2 = [chi, x, z + t * y]
C3 = [chi, z, x - y**2]
C4 = [chi, z, x + t * y]
inter4 = ideal_intersection(C1, C2, [chi, t, y, x, z])
inter4 = ideal_intersection(inter4, C3, [chi, t, y, x, z])
inter4 = ideal_intersection(inter4, C4, [chi, t, y, x, z])
VQ00 = [sp.expand(f.subs({eta: 0, theta2: 0})) for f in VQ]
ideal_equal(inter4, VQ00, [chi, t, y, x, z], "double-infinity corner fiber")
print("saturated image, two-prime eta fiber, and four-component corner: PASS")


# ---------------------------------------------------------------------------
# Global conductor cover and transition functions
# ---------------------------------------------------------------------------
section("global O(1,1) conductor cover")
GLOBAL_CONDUCTOR = sp.expand(R6.subs({x: 0, y: 0, z: 0}))
EXPECTED_GLOBAL_CONDUCTOR = sp.expand(
    Xi**2 - U * (U - t * V) * P * (P - t * Q)
)
assert GLOBAL_CONDUCTOR == EXPECTED_GLOBAL_CONDUCTOR

# Local conductor equations obtained directly from the chart quadratics.
cond_FF = sp.expand(F4.subs({x: 0, y: 0, z: 0}))
cond_UQ = sp.expand(G4.subs({x: 0, y: 0, z: 0}))
cond_VP = sp.expand(K5.subs({x: 0, y: 0, z: 0}))
cond_VQ = sp.expand(L5.subs({x: 0, y: 0, z: 0}))
assert cond_FF == sp.expand(w**2 - (1 - T * lam) * (1 - T * rho))
assert cond_UQ == sp.expand(omega**2 - (1 - T * lam) * theta * (theta - T))
assert cond_VP == sp.expand(psi**2 - eta * (eta - t) * (1 - rho2 * t))
assert cond_VQ == sp.expand(chi**2 - eta * (eta - t) * theta2 * (theta2 - t))

# Transition identities after clearing denominators.
assert sp.expand(
    rho**2 * cond_UQ.subs({theta: 1 / rho, omega: w / rho}) - cond_FF
) == 0
assert sp.expand(
    lam**2 * cond_VP.subs({eta: 1 / lam, psi: w / lam, t: T, rho2: rho})
    - cond_FF.subs(z, 0)
) == 0
assert sp.expand(
    rho2**2 * cond_VQ.subs({theta2: 1 / rho2, chi: psi / rho2}) - cond_VP
) == 0
print("Xi transforms as O(1,1) and the four conductor equations glue: PASS")

print("\nALL BIHOMOGENEOUS A0 CHECKS PASSED")
