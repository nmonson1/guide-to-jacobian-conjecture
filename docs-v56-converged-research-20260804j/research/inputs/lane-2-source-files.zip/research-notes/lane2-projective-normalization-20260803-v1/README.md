# Fixed quintic projective normalization packet

This packet gives one global bihomogeneous normalization algebra for the
fixed quintic outer simultaneous graph in Lane 2. It covers all four standard
charts of the two projective factors, proves finite birational normality,
computes the conductor, and records the overlap character of its generator.

The mathematical source is `bihomogeneous-normalization.md`. The two exact
programs replay complementary parts of the calculation:

- `verify_bihomogeneous_normalization.py` checks the seven bihomogeneous
  relations, four local presentations, saturated graph ideals, normality
  inputs, special fibres, and conductor gluing;
- `verify_conductor_module.py` independently computes the module-theoretic
  conductor annihilator.

This is a theorem about the displayed ordered pair of quintic ideals. It does
not establish an all-rank PRS theorem or a Torelli classification of arbitrary
marked inputs.

The corresponding immutable replay logs are under
`/path/to/versioned-artifact`.
