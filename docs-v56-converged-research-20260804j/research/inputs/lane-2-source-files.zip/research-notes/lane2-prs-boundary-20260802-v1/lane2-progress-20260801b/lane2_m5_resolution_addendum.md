# Addendum to the actual \((5,5)\) PRS flag note

> **Status:** corrective addendum and theorem upgrade.  
> **Applies to:** `lane2_m5_nu5_actual_prs_flag.md` from the preceding packet.

## 1. Correction to the individual outer-graph statement

The earlier note correctly identified the finite affine ratio chart

\[
yz+xt-\lambda xz=0
\]

with an ordinary double point after replacing \(t\) by \(t-\lambda z\).
It then overextended that description to the entire projective graph.

At the missing projective direction, put \(\eta=1/\lambda\).  The exact
coordinate change

\[
X=x-\eta y,
\qquad
Z=z-\eta t
\]

gives

\[
\boxed{XZ=\eta^2yt.}
\]

Thus the full individual graph has an additional two-dimensional toric
singular stratum at \(\eta=0\).  It is normal, but its singular locus is not
only the \(\mathbb P^1\) over the deepest coefficient point.

The companion note `lane2_universal_outer_graph_resolution.md` gives a
complete two-center resolution of this graph.

## 2. Upgrade from a quadratic model to an exact ordered theorem

The earlier note proved only that the **quadratic** simultaneous outer graph
reduces to the quartic toric model.  The companion note
`lane2_exact_ordered_outer_resolution.md` proves an exact higher-order result.

On the finite first-direction chart, after one small resolution of the top
outer graph, the weak bottom ideal is exactly

\[
\boxed{(Z,xH)}
\]

in étale coordinates, with

\[
\frac{\partial H}{\partial\lambda}
=-s(1-a^2sx)^2
\]

a unit.  Hence the residual graph is the exact conifold family

\[
\boxed{rZ=xH,}
\]

not merely a conifold tangent cone.

The projective boundary of the first small resolution has one further exact
singularity: a family of \(A_1\) surfaces

\[
\boxed{A\Theta+q^2=0.}
\]

The conifold and \(A_1\) strata are disjoint and admit explicit smooth
projective resolutions.  This proves that the quartic fan prediction lifts to
the full higher-order **ordered** quintic graph on the finite first-direction
locus.

## 3. Revised local status

The corrected local conclusions are:

1. the middle twisted-cubic graph is smooth;
2. each outer graph is normal but has two projective-direction strata:
   finite ODP charts and one toric infinity chart;
3. on the finite first-direction locus, the ordered two-factor graph has an
   exact conifold stratum and an exact \(A_1\) boundary stratum;
4. both are explicitly resolved;
5. the reverse order follows by the inverse additive-group translation;
6. comparison with the normalization of the unordered simultaneous
   multi-Rees graph remains open.

The remaining obstruction is therefore no longer an unknown higher-order
term in the ordered finite-direction chart.  It is the global comparison and
descent problem: projective infinity, unordered normalization, line-bundle
characters, and the relative-Jacobian marking.
