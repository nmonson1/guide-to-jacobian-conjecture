# The universal outer graph: exact singular locus and a global resolution

> **Status:** new unrefereed proof draft; AI-assisted; exact symbolic replay supplied.  
> **Scope:** the universal two-generator ideal
> \(J=(xz,yz+xt)\) over a characteristic-zero field.  This note repairs the
> earlier claim that every projective direction is an ordinary-double-point
> chart.  There is one degenerate projective direction with a larger toric
> singular stratum.

## 1. The graph

Let

\[
f=xz,
\qquad
g=yz+xt,
\]

and define

\[
\Gamma_J
=\overline{\operatorname{Graph}([f:g])}
\subset
\mathbb A^4_{x,y,z,t}\times\mathbb P^1_{[U:V]}.
\]

Since \((f,g)\) is a regular sequence, the Rees algebra is of linear type and

\[
\Gamma_J=V(Ug-Vf).
\]

## 2. Finite projective directions

On \(U\ne0\), put \(\lambda=V/U\).  The equation is

\[
yz+xt-\lambda xz=0.
\]

With

\[
T=t-\lambda z,
\]

it becomes

\[
\boxed{xT+yz=0.}
\]

Thus every finite projective direction is a threefold ordinary double point,
with the projective parameter \(\lambda\) smooth.  Its singular locus on this
chart is

\[
x=y=z=T=0.
\]

## 3. The unique degenerate projective direction

On \(V\ne0\), put \(\eta=U/V\).  The equation is

\[
\eta(yz+xt)-xz=0.
\]

Set

\[
X=x-\eta y,
\qquad
Z=z-\eta t.
\]

Then

\[
XZ=xz-\eta(xt+yz)+\eta^2yt,
\]

so the graph equation becomes the exact toric binomial

\[
\boxed{XZ=\eta^2yt.}
\]

The reduced singular locus is the union of

\[
L=V(X,Z,y,t),
\]

with \(\eta\) free, and

\[
P_\infty=V(X,Z,\eta),
\]

with \((y,t)\) free.  Their intersection is one point.

Geometrically, \(L\) is the closure of the ordinary-double-point line from
the finite projective chart.  The plane \(P_\infty\) is the additional
singular stratum at the pure \(f=xz\) direction.

## 4. Normality

The graph is an irreducible hypersurface and therefore Cohen--Macaulay.  Its
singular locus has codimension at least two: \(P_\infty\) has dimension two
inside the fourfold \(\Gamma_J\), while \(L\) has dimension one.  Hence
Serre's \(R_1+S_2\) criterion gives:

### Proposition 4.1

\[
\boxed{\Gamma_J\text{ is normal.}}
\]

Thus the special projective direction is a regularity problem, not a
normalization defect.

## 5. First blowup: the infinity plane

Blow up

\[
P_\infty=V(X,Z,\eta)
\]

in the toric chart \(XZ=\eta^2yt\).

### The \(X\)-chart

Put

\[
Z=XZ_1,
\qquad
\eta=Xe.
\]

After removing \(X^2\), the strict equation is

\[
Z_1=e^2yt,
\]

which is smooth.

### The \(Z\)-chart

Symmetrically, the strict equation is smooth.

### The \(\eta\)-chart

Put

\[
X=\eta X_1,
\qquad
Z=\eta Z_1.
\]

After removing \(\eta^2\), the strict equation is

\[
\boxed{X_1Z_1=yt.}
\]

This is a conifold times the smooth parameter \(\eta\).  Its singular locus
is

\[
X_1=Z_1=y=t=0,
\]

which is exactly the strict transform of \(L\).

The blowup is crepant: in the smooth ambient fivefold, the center has
codimension three and the hypersurface has multiplicity two along it.

## 6. Second blowup: the strict ordinary-double-point line

Blow up the strict transform \(\widetilde L\).

- On every finite projective chart, this is the blowup of the vertex in
  \(xT+yz=0\), fiberwise over \(\lambda\).
- On the \(\eta\)-chart after the first blowup, it is the blowup of the vertex
  in \(X_1Z_1-yt=0\), fiberwise over \(\eta\).

For example, on the \(x\)-chart of the first model,

\[
T=xT_1,
\qquad
y=xy_1,
\qquad
z=xz_1,
\]

and the strict equation is

\[
T_1+y_1z_1=0,
\]

which is smooth.  The other charts are identical by symmetry.  The same
calculation resolves \(X_1Z_1=yt\).

### Theorem 6.1 — Canonical two-center resolution

The sequence

\[
\operatorname{Bl}_{\widetilde L}
\operatorname{Bl}_{P_\infty}\Gamma_J
\longrightarrow
\Gamma_J
\]

is a smooth projective resolution.

The first blowup is crepant.  The second is the symmetric divisorial
resolution of the remaining ordinary-double-point family.  Replacing the
second blowup by either small resolution gives the usual local crepant
alternatives wherever those choices glue.

## 7. Consequence for the quintic program

The outer projective factors in the quintic middle chart are copies of this
universal graph.  Hence any global quintic compactification must distinguish:

1. the dense finite-direction ordinary-double-point locus; and
2. the unique projective infinity direction with toric equation
   \(XZ=\eta^2yt\).

A local proof carried out only in the affine ratio \(\lambda\) does not cover
that second stratum.  The ordered-resolution theorem in the companion note is
therefore deliberately scoped to the finite first-direction locus, while the
present theorem supplies the exact missing boundary model.
