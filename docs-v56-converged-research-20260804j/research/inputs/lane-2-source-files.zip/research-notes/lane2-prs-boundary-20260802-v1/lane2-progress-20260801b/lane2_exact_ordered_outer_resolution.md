# Exact ordered resolution of the quintic outer-pair graph

> **Status:** new unrefereed proof draft; AI-assisted; exact symbolic replay supplied.  
> **Scope:** characteristic zero, or more generally a field in which `2` and the
> translation parameter below are units.  The theorem is formal/étale-local
> along the deepest quintic middle-graph fiber and covers the affine chart of
> the first projective outer direction.  It proves an exact higher-order
> resolution theorem for the ordered graph.  It does not identify that ordered
> model with the normalization of the unordered simultaneous multi-Rees graph,
> and it does not address the unique degenerate first-direction chart at
> projective infinity.

## 1. Universal outer pair

Let

\[
R=k[x,y,z,t]
\]

and put

\[
J_0=(f_0,g_0)
=(xz,\ yz+xt).
\]

Consider the locally nilpotent derivation

\[
\partial
=-y^2\partial_x+y\partial_t+(x+yt)\partial_z.
\]

For a unit \(s\in k^\times\), its time-\(s\) map is

\[
\tau_s=\exp(s\partial),
\]

\[
\tau_s(x,y,z,t)
=
(x-sy^2,\ y,\ z+s(x+yt),\ t+sy).
\]

Set

\[
J_s=\tau_s(J_0)=(f_s,g_s).
\]

A direct expansion gives

\[
f_s=(x-sy^2)(z+sx+syt),
\]

\[
g_s=xt+yz+2sxy-s^2y^3.
\]

The actual quintic pair from the middle \(\mathsf Z\)-chart is the case
\(s=1\): under

\[
(x,y,z,t)=(C,D,u,v),
\]

the top factor is

\[
[Cu:Du+Cv]=[f_0:g_0],
\]

while the bottom factor is

\[
[(C-D^2)(u+C+Dv):D(u+C+Dv)+(C-D^2)(v+D)]
=[f_1:g_1].
\]

Thus the theorem below applies verbatim to the full higher-order quintic
outer pair, not merely to its quadratic initial forms.

## 2. First graph and its finite-direction node

Let \([P_0:Q_0]\) be the first projective direction.  On the affine chart
\(P_0\ne0\), put

\[
\lambda=Q_0/P_0.
\]

The graph of \([f_0:g_0]\) is

\[
g_0-\lambda f_0=0.
\]

After the exact change

\[
T=t-\lambda z,
\]

this is

\[
\boxed{xT+yz=0.}
\]

Choose the small resolution obtained by blowing up the rank-one ideal
\((x,y)\).  It has two standard affine charts.

### Chart A

\[
y=ax,
\qquad
T=-az.
\]

Its coordinates are \((x,z,a,\lambda)\).

### Chart B

\[
x=by,
\qquad
z=-bT.
\]

Its coordinates are \((b,y,T,\lambda)\).

Both charts are affine four-space, so the first graph has been resolved
exactly on the finite-direction locus.

## 3. Exact monomialization on Chart A

Pull \(J_s\) to Chart A.  Substituting

\[
y=ax,
\qquad
T=-az,
\qquad
 t=T+\lambda z=(\lambda-a)z
\]

gives

\[
f_s=xU F,
\qquad
g_s=xG,
\]

where

\[
U=1-a^2sx,
\]

\[
F=sx+z+as(\lambda-a)xz,
\]

\[
G=\lambda z+2asx-a^3s^2x^2.
\]

The factor \(x\) is a common Cartier factor and \(U\) is a unit near the
exceptional fiber.  Hence the weak projective map is equivalent to

\[
[F:G].
\]

Put

\[
c=as(\lambda-a),
\qquad
Z=F=sx+(1+cx)z.
\]

Since \(1+cx\) is a unit, \(Z\) is a regular coordinate replacing \(z\).
Define

\[
H=
(2as-a^3s^2x)(1+cx)-s\lambda.
\]

Then the following exact identity holds:

\[
(1+cx)G-\lambda Z=xH.
\]

Consequently

\[
\boxed{(F,G)=(Z,xH)}
\]

in the completed or étale local ring.

The coordinate change is nonsingular because

\[
\frac{\partial H}{\partial\lambda}
=-s(1-a^2sx)^2=-sU^2,
\]

which is a unit.  Therefore

\[
(a,x,Z,H)
\]

are étale coordinates.

This is the key higher-order statement: no uncomputed terms remain.  The weak
second ideal is exactly the monomial complete intersection

\[
(Z,xH).
\]

## 4. Exact residual conifold

Because \(Z,xH\) form a regular sequence, their Rees algebra is the symmetric
algebra.  Thus the second graph is cut out by one bilinear relation.

On the projective chart in which the relation has affine coordinate \(r\), it
is

\[
\boxed{rZ=xH.}
\]

The complementary projective chart is smooth because its equation can be
solved for \(Z\).  The displayed chart is the threefold ordinary double point

\[
rZ-xH=0
\]

times the smooth parameter \(a\).

Its reduced singular locus is

\[
\Sigma_{\mathrm{node}}
=V(r,Z,x,H),
\]

with \(a\) free.

There are two projective small resolutions.

### First small resolution

Blow up \((x,Z)\).  The strict-transform charts are

\[
Z=x\zeta,
\qquad
H=r\zeta,
\]

and

\[
x=Z\xi,
\qquad
r=\xi H.
\]

Both are affine four-space.

### Second small resolution

Blow up \((x,r)\).  The strict-transform charts are

\[
r=x\rho,
\qquad
H=\rho Z,
\]

and

\[
x=r\xi,
\qquad
Z=\xi H.
\]

Again both are affine four-space.  The two small resolutions are related by
the ordinary Atiyah flop, fiberwise over the parameter \(a\).  In particular,
the conifold step is crepant.

This proves that the finite-\(a\) part of the full higher-order ordered graph
is resolved by the same toric subdivision predicted by the quadratic normal
model.

## 5. The projective boundary of the first small resolution

Chart A does not contain the point \(a=\infty\) of the exceptional
\(\mathbb P^1\).  Chart B treats that point.

Substituting

\[
x=by,
\qquad
z=-bT,
\qquad
t=T(1-\lambda b)
\]

gives

\[
f_s=yF_B,
\qquad
g_s=yG_B,
\]

where

\[
F_B=(-b+sy)
\bigl(Tb\lambda sy+Tb-Tsy-bsy\bigr),
\]

\[
G_B=-\bigl(Tb^2\lambda-2bsy+s^2y^2\bigr).
\]

Again the common Cartier factor \(y\) is removed.  The remaining rational map
is \([F_B:G_B]\).

The graph has a codimension-one nonnormal-looking boundary over
\(b=y=0\).  Blow up the ideal

\[
(b,sy)=(b,y).
\]

The calculation becomes independent of \(s\).

### The \(b\)-chart

Put

\[
sy=kb.
\]

After removing the common factor \(b^2\), the transformed pair is

\[
F_k=(k-1)
\bigl(Tbk\lambda-Tk+T-bk\bigr),
\]

\[
G_k=-T\lambda-k^2+2k.
\]

Write

\[
q=k-1,
\qquad
\alpha=1-T\lambda.
\]

Then

\[
G_k=\alpha-q^2,
\]

\[
F_k=-Tq^2-bq(q+1)\alpha.
\]

Let \([P_1:Q_1]\) be the second projective direction.  The strict graph is

\[
P_1G_k-Q_1F_k=0.
\]

#### Finite second direction

On \(P_1\ne0\), put \(\mu=Q_1/P_1\).  The equation is

\[
\boxed{
\alpha+(T\mu-1)q^2
+b\mu q(q+1)\alpha=0.
}
\]

Above the exceptional divisor \(b=0\), this chart is smooth:

- if \(T\ne0\), the derivative with respect to \(\lambda\) is \(-T\);
- if \(T=0\), the equation forces \(q=\pm1\), and the derivative with respect
  to \(q\) is nonzero.

A direct Jacobian calculation in the original coordinates
\((b,k,T,\lambda,\mu)\) shows that the only singular component on this
chart is

\[
k=0,\qquad T=0,\qquad \mu=\lambda,\qquad b\lambda=2.
\]

This is exactly the residual conifold locus from Chart A, written on the
overlap.  In particular it does not meet \(b=0\) in the finite
\(\lambda\)-chart.

For completeness, the case reduction is short.  At a singular point,
\(\partial_\mu E=0\) and \(E=0\) give \(F_k=G_k=0\), hence
\(T\lambda=k(2-k)\).  The \(b\)-derivative becomes
\(k\mu(k-1)^3\).  The case \(k=1\) is excluded by the \(\lambda\)-derivative,
while \(k\notin\{0,1\}\) forces \(\mu=T=0\), then \(k=2\), which is excluded
by the \(k\)-derivative.  Thus \(k=0\); the remaining derivatives give exactly
\(T=0\), \(\mu=\lambda\), and \(b\lambda=2\).

#### Infinite second direction

On \(Q_1\ne0\), put \(\theta=P_1/Q_1\).  The equation is

\[
E=
\theta(\alpha-q^2)
+Tq^2+bq(q+1)\alpha.
\]

A direct Jacobian calculation gives two disjoint singular components.
The first is the same conifold component as above:

\[
k=0,\qquad T=0,\qquad \lambda\theta=1,\qquad b=2\theta.
\]

The second is the genuinely new boundary component

\[
q=0,\qquad \alpha=0,\qquad \theta=0,
\]

with \((b,T)\) free.  On the second component \(T\lambda=1\), so
\(T\) is a unit.  The two components are disjoint because the conifold has
\(k=0\), whereas the new component has \(k=1\).

Indeed, at a singular point \(F_k=G_k=0\), and the \(b\)-derivative is
\(k(k-1)^3\).  Thus \(k=0\) or \(k=1\).  The first case gives the displayed
conifold component.  The second gives \(T\lambda=1\), and the
\(\lambda\)-derivative then forces \(\theta=0\); all remaining derivatives
vanish.  No other cases occur.

Near the new component, set

\[
\Theta=\theta+bq(q+1),
\]

\[
W=T-\Theta+bq(q+1).
\]

Then \(W\) is a unit and

\[
E=\alpha\Theta+Wq^2.
\]

Replacing \(\alpha\) by

\[
A=\alpha/W
\]

gives the exact normal form

\[
\boxed{A\Theta+q^2=0}
\]

times the smooth parameters \((b,T)\).

Thus the only new boundary singularity is a family of du Val \(A_1\)
surface singularities.  Blowing up its singular locus

\[
V(A,\Theta,q)
\]

resolves it.  The three strict-transform charts are

\[
\Theta_1+q_1^2=0,
\qquad
A_1+q_1^2=0,
\qquad
A_1\Theta_1+1=0,
\]

and are all smooth.  Fiberwise, this is the crepant minimal resolution of the
\(A_1\) singularity.

### The \(y\)-chart

Put

\[
b=\ell sy.
\]

After removing the common factor \(s^2y^2\), one obtains

\[
F_\ell
=-(\ell-1)
\bigl(T\ell\lambda sy+T\ell-T-\ell sy\bigr),
\]

\[
G_\ell=-T\ell^2\lambda+2\ell-1.
\]

At \(\ell=0\), the second generator is \(-1\).  Hence the rational map
extends regularly and the graph is smooth there.  This completes the analysis
of the projective boundary of the first small resolution.

## 6. Main theorem

### Theorem 6.1 — Exact finite-direction ordered resolution

Let \(k\) have characteristic zero and let \(s\in k^\times\).  Start with the
pair

\[
J_0=(xz,yz+xt),
\qquad
J_s=\tau_s(J_0).
\]

Over the affine chart of the first projective direction, perform the following
ordered construction:

1. take the graph of \(J_0\);
2. take the small resolution obtained from the ideal \((x,y)\);
3. form the graph of the weak transform of \(J_s\);
4. blow up the boundary center \((b,y)\) on Chart B;
5. choose either small resolution of the residual conifold
   \(rZ=xH\) on Chart A;
6. blow up the residual \(A_1\)-singular locus
   \(V(A,\Theta,q)\) on the infinite second-direction chart.

The resulting space is smooth.  Every step is projective over the preceding
one, and the composite is birational to the ordered graph and hence to the
simultaneous graph on the locus where both projective maps are defined.

All local equations in the proof are exact polynomial identities after
inverting displayed units.  In particular, this is a full higher-order
resolution theorem, not a tangent-cone or associated-graded statement.

### Proof

Chart A is transformed exactly to the complete-intersection ideal
\((Z,xH)\).  Its graph is smooth except for the conifold family
\(rZ=xH\), and either displayed small resolution resolves that family.

On Chart B, blowing up \((b,y)\) gives the two explicit transformed pairs in
Section 5.  The \(\ell\)-chart is regular because \(G_\ell\) is a unit at the
missing projective point.  On the \(k\)-chart, the finite second-direction
chart is smooth over the new exceptional divisor and agrees away from it with
Chart A.  The infinite second-direction chart has exactly the displayed
\(A_1\) family, whose blowup is smooth.  The conifold center and the boundary \(A_1\) center are disjoint
(they have \(k=0\) and \(k=1\), respectively), so their resolutions are
compatible.  The formulas cover the two charts of the first small resolution
and the two charts of the second projective line. ∎

## 7. Reverse order and birational ambiguity

Applying \(\tau_{-s}\) exchanges the roles of \(J_0\) and \(J_s\).  Hence the
same theorem gives a reverse ordered resolution.

There are two independent conifold choices:

1. the choice of small resolution of the first graph node;
2. the choice of small resolution of the exact residual conifold.

Changing either choice is a family Atiyah flop.  The boundary \(A_1\)
resolution is canonical.  Thus, on the finite-direction locus, the entire
order-dependent birational ambiguity is accounted for by two ordinary flop
choices, exactly as suggested by the five-ray quadratic fan.

This conclusion is local.  Identifying a particular global ordered
multi-Rees construction with a particular pair of flop choices still requires
line-bundle and projective-coordinate bookkeeping.

## 8. Quintic corollary

### Corollary 8.1

On the \(\mathsf Z\)-chart of the actual \((m,\nu)=(5,5)\) middle PRS graph,
the ordered graph of the two outer projective subresultant factors admits the
smooth exact resolution of Theorem 6.1.

### Proof

Use

\[
(x,y,z,t)=(C,D,u,v).
\]

The top pair is \(J_0\), and the bottom pair is \(\tau_1(J_0)\), as verified
in Section 1. ∎

## 9. What this proves and what remains

The theorem proves that the quartic toric normal model genuinely lifts to the
full higher-order quintic **ordered** graph on the finite first-direction
locus.  The prior obstruction was therefore not a hidden higher-order term in
this chart.

The remaining local tasks are narrower:

- analyze the degenerate first projective direction, where the individual
  graph has the toric chart \(XZ=\eta^2yt\);
- compare the two ordered resolutions with the normalization and Stein
  factorization of the unordered simultaneous multi-Rees graph;
- identify the exact global fan and line-bundle characters;
- extend the relative-Jacobian ideals through the displayed centers.
