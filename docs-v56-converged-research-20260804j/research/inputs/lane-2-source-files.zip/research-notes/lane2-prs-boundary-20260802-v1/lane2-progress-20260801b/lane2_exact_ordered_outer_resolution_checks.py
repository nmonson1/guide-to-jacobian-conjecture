#!/usr/bin/env python3
"""Exact symbolic replay for the universal outer graph and ordered resolution.

All identities are over ZZ[s] and hence hold whenever s is a unit.  Smoothness
claims are verified by the displayed coordinate eliminations, not numerical
sampling.
"""
from __future__ import annotations

import sympy as sp

x, y, z, t = sp.symbols("x y z t")
T, lam, s = sp.symbols("T lam s")
a, b = sp.symbols("a b")
mu, theta = sp.symbols("mu theta")
k, ell, q = sp.symbols("k ell q")
alpha, Theta, Avar = sp.symbols("alpha Theta Avar")
r = sp.symbols("r")


def tau(poly: sp.Expr, time: sp.Expr) -> sp.Expr:
    """Apply exp(time*delta) to a polynomial by substitution."""
    return sp.expand(
        poly.subs(
            {
                x: x - time * y**2,
                y: y,
                z: z + time * (x + y * t),
                t: t + time * y,
            },
            simultaneous=True,
        )
    )


def main() -> None:
    f0 = x * z
    g0 = y * z + x * t

    # The additive-group action and the exact translated pair.
    u = sp.symbols("u")
    for coord in (x, y, z, t):
        lhs = tau(tau(coord, s), u)
        rhs = tau(coord, s + u)
        assert sp.expand(lhs - rhs) == 0

    fs = sp.factor(tau(f0, s))
    gs = sp.factor(tau(g0, s))
    assert fs == (x - s * y**2) * (z + s * x + s * y * t)
    assert sp.expand(gs - (x * t + y * z + 2 * s * x * y - s**2 * y**3)) == 0

    # First graph: finite-direction node.
    first_eq = sp.expand(g0 - lam * f0)
    node_eq = sp.expand(first_eq.subs(t, T + lam * z))
    assert node_eq == x * T + y * z

    # Unique degenerate projective direction of the individual graph.
    eta, X, Z = sp.symbols("eta X Z")
    inf_eq = sp.expand(eta * g0 - f0)
    # x = X + eta*y, z = Z + eta*t.
    inf_new = sp.expand(inf_eq.subs({x: X + eta * y, z: Z + eta * t}))
    assert inf_new == -(X * Z - eta**2 * y * t)

    # Blow up the infinity plane (X,Z,eta).
    e, Z1, X1 = sp.symbols("e Z1 X1")
    strict_X = sp.expand((X * Z - eta**2 * y * t).subs({Z: X * Z1, eta: X * e}) / X**2)
    assert strict_X == Z1 - e**2 * y * t
    strict_eta = sp.expand((X * Z - eta**2 * y * t).subs({X: eta * X1, Z: eta * Z1}) / eta**2)
    assert strict_eta == X1 * Z1 - y * t

    # Symmetric blowup of an ODP vertex is smooth in each standard chart.
    yy, zz, TT = sp.symbols("yy zz TT")
    strict_node_x = sp.expand((x * T + y * z).subs({T: x * TT, y: x * yy, z: x * zz}) / x**2)
    assert strict_node_x == TT + yy * zz

    # Chart A of the first small resolution: y=a*x, T=-a*z.
    fs_node = sp.expand(fs.subs(t, T + lam * z))
    gs_node = sp.expand(gs.subs(t, T + lam * z))
    fs_A = sp.factor(fs_node.subs({y: a * x, T: -a * z}))
    gs_A = sp.factor(gs_node.subs({y: a * x, T: -a * z}))

    U = 1 - a**2 * s * x
    c = a * s * (lam - a)
    F = s * x + z + c * x * z
    G = lam * z + 2 * a * s * x - a**3 * s**2 * x**2
    assert sp.expand(fs_A - x * U * F) == 0
    assert sp.expand(gs_A - x * G) == 0

    Zcoord = sp.symbols("Zcoord")
    H = (2 * a * s - a**3 * s**2 * x) * (1 + c * x) - s * lam
    assert sp.expand((1 + c * x) * G - lam * F - x * H) == 0
    assert sp.expand(sp.diff(H, lam) + s * U**2) == 0

    # In coordinates Z=F, the exact weak ideal is (Z,xH).
    z_of_Z = (Zcoord - s * x) / (1 + c * x)
    G_in_Z = sp.cancel(G.subs(z, z_of_Z))
    assert sp.factor((1 + c * x) * G_in_Z - lam * Zcoord - x * H) == 0

    # Exact conifold and both small resolutions.
    conifold = r * Zcoord - x * sp.symbols("Hc")
    Hc, zeta, xi, rho = sp.symbols("Hc zeta xi rho")
    conifold = r * Zcoord - x * Hc
    strict_c1 = sp.expand(conifold.subs({Zcoord: x * zeta, Hc: r * zeta}) / x)
    assert strict_c1 == 0
    # Better chart equations before imposing the solved variable.
    assert sp.expand((r * (x * zeta) - x * Hc) / x) == r * zeta - Hc
    assert sp.expand((r * Zcoord - (Zcoord * xi) * Hc) / Zcoord) == r - xi * Hc
    assert sp.expand(((x * rho) * Zcoord - x * Hc) / x) == rho * Zcoord - Hc
    assert sp.expand((r * Zcoord - (r * xi) * Hc) / r) == Zcoord - xi * Hc

    # Chart B of the first small resolution: x=b*y, z=-b*T.
    fs_B = sp.factor(fs_node.subs({x: b * y, z: -b * T}))
    gs_B = sp.factor(gs_node.subs({x: b * y, z: -b * T}))
    FB = (-b + s * y) * (T * b * lam * s * y + T * b - T * s * y - b * s * y)
    GB = -(T * b**2 * lam - 2 * b * s * y + s**2 * y**2)
    assert sp.expand(fs_B - y * FB) == 0
    assert sp.expand(gs_B - y * GB) == 0

    # Blow up (b,s*y), b-chart: s*y=k*b.
    Fk = sp.factor(sp.cancel(FB.subs(y, k * b / s) / b**2))
    Gk = sp.factor(sp.cancel(GB.subs(y, k * b / s) / b**2))
    assert Fk == (k - 1) * (T * b * k * lam - T * k + T - b * k)
    assert Gk == -T * lam - k**2 + 2 * k

    # q=k-1 and alpha=1-T*lam.
    Fq_expected = -T * q**2 - b * q * (q + 1) * alpha
    Gq_expected = alpha - q**2
    assert sp.expand(Fk.subs({k: q + 1, lam: (1 - alpha) / T}) - Fq_expected) == 0
    assert sp.expand(Gk.subs({k: q + 1, lam: (1 - alpha) / T}) - Gq_expected) == 0

    # Finite second projective direction.
    E_mu = sp.expand(Gq_expected - mu * Fq_expected)
    E_mu_expected = alpha + (T * mu - 1) * q**2 + b * mu * q * (q + 1) * alpha
    assert sp.expand(E_mu - E_mu_expected) == 0

    # Exact conifold component in the original (b,k,T,lam,mu) coordinates.
    E_mu_orig = sp.expand(Gk - mu * Fk)
    node_mu_sub = {k: 0, T: 0, mu: lam, b: 2 / lam}
    assert sp.simplify(E_mu_orig.subs(node_mu_sub)) == 0
    for var in (b, k, T, lam, mu):
        assert sp.simplify(sp.diff(E_mu_orig, var).subs(node_mu_sub)) == 0

    # Infinite second projective direction and exact A1 normal form.
    E_theta = sp.expand(theta * Gq_expected - Fq_expected)
    E_theta_expected = theta * (alpha - q**2) + T * q**2 + b * q * (q + 1) * alpha
    assert sp.expand(E_theta - E_theta_expected) == 0

    E_theta_orig = sp.expand(theta * Gk - Fk)
    node_theta_sub = {k: 0, T: 0, theta: 1 / lam, b: 2 / lam}
    assert sp.simplify(E_theta_orig.subs(node_theta_sub)) == 0
    for var in (b, k, T, lam, theta):
        assert sp.simplify(sp.diff(E_theta_orig, var).subs(node_theta_sub)) == 0
    a1_sub = {k: 1, lam: 1 / T, theta: 0}
    assert sp.simplify(E_theta_orig.subs(a1_sub)) == 0
    for var in (b, k, T, lam, theta):
        assert sp.simplify(sp.diff(E_theta_orig, var).subs(a1_sub)) == 0

    Theta_expr = theta + b * q * (q + 1)
    W = T - Theta + b * q * (q + 1)
    E_in_Theta = sp.expand(E_theta_expected.subs(theta, Theta - b * q * (q + 1)))
    assert sp.expand(E_in_Theta - (alpha * Theta + W * q**2)) == 0
    # alpha=Avar*W gives W*(Avar*Theta+q^2).
    assert sp.expand(E_in_Theta.subs(alpha, Avar * W) - W * (Avar * Theta + q**2)) == 0

    # Blowup of the A1 singular locus.
    A1, Th1, q1 = sp.symbols("A1 Th1 q1")
    a1_eq = Avar * Theta + q**2
    strict_A = sp.expand(a1_eq.subs({Theta: Avar * Th1, q: Avar * q1}) / Avar**2)
    strict_Th = sp.expand(a1_eq.subs({Avar: Theta * A1, q: Theta * q1}) / Theta**2)
    strict_q = sp.expand(a1_eq.subs({Avar: q * A1, Theta: q * Th1}) / q**2)
    assert strict_A == Th1 + q1**2
    assert strict_Th == A1 + q1**2
    assert strict_q == A1 * Th1 + 1

    # Blowup (b,s*y), y-chart: b=ell*s*y; the second generator is a unit at ell=0.
    Fell = sp.factor(sp.cancel(FB.subs(b, ell * s * y) / (s**2 * y**2)))
    Gell = sp.factor(sp.cancel(GB.subs(b, ell * s * y) / (s**2 * y**2)))
    assert sp.expand(Fell + (ell - 1) * (T * ell * lam * s * y + T * ell - T - ell * s * y)) == 0
    assert sp.expand(Gell - (-T * ell**2 * lam + 2 * ell - 1)) == 0
    assert Gell.subs(ell, 0) == -1

    # Actual quintic substitution: (x,y,z,t)=(C,D,u,v).
    C, D, uu, vv = sp.symbols("C D uu vv")
    top = (C * uu, D * uu + C * vv)
    bottom = (
        (C - D**2) * (uu + C + D * vv),
        D * (uu + C + D * vv) + (C - D**2) * (vv + D),
    )
    f1_quintic = fs.subs({x: C, y: D, z: uu, t: vv, s: 1})
    g1_quintic = gs.subs({x: C, y: D, z: uu, t: vv, s: 1})
    assert sp.expand(top[0] - f0.subs({x: C, y: D, z: uu, t: vv})) == 0
    assert sp.expand(top[1] - g0.subs({x: C, y: D, z: uu, t: vv})) == 0
    assert sp.expand(bottom[0] - f1_quintic) == 0
    assert sp.expand(bottom[1] - g1_quintic) == 0

    print("Ga translation and exact outer-pair formulas: passed")
    print("individual graph finite ODP and infinity toric chart: passed")
    print("Chart A exact weak ideal (Z,xH): passed")
    print("residual conifold and both small resolutions: passed")
    print("Chart B boundary blowup formulas: passed")
    print("exact boundary A1 normal form and resolution: passed")
    print("actual quintic substitution: passed")
    print("ALL EXACT ORDERED OUTER-RESOLUTION CHECKS PASSED")


if __name__ == "__main__":
    main()
