# Exact saturated equations for the finite–finite unordered chart

> **Status:** exact algebraic certificate accompanying the cubic-scroll normalization theorem.  
> **Scope:** the universal pair `(J_0,J_1)` after normalizing the nonzero translation parameter to one.

Let

\[
T=t-\lambda z,
\qquad
J_0=(xz,yz+xt),
\qquad
J_1=((x-y^2)(z+x+yt),\ xt+yz+2xy-y^3).
\]

Let `rho` denote the finite ratio on the second projective factor.  The naive
two-equation incidence ideal is

\[
I_{\mathrm{naive}}
=(xT+yz,\ g_1-\rho f_1).
\]

It contains torsion supported on the common base locus.  The graph closure is
the saturation

\[
I_{\mathrm{graph}}
=I_{\mathrm{naive}}:(xz\,f_1)^\infty.
\]

Define

\[
\begin{aligned}
A_1={}&-T\rho y^2-\lambda yz+\rho xy-\rho y^3-\rho yz-y^2,\\
A_2={}&\lambda\rho yz-\lambda z+\rho x-\rho y^2+\rho z-2y,
\end{aligned}
\]

and

\[
M_{\lambda,\rho}
=
\begin{pmatrix}
A_1&A_2\\
x-y^2&-y\\
Ty+z&T
\end{pmatrix}.
\]

## Proposition

The saturated graph ideal is exactly

\[
\boxed{I_{\mathrm{graph}}=I_2(M_{\lambda,\rho}).}
\]

The lower minor is

\[
T(x-y^2)+y(Ty+z)=xT+yz.
\]

The other two minors are the two Sylvester forms obtained when the second
graph equation is saturated by the two selected source generators.  The
matrix gives their Hilbert--Burch syzygies automatically.

The supplied replay proves the equality in two independent exact ways:

1. elimination of an auxiliary variable from
   \[
   (I_{\mathrm{naive}},1-hxz f_1);
   \]
2. mutual reduction of the elimination basis and the three maximal minors.

Thus the unordered chart is a codimension-two perfect determinantal scheme,
not the naive complete intersection of the two graph equations.

Its Jacobian singular ideal has radical

\[
\sqrt{\operatorname{Jac}(I_{\mathrm{graph}})}=(x,y,z).
\]

Hence the chart is singular in codimension one and is not normal.  On `T != 0`
the companion theorem transforms it exactly to

\[
\alpha z^2=u^2B,
\]

whose normalization is the cubic-scroll cone.
