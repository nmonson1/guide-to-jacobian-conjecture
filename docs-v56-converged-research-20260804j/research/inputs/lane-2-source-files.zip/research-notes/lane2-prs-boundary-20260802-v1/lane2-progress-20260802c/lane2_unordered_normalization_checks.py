#!/usr/bin/env python3
"""Exact replay for the unordered quintic outer-graph normalization theorem."""
from __future__ import annotations

import sympy as sp


def main() -> None:
    x, y, z, t = sp.symbols("x y z t")
    T, lam, rho, theta = sp.symbols("T lam rho theta")
    u, alpha, B = sp.symbols("u alpha B")

    f0 = x*z
    g0 = y*z + x*t
    f1 = (x-y**2)*(z+x+y*t)
    g1 = x*t + y*z + 2*x*y - y**3

    # First graph and T-unit coordinates.
    first = sp.expand((g0-lam*f0).subs(t, T+lam*z))
    assert first == x*T+y*z

    x_sub = -y*z/T
    f1_first = sp.factor(f1.subs({t:T+lam*z, x:x_sub}, simultaneous=True))
    g1_first = sp.factor(g1.subs({t:T+lam*z, x:x_sub}, simultaneous=True))
    assert sp.simplify(f1_first/y + (T*y+z)*(T**2*y+T*lam*y*z+T*z-y*z)/T**2) == 0
    assert sp.simplify(g1_first/y + (T*y**2+lam*z**2+2*y*z)/T) == 0

    # u=Ty+z, alpha=1-T lambda.
    y_sub = (u-z)/T
    Fstar = u*(T**2*u-alpha*u*z+alpha*z**2)
    Gstar = T*(u**2-alpha*z**2)

    fweak_scaled = sp.factor((-T**3*f1_first/y).subs({y:y_sub, lam:(1-alpha)/T}))
    gweak_scaled = sp.factor((-T**3*g1_first/y).subs({y:y_sub, lam:(1-alpha)/T}))
    assert sp.expand(fweak_scaled-Fstar) == 0
    assert sp.expand(gweak_scaled-Gstar) == 0

    # Finite second direction and exact pinch coordinate.
    D = T+rho*u
    beta = 1-rho*T
    Bexpr = (T*beta+rho*alpha*z)/D
    Efin = sp.expand(rho*Fstar-Gstar)
    assert sp.factor(Efin-D*(alpha*z**2-u**2*Bexpr)) == 0

    rho_inv = T*(1-B)/(T**2+B*u-alpha*z)
    assert sp.factor(Bexpr.subs(rho,rho_inv)-B) == 0

    # Normalization relations and the two smooth conductor-blowup charts.
    q, p, w = sp.symbols("q p w")
    pinch = alpha*z**2-u**2*B
    strict_u = sp.expand(pinch.subs({z:q*u, B:alpha*q**2})/u**2)
    strict_z = sp.expand(pinch.subs({u:p*z, alpha:B*p**2})/z**2)
    assert strict_u == 0
    assert strict_z == 0
    assert sp.expand((alpha*q)**2-alpha*(alpha*q**2)) == 0
    assert sp.expand((B*p)**2-(B*p**2)*B) == 0
    assert sp.expand((alpha*q)*u-alpha*(q*u)) == 0
    assert sp.expand((B*p)*z-B*(p*z)) == 0

    # Infinity chart: exact discriminant normal form.
    A = T*(T-theta)-alpha*z
    Einf = sp.expand(Fstar-theta*Gstar)
    assert sp.expand(Einf-(A*u**2+alpha*z**2*u+alpha*theta*T*z**2)) == 0

    W = 2*A*u+alpha*z**2
    Binf = alpha*z**2-4*A*theta*T
    assert sp.expand(W**2-alpha*Binf*z**2-4*A*Einf) == 0

    # Jacobian of (u,theta)->(W,Binf) at the branch center.
    dW_du = sp.diff(W,u).subs({u:0,z:0,theta:0})
    dW_dth = sp.diff(W,theta).subs({u:0,z:0,theta:0})
    dB_du = sp.diff(Binf,u).subs({u:0,z:0,theta:0})
    dB_dth = sp.diff(Binf,theta).subs({u:0,z:0,theta:0})
    jac = sp.expand(dW_du*dB_dth-dW_dth*dB_du)
    assert jac == -8*T**5

    # Blowup of (W,z) equals the normalization on the z chart.
    winf = sp.symbols("winf")
    inf_eq = W**2-alpha*Binf*z**2
    # Abstract strict transform: W=winf*z.
    Wa, Za, Aa, Ba = sp.symbols("Wa Za Aa Ba")
    abstract = Wa**2-Aa*Ba*Za**2
    strict_inf_z = sp.expand(abstract.subs(Wa,winf*Za)/Za**2)
    assert strict_inf_z == winf**2-Aa*Ba

    # A1 resolution charts.
    a1eq = winf**2-Aa*Ba
    b1, a1, w1 = sp.symbols("b1 a1 w1")
    strict_A = sp.expand(a1eq.subs({Ba:Aa*b1,winf:Aa*w1})/Aa**2)
    strict_B = sp.expand(a1eq.subs({Aa:Ba*a1,winf:Ba*w1})/Ba**2)
    strict_w = sp.expand(a1eq.subs({Aa:winf*a1,Ba:winf*b1})/winf**2)
    assert strict_A == w1**2-b1
    assert strict_B == w1**2-a1
    assert strict_w == 1-a1*b1

    # Global conductor branch polynomial.
    P,Q = sp.symbols("P Q")
    branch = alpha*P*(P-T*Q)
    assert sp.expand(branch.subs({P:1,Q:rho})-alpha*(1-T*rho)) == 0
    assert sp.expand(branch.subs({P:theta,Q:1})-alpha*theta*(theta-T)) == 0
    assert sp.expand(Binf.subs({u:0,z:0})-4*T**2*theta*(theta-T)) == 0

    # Exact Hilbert--Burch presentation of the saturated finite-finite chart.
    A1 = -T*rho*y**2-lam*y*z+rho*x*y-rho*y**3-rho*y*z-y**2
    A2 = lam*rho*y*z-lam*z+rho*x-rho*y**2+rho*z-2*y
    M = sp.Matrix([
        [A1,A2],
        [x-y**2,-y],
        [T*y+z,T],
    ])
    minors = [
        sp.expand(M[1,0]*M[2,1]-M[1,1]*M[2,0]),
        sp.expand(M[0,0]*M[2,1]-M[0,1]*M[2,0]),
        sp.expand(M[0,0]*M[1,1]-M[0,1]*M[1,0]),
    ]
    assert minors[0] == x*T+y*z

    # Check the saturation by elimination and equality of ideals via Groebner bases.
    h = sp.symbols("h")
    t_expr = T+lam*z
    fs = sp.expand(f1.subs(t,t_expr))
    gs = sp.expand(g1.subs(t,t_expr))
    E0 = x*T+y*z
    E1 = sp.expand(gs-rho*fs)
    sat = sp.groebner(
        [E0,E1,1-h*(x*z)*fs],
        h,rho,lam,T,z,y,x,
        order="lex",
    )
    sat_no_h = [p.as_expr() for p in sat.polys if not p.as_expr().has(h)]
    Gsat = sp.groebner(sat_no_h,rho,lam,T,z,y,x,order="grevlex")
    Gmin = sp.groebner(minors,rho,lam,T,z,y,x,order="grevlex")
    for f in sat_no_h:
        assert Gmin.reduce(f)[1] == 0
    for f in minors:
        assert Gsat.reduce(f)[1] == 0

    # Singular radical of the saturated chart is (x,y,z).
    vars_ff = (x,y,z,T,lam,rho)
    Jac = sp.Matrix([[sp.diff(f,v) for v in vars_ff] for f in minors])
    jac_minors = []
    for i in range(3):
        for j in range(i+1,3):
            for a in range(6):
                for b in range(a+1,6):
                    m = sp.expand(Jac[i,a]*Jac[j,b]-Jac[i,b]*Jac[j,a])
                    if m != 0:
                        jac_minors.append(m)
    Gsing = sp.groebner(minors+jac_minors,rho,lam,T,z,y,x,order="grevlex")
    assert Gsing.reduce(x**2)[1] == 0
    assert Gsing.reduce(y**3)[1] == 0
    assert Gsing.reduce(z**3)[1] == 0
    for f in minors+jac_minors:
        assert sp.expand(f.subs({x:0,y:0,z:0})) == 0

    # The cubic-scroll normalization is singular only at its vertex.
    aa, bb, uu, zz, ww = sp.symbols("aa bb uu zz ww")
    scroll = [ww**2-aa*bb, ww*uu-aa*zz, ww*zz-bb*uu]
    Jscroll = sp.Matrix([[sp.diff(f,v) for v in (aa,bb,uu,zz,ww)] for f in scroll])
    scroll_jac = []
    for i in range(3):
        for j in range(i+1,3):
            for a in range(5):
                for b in range(a+1,5):
                    m = sp.expand(Jscroll[i,a]*Jscroll[j,b]-Jscroll[i,b]*Jscroll[j,a])
                    if m != 0:
                        scroll_jac.append(m)
    Gscroll = sp.groebner(scroll+scroll_jac,ww,zz,uu,bb,aa,order="grevlex")
    for v in (aa,bb,uu,zz,ww):
        assert Gscroll.reduce(v**2)[1] == 0
    for f in scroll+scroll_jac:
        assert sp.expand(f.subs({aa:0,bb:0,uu:0,zz:0,ww:0})) == 0

    print("first-graph reduction and exact weak pair: passed")
    print("finite second-direction double-pinch normal form: passed")
    print("cubic-scroll normalization and smooth conductor blowup charts: passed")
    print("second-projective-infinity discriminant normal form: passed")
    print("A1 normalization/resolution and global conductor branch: passed")
    print("Hilbert--Burch saturated multi-Rees chart: passed")
    print("ALL UNORDERED NORMALIZATION CHECKS PASSED")


if __name__ == "__main__":
    main()
