# All-rank structural repairs for Lane 2

> **Status:** new unrefereed proof draft; AI-assisted; exact regression script supplied.  
> **Scope:** characteristic zero unless otherwise stated.  These lemmas repair
> the local coordinate and filtered-Smith parts of `RMU-4D2E0001`.  The
> formerly missing arbitrary-rank block recursion is now proved separately in
> `lane2_all_rank_hankel_rank_profile.md`.

## 1. Cyclotomic remainder coordinates are étale

Let

\[
Q(w)=w^m+q_1w^{m-1}+\cdots+q_m
\]

and let

\[
\mathcal R_\nu(Q)=w^\nu\bmod Q\in k[w]_{<m}.
\]

This defines a polynomial map from the monic coefficient space to the
\(m\)-dimensional remainder space.

### Theorem 1.1 — Explicit cyclotomic differential

Fix \(\lambda\ne0\), put

\[
Q_0=w^m-\lambda,
\]

and write

\[
\nu=km+r,
\qquad
k\ge1,
\qquad
0\le r<m.
\]

Identify the tangent space at \(Q_0\) with \(k[w]_{<m}\).  Then

\[
d\mathcal R_\nu\big|_{Q_0}(\delta Q)
=-k\lambda^{k-1}
 \bigl(w^r\delta Q\bmod(w^m-\lambda)\bigr).
\]

In particular, this differential is invertible whenever \(k\) and
\(\lambda\) are units.  Over a characteristic-zero field, the remainder map
is étale at every \(Q_0=w^m-\lambda\) and every \(\nu\ge m\).

### Proof

Work over the dual numbers and write

\[
Q_\epsilon=w^m-\lambda+\epsilon\delta Q,
\qquad \epsilon^2=0.
\]

In the quotient by \(Q_\epsilon\),

\[
w^m=\lambda-\epsilon\delta Q.
\]

Hence

\[
\begin{aligned}
w^\nu
&=w^r(w^m)^k\\
&=w^r(\lambda-\epsilon\delta Q)^k\\
&=\lambda^kw^r
 -k\lambda^{k-1}\epsilon w^r\delta Q.
\end{aligned}
\]

Reducing the last product modulo \(w^m-\lambda\) gives the formula.
Multiplication by \(w^r\) is an automorphism of
\(k[w]/(w^m-\lambda)\), because \(w^m=\lambda\) is a unit. ∎

### Determinant

In the ascending monomial basis, multiplication by \(w\) modulo
\(w^m-\lambda\) has determinant

\[
(-1)^{m-1}\lambda.
\]

Therefore

\[
\det d\mathcal R_\nu|_{Q_0}
=
(-k\lambda^{k-1})^m
\bigl((-1)^{m-1}\lambda\bigr)^r.
\]

This is the precise replacement for the earlier unsupported sentence that a
“deepest cyclotomic cell is étale.”  When \(r=0\), the remainder is constant
and the differential is the scalar
\(-k\lambda^{k-1}\operatorname{id}\).

## 2. The companion--Krylov matrix is triangularly Hankel

Let \(C\) be multiplication by \(w\) on \(k[w]/(Q)\) in the ascending basis

\[
1,w,\ldots,w^{m-1},
\]

and let \(J\) reverse that basis.  The matrix

\[
K_\nu=JC^\nu
\]

has as its \(j\)-th column the coefficients of
\(w^{\nu+j}\bmod Q\), written in descending order.

Put

\[
R_\nu=w^\nu\bmod Q
\]

and expand at infinity

\[
\frac{R_\nu(w)}{Q(w)}
=\sum_{\ell\ge1}s_\ell w^{-\ell}.
\]

Define the symmetric Hankel matrix

\[
H_\nu=(s_{i+j+1})_{0\le i,j<m}.
\]

Finally, with \(q_0=1\), let

\[
L_Q=(q_{i-j})_{0\le j\le i<m}
\]

be the unit lower-triangular Toeplitz matrix.

### Theorem 2.1 — Exact triangular reduction

One has the identity

\[
\boxed{K_\nu=L_QH_\nu.}
\]

Consequently \(K_\nu\) and \(H_\nu\) have identical ranks for every
northwest rectangular prefix, and hence the same rank-profile permutation.

### Proof

The proper part of

\[
w^j\frac{R_\nu}{Q}
\]

is

\[
\frac{w^{\nu+j}\bmod Q}{Q}.
\]

Its Laurent coefficients are therefore
\(s_{j+1},s_{j+2},\ldots\).  If

\[
w^{\nu+j}\bmod Q
=\sum_{a=0}^{m-1}r_{a,j}w^a,
\]

then multiplying the Laurent series by

\[
Q=w^m+q_1w^{m-1}+\cdots+q_m
\]

gives

\[
r_{m-1-i,j}
=\sum_{b=0}^i q_{i-b}s_{b+j+1}.
\]

This is exactly the matrix identity.  Since every leading square block of
\(L_Q\) is invertible, left multiplication by \(L_Q\) preserves every
northwest prefix rank. ∎

This removes a convention problem in the retained theorem: the displayed
companion matrix need not itself look symmetric.  It is related by a fixed
unit lower-triangular operation to the genuine moment Hankel matrix.

## 3. The first normal block is always a reversal

Let

\[
H=(s_{i+j+1})_{0\le i,j<N}
\]

be a scalar Hankel matrix.  Suppose its first nonsingular leading principal
minor has size \(d\):

\[
\det H_k=0\quad(1\le k<d),
\qquad
\det H_d\ne0.
\]

### Theorem 3.1 — First-gap reversal lemma

Then

\[
s_1=\cdots=s_{d-1}=0,
\qquad
s_d\ne0,
\]

and, for \(1\le a,b\le d\),

\[
\operatorname{rank}H_{[1,a]\times[1,b]}
=\max(0,a+b-d).
\]

Thus the northwest rank-profile permutation on the first \(d\) rows and
columns is exactly the reversal matrix \(J_d\).

### Proof

Induct on \(k\).  If
\(s_1=\cdots=s_{k-1}=0\), then the leading \(k\times k\) Hankel determinant is

\[
\det H_k
=(-1)^{k(k-1)/2}s_k^k.
\]

The vanishing and nonvanishing assumptions therefore give the first claim.

For an \(a\times b\) northwest rectangle with \(a,b\le d\), every entry with
\(i+j<d-1\) is zero.  Hence at most

\[
t=\max(0,a+b-d)
\]

rows can be nonzero.  The final \(t\) relevant rows and columns contain an
anti-triangular \(t\times t\) minor with anti-diagonal entry \(s_d\), so its
rank is exactly \(t\). ∎

## 4. The rank-profile recursion is now complete

The first-gap lemma in this note is the initial case of the general argument
proved in `lane2_all_rank_hankel_rank_profile.md`.  That proof uses the moment
functional and monic orthogonal residual polynomial at each normal index.  It
shows that the next Schur-complement block is unit-triangularly congruent to a
Hankel matrix whose first nonzero moment lies on its anti-diagonal.  Hence every
normal-index gap contributes exactly one reversal block, and iteration gives

\[
J_{d_1}\oplus\cdots\oplus J_{d_s}.
\]

No quasi-Hankel continuation hypothesis remains.

## 5. Filtered Smith exponents after the rank profile

Suppose the resulting Bruhat factorization is

\[
H_\nu=LPU,
\]

with \(L\) unit lower triangular, \(U\) unit upper triangular, and

\[
P=J_{d_1}\oplus\cdots\oplus J_{d_s},
\qquad
d_j=n_j-n_{j-1}.
\]

Under the radial deformation

\[
Q_r(w)=r^mQ(w/r),
\]

the regular conjugated lower and upper factors remain unimodular over
\(k[[r]]\).  A pivot in row \(i\), column \(\pi(i)\) has full exponent

\[
\nu-m+1+i+\pi(i).
\]

On the reversal block with indices
\(n_{j-1},\ldots,n_j-1\),

\[
i+\pi(i)=n_{j-1}+n_j-1.
\]

Therefore the Smith exponent on that block is

\[
\boxed{\nu-m+n_{j-1}+n_j}
\]

with multiplicity \(d_j\).

The determinant check telescopes:

\[
\sum_jd_j(\nu-m+n_{j-1}+n_j)=m\nu.
\]

Hence the filtered Smith statement is unconditional once combined with the
normal-index rank-profile theorem proved in the companion note.

## 6. Revised proof dependency for `RMU-4D2E0001`

The retained theorem can be split into five auditable pieces:

| piece | status after this note |
|---|---|
| cyclotomic remainder coordinates | proved, with explicit Jacobian |
| companion--Krylov to Hankel reduction | proved by \(K_\nu=L_QH_\nu\) |
| first normal block | proved directly |
| later block recursion | proved by orthogonal-residual Schur-complement induction |
| radial Smith exponents | proved from the block-reversal permutation |

The principal-subresultant/Hankel-determinant/rectangular-Schur identity is
proved in `lane2_all_rank_psc_hankel_schur.md`, and the full normal-index block
recursion is proved in `lane2_all_rank_hankel_rank_profile.md`.  Thus no
load-bearing general-rank linear-algebra step remains in this local theorem.

## 7. Literature bridge to audit

Two primary references provide an external literature bridge for the completed
block-factorization theorem:

- D. Pal and T. Kailath, *Fast Triangular Factorization and Inversion of Hankel
  and Related Matrices with Arbitrary Rank Profile*, SIAM J. Matrix Anal.
  Appl., DOI `10.1137/S0895479889172643`.
- A. Taik and S. Belhaj, *Block Factorization of Hankel Matrices and Euclidean
  Algorithm*, Math. Model. Nat. Phenom. 5 (2010).

The present proof is self-contained in the program's conventions; these
references now serve as independent structural context rather than as a
missing proof dependency.
