#!/usr/bin/env python3
"""Exact checks for the actual complete-PRS coefficient model at (m,nu)=(5,5).

We work on the transverse cyclotomic slice
    Q = w^5 - A w^4 - B w^3 - C w^2 - D w - 1,
so w^5 mod Q = A w^4 + B w^3 + C w^2 + D w + 1.
All identities are over ZZ and hence valid in characteristic zero.
"""
from __future__ import annotations

import sympy as sp

w = sp.symbols("w")
A, B, C, D = sp.symbols("A B C D")
u, v = sp.symbols("u v")
x, y, z, t = sp.symbols("x y z t")
lam, mu = sp.symbols("lam mu")


def main() -> None:
    Q = w**5 - A*w**4 - B*w**3 - C*w**2 - D*w - 1
    chain = sp.subresultants(w**5, Q, w)
    by_degree = {sp.degree(p, w): sp.Poly(sp.expand(p), w) for p in chain}

    s3 = by_degree[3]
    s2 = by_degree[2]
    s1 = by_degree[1]

    X = B**2 - A*C
    Y = A*D - B*C
    Z = C**2 - B*D

    # Degree-three and degree-two subresultants.
    assert sp.expand(s3.as_expr() - (X*w**3 - Y*w**2 + (B*D-A)*w + B)) == 0
    U = X + D*Y + C*Z
    V = Y + D*Z
    assert sp.expand(s2.as_expr() + U*w**2 + V*w + Z) == 0

    P = -A + 2*B*D + C**2 - 3*C*D**2 + D**4
    T = B - 2*C*D + D**3
    assert sp.expand(s1.as_expr() - (P*w + T)) == 0

    # Exact Hilbert--Burch syzygies for the twisted-cubic center.
    assert sp.expand(D*X + C*Y + B*Z) == 0
    assert sp.expand(C*X + B*Y + A*Z) == 0

    # The degree-two coefficient ideal is exactly (X,Y,Z).
    assert sp.expand(V - (Y + D*Z)) == 0
    assert sp.expand(U - (X + D*V + (C-D**2)*Z)) == 0

    # W=Z chart of the middle graph; solve its two linear syzygies exactly.
    Amid = -C*u + D*u*v + C*v**2
    Bmid = -D*u - C*v
    assert sp.expand(D*u + C*v + Bmid) == 0
    assert sp.expand(C*u + Bmid*v + Amid) == 0
    Zpull = sp.expand(Z.subs({A: Amid, B: Bmid}))
    assert Zpull == C**2 + C*D*v + D**2*u

    # Exact top restriction and exact bottom parametrization.
    assert tuple(sp.expand(e.subs({A: 0, B: 0})) for e in (X, Y, Z)) == (0, 0, C**2)
    Abot = C**2 + C*D**2 - D**4
    Bbot = D*(2*C-D**2)
    kappa = C-D**2
    assert tuple(sp.factor(e.subs({A: Abot, B: Bbot})) for e in (X, Y, Z)) == (
        -kappa**3,
        -D*kappa**2,
        kappa**2,
    )

    # The two outer centers meet in the explicit length-six complete intersection.
    f = D*(2*C-D**2)
    g = C**2 + C*D**2 - D**4
    assert sp.factor(sp.resultant(f, g, C)) == -D**6
    assert sp.factor(sp.resultant(f, g, D)) == C**6
    gb = sp.groebner([f, g], C, D, order="lex")
    assert [sp.expand(p.as_expr()) for p in gb.polys] == [
        2*C**2-D**4,
        2*C*D-D**3,
        D**5,
    ]

    # Exact universal-node form of the top factor.
    Atop = sp.expand(Amid + v*Bmid)
    assert Atop == -C*u
    assert Bmid == -(D*u+C*v)

    # Exact universal-node form of the bottom factor.
    Ppull = sp.expand(P.subs({A: Amid, B: Bmid}))
    Tpull = sp.expand(T.subs({A: Amid, B: Bmid}))
    rho = u + C + D*v
    s = v + D
    assert sp.expand(Tpull + D*rho + kappa*s) == 0
    assert sp.expand(Ppull - s*Tpull - kappa*rho) == 0

    # The coordinate change between the two node models is a polynomial automorphism.
    xp = x-y**2
    yp = y
    zp = z+x+y*t
    tp = t+y
    xback = sp.expand(xp+y**2)
    tback = sp.expand(tp-y)
    zback = sp.expand(zp-xp-y*tp)
    assert (xback, yp, zback, tback) == (x, y, z, t)

    # It is the time-one map of a locally nilpotent derivation on the generators.
    # delta(x)=-y^2, delta(y)=0, delta(t)=y, delta(z)=x+yt, and delta^2(z)=0.
    assert sp.expand((-y**2) + y*y) == 0

    # Every individual outer graph chart is an exact ODP times its projective parameter.
    node = y*z + x*t - lam*x*z
    shifted = sp.expand(node.subs(t, t+lam*z))
    assert shifted == x*t + y*z
    assert sp.factor(sp.hessian(x*t+y*z, (x, t, y, z)).det()) == 1

    # Saturated simultaneous quadratic model.
    f0 = x*z
    g0 = y*z+x*t
    f1 = x*(z+x)
    g1 = y*(z+x)+x*(t+y)
    E0 = sp.expand(g0-lam*f0)
    E1 = sp.expand(g1-mu*f1)
    K = 2*y+(lam-mu)*z-mu*x
    assert sp.expand(E1-E0-x*K) == 0
    ysol = (mu*x-(lam-mu)*z)/2
    reduced = sp.expand(2*E0.subs(y, ysol))
    assert sp.expand(reduced - (2*x*t + (mu-2*lam)*x*z - (lam-mu)*z**2)) == 0
    tau = sp.symbols("tau")
    reduced_shift = sp.expand(reduced.subs(t, tau-(mu-2*lam)*z/2))
    assert sp.expand(reduced_shift - (2*x*tau-(lam-mu)*z**2)) == 0

    # The symmetric blowup of the toric singular locus resolves the quadratic model.
    Xc, Tc, Zc, alpha = sp.symbols("Xc Tc Zc alpha")
    model = Xc*Tc+alpha*Zc**2
    # X-chart: Tc=Xc*T1, Zc=Xc*Z1.
    T1, Z1 = sp.symbols("T1 Z1")
    strict_x = sp.expand(model.subs({Tc: Xc*T1, Zc: Xc*Z1}) / Xc**2)
    assert strict_x == T1+alpha*Z1**2
    # T-chart.
    X1 = sp.symbols("X1")
    strict_t = sp.expand(model.subs({Xc: Tc*X1, Zc: Tc*Z1}) / Tc**2)
    assert strict_t == X1+alpha*Z1**2
    # Z-chart.
    strict_z = sp.expand(model.subs({Xc: Zc*X1, Tc: Zc*T1}) / Zc**2)
    assert strict_z == X1*T1+alpha

    print("actual subresultant formulas: passed")
    print("exact twisted-cubic middle center and smooth graph charts: passed")
    print("top and bottom doubled contacts: passed")
    print("outer-center intersection algebra: length 6")
    print("both outer graph factors: exact universal ODP models")
    print("simultaneous quadratic graph: quartic toric model x smooth parameter")
    print("ALL ACTUAL (m,nu)=(5,5) COMPLETE-PRS LOCAL CHECKS PASSED")


if __name__ == "__main__":
    main()
