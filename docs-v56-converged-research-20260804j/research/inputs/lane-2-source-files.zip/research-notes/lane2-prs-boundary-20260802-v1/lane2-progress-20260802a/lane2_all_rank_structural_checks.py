#!/usr/bin/env python3
"""Exact regression checks for the all-rank Lane-2 structural lemmas.

Checks:
1. the cyclotomic remainder-coordinate Jacobian formula;
2. the unit-lower-Toeplitz reduction J C^nu = L H from the companion
   Krylov matrix to a symmetric Hankel moment matrix;
3. the first-normal-block rank formula.
"""
from __future__ import annotations

from itertools import product
import sympy as sp

w, z, lam = sp.symbols("w z lam")


def companion_desc(q: list[sp.Expr]) -> sp.Matrix:
    """Multiplication by w in ascending basis for Q=w^m+q1*w^(m-1)+...+qm."""
    m = len(q)
    C = sp.zeros(m)
    for j in range(m-1):
        C[j+1, j] = 1
    for i in range(m):
        C[i, m-1] = -q[m-1-i]
    return C


def reverse_matrix(m: int) -> sp.Matrix:
    J = sp.zeros(m)
    for i in range(m):
        J[i, m-1-i] = 1
    return J


def lower_toeplitz(q: list[sp.Expr]) -> sp.Matrix:
    m = len(q)
    qq = [sp.Integer(1), *q]
    return sp.Matrix(m, m, lambda i, j: qq[i-j] if i >= j else 0)


def moments(q: list[sp.Expr], nu: int, count: int) -> list[sp.Expr]:
    m = len(q)
    Q = w**m + sum(q[i]*w**(m-1-i) for i in range(m))
    R = sp.rem(w**nu, Q, domain=sp.QQ)
    numerator = sp.expand(z**m * R.subs(w, 1/z))
    denominator = 1 + sum(q[i]*z**(i+1) for i in range(m))
    series = sp.series(numerator/denominator, z, 0, count+1).removeO().expand()
    return [sp.expand(series.coeff(z, j)) for j in range(1, count+1)]


def check_cyclotomic_jacobians() -> int:
    checked = 0
    for m in range(2, 7):
        aa = sp.symbols(f"a0:{m}")
        Q = w**m + sum(aa[i]*w**i for i in range(m))
        C0 = sp.zeros(m)
        for j in range(m-1):
            C0[j+1, j] = 1
        C0[0, m-1] = lam
        point = {aa[0]: -lam, **{aa[i]: 0 for i in range(1, m)}}
        for nu in range(m, 3*m+2):
            k, r = divmod(nu, m)
            R = sp.Poly(sp.rem(w**nu, Q, w), w)
            coeff = sp.Matrix([R.coeff_monomial(w**i) for i in range(m)])
            Jac = coeff.jacobian(aa).subs(point).applyfunc(sp.expand)
            expected = (-k*lam**(k-1)) * (C0**r)
            assert (Jac-expected).applyfunc(sp.expand) == sp.zeros(m)
            determinant = sp.factor(Jac.det())
            predicted = sp.factor(
                (-k*lam**(k-1))**m * (((-1)**(m-1)*lam)**r)
            )
            assert sp.expand(determinant-predicted) == 0
            checked += 1
    return checked


def check_krylov_hankel() -> int:
    checked = 0
    samples = [
        (-2, -1, 1, 2),
        (-1, 0, 1, 1),
        (1, -2, 2, -1),
    ]
    for m in range(2, 7):
        for seed in samples:
            q = [sp.Integer(seed[i % len(seed)]) for i in range(m)]
            if q[-1] == 0:
                q[-1] = 1
            C = companion_desc(q)
            J = reverse_matrix(m)
            L = lower_toeplitz(q)
            for nu in range(m, m+4):
                ss = moments(q, nu, 2*m-1)
                H = sp.Matrix(m, m, lambda i, j: ss[i+j])
                K = J*(C**nu)
                assert (K-L*H).applyfunc(sp.expand) == sp.zeros(m)
                assert H == H.T
                # L is unit lower triangular, hence every NW rank agrees.
                for a in range(1, m+1):
                    for b in range(1, m+1):
                        assert K[:a, :b].rank() == H[:a, :b].rank()
                checked += 1
    return checked


def check_first_normal_block() -> int:
    checked = 0
    # Moment strings with first nonzero moment s_d, followed by deterministic tails.
    for n in range(2, 9):
        for d in range(1, n+1):
            seq = [sp.Integer(0)]*(d-1) + [sp.Integer(2)]
            seq += [sp.Integer((j % 5)-2) for j in range(2*n-len(seq))]
            H = sp.Matrix(n, n, lambda i, j: seq[i+j])
            for a in range(1, d+1):
                for b in range(1, d+1):
                    expected = max(0, a+b-d)
                    assert H[:a, :b].rank() == expected
            detd = sp.factor(H[:d, :d].det())
            expected_det = (-1)**(d*(d-1)//2) * 2**d
            assert detd == expected_det
            checked += 1
    return checked


def main() -> None:
    c1 = check_cyclotomic_jacobians()
    c2 = check_krylov_hankel()
    c3 = check_first_normal_block()
    print(f"cyclotomic Jacobian cases: {c1}")
    print(f"Krylov-to-Hankel exact cases: {c2}")
    print(f"first-normal-block cases: {c3}")
    print("ALL LANE-2 ALL-RANK STRUCTURAL CHECKS PASSED")


if __name__ == "__main__":
    main()
