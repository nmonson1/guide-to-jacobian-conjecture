# Principal subresultants, Krylov minors, and rectangular Schur polynomials

> **Status:** new unrefereed proof draft; AI-assisted; exact symbolic and
> integer regression supplied.  
> **Scope:** a field of characteristic zero, a monic polynomial with nonzero
> constant term, and the explicit determinant convention below.  The proof is
> algebraic and extends to any characteristic in which the displayed
> identities and separability reductions are interpreted appropriately.

This note removes the convention-dependent part of `RMU-4D2E0001` that had
been attributed only to an unavailable source message.

## 1. Setup and determinant convention

Let

\[
Q(w)=w^m+q_1w^{m-1}+\cdots+q_m,
\qquad q_m\ne0,
\]

let \(\nu\ge m\), and put

\[
R(w)=w^\nu\bmod Q(w),
\qquad \deg R<m.
\]

Expand at infinity

\[
\frac{R(w)}{Q(w)}=\sum_{\ell\ge1}s_\ell w^{-\ell}
\]

and define

\[
H_k=(s_{i+j+1})_{0\le i,j<k}.
\]

For \(1\le k\le m\), define the displayed principal subresultant coefficient
\(\operatorname{psc}_{m-k}^{\mathrm{disp}}(Q,R)\) to be the determinant of
the \((2k-1)\times(2k-1)\) coefficient matrix whose rows, in order, are

\[
w^{k-2}Q,\ldots,Q,
\quad
w^{k-1}R,\ldots,R,
\]

and whose columns, in order, are the coefficients of

\[
w^{m+k-2},w^{m+k-3},\ldots,w^{m-k}.
\]

This is the standard principal-subresultant determinant after fixing the row
and column order explicitly.  Other common conventions differ by a fixed
sign only.

## 2. The exact determinant identity

### Theorem 2.1 — PSC equals a northwest Krylov determinant

Let \(K_k\) be the \(k\times k\) matrix whose \(j\)-th column, for
\(0\le j<k\), consists of the coefficients of

\[
w^jR\bmod Q
\]

in degrees \(m-1,m-2,\ldots,m-k\).  Then

\[
\boxed{
\operatorname{psc}_{m-k}^{\mathrm{disp}}(Q,R)
=(-1)^{\binom{k}{2}}\det K_k.
}
\]

#### Proof

The first \(k-1\) rows of the displayed subresultant matrix have leading
coefficients forming the identity matrix in the columns of degrees

\[
m+k-2,m+k-3,\ldots,m.
\]

Use these rows to divide every lower row by the monic polynomial \(Q\).  This
is a sequence of determinant-preserving row operations.  The resulting lower
rows are

\[
w^{k-1}R\bmod Q,\ldots,R,
\]

and the lower-right \(k\times k\) block records their coefficients in degrees
\(m-1,\ldots,m-k\).

The rows occur in the reverse of the column order used in \(K_k\).  Reversing
\(k\) objects contributes the sign

\[
(-1)^{\binom{k}{2}},
\]

and transposition does not change a determinant. ∎

### Theorem 2.2 — Krylov equals Hankel

One has

\[
\boxed{\det K_k=\det H_k.}
\]

#### Proof

Let \(K_\nu=JC^\nu\) be the full descending-coefficient companion--Krylov
matrix, as in the structural lemma packet, and let

\[
L_Q=(q_{i-j})_{0\le j\le i<m},\qquad q_0=1.
\]

The exact identity

\[
K_\nu=L_QH_\nu
\]

holds, where \(H_\nu=(s_{i+j+1})_{0\le i,j<m}\).  Taking the northwest
\(k\times k\) block gives

\[
(K_\nu)_k=(L_Q)_kH_k.
\]

The matrix \((L_Q)_k\) is unit lower triangular, so its determinant is one.
The block \((K_\nu)_k\) is exactly \(K_k\). ∎

Combining the two theorems gives

\[
\boxed{
\operatorname{psc}_{m-k}^{\mathrm{disp}}(Q,R)
=(-1)^{\binom{k}{2}}\det H_k.
}
\]

Since replacing \(w^\nu\) by its remainder modulo the monic polynomial \(Q\)
is itself determinant-preserving Sylvester elimination, the same displayed
principal coefficient is obtained from the pair \((w^\nu,Q)\).

## 3. Root formula and the rectangular partition

Let \(\alpha_1,\ldots,\alpha_m\) be the roots of \(Q\) in a splitting field.
First assume they are distinct.  Since

\[
R(\alpha_i)=\alpha_i^\nu,
\]

partial fractions give

\[
\frac{R(w)}{Q(w)}
=\sum_{i=1}^m
 \frac{\alpha_i^\nu}{Q'(\alpha_i)(w-\alpha_i)}.
\]

Consequently

\[
s_\ell
=\sum_{i=1}^m
 \frac{\alpha_i^{\nu+\ell-1}}{Q'(\alpha_i)}.
\]

### Theorem 3.1 — Hankel determinant as a subset sum

For \(1\le k\le m\),

\[
\det H_k
=(-1)^{\binom{k}{2}}
\sum_{\substack{I\subset\{1,\ldots,m\}\\|I|=k}}
\frac{\prod_{i\in I}\alpha_i^\nu}
{\prod_{i\in I,\ j\notin I}(\alpha_i-\alpha_j)}.
\]

#### Proof

Write

\[
H_k=V_I\,\operatorname{diag}
\left(\frac{\alpha_i^\nu}{Q'(\alpha_i)}\right)V_I^{\mathsf T}
\]

at the level of the full rectangular Vandermonde factorization and apply
Cauchy--Binet.  This gives

\[
\det H_k
=\sum_{|I|=k}
 \frac{\prod_{i\in I}\alpha_i^\nu\,\Delta_I^2}
 {\prod_{i\in I}Q'(\alpha_i)}.
\]

For each unordered pair inside \(I\), the two derivative factors contribute
one minus sign, while the remaining derivative factors are exactly the cross
product in the denominator.  Hence

\[
\frac{\Delta_I^2}{\prod_{i\in I}Q'(\alpha_i)}
=rac{(-1)^{\binom{k}{2}}}
 {\prod_{i\in I,j\notin I}(\alpha_i-\alpha_j)}.
\]
∎

Put

\[
a=\nu-m+k.
\]

This is nonnegative because \(\nu\ge m\).

### Theorem 3.2 — The subset sum is a rectangular Schur polynomial

Let \(\lambda=(a^k)\), the rectangle of height \(k\) and width \(a\).  Then

\[
\sum_{|I|=k}
\frac{\prod_{i\in I}\alpha_i^\nu}
{\prod_{i\in I,j\notin I}(\alpha_i-\alpha_j)}
=s_{(a^k)}(\alpha_1,\ldots,\alpha_m).
\]

#### Proof

Use the bialternant formula for the partition

\[
(a,\ldots,a,0,\ldots,0),
\]

with \(k\) copies of \(a\).  The numerator alternant has exponent rows

\[
\nu+k-1,\ldots,\nu,
\quad
m-k-1,\ldots,0.
\]

Laplace-expand along the first \(k\) rows.  Choosing a set \(I\) of \(k\)
columns contributes

\[
\left(\prod_{i\in I}\alpha_i^\nu\right)
\Delta_I\Delta_{I^c}.
\]

Dividing by the full Vandermonde leaves precisely the displayed cross
denominator; the Laplace and Vandermonde shuffle signs cancel. ∎

The distinct-root locus is Zariski dense, and both sides are symmetric
polynomials in the roots.  Therefore the identity extends to arbitrary monic
\(Q\), including nonreduced root schemes.

## 4. Final convention-complete identity

### Corollary 4.1

For every \(1\le k\le m\),

\[
\boxed{
\operatorname{psc}_{m-k}^{\mathrm{disp}}(w^\nu,Q)
=s_{((\nu-m+k)^k)}(\alpha_1,\ldots,\alpha_m)
=(-1)^{\binom{k}{2}}\det H_k.
}
\]

Thus:

1. the southwest/northwest Krylov determinant convention is explicit;
2. the subresultant sign is explicit;
3. the rectangular partition is
   \(((\nu-m+k)^k)\);
4. the vanishing loci and normal indices are independent of every remaining
   sign convention.

## 5. Consequences for Lane 2

The following portions of the retained rank-profile record are now proved
without relying on a private source message:

- companion--Krylov prefixes reduce triangularly to genuine Hankel prefixes;
- the relevant leading Hankel determinants are principal subresultant
  coefficients;
- those coefficients are rectangular Schur polynomials with the displayed
  partition;
- the first normal-index gap gives the first reversal block;
- once the full block-reversal profile is known, the filtered Smith exponents
  follow formally.

The remaining all-rank step is narrow: prove that successive Schur complements
of the Hankel moment matrix retain the required quasi-Hankel prefix-rank
recursion, thereby producing every later reversal block.  Existing arbitrary
rank-profile Hankel factorizations strongly support this step, but a
self-contained proof in the exact conventions of this program is still
needed.

## 6. Exact replay

The supplied script checks both identities

\[
\operatorname{psc}_{m-k}^{\mathrm{disp}}
=(-1)^{\binom{k}{2}}\det H_k
\]

and

\[
\operatorname{psc}_{m-k}^{\mathrm{disp}}
=s_{((\nu-m+k)^k)}
\]

for:

- 150 deterministic integer polynomial cases with \(2\le m\le7\);
- 675 exact determinant identities across all \(k\);
- 27 fully symbolic identities in ranks \(2,3,4\).

All checks pass.
