# Normal indices determine the full Hankel rank-profile permutation

> **Status:** new unrefereed proof draft; AI-assisted; exact regression supplied.  
> **Scope:** a field, a finite nonsingular scalar Hankel matrix, and normal
> indices defined by nonzero leading principal minors.  Combined with the
> companion--Hankel and principal-subresultant identifications in the adjacent
> notes, this proves the previously missing all-rank block-reversal statement
> in `RMU-4D2E0001`.

## 1. Statement

Let \(\Lambda:k[w]\to k\) be a linear functional and put

\[
s_{r+1}=\Lambda(w^r).
\]

For \(n\ge0\), let

\[
H_n=(s_{i+j+1})_{0\le i,j<n},
\qquad
D_n=\det H_n,
\qquad
D_0=1.
\]

Assume \(H_m\) is nonsingular.  List the normal indices

\[
0=n_0<n_1<\cdots<n_s=m
\]

for which \(D_{n_j}\ne0\), and put

\[
d_j=n_j-n_{j-1}.
\]

### Theorem 1.1 — Complete rank-profile theorem

The northwest rank-profile permutation of \(H_m\) is

\[
\boxed{
J_{d_1}\oplus J_{d_2}\oplus\cdots\oplus J_{d_s},
}
\]

where \(J_d\) is the reversal permutation of a consecutive block of size
\(d\).

Equivalently, every gap between consecutive normal indices contributes one
and only one reversal block.

## 2. Orthogonal residuals and Schur complements

Write

\[
\langle f,g\rangle=\Lambda(fg).
\]

Let

\[
V_d=k[w]_{<d}.
\]

If \(D_d\ne0\), the form is nondegenerate on \(V_d\).  For each \(i\ge0\),
there is therefore a unique residual polynomial

\[
r_i=w^{d+i}-\pi_d(w^{d+i})
\]

such that

\[
\pi_d(w^{d+i})\in V_d,
\qquad
r_i\perp V_d.
\]

The first residual

\[
p_d=r_0
\]

is the unique monic degree-\(d\) polynomial orthogonal to \(V_d\).

Partition a larger leading Hankel matrix after its first \(d\) rows and
columns.  Its Schur complement has entries

\[
S^{(d)}_{ij}=\langle r_i,r_j\rangle.
\]

Indeed, subtracting the orthogonal projections from the tail monomials is
exactly block Gaussian elimination of the Gram matrix.

For every \(t\), Schur's determinant formula gives

\[
\boxed{
\det S^{(d)}_t=\frac{D_{d+t}}{D_d}.
}
\]

## 3. The gap lemma

Fix consecutive normal indices

\[
d=n_{j-1},
\qquad
n_j=d+e.
\]

Thus

\[
D_d\ne0,
\qquad
D_{d+t}=0\quad(1\le t<e),
\qquad
D_{d+e}\ne0.
\]

Define the transformed moments

\[
\mu_a=\langle p_d,w^ap_d\rangle.
\]

### Lemma 3.1 — Orthogonality propagates through the gap

One has

\[
\mu_0=\mu_1=\cdots=\mu_{e-2}=0,
\qquad
\mu_{e-1}\ne0.
\]

Moreover, on the first \(e\) residuals, the Schur complement is related by a
unit lower-triangular congruence to the Hankel matrix

\[
T_e=(\mu_{a+b})_{0\le a,b<e}.
\]

#### Proof

We prove inductively that, before step \(t\),

\[
p_d\perp V_{d+t-1}
\]

and

\[
\mu_0=\cdots=\mu_{t-2}=0.
\]

This is true for \(t=1\), because \(p_d\perp V_d\).

For \(0\le i<t\), put

\[
u_i=w^ip_d.
\]

If \(a<d\), then

\[
i+a\le d+t-2,
\]

so the induction hypothesis gives

\[
\langle u_i,w^a\rangle=0.
\]

Thus \(u_i\in V_d^\perp\).  The space

\[
V_d^\perp\cap k[w]_{<d+i+1}
\]

has dimension \(i+1\), and

\[
r_0,\ldots,r_i
\]

form a basis of it.  Comparing leading terms gives a unit lower-triangular
relation

\[
(u_0,\ldots,u_{t-1})^{\mathsf T}
=U_t(r_0,\ldots,r_{t-1})^{\mathsf T}.
\]

Therefore

\[
T_t=U_tS^{(d)}_tU_t^{\mathsf T}.
\]

In particular,

\[
\det T_t=\det S^{(d)}_t.
\]

Since \(\mu_0,\ldots,\mu_{t-2}\) vanish, \(T_t\) has zeros strictly before
its anti-diagonal and constant anti-diagonal \(\mu_{t-1}\).  Hence

\[
\det T_t
=(-1)^{\binom t2}\mu_{t-1}^{\,t}.
\]

For \(t<e\), the normal-index hypothesis and Schur's formula give

\[
\det T_t=\det S^{(d)}_t=0,
\]

so \(\mu_{t-1}=0\).

Write

\[
w^{t-1}p_d=w^{d+t-1}+h,
\qquad
\deg h\le d+t-2.
\]

The induction hypothesis gives \(\langle p_d,h\rangle=0\), and therefore

\[
0=\mu_{t-1}
=\langle p_d,w^{d+t-1}\rangle.
\]

This extends the orthogonality to \(V_{d+t}\), completing the induction.

At \(t=e\), the determinant is nonzero, so

\[
\mu_{e-1}\ne0.
\]
∎

### Corollary 3.2 — Every normal-index gap is a reversal block

The northwest rank-profile permutation of the first \(e\) rows and columns of
\(S^{(d)}\) is \(J_e\).

#### Proof

The matrix \(T_e\) satisfies

\[
(T_e)_{ab}=0\quad\text{if }a+b<e-1
\]

and has nonzero anti-diagonal \(\mu_{e-1}\).  Consequently every northwest
\(a\times b\) prefix has rank

\[
\max(0,a+b-e),
\]

which is exactly the prefix-rank function of \(J_e\).

The congruence

\[
T_e=U_eS^{(d)}_eU_e^{\mathsf T}
\]

uses a lower-triangular matrix on the left and an upper-triangular matrix on
the right.  Such transformations preserve all northwest prefix ranks. ∎

## 4. Proof of the complete theorem

Start at \(d=n_0=0\).  Corollary 3.2 gives the first reversal block
\(J_{d_1}\).

Because the corresponding leading block is nonsingular, block Gaussian
elimination clears its right and lower rectangles using a unit lower
transformation on the left and a unit upper transformation on the right.
These transformations preserve all northwest prefix ranks.  The residual
matrix is the Schur complement after the first normal index.

Apply Corollary 3.2 with

\[
d=n_1,
\qquad
e=d_2.
\]

It gives the next block \(J_{d_2}\).  Continue through all consecutive normal
indices.  Schur-complement associativity shows that eliminating the blocks
successively gives the same residual as taking the Schur complement of the
full leading \(n_j\times n_j\) block directly.

Thus the complete rank-profile permutation is

\[
J_{d_1}\oplus\cdots\oplus J_{d_s}.
\]
∎

## 5. Consequences for the companion--PRS theorem

For the Lane 2 matrix associated with multiplication by \(w^\nu\bmod Q\):

1. the exact triangular identity
   \[
   K_\nu=L_QH_\nu
   \]
   identifies its northwest rank profile with the moment Hankel matrix;
2. the convention-complete identity
   \[
   \operatorname{psc}_{m-k}(w^\nu,Q)
   =(-1)^{\binom k2}\det H_k
   \]
   identifies the Euclidean/subresultant normal indices with the Hankel normal
   indices;
3. Theorem 1.1 gives
   \[
   J_{d_1}\oplus\cdots\oplus J_{d_s};
   \]
4. the filtered Bruhat--Smith lemma then gives exponent
   \[
   \boxed{\nu-m+n_{j-1}+n_j}
   \]
   with multiplicity \(d_j\).

Thus the rank-profile and filtered-Smith portions of `RMU-4D2E0001` now have a
self-contained proof chain.  What remains for the broader Lane 2 program is
not this local linear algebra, but the global geometry of closures of the
composition cells and the compatibility of their graph modifications.

## 6. Exact replay

The supplied checker verifies:

- all \(2^{m-1}\) ordered compositions for every \(2\le m\le5\), using 30
  explicit moment sequences;
- every northwest rectangular prefix rank against the direct sum of reversal
  blocks;
- the orthogonal-polynomial gap propagation;
- the exact triangular congruence
  \[
  T_e=U_eS_eU_e^{\mathsf T};
  \]
- 120 additional exact nonsingular Hankel examples in ranks \(6,7,8\).

All checks pass.
