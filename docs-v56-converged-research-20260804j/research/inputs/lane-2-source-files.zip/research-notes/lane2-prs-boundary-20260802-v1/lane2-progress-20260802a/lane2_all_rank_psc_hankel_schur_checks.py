#!/usr/bin/env python3
"""Exact regression checks for the all-rank PSC–Hankel–Schur identity."""
from __future__ import annotations

import itertools
import sympy as sp

w = sp.symbols("w")


def coeff_row(poly: sp.Expr, degrees: list[int]) -> list[sp.Expr]:
    p = sp.Poly(poly, w)
    return [p.coeff_monomial(w**d) for d in degrees]


def displayed_psc(Q: sp.Expr, R: sp.Expr, m: int, k: int) -> sp.Expr:
    """PSC_{m-k} in the displayed row/column convention of the note."""
    degrees = list(range(m + k - 2, m - k - 1, -1))
    rows: list[list[sp.Expr]] = []
    for a in range(k - 2, -1, -1):
        rows.append(coeff_row(sp.expand(w**a * Q), degrees))
    for a in range(k - 1, -1, -1):
        rows.append(coeff_row(sp.expand(w**a * R), degrees))
    matrix = sp.Matrix(rows)
    assert matrix.shape == (2 * k - 1, 2 * k - 1)
    return sp.expand(matrix.det())


def moments_of_R_over_Q(
    q: tuple[int, ...], R: sp.Expr, m: int, count: int
) -> list[sp.Expr]:
    """Return s_1,...,s_count for R/Q=sum s_l w^{-l}."""
    rp = sp.Poly(R, w)
    numerator = [sp.Integer(0)] * (count + 1)
    for a in range(m):
        ell = m - a
        if ell <= count:
            numerator[ell] = rp.coeff_monomial(w**a)

    s = [sp.Integer(0)] * (count + 1)
    for ell in range(1, count + 1):
        value = numerator[ell]
        for i in range(1, min(m, ell - 1) + 1):
            value -= q[i - 1] * s[ell - i]
        s[ell] = sp.expand(value)
    return s[1:]


def hankel_det(moments: list[sp.Expr], k: int) -> sp.Expr:
    return sp.expand(
        sp.Matrix([[moments[i + j] for j in range(k)] for i in range(k)]).det()
    )


def complete_symmetric(q: tuple[int, ...], m: int, count: int) -> list[sp.Expr]:
    """h_0,...,h_count for roots of w^m+q_1w^{m-1}+...+q_m."""
    h = [sp.Integer(1)]
    for n in range(1, count + 1):
        value = sp.Integer(0)
        for i in range(1, min(m, n) + 1):
            value += q[i - 1] * h[n - i]
        h.append(sp.expand(-value))
    return h


def rectangular_schur(q: tuple[int, ...], m: int, width: int, height: int) -> sp.Expr:
    h = complete_symmetric(q, m, width + height - 1)

    def h_at(index: int) -> sp.Expr:
        return sp.Integer(0) if index < 0 else h[index]

    jt = sp.Matrix(
        [
            [h_at(width - i + j) for j in range(height)]
            for i in range(height)
        ]
    )
    return sp.expand(jt.det())


def coefficient_samples(m: int) -> list[tuple[int, ...]]:
    # Deterministic samples, always with nonzero constant coefficient.
    values = [-2, -1, 0, 1, 2]
    samples: list[tuple[int, ...]] = []
    for index, prefix in enumerate(itertools.product(values, repeat=m - 1)):
        if index % max(1, 5 ** max(0, m - 3)) != 0:
            continue
        constant = (-1, 1, 2)[len(samples) % 3]
        samples.append(tuple(prefix) + (constant,))
        if len(samples) == 5:
            break
    return samples


def main() -> None:
    tested_polynomials = 0
    tested_identities = 0
    symbolic_identities = 0

    for m in range(2, 8):
        for nu in range(m, m + 5):
            for q in coefficient_samples(m):
                Q = w**m + sum(q[i] * w ** (m - 1 - i) for i in range(m))
                R = sp.rem(w**nu, Q, w)
                moments = moments_of_R_over_Q(q, R, m, 2 * m - 1)
                for k in range(1, m + 1):
                    psc = displayed_psc(Q, R, m, k)
                    hdet = hankel_det(moments, k)
                    sign = (-1) ** (k * (k - 1) // 2)
                    schur = rectangular_schur(q, m, nu - m + k, k)
                    assert sp.expand(psc - sign * hdet) == 0
                    assert sp.expand(psc - schur) == 0
                    tested_identities += 1
                tested_polynomials += 1

    # Fully symbolic checks in the first nontrivial ranks.
    for m in (2, 3, 4):
        qsym = sp.symbols(f"q1:{m + 1}")
        Q = w**m + sum(qsym[i] * w ** (m - 1 - i) for i in range(m))
        for nu in range(m, m + 3):
            R = sp.rem(w**nu, Q, w)
            moments = moments_of_R_over_Q(qsym, R, m, 2 * m - 1)
            for k in range(1, m + 1):
                psc = displayed_psc(Q, R, m, k)
                hdet = hankel_det(moments, k)
                sign = (-1) ** (k * (k - 1) // 2)
                schur = rectangular_schur(qsym, m, nu - m + k, k)
                assert sp.expand(psc - sign * hdet) == 0
                assert sp.expand(psc - schur) == 0
                symbolic_identities += 1

    print(f"numeric polynomial cases: {tested_polynomials}")
    print(f"numeric determinant identities: {tested_identities}")
    print(f"fully symbolic identities: {symbolic_identities}")
    print("ALL PSC–HANKEL–SCHUR CHECKS PASSED")


if __name__ == "__main__":
    main()
