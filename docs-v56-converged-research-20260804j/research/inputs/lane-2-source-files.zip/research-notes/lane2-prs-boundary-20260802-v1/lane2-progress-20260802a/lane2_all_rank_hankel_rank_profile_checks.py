#!/usr/bin/env python3
"""Exact checks for the all-rank Hankel normal-index rank-profile theorem."""
from __future__ import annotations

import random
from fractions import Fraction
import sympy as sp


REPRESENTATIVES: dict[int, dict[tuple[int, ...], tuple[int, ...]]] = {
    2: {
        (1, 1): (-1, -1, 0),
        (2,): (0, -1, -1),
    },
    3: {
        (1, 1, 1): (-1, -1, 0, -1, -1),
        (1, 2): (-1, -1, -1, 0, -1),
        (2, 1): (0, -1, -1, -1, 0),
        (3,): (0, 0, -1, -1, -1),
    },
    4: {
        (1, 1, 1, 1): (-1, -1, 0, -1, -1, -1, -1),
        (1, 1, 2): (-1, -1, 0, -1, 1, -1, -1),
        (1, 2, 1): (-1, -1, -1, 0, -1, -1, -1),
        (1, 3): (-1, -1, -1, -1, 0, -1, -1),
        (2, 1, 1): (0, -1, -1, -1, 0, -1, -1),
        (2, 2): (0, -1, -1, -1, -1, 0, -1),
        (3, 1): (0, 0, -1, -1, -1, -1, 0),
        (4,): (0, 0, 0, -1, -1, -1, -1),
    },
    5: {
        (1, 1, 1, 1, 1): (-1, -1, 0, -1, -1, -1, -1, -1, 0),
        (1, 1, 1, 2): (-1, -1, 0, -1, -1, 0, -1, 0, -1),
        (1, 1, 2, 1): (-1, -1, 0, -1, 1, -1, -1, -1, -1),
        (1, 1, 3): (-1, -1, 0, 0, 0, 0, -1, -1, -1),
        (1, 2, 1, 1): (-1, -1, -1, 0, -1, -1, -1, -1, -1),
        (1, 2, 2): (-1, -1, -1, 0, -1, 0, 0, 0, -1),
        (1, 3, 1): (-1, -1, -1, -1, 0, -1, -1, -1, -1),
        (1, 4): (-1, -1, -1, -1, -1, 0, -1, -1, -1),
        (2, 1, 1, 1): (0, -1, -1, -1, 0, -1, -1, -1, -1),
        (2, 1, 2): (0, -1, -1, -1, 0, 0, 1, -1, -1),
        (2, 2, 1): (0, -1, -1, -1, -1, 0, -1, -1, -1),
        (2, 3): (0, -1, -1, -1, -1, -1, 0, -1, -1),
        (3, 1, 1): (0, 0, -1, -1, -1, -1, 0, -1, -1),
        (3, 2): (0, 0, -1, -1, -1, -1, -1, 0, -1),
        (4, 1): (0, 0, 0, -1, -1, -1, -1, -1, 0),
        (5,): (0, 0, 0, 0, -1, -1, -1, -1, -1),
    },
}


def hankel(seq: tuple[int, ...] | list[sp.Expr], rows: int, cols: int | None = None, shift: int = 0) -> sp.Matrix:
    if cols is None:
        cols = rows
    return sp.Matrix([[seq[shift + i + j] for j in range(cols)] for i in range(rows)])


def normal_indices(seq: tuple[int, ...], m: int) -> list[int]:
    result = [0]
    for k in range(1, m + 1):
        if hankel(seq, k).det() != 0:
            result.append(k)
    return result


def expected_permutation(indices: list[int], m: int) -> sp.Matrix:
    p = sp.zeros(m)
    for left, right in zip(indices[:-1], indices[1:]):
        for i in range(left, right):
            p[i, left + right - 1 - i] = 1
    return p


def assert_prefix_ranks(matrix: sp.Matrix, permutation: sp.Matrix) -> None:
    rows, cols = matrix.shape
    for a in range(1, rows + 1):
        for b in range(1, cols + 1):
            assert matrix[:a, :b].rank() == permutation[:a, :b].rank()


def bilinear(seq: tuple[int, ...], f: list[sp.Expr], g: list[sp.Expr], shift: int = 0) -> sp.Expr:
    value = sp.Integer(0)
    for i, fi in enumerate(f):
        for j, gj in enumerate(g):
            value += fi * gj * seq[shift + i + j]
    return sp.expand(value)


def monic_orthogonal_polynomial(seq: tuple[int, ...], d: int) -> list[sp.Expr]:
    if d == 0:
        return [sp.Integer(1)]
    hd = hankel(seq, d)
    rhs = sp.Matrix([-seq[d + j] for j in range(d)])
    lower = list(hd.LUsolve(rhs))
    return [sp.expand(x) for x in lower] + [sp.Integer(1)]


def schur_complement(seq: tuple[int, ...], m: int, d: int) -> sp.Matrix:
    full = hankel(seq, m)
    if d == 0:
        return full
    a = full[:d, :d]
    b = full[:d, d:]
    c = full[d:, d:]
    return sp.simplify(c - b.T * a.inv() * b)


def verify_gap_model(seq: tuple[int, ...], m: int, left: int, right: int) -> None:
    e = right - left
    p = monic_orthogonal_polynomial(seq, left)
    mu = [bilinear(seq, p, [sp.Integer(0)] * j + p) for j in range(2 * e - 1)]
    assert all(value == 0 for value in mu[: e - 1])
    assert mu[e - 1] != 0

    s = schur_complement(seq, m, left)[:e, :e]
    t = sp.Matrix([[mu[i + j] for j in range(e)] for i in range(e)])

    # Construct residual polynomials r_i=w^{d+i}-projection to degree <d.
    residuals: list[list[sp.Expr]] = []
    for i in range(e):
        if left == 0:
            residuals.append([sp.Integer(0)] * i + [sp.Integer(1)])
            continue
        hd = hankel(seq, left)
        rhs = sp.Matrix([seq[left + i + j] for j in range(left)])
        projection = list(hd.LUsolve(rhs))
        r = [-sp.expand(x) for x in projection]
        r.extend([sp.Integer(0)] * i)
        r.append(sp.Integer(1))
        residuals.append(r)

    # u_i=w^i p is a unit-lower-triangular combination of r_0,...,r_i.
    u = sp.eye(e)
    for i in range(e):
        shifted = [sp.Integer(0)] * i + p
        for ell in range(i):
            degree = left + ell
            coefficient = shifted[degree] if degree < len(shifted) else sp.Integer(0)
            u[i, ell] = coefficient
        combination = [sp.Integer(0)] * (left + i + 1)
        for ell in range(i + 1):
            for degree, value in enumerate(residuals[ell]):
                combination[degree] += u[i, ell] * value
        assert all(sp.expand(a - b) == 0 for a, b in zip(shifted, combination))

    assert sp.simplify(t - u * s * u.T) == sp.zeros(e)
    assert_prefix_ranks(s, sp.Matrix([[1 if i + j == e - 1 else 0 for j in range(e)] for i in range(e)]))


def verify_sequence(seq: tuple[int, ...], m: int) -> tuple[int, ...]:
    indices = normal_indices(seq, m)
    assert indices[-1] == m
    composition = tuple(b - a for a, b in zip(indices[:-1], indices[1:]))
    full = hankel(seq, m)
    permutation = expected_permutation(indices, m)
    assert_prefix_ranks(full, permutation)
    for left, right in zip(indices[:-1], indices[1:]):
        verify_gap_model(seq, m, left, right)
    return composition


def main() -> None:
    representative_cases = 0
    represented_compositions = 0
    for m, by_composition in REPRESENTATIVES.items():
        assert len(by_composition) == 2 ** (m - 1)
        for expected, seq in by_composition.items():
            actual = verify_sequence(seq, m)
            assert actual == expected
            representative_cases += 1
        represented_compositions += len(by_composition)

    rng = random.Random(20260802)
    random_cases = 0
    for m in (6, 7, 8):
        while random_cases < (m - 5) * 40:
            seq = tuple(rng.choice((-2, -1, 0, 1, 2)) for _ in range(2 * m - 1))
            if hankel(seq, m).det() == 0:
                continue
            verify_sequence(seq, m)
            random_cases += 1

    print(f"composition representatives: {representative_cases}")
    print(f"all compositions represented through rank 5: {represented_compositions}")
    print(f"additional exact random cases in ranks 6–8: {random_cases}")
    print("ALL HANKEL RANK-PROFILE CHECKS PASSED")


if __name__ == "__main__":
    main()
