#!/usr/bin/env python3
"""Deterministic exact rank-profile and Smith regression for m=5.

Grid:
    q_i in {-1,0,1}, q_5 != 0, and 5 <= nu <= 15.
For every case, the script computes Euclidean normal indices, the northwest
rank profile of the reversed companion Krylov matrix, and all radial Smith
exponents from determinantal valuations.
"""
from __future__ import annotations

from itertools import combinations, product
import sympy as sp

w = sp.symbols("w")


def companion(coeffs: tuple[int, ...]) -> sp.Matrix:
    m = len(coeffs)
    matrix = sp.zeros(m)
    for j in range(m-1):
        matrix[j+1, j] = 1
    for i in range(m):
        matrix[i, m-1] = -coeffs[m-1-i]
    return matrix


def normal_indices(coeffs: tuple[int, ...], nu: int) -> list[int]:
    m = len(coeffs)
    polynomial = w**m + sum(sp.Integer(coeffs[i])*w**(m-1-i) for i in range(m))
    left = sp.Poly(w**nu, w, domain=sp.QQ)
    right = sp.Poly(polynomial, w, domain=sp.QQ)
    indices = [0]
    while True:
        remainder = left.rem(right)
        if remainder.is_zero:
            raise AssertionError("unexpected non-coprime pair")
        indices.append(m-remainder.degree())
        if remainder.degree() == 0:
            return indices
        left, right = right, remainder


def block_reversal(composition: tuple[int, ...]) -> sp.Matrix:
    m = sum(composition)
    permutation = sp.zeros(m)
    offset = 0
    for block in composition:
        for i in range(block):
            permutation[offset+i, offset+block-1-i] = 1
        offset += block
    return permutation


def same_northwest_ranks(left: sp.Matrix, right: sp.Matrix) -> tuple[bool, tuple[int, int] | None]:
    m = left.rows
    for rows in range(1, m+1):
        for columns in range(1, m+1):
            if left[:rows, :columns].rank() != right[:rows, :columns].rank():
                return False, (rows, columns)
    return True, None


def smith_exponents(matrix: sp.Matrix, nu: int) -> tuple[int, ...]:
    """Valuations after C_r^nu=r^nu D^{-1} C^nu D."""
    m = matrix.rows
    determinantal_valuations = [0]
    for size in range(1, m+1):
        best: int | None = None
        for rows in combinations(range(m), size):
            for columns in combinations(range(m), size):
                if matrix.extract(rows, columns).det() == 0:
                    continue
                value = size*nu + sum(columns)-sum(rows)
                best = value if best is None else min(best, value)
        if best is None:
            raise AssertionError("full companion power unexpectedly singular")
        determinantal_valuations.append(best)
    return tuple(
        determinantal_valuations[i]-determinantal_valuations[i-1]
        for i in range(1, m+1)
    )


def predicted_exponents(indices: list[int], nu: int, m: int) -> tuple[int, ...]:
    return tuple(
        exponent
        for left, right in zip(indices, indices[1:])
        for exponent in [nu-m+left+right]*(right-left)
    )


def main() -> None:
    counts: dict[tuple[int, ...], int] = {}
    checked = 0
    reversal = sp.zeros(5)
    for i in range(5):
        reversal[i, 4-i] = 1

    for coeffs in product(range(-1, 2), repeat=5):
        if coeffs[-1] == 0:
            continue
        matrix = companion(coeffs)
        for nu in range(5, 16):
            indices = normal_indices(coeffs, nu)
            composition = tuple(right-left for left, right in zip(indices, indices[1:]))
            counts[composition] = counts.get(composition, 0)+1

            power = matrix**nu
            okay, position = same_northwest_ranks(
                reversal*power,
                block_reversal(composition),
            )
            if not okay:
                raise AssertionError(("rank-profile failure", coeffs, nu, composition, position))

            actual = smith_exponents(power, nu)
            predicted = predicted_exponents(indices, nu, 5)
            if actual != predicted:
                raise AssertionError(("Smith failure", coeffs, nu, composition, actual, predicted))
            checked += 1

    expected_compositions = {
        (1, 1, 1, 1, 1), (1, 1, 1, 2), (1, 1, 2, 1), (1, 1, 3),
        (1, 2, 1, 1), (1, 2, 2), (1, 3, 1), (1, 4),
        (2, 1, 1, 1), (2, 1, 2), (2, 2, 1), (2, 3),
        (3, 1, 1), (3, 2), (4, 1), (5,),
    }
    assert set(counts) == expected_compositions
    assert checked == 1782

    print(f"exact cases checked: {checked}")
    print(f"ordered compositions realized: {len(counts)} of 16")
    for composition in sorted(counts):
        print(f"{composition}: {counts[composition]}")
    print("ALL M=5 COMPOSITION-GRID CHECKS PASSED")


if __name__ == "__main__":
    main()
