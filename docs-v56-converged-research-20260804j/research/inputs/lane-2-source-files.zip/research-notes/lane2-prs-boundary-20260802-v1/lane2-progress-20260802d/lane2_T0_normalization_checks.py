#!/usr/bin/env python3
"""Exact replay for the T=0 normalization and toric normal-form theorem."""
from __future__ import annotations

import itertools
import sympy as sp


def pfaffian4(a, b, c, d, e, f):
    """Pfaffian of [[0,a,b,c],[-a,0,d,e],[-b,-d,0,f],[-c,-e,-f,0]]."""
    return sp.expand(a*f-b*e+c*d)


def main() -> None:
    x, y, z, T, lam, rho, w = sp.symbols("x y z T lam rho w")
    alpha = 1-T*lam
    beta = 1-T*rho
    u = T*y+z
    xi = x-y**2
    v = u+alpha*x

    F0 = sp.expand(T*x+y*z)
    F1 = sp.expand(w*u-alpha*z)
    F2 = sp.expand(w*xi-alpha*x)
    F3 = sp.expand(rho*v-lam*z-(w+1)*y)
    F4 = sp.expand(w**2-alpha*(beta+rho*w*y))
    finite_ideal = [F0,F1,F2,F3,F4]

    # Saturated Hilbert--Burch graph.
    A1 = -T*rho*y**2-lam*y*z+rho*x*y-rho*y**3-rho*y*z-y**2
    A2 = lam*rho*y*z-lam*z+rho*x-rho*y**2+rho*z-2*y
    M = sp.Matrix([[A1,A2],[xi,-y],[u,T]])
    minors = [
        sp.expand(M[1,0]*M[2,1]-M[1,1]*M[2,0]),
        sp.expand(M[0,0]*M[2,1]-M[0,1]*M[2,0]),
        sp.expand(M[0,0]*M[1,1]-M[0,1]*M[1,0]),
    ]
    assert minors[0] == F0

    qsat = sp.symbols("qsat")
    Gsat = sp.groebner(
        minors+[F1,1-qsat*u],
        qsat,w,rho,lam,T,z,y,x,
        order="lex",
    )
    sat_no_q = [p.as_expr() for p in Gsat.polys if not p.as_expr().has(qsat)]
    Gsat2 = sp.groebner(sat_no_q,w,rho,lam,T,z,y,x,order="grevlex")
    Gfin = sp.groebner(finite_ideal,w,rho,lam,T,z,y,x,order="grevlex")
    for f in sat_no_q:
        assert Gfin.reduce(f)[1] == 0
    for f in finite_ideal:
        assert Gsat2.reduce(f)[1] == 0

    # Exact syzygies used on the two sheets.
    assert sp.expand(y*F1+T*F2-(w-alpha)*F0) == 0
    assert sp.expand((w-alpha)*F3-(rho-lam)*F1-rho*alpha*F2+y*F4) == 0

    B = sp.expand(beta+rho*w*y)
    assert sp.expand(F4-(w**2-alpha*B)) == 0
    assert sp.expand(w*z-B*u-((1-rho*y)*F1+T*F3-rho*alpha*F0)) == 0

    # Negative-sheet Jacobian.
    Jminus = sp.Matrix([
        [sp.diff(F1,var) for var in (z,x,w)],
        [sp.diff(F2,var) for var in (z,x,w)],
        [sp.diff(F4,var) for var in (z,x,w)],
    ])
    det_minus = sp.factor(Jminus.det().subs({x:0,y:0,z:0,T:0,w:-1}))
    assert det_minus == -8

    # Positive-sheet variables.
    h = sp.symbols("h")
    s = 1-h
    m1 = sp.expand(h*x-y**2)
    m2 = sp.expand(T*y+h*z)
    m3 = F0
    F = sp.expand(alpha-s**2*beta-rho*alpha*s*y)
    ell1 = sp.expand(s*(rho*s-lam))
    ell2 = sp.expand(alpha+s)
    ell3 = sp.expand(rho*alpha*s)
    G0 = sp.expand(x*ell3-y*ell2+z*ell1)

    w_sub = alpha/s
    assert sp.factor((s/alpha)*F1.subs(w,w_sub)-m2) == 0
    assert sp.factor((s/alpha)*F2.subs(w,w_sub)-m1) == 0
    assert sp.factor((s**2/alpha)*F4.subs(w,w_sub)-F) == 0
    transformed_F3 = sp.expand(s*F3.subs(w,w_sub))
    assert sp.factor(transformed_F3-G0-rho*s*m2) == 0

    # Pfaffian presentation.
    Phi = sp.Matrix([
        [0,0,x,y,z],
        [0,0,y,h,-T],
        [-x,-y,0,ell1,ell2],
        [-y,-h,-ell1,0,ell3],
        [-z,T,-ell2,-ell3,0],
    ])
    pf = []
    for omit in range(5):
        inds = [i for i in range(5) if i != omit]
        Q = Phi.extract(inds,inds)
        pf.append(pfaffian4(Q[0,1],Q[0,2],Q[0,3],Q[1,2],Q[1,3],Q[2,3]))
    assert [sp.expand(t) for t in pf] == [sp.expand(-F),G0,m2,m3,sp.expand(-m1)]

    # Pfaffian syzygies and local complete intersection.
    assert sp.expand(ell2*m1-(x*F+y*G0-ell1*m3)) == 0
    assert sp.expand(ell2*m2-(z*F-T*G0+ell3*m3)) == 0

    R = sp.expand(T*ell2+z*ell3)
    Delta = ell1
    assert sp.expand(ell2*m3-(x*R+Delta*z**2-z*G0)) == 0

    # Etale coordinate change at the central positive sheet.
    old = (h,y,T,rho,x,z,lam)
    new = (F,G0,R,Delta,x,z,lam)
    Jchange = sp.Matrix([[sp.diff(f,var) for var in old] for f in new])
    det_change = sp.factor(Jchange.det().subs({h:0,y:0,T:0,x:0,z:0}))
    assert det_change == -8

    # Exact resolution charts of the abstract normal form x*R0+Delta0*z^2.
    a,b,c,d = sp.symbols("a b c d")
    R0, Delta0 = sp.symbols("R0 Delta0")
    normal = x*R0+Delta0*z**2
    strict_x = sp.expand(normal.subs(z,a*x)/x)
    assert strict_x == R0+Delta0*a**2*x
    strict_z = sp.expand(normal.subs(x,b*z)/z)
    assert strict_z == b*R0+Delta0*z
    conifold = b*R0+Delta0*z
    strict_b = sp.expand(conifold.subs(z,c*b)/b)
    strict_z2 = sp.expand(conifold.subs(b,d*z)/z)
    assert strict_b == R0+Delta0*c
    assert strict_z2 == d*R0+Delta0

    # Singular locus of the toric normal form.
    vars_nf = (x,R0,z,Delta0,lam)
    grad = [sp.diff(normal,var) for var in vars_nf]
    assert grad == [R0,x,2*Delta0*z,z**2,0]

    print("saturated graph-of-w presentation: passed")
    print("finite cubic-scroll gluing identities: passed")
    print("negative T=0 sheet smoothness: passed")
    print("positive-sheet Pfaffian presentation: passed")
    print("exact etale normal form x*R+Delta*z^2: passed")
    print("two-step toric/conifold resolution: passed")
    print("ALL T=0 NORMALIZATION CHECKS PASSED")


if __name__ == "__main__":
    main()
