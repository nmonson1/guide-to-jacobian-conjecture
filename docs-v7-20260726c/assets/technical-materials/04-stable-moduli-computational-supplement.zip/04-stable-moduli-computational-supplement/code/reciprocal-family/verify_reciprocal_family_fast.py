#!/usr/bin/env python3
"""Fast exact checks for the arbitrary-polynomial reciprocal family.

This script verifies the structural identities without expanding a high-degree
Jacobian in x,y,z.  The proof uses the rational coordinates (P,s,y), in which
all cancellations are transparent.  Tested with SymPy 1.14.
"""
from __future__ import annotations

import sympy as sp

x, y, z = sp.symbols("x y z")
p, q, r, s = sp.symbols("p q r s")
G = sp.symbols("G")

A = 1 + x*y
B = sp.expand(A**2*z + y**2*(4 + 3*x*y))
P = sp.expand(A*B)
Q = sp.expand(y + 3*x*B)
R = sp.expand(2*x - 3*x**2*y - x**3*z)
s_source = x/A

# The base coordinate changes used throughout the note.
assert sp.factor(sp.Matrix([P, Q, R]).jacobian((x, y, z)).det() + 2) == 0
assert sp.factor(sp.Matrix([P, s_source, y]).jacobian((x, y, z)).det() - A) == 0

# For an arbitrary differentiable symbol g(p), the output Jacobian in
# (p,s,y)-coordinates is -2(1-ys).  Derivatives of g cancel.
gfun = sp.Function("g")
gp = gfun(p)
q_psy = y + 3*p*gp*s
r_psy = 2*p*gp*s**3 - q_psy*s**2 + 2*s
Jout = sp.Matrix([p, q_psy, r_psy]).jacobian((p, s, y)).det()
assert sp.simplify(Jout + 2*(1-y*s)) == 0
assert sp.simplify(Jout.subs({p: P, s: s_source}) * A + 2) == 0

# Pole cancellation: g(P)=1+P^2 eta(P) removes A^{-2} exactly.
etaP = sp.symbols("etaP")
gP = 1 + P**2*etaP
r_shift = sp.cancel(-P*(gP-1)*s_source**3)
assert sp.factor(r_shift + x**3*B**3*etaP) == 0
q_shift = sp.cancel(3*P*(gP-1)*s_source)
assert sp.factor(q_shift - 3*x*A**2*B**3*etaP) == 0

# Abstract simple-root reconstruction with G standing for g(p).
Omega = 2*p*G*s**3 - q*s**2 + 2*s - r
D = sp.diff(Omega, s)
a = 2/D
xrec = sp.cancel(a*s)
yrec = q - 3*p*G*s
brec = sp.cancel(p/a)
zrec = sp.cancel((brec - yrec**2*(4+3*xrec*yrec))/a**2)
Arec = sp.cancel(1+xrec*yrec)
Brec = sp.cancel(Arec**2*zrec + yrec**2*(4+3*xrec*yrec))
assert sp.factor(Arec-a) == 0
assert sp.factor(Brec-brec) == 0
assert sp.factor(Arec*Brec-p) == 0
assert sp.factor(yrec + 3*p*G*s-q) == 0
assert sp.factor(2*p*G*s**3-q*s**2+2*s-r-Omega) == 0

# Cubic discriminant and the nonsquare certificate.
Delta = sp.factor(sp.discriminant(Omega, s)/4)
Delta_expected = q**2 - 16*p*G - q**3*r + 18*p*G*q*r - 27*p**2*G**2*r**2
assert sp.expand(Delta-Delta_expected) == 0
assert sp.factor(sp.discriminant(Delta_expected, r) - (q**2-12*p*G)**3) == 0

print("All fast structural checks for the reciprocal family passed.")
