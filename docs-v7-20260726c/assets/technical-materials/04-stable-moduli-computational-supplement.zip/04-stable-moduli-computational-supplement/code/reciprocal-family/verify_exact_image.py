#!/usr/bin/env python3
"""Exact algebra checks used in the omitted-locus proof.

This checks the source identities, the rational inverse attached to a simple
root, the exceptional p=0 chart, and the elliptic change of variables.  The
root-multiplicity classification and the Albanese argument are mathematical
arguments, not computer outputs.
"""

import sympy as sp

x, y, z, lam = sp.symbols("x y z lambda")
p, q, r, s, D = sp.symbols("p q r s D")

A = 1 + x*y
B = sp.expand(A**2*z + y**2*(4 + 3*x*y))
P = sp.expand(A*B)
Q = sp.expand(y + 3*x*B)
R = sp.expand(2*x - 3*x**2*y - x**3*z)

eta = lam*(4*P + 1)
Q_lam = sp.expand(Q + A**2*x*B**3*eta)
R_lam = sp.expand(R - sp.Rational(1, 3)*x**3*B**3*eta)

gP = 1 + lam*P**2*(4*P + 1)/3
s_source = x/A

# Identities on A != 0. Clearing denominators makes them polynomial checks.
assert sp.factor(A*(Q_lam - (y + 3*P*gP*s_source))) == 0
assert sp.factor(A**3*(R_lam - (2*P*gP*s_source**3 - Q_lam*s_source**2 + 2*s_source))) == 0
assert sp.factor(A*(6*P*gP*s_source**2 - 2*Q_lam*s_source + 2) - 2) == 0

# Abstract reconstruction from a simple root.
g = 1 + lam*p**2*(4*p + 1)/3
Omega = 2*p*g*s**3 - q*s**2 + 2*s - r
D_expr = sp.diff(Omega, s)
a = 2/D_expr
x_rec = sp.cancel(a*s)
y_rec = q - 3*p*g*s
b_rec = sp.cancel(p/a)
z_rec = sp.cancel((b_rec - y_rec**2*(4 + 3*x_rec*y_rec))/a**2)

assert sp.factor(1 + x_rec*y_rec - a) == 0

A_rec = sp.cancel(1 + x_rec*y_rec)
B_rec = sp.cancel(A_rec**2*z_rec + y_rec**2*(4 + 3*x_rec*y_rec))
P_rec = sp.cancel(A_rec*B_rec)
Q_rec = sp.cancel(y_rec + 3*x_rec*B_rec + lam*A_rec**2*x_rec*B_rec**3*(4*P_rec + 1))
R_rec = sp.cancel(2*x_rec - 3*x_rec**2*y_rec - x_rec**3*z_rec
                  - lam*sp.Rational(1, 3)*x_rec**3*B_rec**3*(4*P_rec + 1))

assert sp.factor(P_rec - p) == 0
assert sp.factor(Q_rec - q) == 0
# R_rec-r equals a rational multiple of Omega, hence vanishes at a root.
assert sp.factor(R_rec - r - Omega) == 0

# Exceptional p=0 chart.
z0 = q**3/sp.Integer(8) * (sp.Rational(10, 1)/q - lam*q**3/sp.Integer(24) - r)
x0 = 2/q
y0 = -q/2
A0 = sp.cancel(1 + x0*y0)
B0 = sp.cancel(A0**2*z0 + y0**2*(4 + 3*x0*y0))
P0 = sp.cancel(A0*B0)
Q0 = sp.cancel(y0 + 3*x0*B0 + lam*A0**2*x0*B0**3*(4*P0 + 1))
R0 = sp.cancel(2*x0 - 3*x0**2*y0 - x0**3*z0
               - lam*sp.Rational(1, 3)*x0**3*B0**3*(4*P0 + 1))
assert sp.factor(P0) == 0
assert sp.factor(Q0 - q) == 0
assert sp.factor(R0 - r) == 0

# Elliptic change of variables on Gamma.
X, Y = sp.symbols("X Y")
g_inv = sp.cancel(g.subs(p, 1/X))
assert sp.factor((12*(1/X)*g_inv) - (12*X**3 + 4*lam*X + 16*lam)/X**4) == 0

# Exceptional parameters and j-invariant.
assert sp.factor(sp.discriminant(sp.Poly(g, p), p)) == -sp.Rational(4, 27)*lam**2*(lam + 324)
aW = lam/3
bW = 4*lam/3
j = sp.factor(1728*(4*aW**3)/(4*aW**3 + 27*bW**2))
assert j == 1728*lam/(lam + 324)

print("All omitted-locus algebra checks passed.")
