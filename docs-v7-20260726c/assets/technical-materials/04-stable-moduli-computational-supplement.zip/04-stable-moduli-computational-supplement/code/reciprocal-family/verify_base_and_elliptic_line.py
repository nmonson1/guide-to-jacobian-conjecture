#!/usr/bin/env python3
"""Exact symbolic checks for the public deformation note.

Uses only SymPy and exact rational arithmetic.  The geometric arguments about
image complements and stable equivalence are proved in the accompanying note;
this script checks the polynomial identities on which they rest.
"""

import sympy as sp

x, y, z, lam = sp.symbols("x y z lambda")
p, q, r, s = sp.symbols("p q r s")

A = 1 + x*y
B = sp.expand(A**2*z + y**2*(4 + 3*x*y))
P = sp.expand(A*B)
Q = sp.expand(y + 3*x*B)
R = sp.expand(2*x - 3*x**2*y - x**3*z)

eta = lam*(4*P + 1)
Q_lam = sp.expand(Q + A**2*x*B**3*eta)
R_lam = sp.expand(R - sp.Rational(1, 3)*x**3*B**3*eta)
G_lam = sp.Matrix([P, Q_lam, R_lam])
F_lam = sp.Matrix([R_lam/2, Q_lam, P])

# Constant Jacobian and normalization.
assert sp.factor(G_lam.jacobian((x, y, z)).det()) == -2
assert sp.factor(F_lam.jacobian((x, y, z)).det()) == 1
assert F_lam.subs({x: 0, y: 0, z: 0}) == sp.zeros(3, 1)
assert F_lam.jacobian((x, y, z)).subs({x: 0, y: 0, z: 0}) == sp.eye(3)

# The announced collision persists for every lambda.
collision = [
    {x: 0, y: 0, z: -sp.Rational(1, 4)},
    {x: 1, y: -sp.Rational(3, 2), z: sp.Rational(13, 2)},
    {x: -1, y: sp.Rational(3, 2), z: sp.Rational(13, 2)},
]
for point in collision:
    assert G_lam.subs(point) == sp.Matrix([-sp.Rational(1, 4), 0, 0])
    assert F_lam.subs(point) == sp.Matrix([0, 0, -sp.Rational(1, 4)])

# Fiber cubic in the reciprocal primitive s=x/(1+xy).
g_source = 1 + lam*P**2*(4*P + 1)/3
Omega_source = 2*P*g_source*s**3 - Q_lam*s**2 + 2*s - R_lam
s_source = x/A
assert sp.factor(Omega_source.subs(s, s_source)) == 0
assert sp.factor(sp.diff(Omega_source, s).subs(s, s_source)) == 2/A

# Abstract discriminant and its nonsquare certificate.
g = 1 + lam*p**2*(4*p + 1)/3
Omega = sp.expand(2*p*g*s**3 - q*s**2 + 2*s - r)
Delta = sp.factor(sp.discriminant(Omega, s)/4)
Delta_expected = sp.expand(
    q**2 - 16*p*g - q**3*r + 18*p*g*q*r - 27*p**2*g**2*r**2
)
assert sp.expand(Delta - Delta_expected) == 0
assert sp.factor(sp.discriminant(Delta_expected, r) - (q**2 - 12*p*g)**3) == 0

# Bad parameters for the cubic g_lambda(p): repeated roots only at 0 and -324.
assert sp.factor(sp.discriminant(sp.Poly(g, p), p)) == -sp.Rational(4, 27)*lam**2*(lam + 324)

# Triple-root equations.  Substitution of q=6 p g u and r=2 p g u^3,
# together with 3 p g u^2=1, gives the displayed eliminated equations.
u = sp.symbols("u")
q_triple = 6*p*g*u
r_triple = 2*p*g*u**3
rel = 3*p*g*u**2 - 1
assert sp.factor((q_triple**2 - 12*p*g) - 12*p*g*rel) == 0
assert sp.factor((3*q_triple*r_triple - 4) - 4*(rel**2 + 2*rel)) == 0

# Elliptic completion and j-invariant.
# After Y^2=12 X^3+4 lambda X+16 lambda, divide Y by sqrt(12):
# y^2=X^3+aX+b with a=lambda/3, b=4lambda/3.
a = lam/3
b = 4*lam/3
j = sp.factor(1728 * (4*a**3) / (4*a**3 + 27*b**2))
assert j == 1728*lam/(lam + 324)

print("All exact symbolic checks passed.")
