#!/usr/bin/env python3
"""Exact symbolic checks for the six-step Keller-map analysis.

The proofs are in research_report.md.  This script checks the polynomial and
rational identities that are most vulnerable to transcription errors.
Tested with SymPy 1.14.
"""
from __future__ import annotations

import sympy as sp

x, y, z = sp.symbols("x y z")
p, q, r, s, u, v = sp.symbols("p q r s u v")
a0, a1, a2 = sp.symbols("a0 a1 a2")
rho, k = sp.symbols("rho k", nonzero=True)
T, C = sp.symbols("T C")

# ------------------------------------------------------------------ base map
A = 1 + x*y
B = sp.expand(A**2*z + y**2*(4 + 3*x*y))
P = sp.expand(A*B)
Q = sp.expand(y + 3*x*B)
R = sp.expand(2*x - 3*x**2*y - x**3*z)
assert sp.factor(sp.Matrix([P, Q, R]).jacobian((x, y, z)).det()) == -2

# -------------------------------------------------------- arbitrary eta family
etaP = a0 + a1*P + a2*P**2
gP = 1 + P**2*etaP
Qeta = sp.expand(Q + 3*x*A**2*B**3*etaP)
Reta = sp.expand(R - x**3*B**3*etaP)
s_source = x/A

# Uniform fiber identities.
assert sp.factor(A*(Qeta - (y + 3*P*gP*s_source))) == 0
assert sp.factor(A**3*(Reta - (2*P*gP*s_source**3 - Qeta*s_source**2 + 2*s_source))) == 0
assert sp.factor(A*(6*P*gP*s_source**2 - 2*Qeta*s_source + 2) - 2) == 0

# Conceptual Jacobian factorization in (p,s,y)-coordinates.
gfun = sp.Function("g")
g = gfun(p)
q_psy = y + 3*p*g*s
r_psy = 2*p*g*s**3 - q_psy*s**2 + 2*s
J_out = sp.Matrix([p, q_psy, r_psy]).jacobian((p, s, y)).det()
assert sp.simplify(J_out + 2*(1-y*s)) == 0
J_in = sp.Matrix([P, s_source, y]).jacobian((x, y, z)).det()
assert sp.factor(J_in - A) == 0
assert sp.simplify((J_out.subs({p: P, s: s_source}))*J_in + 2) == 0

# Abstract simple-root reconstruction.
eta = a0 + a1*p + a2*p**2
gabs = 1 + p**2*eta
Omega = 2*p*gabs*s**3 - q*s**2 + 2*s - r
D = sp.diff(Omega, s)
a = 2/D
xrec = sp.cancel(a*s)
yrec = q - 3*p*gabs*s
brec = sp.cancel(p/a)
zrec = sp.cancel((brec - yrec**2*(4 + 3*xrec*yrec))/a**2)
assert sp.factor(1 + xrec*yrec - a) == 0
Arec = sp.cancel(1 + xrec*yrec)
Brec = sp.cancel(Arec**2*zrec + yrec**2*(4 + 3*xrec*yrec))
Prec = sp.cancel(Arec*Brec)
Qrec = sp.cancel(yrec + 3*xrec*Brec + 3*xrec*Arec**2*Brec**3*eta.subs(p, Prec))
Rrec = sp.cancel(2*xrec - 3*xrec**2*yrec - xrec**3*zrec - xrec**3*Brec**3*eta.subs(p, Prec))
assert sp.factor(Prec-p) == 0
assert sp.factor(Qrec-q) == 0
assert sp.factor(Rrec-r-Omega) == 0

# Exceptional p=0/infinity chart for arbitrary eta(0)=a0.
x0 = 2/q
y0 = -q/2
z0 = 5*q**2/4 - a0*q**6/64 - r*q**3/8
A0 = sp.cancel(1+x0*y0)
B0 = sp.cancel(A0**2*z0 + y0**2*(4+3*x0*y0))
P0 = sp.cancel(A0*B0)
Q0 = sp.cancel(y0 + 3*x0*B0 + 3*x0*A0**2*B0**3*(a0+a1*P0+a2*P0**2))
R0 = sp.cancel(2*x0-3*x0**2*y0-x0**3*z0-x0**3*B0**3*(a0+a1*P0+a2*P0**2))
assert sp.factor(P0) == 0
assert sp.factor(Q0-q) == 0
assert sp.factor(R0-r) == 0

# Binary cubic and discriminant.
H = 2*p*gabs*u**3 - q*u**2*v + 2*u*v**2 - r*v**3
assert sp.expand(H.subs({u: s, v: 1}) - Omega) == 0
Delta = sp.factor(sp.discriminant(Omega, s)/4)
Delta_expected = sp.expand(q**2 - 16*p*gabs - q**3*r + 18*p*gabs*q*r - 27*p**2*gabs**2*r**2)
assert sp.expand(Delta-Delta_expected) == 0
assert sp.factor(sp.discriminant(Delta_expected, r) - (q**2-12*p*gabs)**3) == 0

# Reciprocal chart at infinity: Psi'(t)=2/x on source.
tau = sp.symbols("tau")
Psi = r*tau**3 - 2*tau**2 + q*tau - 2*p*gabs
# On X, p/tau = (q-2tau+r tau^2)/(2g).
ratio = (q-2*tau+r*tau**2)/(2*gabs)
Dinf = sp.diff(Psi, tau)
xinf = 2/Dinf
yinf = tau-Dinf/2
Binf = sp.cancel(Dinf*ratio/2)
Ainf = sp.cancel(xinf*tau)
assert sp.factor(Ainf*Binf-p-Psi/(2*gabs)) == 0  # identity modulo Psi
assert sp.factor(1+xinf*yinf-Ainf) == 0

# ----------------------------------------------------- scaling and elliptic j
# g=1+a p^2+b p^3.  Scaling p -> rho^{-2}p gives weights 4 and 6.
aa, bb = sp.symbols("aa bb")
glin = 1 + aa*p**2 + bb*p**3
gscaled = sp.expand(glin.subs(p, rho**-2*p))
assert sp.expand(gscaled - (1 + aa*rho**-4*p**2 + bb*rho**-6*p**3)) == 0
I = -3*aa
J = -27*bb
jinv = sp.factor(6912*I**3/(4*I**3-J**2))
assert jinv == 6912*aa**3/(4*aa**3+27*bb**2)
# Special line aa=lambda/3, bb=4lambda/3.
lam = sp.symbols("lambda")
assert sp.factor(jinv.subs({aa: lam/3, bb: 4*lam/3})) == 1728*lam/(lam+324)

# ---------------------------------------------------- public frame covariance
def frame(h, w):
    tt = y + 1/x
    rr = sp.Rational(2)/x
    cc = sp.expand(w-x**3*z)
    bout = sp.cancel(rr-sp.diff(h, T).subs({T: tt, C: cc}))
    aout = sp.cancel((h.subs({T: tt, C: cc})+tt*bout)/2)
    return tuple(sp.expand(e) for e in (aout, bout, cc))

h0 = C*T**3 - 2*T**2
w0 = 2*x - 3*x**2*y
hk = C*T**3 - (2+k*C)*T**2
wk = 2*x - 3*x**2*y + k*x**2
F0 = frame(h0, w0)
Fk = frame(hk, wk)
assert all(sp.denom(sp.together(e)).is_number for e in Fk)
# S_k: y -> y-k/3.  Exact target shear from the report.
F0S = tuple(sp.expand(e.subs(y, y-k/3)) for e in F0)
ck = Fk[2]
TkFk = (
    sp.expand(Fk[0] - k*Fk[1]/6 + k**2/9 + k**3*ck/27),
    sp.expand(Fk[1] - 4*k/3 - k**2*ck/3),
    ck,
)
assert all(sp.expand(F0S[i]-TkFk[i]) == 0 for i in range(3))

# Degrees in the reciprocal normal form.  deg g=m gives max degree 7m+6.
for m in (2, 3, 4):
    cm = sp.symbols(f"c{m}")
    gmP = 1 + cm*P**m
    # eta=(g-1)/P^2=cm P^(m-2)
    Qm = sp.expand(y + 3*x*B*gmP)
    Rm = sp.expand(R - x**3*B**3*cm*P**(m-2))
    assert sp.Poly(Qm, x, y, z).total_degree() == 7*m+6
    assert sp.Poly(Rm, x, y, z).total_degree() == 7*m+4

print("All six-step exact symbolic checks passed.")
