#!/usr/bin/env python3
"""Compute the first two coefficients of the unique formal source conjugacy.

For G_t=G_0+tH, solve G_0(phi_t)=G_t with
phi_t=id+t v1+t^2 v2+... .  The exact recursions are
  JG_0 v1 = H,
  JG_0 v2 = -(1/2)D^2G_0(v1,v1).
The output records degrees and sparse term counts and verifies both equations.
"""
from __future__ import annotations

import json
from pathlib import Path
import sympy as sp

x,y,z=sp.symbols('x y z')
V=(x,y,z)
A=1+x*y
B=sp.expand(A**2*z+y**2*(4+3*x*y))
P=sp.expand(A*B)
Q=sp.expand(y+3*x*B)
R=sp.expand(2*x-3*x**2*y-x**3*z)
G=sp.Matrix([P,Q,R])
H=sp.Matrix([
    0,
    sp.expand(x*A**2*B**3*(4*P+1)),
    sp.expand(-sp.Rational(1,3)*x**3*B**3*(4*P+1)),
])
J=G.jacobian(V)
assert sp.factor(J.det())==-2
Jinv=J.inv()

v1=sp.Matrix([sp.expand(e) for e in Jinv*H])
assert all(sp.expand((J*v1-H)[i])==0 for i in range(3))

def hess_contract(f,u,v):
    return sp.expand(sum(sp.diff(f,V[i],V[j])*u[i]*v[j]
                         for i in range(3) for j in range(3)))
quad=sp.Matrix([hess_contract(f,v1,v1)/2 for f in G])
v2=sp.Matrix([sp.expand(e) for e in -Jinv*quad])
assert all(sp.expand((J*v2+quad)[i])==0 for i in range(3))

def stats(vec):
    return {
        'degrees':[sp.Poly(e,*V).total_degree() if e else -1 for e in vec],
        'term_counts':[len(sp.Poly(e,*V).terms()) if e else 0 for e in vec],
        'factored':[str(sp.factor(e)) for e in vec],
    }

out={
    'v1':stats(v1),
    'v2':stats(v2),
    'max_degree_sequence':[max(stats(v1)['degrees']),max(stats(v2)['degrees'])],
}
path=Path(__file__).with_name('data')/'formal_conjugacy_degrees.json'
path.write_text(json.dumps(out,indent=2))
print(json.dumps({
    'v1_degrees':out['v1']['degrees'],
    'v1_terms':out['v1']['term_counts'],
    'v2_degrees':out['v2']['degrees'],
    'v2_terms':out['v2']['term_counts'],
},indent=2))
