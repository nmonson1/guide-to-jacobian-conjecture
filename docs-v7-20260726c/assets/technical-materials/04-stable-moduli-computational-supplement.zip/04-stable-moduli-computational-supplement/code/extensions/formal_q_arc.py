#!/usr/bin/env python3
"""First two coefficients of the formal source trivialization of the q-arc."""
from __future__ import annotations
import json
from pathlib import Path
import sympy as sp

x,y,z,q=sp.symbols('x y z q')
s=sp.symbols('s')
T=sp.symbols('T')
V=(x,y,z)
t=y+1/x
c=2*x-3*x**2*y-x**3*z

def frame(A,B):
    h=A*T**3+B*T**2
    bb=sp.expand(sp.cancel(2/x-sp.diff(h,T).subs(T,t)))
    aa=sp.expand(sp.cancel((h.subs(T,t)+t*bb)/2))
    return sp.Matrix([aa,bb,c])

F0=frame(c,-2)
Fs=frame(c+s*c**2,-2-4*s*c+q*s**2*c**2)
assert all(sp.degree(e,s)<=2 for e in Fs)
H1=sp.Matrix([sp.expand(sp.diff(e,s).subs(s,0)) for e in Fs])
H2=sp.Matrix([sp.expand(sp.diff(e,s,2).subs(s,0)/2) for e in Fs])
J=F0.jacobian(V)
assert sp.factor(J.det()+2)==0
Jinv=sp.simplify(J.inv())
v1=sp.Matrix([sp.expand(e) for e in Jinv*H1])
assert all(sp.expand((J*v1-H1)[i])==0 for i in range(3))

def hess_contract(f,u,v):
    return sp.expand(sum(sp.diff(f,V[i],V[j])*u[i]*v[j]
                         for i in range(3) for j in range(3)))
quad=sp.Matrix([hess_contract(f,v1,v1)/2 for f in F0])
v2=sp.Matrix([sp.expand(e) for e in Jinv*(H2-quad)])
assert all(sp.expand((J*v2+quad-H2)[i])==0 for i in range(3))


# Third order: Fs has no s^3 coefficient.
def third_contract(f,u,v,w):
    return sp.expand(sum(sp.diff(f,V[i],V[j],V[k])*u[i]*v[j]*w[k]
                         for i in range(3) for j in range(3) for k in range(3)))
mix=sp.Matrix([hess_contract(f,v1,v2) for f in F0])
cubic=sp.Matrix([third_contract(f,v1,v1,v1)/6 for f in F0])
v3=sp.Matrix([sp.expand(e) for e in -Jinv*(mix+cubic)])
assert all(sp.expand((J*v3+mix+cubic)[i])==0 for i in range(3))

def degree_xyz(expr):
    return sp.Poly(expr,x,y,z).total_degree() if expr else -1

def terms_xyzq(expr):
    return len(sp.Poly(expr,x,y,z,q).terms()) if expr else 0

out={
  'arc':'alpha=s, beta=q*s^2',
  'v1':{
    'degrees':[degree_xyz(e) for e in v1],
    'term_counts':[terms_xyzq(e) for e in v1],
    'q_dependent':[bool(e.has(q)) for e in v1],
  },
  'v2':{
    'degrees':[degree_xyz(e) for e in v2],
    'term_counts':[terms_xyzq(e) for e in v2],
    'q_dependent':[bool(e.has(q)) for e in v2],
  },
  'v3':{
    'degrees':[degree_xyz(e) for e in v3],
    'term_counts':[terms_xyzq(e) for e in v3],
    'q_dependent':[bool(e.has(q)) for e in v3],
  },
}
Path(__file__).with_name('data').joinpath('formal_q_arc.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
