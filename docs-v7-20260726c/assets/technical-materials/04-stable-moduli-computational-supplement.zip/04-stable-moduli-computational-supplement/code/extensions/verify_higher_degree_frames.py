#!/usr/bin/env python3
"""Exact checks for The Higher-Degree Frame Calculus.

All theorem-level identities checked here use exact SymPy arithmetic.
"""
from __future__ import annotations

import json
import sympy as sp


def assert_zero(expr: sp.Expr, label: str) -> None:
    value = sp.factor(sp.cancel(expr))
    if value != 0:
        raise AssertionError(f"{label} failed: {value}")


x, y, z, T, lam = sp.symbols("x y z T lam")
xi = 1 + x*y
d = 2 - 3*x*y - x**2*z
c = x*d
t = xi/x
r = 2/x
w = sp.expand(c*t)
eps = sp.cancel((w-2)/x)
assert_zero(eps + y + x*z + 3*x*y**2 + x**2*y*z, "epsilon")

# Universal coordinate and Legendre Jacobians.
rr, tt, cc = sp.symbols("rr tt cc")
hfun = sp.Function("h")(tt, cc)
bf = rr - sp.diff(hfun, tt)
af = sp.Rational(1, 2)*(hfun + tt*bf)
J_frame = sp.Matrix([
    [sp.diff(af, tt), sp.diff(af, rr), sp.diff(af, cc)],
    [sp.diff(bf, tt), sp.diff(bf, rr), sp.diff(bf, cc)],
    [0, 0, 1],
]).det()
assert_zero(J_frame-rr/2, "universal frame Jacobian")
J_coord = sp.Matrix([
    [sp.diff(t, x), sp.diff(t, y), sp.diff(t, z)],
    [sp.diff(r, x), sp.diff(r, y), sp.diff(r, z)],
    [sp.diff(c, x), sp.diff(c, y), sp.diff(c, z)],
]).det()
assert_zero(J_coord+2*x, "coordinate Jacobian")

# Base cubic frame.
h3 = T**2*(c*T-2)
b3 = sp.cancel(r-sp.diff(h3, T).subs(T, t))
a3 = sp.cancel((h3.subs(T, t)+t*b3)/2)
for expr, label in [(a3, "a3"), (b3, "b3")]:
    num, den = sp.fraction(expr)
    if sp.factor(den) != 1:
        raise AssertionError(f"{label} denominator: {den}")
assert_zero(sp.Matrix([
    [sp.diff(a3, x), sp.diff(a3, y), sp.diff(a3, z)],
    [sp.diff(b3, x), sp.diff(b3, y), sp.diff(b3, z)],
    [sp.diff(c, x), sp.diff(c, y), sp.diff(c, z)],
]).det()+2, "base determinant")

# Closed all-degree formulas and component degrees.
degree_report = {}
for n in range(4, 13):
    if n % 2 == 0:
        k = n // 2
        h = h3 + lam*c*T**k*(c*T-2)**k
        a_closed = a3 - sp.Rational(1, 2)*lam*d*xi**k*eps**(k-1)*((2*k-1)*w-2*k+2)
        b_closed = b3 - 2*k*lam*x*d*xi**(k-1)*eps**(k-1)*(w-1)
        expected_a = 3*n+4
    else:
        k = (n-1) // 2
        h = h3 + lam*T**k*(c*T-2)**(k+1)
        a_closed = a3 - lam*xi**k*eps**k*(k*w-k+1)
        b_closed = b3 - lam*x*xi**(k-1)*eps**k*((2*k+1)*w-2*k)
        expected_a = 3*n+2
    b = sp.cancel(r-sp.diff(h, T).subs(T, t))
    a = sp.cancel((h.subs(T, t)+t*b)/2)
    assert_zero(a-a_closed, f"closed a degree {n}")
    assert_zero(b-b_closed, f"closed b degree {n}")
    for expr, label in [(a, "a"), (b, "b")]:
        num, den = sp.fraction(expr)
        if sp.factor(den) != 1:
            raise AssertionError(f"degree {n} {label} denominator: {den}")
    da = sp.Poly(sp.expand(a), x, y, z).total_degree()
    db = sp.Poly(sp.expand(b), x, y, z).total_degree()
    if (da, db) != (expected_a, expected_a-1):
        raise AssertionError(f"degree {n}: got {(da,db)}, expected {(expected_a,expected_a-1)}")
    if sp.Poly(h, T).degree() != n:
        raise AssertionError(f"inverse degree {n} failed")
    degree_report[str(n)] = [da, db, 4]

# Quartic formula, leading coefficient, and projective form.
h4 = sp.expand(h3 + lam*c*T**2*(c*T-2)**2)
if sp.factor(sp.Poly(h4, T).LC()-lam*c**3) != 0:
    raise AssertionError("quartic leading coefficient")
s = sp.symbols("s")
P4_hom = sp.expand(s**4*(h4.subs(T, 1/s) + sp.Symbol("bb")/s - 2*sp.Symbol("aa")))
P4_expected = sp.expand(s*(c-2*s)+lam*c*(c-2*s)**2+sp.Symbol("bb")*s**3-2*sp.Symbol("aa")*s**4)
assert_zero(P4_hom-P4_expected, "quartic projective form")

# Finite-degree linear solve: quartic regularity forces H4 divisible by c^3.
C = sp.symbols("C")
unknowns = []
hq = 0
for j, maxk in [(4, 3), (3, 2), (2, 1)]:
    for q in range(maxk+1):
        u = sp.symbols(f"h{j}_{q}")
        unknowns.append(u)
        hq += u*C**q*T**j
bq = sp.together(r-sp.diff(hq, T).subs({T:t, C:c}))
aq = sp.together((hq.subs({T:t, C:c})+t*bq)/2)
conditions = []
for expr in (bq, aq):
    ser = sp.series(expr, x, 0, 1).removeO().expand()
    by_power = {}
    for term in sp.Add.make_args(ser):
        exponent = int(term.as_powers_dict().get(x, 0))
        if exponent < 0:
            by_power[exponent] = by_power.get(exponent, 0) + term/x**exponent
    for coefficient in by_power.values():
        conditions.extend(coef for _, coef in sp.Poly(sp.expand(coefficient), y, z).terms())
M, rhs = sp.linear_eq_to_matrix(conditions, unknowns)
solution = next(iter(sp.linsolve((M, rhs), unknowns)))
sol = dict(zip(unknowns, solution))
for name in ("h4_0", "h4_1", "h4_2", "h3_0"):
    if sp.factor(sol[sp.symbols(name)]) != 0:
        raise AssertionError(f"quartic obstruction {name}")
assert_zero(sol[sp.symbols("h3_1")]-1, "quartic H3 linear jet")
assert_zero(sol[sp.symbols("h2_0")]+2, "quartic H2 constant jet")
jet_relation = sp.symbols("h2_1") + 4*sp.symbols("h3_2") + 12*sp.symbols("h4_3")
assert_zero(jet_relation.subs(sol), "quartic jet relation")

# Negative-weight normal-form generators are individually regular.
for ell in range(1, 5):
    Rw = 1 + w + w**2
    hneg = T**(ell+2)*(c*T-2)**(ell+3)*(1+c*T+(c*T)**2)
    bneg = sp.cancel(-sp.diff(hneg, T).subs(T, t))
    aneg = sp.cancel((hneg.subs(T, t)+t*bneg)/2)
    for expr, label in [(aneg, "a"), (bneg, "b")]:
        _, den = sp.fraction(expr)
        if sp.factor(den) != 1:
            raise AssertionError(f"negative layer ell={ell} {label}: {den}")

report = {
    "status": "ALL HIGHER-DEGREE FRAME CHECKS PASSED",
    "base_component_degrees": [7, 6, 4],
    "checked_generic_degrees": degree_report,
    "quartic_component_degrees": degree_report["4"],
    "quartic_leading_coefficient": "lambda*c^3",
    "normal_form_negative_layers_checked": [1, 2, 3, 4],
}
print(json.dumps(report, indent=2, sort_keys=True))
