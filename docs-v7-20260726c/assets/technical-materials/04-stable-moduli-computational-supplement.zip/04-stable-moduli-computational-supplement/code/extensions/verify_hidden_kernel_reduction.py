#!/usr/bin/env python3
"""Exact checks for the hidden-kernel reduction to the standard cusp."""
import sympy as sp
A,B,a,b,U,T = sp.symbols('A B a b U T', nonzero=True)
p = (3*A*b-B**2)/(3*A**2)
q = (2*B**3-9*A*B*b-54*A**2*a)/(27*A**3)
expr = A*T**3+B*T**2+b*T-2*a
shifted = sp.expand(expr.subs(T, U-B/(3*A))/A)
assert sp.simplify(shifted-(U**3+p*U+q)) == 0
# cubic discriminant: original equals A^4 times discriminant of monic depressed cubic
D_orig = sp.discriminant(expr, T)
D_dep = -4*p**3-27*q**2
assert sp.simplify(D_orig-A**4*D_dep) == 0
print('ALL HIDDEN-KERNEL REDUCTION CHECKS PASSED')
