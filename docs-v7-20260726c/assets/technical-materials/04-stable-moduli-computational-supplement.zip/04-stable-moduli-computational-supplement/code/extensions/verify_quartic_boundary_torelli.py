#!/usr/bin/env python3
"""Exact symbolic checks for Quartic Boundary Torelli."""
from __future__ import annotations

import json
import sympy as sp


def assert_zero(expr: sp.Expr, label: str) -> None:
    val = sp.factor(sp.cancel(expr))
    if val != 0:
        raise AssertionError(f"{label}: {val}")


x, y, z, T = sp.symbols("x y z T")
c, t, a, b = sp.symbols("c t a b")
rho, sigma = sp.symbols("rho sigma")

xi = 1 + x*y
d = 2 - 3*x*y - x**2*z
cx = x*d
tx = xi/x
rx = 2/x

C = c**3
A = c + rho*c**2 + sigma*c**3
B = -2 - (4*rho + 12)*c
h = C*T**4 + A*T**3 + B*T**2

# Frame polynomiality and exact Jacobian.
hx = h.subs(c, cx)
bx = sp.cancel(rx - sp.diff(hx, T).subs(T, tx))
ax = sp.cancel((hx.subs(T, tx) + tx*bx)/2)
for expr, label in ((ax, "a"), (bx, "b")):
    _, den = sp.fraction(expr)
    if sp.factor(den) != 1:
        raise AssertionError(f"{label} denominator: {den}")
J = sp.Matrix([
    [sp.diff(ax, x), sp.diff(ax, y), sp.diff(ax, z)],
    [sp.diff(bx, x), sp.diff(bx, y), sp.diff(bx, z)],
    [sp.diff(cx, x), sp.diff(cx, y), sp.diff(cx, z)],
]).det()
assert_zero(J + 2, "Jacobian")

# Fixed ordinary degrees.
da = sp.Poly(sp.expand(ax), x, y, z).total_degree()
db = sp.Poly(sp.expand(bx), x, y, z).total_degree()
dc = sp.Poly(sp.expand(cx), x, y, z).total_degree()
if (da, db, dc) != (16, 15, 4):
    raise AssertionError(f"degrees: {(da,db,dc)}")

# Marked section x=0.
a0 = sp.expand(ax).subs(x, 0)
b0 = sp.expand(bx).subs(x, 0)
assert_zero(a0 - (z + 4*y**2 + (2*rho+12)*y - 8*sigma), "x=0 a")
assert_zero(b0 - (y + 4*rho + 16), "x=0 b")

# Discriminant and residual component.
P = C*T**4 + A*T**3 + B*T**2 + b*T - 2*a
Delta = sp.factor(sp.discriminant(P, T))
R = sp.cancel(-Delta/c**2)
_, denR = sp.fraction(R)
if sp.factor(denR) != 1:
    raise AssertionError(f"residual discriminant denominator: {denR}")
assert_zero(R.subs(c, 0) - 4*(16*a-b**2), "residual at c=0")

# Repeated-root normalization.
bnu = sp.expand(-(4*C*t**3 + 3*A*t**2 + 2*B*t))
anu = sp.expand((-3*C*t**4 - 2*A*t**3 - B*t**2)/2)
assert_zero(P.subs({T:t, a:anu, b:bnu}), "P on normalization")
assert_zero(sp.diff(P,T).subs({T:t, a:anu, b:bnu}), "P' on normalization")
assert_zero(anu.subs(c,0)-t**2, "M a")
assert_zero(bnu.subs(c,0)-4*t, "M b")

# Universal cusp and double-double factors.
H = sp.expand(6*C*t**2 + 3*A*t + B)
G = sp.expand(8*C**2*t**2 + 4*A*C*t + 4*B*C - A**2)
N = sp.cancel(G/c**2)
_, denN = sp.fraction(N)
if sp.factor(denN) != 1:
    raise AssertionError(f"N denominator: {denN}")
assert_zero(H.subs(c,0)+2, "H at M")
assert_zero(N.subs(c,0)+1, "N at M")

# Pullback of residual-discriminant gradient.
assert_zero(sp.diff(R,a).subs({a:anu,b:bnu}) - 8*H**3*N, "R_a factor")
assert_zero(sp.diff(R,b).subs({a:anu,b:bnu}) + 4*t*H**3*N, "R_b factor")
Cp, Ap, Bp = sp.diff(C,c), sp.diff(A,c), sp.diff(B,c)
assert_zero(
    sp.diff(R,c).subs({a:anu,b:bnu})
    + 4*t**2*(Cp*t**2 + Ap*t + Bp)*H**3*N,
    "R_c factor",
)

# Rigidity coefficient comparison, performed symbolically after the forced
# relations mu=lambda^-2 and kappa=lambda^-1.
lam, rhop, sigmap, h0 = sp.symbols("lam rhop sigmap h0", nonzero=True)
mu = lam**-2
kappa = lam**-1
Cnew = lam*c
Tnew = mu*t + h0
Hp = 6*Cnew**3*Tnew**2 + 3*Cnew*(1+rhop*Cnew+sigmap*Cnew**2)*Tnew - 2 - (4*rhop+12)*Cnew
Horig = 6*c**3*t**2 + 3*c*(1+rho*c+sigma*c**2)*t - 2 - (4*rho+12)*c
rig = sp.Poly(sp.expand(Hp-kappa*Horig), t, c)
# Check that imposing lambda=1, rho'=rho, sigma'=sigma, h0=0 annihilates it.
assert_zero((Hp-kappa*Horig).subs({lam:1,rhop:rho,sigmap:sigma,h0:0}), "rigidity identity")

# Slow cusp branch and Laurent jet.
s = sp.symbols("s")
d3 = 2*rho + sp.Rational(8,3)
d4 = -2*rho**2 - sp.Rational(8,3)*rho + 2*sigma + sp.Rational(80,9)
sbranch = -2*c**2 + d3*c**3 + d4*c**4
Hs = 6*c**3 + 3*c*(1+rho*c+sigma*c**2)*s - (2+(4*rho+12)*c)*s**2
if sp.expand(Hs.subs(s,sbranch)).series(c,0,6).removeO() != 0:
    raise AssertionError("slow branch through order c^5")
laurent = sp.series(1/sbranch, c, 0, 1).removeO()
expected = (
    -sp.Rational(1,2)/c**2
    -(rho/sp.Integer(2)+sp.Rational(2,3))/c
    -(sigma/sp.Integer(2)+2*rho/sp.Integer(3)+sp.Rational(28,9))
)
assert_zero(laurent-expected, "Laurent jet")

report = {
    "status": "ALL QUARTIC BOUNDARY TORELLI CHECKS PASSED",
    "component_degrees": [da, db, dc],
    "generic_degree": 4,
    "parameter_dimension": 2,
    "discriminant_forced_factor": "c^2",
    "marked_intersection": "a=t^2, b=4t, c=0",
    "cusp_equation": str(sp.factor(H)),
    "double_double_equation": str(sp.factor(N)),
    "slow_cusp_laurent_jet": str(expected),
}
print(json.dumps(report, indent=2, sort_keys=True))
