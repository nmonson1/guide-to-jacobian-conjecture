#!/usr/bin/env python3
"""Exact checks for the cubic completion/conductor note."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sympy as sp

parser = argparse.ArgumentParser()
parser.add_argument("--output", type=Path)
args = parser.parse_args()

A, B, a, b, t = sp.symbols("A B a b t")
rho, sigma = sp.symbols("rho sigma")
H = 3*A*t + B
bpar = -3*A*t**2 - 2*B*t
apar = -A*t**3 - sp.Rational(1,2)*B*t**2

checks = {}
checks["H2_recovery"] = sp.expand((B**2 - 3*A*bpar) - H**2) == 0
checks["tH2_recovery"] = sp.expand((-18*A*apar - B*bpar) - 2*t*H**2) == 0
checks["H3_in_ring"] = sp.expand(3*A*t*H**2 + B*H**2 - H**3) == 0

# Two equations used to build the monic quadratic for t.
eq1 = 3*A*t**2 + 2*B*t + b
eq2 = B*t**2 + 2*b*t - 6*a
checks["root_relation_1_on_normalization"] = sp.expand(eq1.subs({a:apar,b:bpar})) == 0
checks["root_relation_2_on_normalization"] = sp.expand(eq2.subs({a:apar,b:bpar})) == 0
# Formal Bezout coefficients satisfy rho*A+sigma*B=1.  Verify the t^2 coefficient.
bezout_combo = sp.expand(sp.Rational(1,3)*rho*eq1 + sigma*eq2)
checks["monic_coefficient_under_bezout"] = sp.expand(bezout_combo.coeff(t,2) - (rho*A + sigma*B)) == 0

bH = (B**2-H**2)/(3*A)
aH = (-B**3+3*B*H**2-2*H**3)/(54*A**2)
checks["b_cusp_coordinate"] = sp.simplify(bH.subs(H,3*A*t+B) - bpar) == 0
checks["a_cusp_coordinate"] = sp.simplify(aH.subs(H,3*A*t+B) - apar) == 0

# Universal cubic discriminant and its pullback.
Delta = B**2*b**2 - 4*A*b**3 + 8*B**3*a - 108*A**2*a**2 - 36*A*B*a*b
checks["discriminant_pullback"] = sp.expand(Delta.subs({a:apar,b:bpar})) == 0
checks["grad_a"] = sp.expand(sp.diff(Delta,a).subs({a:apar,b:bpar}) - 8*H**3) == 0
checks["grad_b"] = sp.expand(sp.diff(Delta,b).subs({a:apar,b:bpar}) + 4*t*H**3) == 0

# Weighted action consistency in the canonical chart.
c, lam = sp.symbols("c lam")
q1,q2,r0,r1 = sp.symbols("q1 q2 r0 r1")
Q = 1+q1*c+q2*c**2
R = r0+r1*c
Bcan = -2-4*q1*c+c**2*R
Qscaled = sp.expand(Q.subs(c,lam*c))
Bscaled = sp.expand(Bcan.subs(c,lam*c))
Qweights = 1+(lam*q1)*c+(lam**2*q2)*c**2
Bweights = -2-4*(lam*q1)*c+c**2*((lam**2*r0)+(lam**3*r1)*c)
checks["weighted_Q"] = sp.expand(Qscaled-Qweights) == 0
checks["weighted_B"] = sp.expand(Bscaled-Bweights) == 0

# First-order LR identity: dF W = V o F, encoded abstractly as J*J^{-1}V=V.
j11,j12,j21,j22,v1,v2 = sp.symbols("j11 j12 j21 j22 v1 v2")
J=sp.Matrix([[j11,j12],[j21,j22]])
V=sp.Matrix([v1,v2])
checks["dual_number_lift"] = sp.simplify(J*(J.inv()*V)-V) == sp.zeros(2,1)

ok = all(checks.values())
report = {"all_passed": ok, "checks": checks}
if args.output is not None:
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError(f"refusing to overwrite {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, default=bool))
print("ALL TRIPLE-COVER/CONDUCTOR CHECKS PASSED" if ok else "CHECK FAILURE")
if not ok:
    raise SystemExit(1)
