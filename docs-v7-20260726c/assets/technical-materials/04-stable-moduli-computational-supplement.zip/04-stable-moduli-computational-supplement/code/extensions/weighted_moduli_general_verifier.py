#!/usr/bin/env python3
"""Exact symbolic checks supporting the weighted-lift moduli theorem.

The geometric proof (normalization and ramification-divisor argument) is in
the accompanying report.  This script checks the explicit quartic seed
family, the polynomial normalization formula, the critical-root invariants,
and their generic algebraic independence.
"""
import sympy as sp
w,u,zeta,C,D,k,lam=sp.symbols('w u zeta C D k lam', nonzero=True)
a=2+C/sp.Integer(2)+4*D/sp.Integer(5)
b=-3-3*C/sp.Integer(2)-9*D/sp.Integer(5)
p=sp.expand(a*w+b*w**2+C*w**3+D*w**4)
Phi=sp.integrate(p,w)
q=sp.expand(w*p-Phi)
assert p.subs(w,0)==0
assert sp.factor(p.subs(w,1))==-1
assert sp.factor(Phi.subs(w,1))==0
assert sp.factor(sp.diff(q,w)-w*sp.diff(p,w))==0
# Wall-surface normalization map: (u,zeta)->(q(zeta*u)/zeta^2,p(zeta*u)/zeta,zeta).
Bn=sp.cancel(p.subs(w,zeta*u)/zeta)
An=sp.cancel(q.subs(w,zeta*u)/zeta**2)
assert sp.denom(Bn)==1 and sp.denom(An)==1
assert sp.factor(sp.diff(Bn,u)-sp.diff(p,w).subs(w,zeta*u))==0
assert sp.factor(sp.diff(An,u)-u*sp.diff(p,w).subs(w,zeta*u))==0
# Cubic p' root-configuration invariants under scalar multiplication and w scaling.
f=sp.diff(p,w)
A3=4*D; B2=3*C; C1=2*b; D0=a
I=sp.factor(B2*C1/(A3*D0))
J=sp.factor(B2**3/(A3**2*D0))
Jac=sp.factor(sp.det(sp.Matrix([[sp.diff(I,C),sp.diff(I,D)],[sp.diff(J,C),sp.diff(J,D)]])))
assert Jac != 0
# Verify invariance under f(w)->k*f(w/lam).
Ap=k*A3/lam**3; Bp=k*B2/lam**2; Cp=k*C1/lam; Dp=k*D0
assert sp.factor(Bp*Cp/(Ap*Dp)-I)==0
assert sp.factor(Bp**3/(Ap**2*Dp)-J)==0
# One point in the required generic open set.
w0={C:1,D:1}
p0=sp.Poly(p.subs(w0),w,domain=sp.QQ)
q0=sp.Poly(q.subs(w0),w,domain=sp.QQ)
f0=sp.Poly(f.subs(w0),w,domain=sp.QQ)
assert sp.gcd(p0,q0)==sp.Poly(w,w,domain=sp.QQ)
assert sp.gcd(f0,sp.diff(f0.as_expr(),w))==1
assert f0.eval(0)!=0
assert sp.diff(p,w).subs(w0).subs(w,1)!=-2
print('seed p(C,D) =',p)
print('q(C,D) =',q)
print('normalization B(u,zeta) =',sp.factor(Bn))
print('normalization A(u,zeta) =',sp.factor(An))
print('I(C,D) =',I)
print('J(C,D) =',J)
print('det d(I,J)/d(C,D) =',Jac)
print('generic-open witness: C=1,D=1')
print('RESULT: the quartic-seed invariant map has generic rank 2.')
