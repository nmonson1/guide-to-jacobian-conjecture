#!/usr/bin/env python3
"""Exact certificates for conductor and marked-arrangement results in the cubic frame."""
from __future__ import annotations

import json
from pathlib import Path
import sympy as sp

# ---------------------------------------------------------------------------
# 1. Universal discriminant-normalization and conductor identities.
# ---------------------------------------------------------------------------
a, b, t, u, v = sp.symbols("a b t u v")
H = 3*a*t + b
vnu = -3*a*t**2 - 2*b*t
unu = -a*t**3 - sp.Rational(1, 2)*b*t**2
Delta = b**2*v**2 - 4*a*v**3 + 8*b**3*u - 108*a**2*u**2 - 36*a*b*u*v

assert sp.expand(Delta.subs({u: unu, v: vnu})) == 0
assert sp.expand((b**2 - 3*a*v).subs(v, vnu) - H**2) == 0
assert sp.expand((-18*a*u - b*v).subs({u: unu, v: vnu}) - 2*t*H**2) == 0

# At the generic point of H=0, the discriminant ring is the cusp ring k[H^2,H^3].
h = sp.symbols("h")
t_of_h = (h-b)/(3*a)
u_of_h = sp.factor(-a*t_of_h**3 - sp.Rational(1, 2)*b*t_of_h**2)
v_of_h = sp.factor(-3*a*t_of_h**2 - 2*b*t_of_h)
assert sp.factor(v_of_h - (b**2-h**2)/(3*a)) == 0
assert sp.factor(u_of_h + b**3/(54*a**2) - b*h**2/(18*a**2) + h**3/(27*a**2)) == 0

# ---------------------------------------------------------------------------
# 2. The normalized q-family: explicit map, determinant, collision, geometry.
# ---------------------------------------------------------------------------
x, y, z, q = sp.symbols("x y z q")
T = sp.symbols("T")
source_t = y + 1/x
source_c = 2*x - 3*x**2*y - x**3*z
Aq = source_c*(source_c + 1)
Bq = q*source_c**2 - 4*source_c - 2
hq = Aq*T**3 + Bq*T**2
Gq_b = sp.expand(sp.cancel(2/x - sp.diff(hq, T).subs(T, source_t)))
Gq_a = sp.expand(sp.cancel((hq.subs(T, source_t) + source_t*Gq_b)/2))
Gq_c = sp.expand(source_c)
Gq = sp.Matrix([Gq_a, Gq_b, Gq_c])
assert sp.factor(Gq.jacobian((x, y, z)).det() + 2) == 0
assert [sp.Poly(e, x, y, z).total_degree() for e in Gq] == [11, 10, 4]

# Uniform three-point collision above (-1/4,0,0).
collision_points = [
    (1, sp.Rational(-3, 2), sp.Rational(13, 2)),
    (-1, sp.Rational(3, 2), sp.Rational(13, 2)),
    (0, -4, 2*q - sp.Rational(225, 4)),
]
for px, py, pz in collision_points:
    vals = [sp.factor(e.subs({x: px, y: py, z: pz})) for e in Gq]
    assert vals == [sp.Rational(-1, 4), 0, 0]

# Target discriminant and conductor data.
c, U, V = sp.symbols("c U V")
A = c*(c+1)
B = q*c**2 - 4*c - 2
Delta_q = sp.expand(B**2*V**2 - 4*A*V**3 + 8*B**3*U - 108*A**2*U**2 - 36*A*B*U*V)
Hq = sp.expand(3*A*t + B)
Vnu = sp.expand(-3*A*t**2 - 2*B*t)
Unu = sp.expand(-A*t**3 - sp.Rational(1, 2)*B*t**2)
assert sp.factor(Delta_q.subs({U: Unu, V: Vnu})) == 0
assert sp.factor((B**2-3*A*V).subs(V, Vnu) - Hq**2) == 0
assert sp.factor((-18*A*U-B*V).subs({U: Unu, V: Vnu}) - 2*t*Hq**2) == 0
assert sp.factor(sp.discriminant(Delta_q, U) + 64*(3*A*V-B**2)**3) == 0

# Tangent slopes of the conductor closure at the two roots of A.
slope_0 = sp.factor(-3*sp.diff(A, c).subs(c, 0)/B.subs(c, 0))
slope_m1 = sp.factor(-3*sp.diff(A, c).subs(c, -1)/B.subs(c, -1))
assert slope_0 == sp.Rational(3, 2)
assert slope_m1 == 3/(q+2)
assert sp.factor(2*slope_0/slope_m1 - 2 - q) == 0

# q=-2: residual discriminant is irreducible over C(c,V), certified by non-square u-discriminant.
Delta_m2 = sp.factor(Delta_q.subs(q, -2))
assert sp.rem(Delta_m2, c+1, c) == 0
Delta_res_m2 = sp.factor(Delta_m2/(c+1))
disc_res_u = sp.factor(sp.discriminant(Delta_res_m2, U))
assert sp.factor(disc_res_u + 64*(c+1)*(3*c*V-4*(c+1)**3)**3) == 0
assert sp.factor(Delta_res_m2.subs(c, -1) - 4*V**3) == 0
for var in (U, V, c):
    assert sp.factor(sp.diff(Delta_res_m2, var).subs({c: -1, U: 0, V: 0})) == 0

# ---------------------------------------------------------------------------
# 3. General cylinder-arrangement coefficient identities.
# ---------------------------------------------------------------------------
c, tp = sp.symbols("c tp")
lam, mu0, nu, kap = sp.symbols("lam mu0 nu kap", nonzero=True)
# Abstract coefficient comparison is represented with symbolic polynomials A0,B0,A1,B1.
# The theorem's equations are checked on a generic concrete degree-three instance below.

# ---------------------------------------------------------------------------
# 4. Explicit three-parameter degree-15 family (degree(A)=3).
# ---------------------------------------------------------------------------
s, d1, d2 = sp.symbols("s d1 d2", nonzero=True)
A3 = sp.expand(c*(c+1)*(c+s)/s)  # roots 0,-1,-s and A3'(0)=1
b2 = sp.factor((d1*s**3 - d2 - 2*s**3 - 4*s**2 + 4*s + 2)/(s**2*(s-1)))
b3 = sp.factor((d1*s**2 - d2 - 2*s**2 + 2)/(s**2*(s-1)))
B3 = sp.expand(-2 - 4*(s+1)/s*c + b2*c**2 + b3*c**3)
assert sp.factor(A3.subs(c, 0)) == 0
assert sp.factor(sp.diff(A3, c).subs(c, 0) - 1) == 0
assert sp.factor(B3.subs(c, 0) + 2) == 0
assert sp.factor(sp.diff(B3, c).subs(c, 0) + 2*sp.diff(A3, c, 2).subs(c, 0)) == 0
assert sp.factor(B3.subs(c, -1) - d1) == 0
assert sp.factor(B3.subs(c, -s) - d2) == 0

# Involution swapping the two missing roots: (s,d1,d2) -> (1/s,d2,d1).
s2 = 1/s
A3_swap = sp.factor(A3.subs(s, s2).subs(c, c/s))
# The coefficient polynomial transforms up to the scalar required by t-scaling.
assert sp.factor(A3_swap - A3/s) == 0
B3_swap = sp.factor(B3.subs({s: s2, d1: d2, d2: d1}, simultaneous=True).subs(c, c/s))
assert sp.factor(B3_swap - B3) == 0

# Build a numerical-symbolic specialization to certify polynomiality, determinant and degree 15.
# Keeping s,d1,d2 symbolic makes a direct determinant unnecessarily large; this exact generic
# specialization lies off every excluded divisor and verifies the degree pattern independently.
subs_generic = {s: sp.Rational(2), d1: sp.Rational(3), d2: sp.Rational(5)}
A3g = sp.factor(A3.subs(subs_generic))
B3g = sp.factor(B3.subs(subs_generic))
xx, yy, zz = sp.symbols("xx yy zz")
tt = yy + 1/xx
cc = 2*xx - 3*xx**2*yy - xx**3*zz
h3 = A3g.subs(c, cc)*T**3 + B3g.subs(c, cc)*T**2
bmap3 = sp.expand(sp.cancel(2/xx - sp.diff(h3, T).subs(T, tt)))
amap3 = sp.expand(sp.cancel((h3.subs(T, tt)+tt*bmap3)/2))
cmap3 = sp.expand(cc)
assert all(not sp.denom(e).has(xx, yy, zz) for e in (amap3, bmap3, cmap3))
assert [sp.Poly(e, xx, yy, zz).total_degree() for e in (amap3, bmap3, cmap3)] == [15, 14, 4]
assert sp.factor(sp.Matrix([amap3, bmap3, cmap3]).jacobian((xx, yy, zz)).det() + 2) == 0


# Exact map-level realization of the involution at the same generic specialization.
A3g_swap = sp.factor(A3.subs({s: sp.Rational(1,2), d1: sp.Rational(5), d2: sp.Rational(3)}))
B3g_swap = sp.factor(B3.subs({s: sp.Rational(1,2), d1: sp.Rational(5), d2: sp.Rational(3)}))
h3_swap = A3g_swap.subs(c, cc)*T**3 + B3g_swap.subs(c, cc)*T**2
bmap3_swap = sp.expand(sp.cancel(2/xx - sp.diff(h3_swap, T).subs(T, tt)))
amap3_swap = sp.expand(sp.cancel((h3_swap.subs(T, tt)+tt*bmap3_swap)/2))
F3_swap = sp.Matrix([amap3_swap, bmap3_swap, cmap3])
scale = sp.Rational(2)
sigma_sub = {xx: xx/scale, yy: scale*yy, zz: scale**2*zz}
lhs_swap = sp.Matrix([sp.expand(sp.cancel(e.subs(sigma_sub, simultaneous=True))) for e in F3_swap])
rhs_swap = sp.Matrix([scale**2*amap3, scale*bmap3, cmap3/scale])
for i in range(3):
    assert sp.factor(lhs_swap[i]-rhs_swap[i]) == 0

# ---------------------------------------------------------------------------
# 5. Machine-readable audit.
# ---------------------------------------------------------------------------
out = {
    "universal_conductor": {
        "H": str(H),
        "H_squared_in_discriminant_ring": "b^2 - 3*a*v",
        "t_H_squared_in_discriminant_ring": "(-18*a*u - b*v)/2",
        "conductor_in_normalization": "(H^2)",
        "conductor_in_discriminant_ring_generators": [
            "b^2 - 3*a*v",
            "-18*a*u - b*v",
        ],
    },
    "q_family": {
        "degrees": [11, 10, 4],
        "collision_target": ["-1/4", "0", "0"],
        "collision_points": [[str(a) for a in p] for p in collision_points],
        "A": str(A),
        "B": str(B),
        "Delta": str(Delta_q),
        "H": str(Hq),
        "tangent_slopes": {"c=0": str(slope_0), "c=-1": str(slope_m1)},
        "intrinsic_formula": "q = 2*(slope_at_0/slope_at_-1) - 2",
        "q_minus_2_residual_u_discriminant": str(disc_res_u),
    },
    "degree_15_family": {
        "A_s": str(A3),
        "B_s_d1_d2": str(B3),
        "parameters": ["s", "d1", "d2"],
        "excluded": ["s=0", "s=1", "d1=0", "d2=0"],
        "finite_identification": "(s,d1,d2) ~ (1/s,d2,d1)",
        "degrees": [15, 14, 4],
    },
}
path = Path(__file__).with_name("data")
path.mkdir(exist_ok=True)
(path / "conductor_arrangements.json").write_text(json.dumps(out, indent=2)+"\n")
print("ALL CONDUCTOR/ARRANGEMENT CHECKS PASSED")
