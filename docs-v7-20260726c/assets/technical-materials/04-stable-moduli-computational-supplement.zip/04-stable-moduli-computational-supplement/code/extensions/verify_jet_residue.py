#!/usr/bin/env python3
"""Exact checks for Jet Residues at Infinity and Collision Moduli.

Requires SymPy >= 1.12.  All assertions are symbolic over QQ.
"""
from __future__ import annotations

import json
import sympy as sp


def assert_zero(expr: sp.Expr, label: str) -> None:
    value = sp.factor(sp.together(expr))
    if value != 0:
        raise AssertionError(f"{label} failed: {value}")


# 1. Universal cubic discriminant and normalization.
a, b, A, B, t, Ap, Bp = sp.symbols("a b A B t Ap Bp")
Delta = B**2*b**2 - 4*A*b**3 + 8*B**3*a - 108*A**2*a**2 - 36*A*B*a*b
an = -A*t**3 - sp.Rational(1, 2)*B*t**2
bn = -3*A*t**2 - 2*B*t
H = 3*A*t + B
assert_zero(Delta.subs({a: an, b: bn}), "normalization")
assert_zero(B**2 - 3*A*bn - H**2, "recovery 1")
assert_zero(-18*A*an - B*bn - 2*t*H**2, "recovery 2")
assert_zero(sp.diff(Delta, a).subs({a: an, b: bn}) - 8*H**3, "gradient a")
assert_zero(sp.diff(Delta, b).subs({a: an, b: bn}) + 4*t*H**3, "gradient b")
Dc = sp.diff(Delta, A)*Ap + sp.diff(Delta, B)*Bp
assert_zero(Dc.subs({a: an, b: bn}) + 4*t**2*(Ap*t+Bp)*H**3, "gradient c")
assert_zero(sp.discriminant(Delta, a) - 64*(B**2-3*A*b)**3, "disc in a")


# 2. Universal frame Jacobian.
r, c = sp.symbols("r c")
h = sp.Function("h")(t, c)
bf = r - sp.diff(h, t)
af = sp.Rational(1, 2)*(h+t*bf)
Jf = sp.Matrix([
    [sp.diff(af, t), sp.diff(af, r), sp.diff(af, c)],
    [sp.diff(bf, t), sp.diff(bf, r), sp.diff(bf, c)],
    [0, 0, 1],
]).det()
assert_zero(Jf-r/2, "frame Jacobian")

x, y, z = sp.symbols("x y z")
T = y+1/x
R = 2/x
C = 2*x-3*x**2*y-x**3*z
Jc = sp.Matrix([
    [sp.diff(T, x), sp.diff(T, y), sp.diff(T, z)],
    [sp.diff(R, x), sp.diff(R, y), sp.diff(R, z)],
    [sp.diff(C, x), sp.diff(C, y), sp.diff(C, z)],
]).det()
assert_zero(Jc+2*x, "coordinate Jacobian")
assert_zero((R/2)*Jc+2, "total Jacobian")


# 3. Polynomiality and retained infinity section for generic quintic data.
a2, a3, a4, a5 = sp.symbols("a2 a3 a4 a5")
b2, b3, b4, b5 = sp.symbols("b2 b3 b4 b5")
AA = C+a2*C**2+a3*C**3+a4*C**4+a5*C**5
BB = -2-4*a2*C+b2*C**2+b3*C**3+b4*C**4+b5*C**5
sroot = sp.symbols("sroot")
hpoly = AA*T**3+BB*T**2
bpoly = sp.cancel(R-sp.diff(AA*sroot**3+BB*sroot**2, sroot).subs(sroot, T))
apoly = sp.cancel(sp.Rational(1, 2)*(hpoly+T*bpoly))
for expr, label in [(apoly, "a polynomial"), (bpoly, "b polynomial")]:
    num, den = sp.fraction(sp.cancel(expr))
    if sp.factor(den) != 1:
        raise AssertionError(f"{label}: denominator {sp.factor(den)}")
    sp.Poly(sp.expand(num), x, y, z)
assert_zero(sp.expand(bpoly).subs(x, 0)-(y+4*a2), "marked b")
assert_zero(sp.expand(apoly).subs(x, 0)-(z+4*y**2+2*a2*y-2*b2-8*a3), "marked a")


# 4. Tschirnhaus gauge identity.
AA0, BB0, phi, tt, rr = sp.symbols("AA0 BB0 phi tt rr")
h0 = AA0*tt**3+BB0*tt**2
b0 = rr-sp.diff(h0, tt)
a0 = sp.Rational(1, 2)*(h0+tt*b0)
hshift = AA0*(tt+phi)**3+BB0*(tt+phi)**2
bshift = rr-sp.diff(AA0*sroot**3+BB0*sroot**2, sroot).subs(sroot, tt+phi)
ashift = sp.Rational(1, 2)*(hshift+(tt+phi)*bshift)
Bnew = BB0+3*AA0*phi
hnew = AA0*tt**3+Bnew*tt**2
bnew = rr-sp.diff(hnew, tt)
anew = sp.Rational(1, 2)*(hnew+tt*bnew)
Lphi = 3*AA0*phi**2+2*BB0*phi
Kphi = AA0*phi**3+BB0*phi**2
assert_zero(bshift+Lphi-bnew, "gauge b")
assert_zero(ashift-phi*bshift/2-Kphi/2-anew, "gauge a")


# 5. Weighted universal action.
lam, cc = sp.symbols("lam cc", nonzero=True)
q1, q2, q3 = sp.symbols("q1 q2 q3")
r0, r1, r2 = sp.symbols("r0 r1 r2")
Q = 1+q1*cc+q2*cc**2+q3*cc**3
Rpoly = r0+r1*cc+r2*cc**2
Auniv = cc*Q
Buniv = -2-4*q1*cc+cc**2*Rpoly
Qact = Q.subs(cc, lam*cc)
Ract = lam**2*Rpoly.subs(cc, lam*cc)
Bact = -2-4*(lam*q1)*cc+cc**2*Ract
assert_zero(Bact-Buniv.subs(cc, lam*cc), "weighted B action")
assert_zero(cc*Qact-Auniv.subs(cc, lam*cc)/lam, "weighted A normalization")


# 6. Double-point jet family.
s, u = sp.symbols("s u")
A2 = sp.expand(cc*(1-cc)**2)
B2 = -2+8*cc+s*cc**2+u*cc**3
assert_zero(A2.subs(cc, 0), "A2(0)")
assert_zero(sp.diff(A2, cc).subs(cc, 0)-1, "A2'(0)")
assert_zero(B2.subs(cc, 0)+2, "B2(0)")
assert_zero(sp.diff(B2, cc).subs(cc, 0)+2*sp.diff(A2, cc, 2).subs(cc, 0), "B2'(0)")
assert_zero(B2.subs(cc, 1)-(6+s+u), "double value")
assert_zero(sp.diff(B2, cc).subs(cc, 1)-(8+2*s+3*u), "double derivative")
eps = sp.symbols("eps")
tau2 = sp.series((-B2/(3*A2)).subs(cc, 1+eps), eps, 0, 1).removeO()
expected_tau2 = -(6+s+u)/(3*eps**2) - (2+s+2*u)/(3*eps) + sp.Rational(2, 3)-u/3
assert_zero(tau2-expected_tau2, "double principal part")


# 7. Collision of two values into a first jet.
hcol, v, w = sp.symbols("hcol v w")
Scol = v+w*(cc-1)
assert_zero(Scol.subs(cc, 1)-v, "collision first value")
assert_zero(Scol.subs(cc, 1+hcol)-(v+hcol*w), "collision second value")


# 8. Sample discriminant-content checks.
d = sp.symbols("d")
for m, n in [(1, 1), (1, 2), (2, 1), (3, 1), (3, 2), (4, 3)]:
    Aloc = d**m
    Bloc = d**n
    Dloc = sp.expand(Delta.subs({A: Aloc, B: Bloc}))
    poly = sp.Poly(Dloc, d, a, b)
    min_d = min(mon[0] for mon, coeff in poly.terms() if coeff != 0)
    if min_d != min(m, 2*n):
        raise AssertionError(f"content order {(m,n)}: {min_d}")


report = {
    "status": "ALL JET-RESIDUE CHECKS PASSED",
    "double_point_A": str(A2),
    "double_point_B": str(B2),
    "double_point_unit_condition": "6+s+u != 0",
    "double_point_component_degrees": [15, 14, 4],
    "weighted_q_weights_N3": [1, 2, 3],
    "weighted_r_weights_N3": [2, 3, 4],
}
print(json.dumps(report, indent=2, sort_keys=True))
