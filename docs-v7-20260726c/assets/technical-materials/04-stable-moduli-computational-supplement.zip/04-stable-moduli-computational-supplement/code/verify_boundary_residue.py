#!/usr/bin/env python3
"""Exact symbolic checks for the cubic-frame boundary-residue extension.

Requires SymPy >= 1.12.  Every assertion is over QQ with symbolic parameters.
"""
from __future__ import annotations

import json
import sympy as sp


def assert_zero(expr: sp.Expr, label: str) -> None:
    value = sp.factor(sp.together(expr))
    if value != 0:
        raise AssertionError(f"{label} failed: {value}")


# ---------------------------------------------------------------------------
# 1. Universal cubic discriminant, normalization, singular-locus identities.
# ---------------------------------------------------------------------------
a, b, A, B, t, Ap, Bp = sp.symbols("a b A B t Ap Bp")
Delta = (
    B**2 * b**2
    - 4 * A * b**3
    + 8 * B**3 * a
    - 108 * A**2 * a**2
    - 36 * A * B * a * b
)

a_nu = -A * t**3 - sp.Rational(1, 2) * B * t**2
b_nu = -3 * A * t**2 - 2 * B * t
H = 3 * A * t + B

assert_zero(Delta.subs({a: a_nu, b: b_nu}), "normalization lies on discriminant")
assert_zero(B**2 - 3 * A * b_nu - H**2, "first recovery identity")
assert_zero(-18 * A * a_nu - B * b_nu - 2 * t * H**2, "second recovery identity")
assert_zero(sp.diff(Delta, a).subs({a: a_nu, b: b_nu}) - 8 * H**3, "Delta_a pullback")
assert_zero(sp.diff(Delta, b).subs({a: a_nu, b: b_nu}) + 4 * t * H**3, "Delta_b pullback")
Dc = sp.diff(Delta, A) * Ap + sp.diff(Delta, B) * Bp
assert_zero(
    Dc.subs({a: a_nu, b: b_nu}) + 4 * t**2 * (Ap * t + Bp) * H**3,
    "Delta_c pullback",
)
assert_zero(sp.discriminant(Delta, a) - 64 * (B**2 - 3 * A * b) ** 3, "quadratic discriminant")


# ---------------------------------------------------------------------------
# 2. Universal frame Jacobian.
# ---------------------------------------------------------------------------
r, c = sp.symbols("r c")
h = sp.Function("h")(t, c)
h_t = sp.diff(h, t)
b_frame = r - h_t
a_frame = sp.Rational(1, 2) * (h + t * b_frame)
J_frame = sp.Matrix(
    [
        [sp.diff(a_frame, t), sp.diff(a_frame, r), sp.diff(a_frame, c)],
        [sp.diff(b_frame, t), sp.diff(b_frame, r), sp.diff(b_frame, c)],
        [0, 0, 1],
    ]
).det()
assert_zero(J_frame - r / 2, "frame Jacobian")

x, y, z = sp.symbols("x y z")
t_xyz = y + 1 / x
r_xyz = 2 / x
c_xyz = 2 * x - 3 * x**2 * y - x**3 * z
J_coords = sp.Matrix(
    [
        [sp.diff(t_xyz, x), sp.diff(t_xyz, y), sp.diff(t_xyz, z)],
        [sp.diff(r_xyz, x), sp.diff(r_xyz, y), sp.diff(r_xyz, z)],
        [sp.diff(c_xyz, x), sp.diff(c_xyz, y), sp.diff(c_xyz, z)],
    ]
).det()
assert_zero(J_coords + 2 * x, "coordinate Jacobian")
assert_zero((r_xyz / 2) * J_coords + 2, "total Jacobian")


# ---------------------------------------------------------------------------
# 3. Polynomiality for a generic quartic admissible pair.
# ---------------------------------------------------------------------------
a2, a3, a4, b2, b3, b4 = sp.symbols("a2 a3 a4 b2 b3 b4")
C = c_xyz
T = t_xyz
Apoly = C + a2 * C**2 + a3 * C**3 + a4 * C**4
Bpoly = -2 - 4 * a2 * C + b2 * C**2 + b3 * C**3 + b4 * C**4
hpoly = Apoly * T**3 + Bpoly * T**2
bpoly = sp.cancel(r_xyz - sp.diff(Apoly * sp.Symbol("T")**3 + Bpoly * sp.Symbol("T")**2, sp.Symbol("T")).subs(sp.Symbol("T"), T))
apoly = sp.cancel(sp.Rational(1, 2) * (hpoly + T * bpoly))
for expr, label in [(apoly, "a polynomial"), (bpoly, "b polynomial")]:
    num, den = sp.fraction(sp.cancel(expr))
    if sp.factor(den) != 1:
        raise AssertionError(f"{label} failed: denominator {sp.factor(den)}")
    sp.Poly(sp.expand(num), x, y, z)

# Marked infinity section x=0.
a_x0 = sp.expand(apoly).subs(x, 0)
b_x0 = sp.expand(bpoly).subs(x, 0)
assert_zero(b_x0 - (y + 4 * a2), "marked infinity b-coordinate")
assert_zero(a_x0 - (z + 4 * y**2 + 2 * a2 * y - 2 * b2 - 8 * a3), "marked infinity a-coordinate")


# ---------------------------------------------------------------------------
# 4. Root-translation/Tschirnhaus gauge identity.
# ---------------------------------------------------------------------------
AA, BB, phi, tt, rr = sp.symbols("AA BB phi tt rr")
h0 = AA * tt**3 + BB * tt**2
b0 = rr - sp.diff(h0, tt)
a0 = sp.Rational(1, 2) * (h0 + tt * b0)

# Evaluate the old frame at the shifted root tt+phi.
h_shift = AA * (tt + phi) ** 3 + BB * (tt + phi) ** 2
b_shift = rr - sp.diff(AA * sp.Symbol("s")**3 + BB * sp.Symbol("s")**2, sp.Symbol("s")).subs(sp.Symbol("s"), tt + phi)
a_shift = sp.Rational(1, 2) * (h_shift + (tt + phi) * b_shift)

Bnew = BB + 3 * AA * phi
hnew = AA * tt**3 + Bnew * tt**2
bnew = rr - sp.diff(hnew, tt)
anew = sp.Rational(1, 2) * (hnew + tt * bnew)
L = 3 * AA * phi**2 + 2 * BB * phi
K = AA * phi**3 + BB * phi**2
assert_zero((b_shift + L) - bnew, "target b-shear")
assert_zero((a_shift - phi * b_shift / 2 - K / 2) - anew, "target a-shear")


# ---------------------------------------------------------------------------
# 5. Explicit three-parameter example: roots 1,2,4.
# ---------------------------------------------------------------------------
cc = sp.symbols("c")
v1, v2, v3 = sp.symbols("v1 v2 v3")
A3 = sp.expand(-sp.Rational(1, 8) * cc * (cc - 1) * (cc - 2) * (cc - 4))
coeffs = sp.symbols("q0:5")
Btrial = sum(coeffs[i] * cc**i for i in range(5))
solution = sp.solve(
    [
        sp.Eq(Btrial.subs(cc, 0), -2),
        sp.Eq(sp.diff(Btrial, cc).subs(cc, 0), -2 * sp.diff(A3, cc, 2).subs(cc, 0)),
        sp.Eq(Btrial.subs(cc, 1), v1),
        sp.Eq(Btrial.subs(cc, 2), v2),
        sp.Eq(Btrial.subs(cc, 4), v3),
    ],
    coeffs,
    dict=True,
)[0]
B3 = sp.expand(Btrial.subs(solution))
assert_zero(A3.subs(cc, 0), "A3(0)")
assert_zero(sp.diff(A3, cc).subs(cc, 0) - 1, "A3'(0)")
assert_zero(B3.subs(cc, 0) + 2, "B3(0)")
assert_zero(sp.diff(B3, cc).subs(cc, 0) + 2 * sp.diff(A3, cc, 2).subs(cc, 0), "B3'(0)")
assert_zero(B3.subs(cc, 1) - v1, "B3(1)")
assert_zero(B3.subs(cc, 2) - v2, "B3(2)")
assert_zero(B3.subs(cc, 4) - v3, "B3(4)")

report = {
    "status": "ALL BOUNDARY-RESIDUE CHECKS PASSED",
    "explicit_A3": str(A3),
    "explicit_B3": str(B3),
    "generic_component_degrees_for_deg_A_d": ["4d+3", "4d+2", "4"],
    "three_parameter_example_component_degrees": [19, 18, 4],
}
print(json.dumps(report, indent=2, sort_keys=True))
