import sympy as s
w,P,Q,A,B,C=s.symbols('w P Q A B C')
D=s.Rational(1); cc=s.Rational(0)
a=cc/s.Integer(2)+4*D/s.Integer(5)+2
b=-3*cc/s.Integer(2)-9*D/s.Integer(5)-3
p=s.expand(a*w+b*w**2+cc*w**3+D*w**4)
Phi=s.integrate(p,w)
q=s.expand(w*p-Phi)
print('p',p,'q',q,'p1',p.subs(w,1),'int',Phi.subs(w,1))
f=s.factor(s.resultant(P-p,Q-q,w));print('implicit factor',f)
print('degree',s.Poly(f,P,Q).total_degree(), 'terms',len(s.Poly(f,P,Q).terms()))
sub=s.factor(f.subs({P:B*C,Q:A*C**2}));print('subfactor',sub)
# strip C
poly=s.Poly(sub,A,B,C); mn=min(e[2] for e,c in poly.terms()); g=s.factor(sub/C**mn);print('Cpower',mn,'g',g)
print('g degree',s.Poly(g,A,B,C).total_degree(),'terms',len(s.Poly(g,A,B,C).terms()))
# singular ideal partial derivatives factor/groebner maybe
partials=[s.factor(s.diff(g,v)) for v in (A,B,C)]
print('partials factors')
for h in partials: print(s.factor(h))
# evaluate C=0
print('g C0',s.factor(g.subs(C,0)))
print('partials C0',[s.factor(h.subs(C,0)) for h in partials])
