#!/usr/bin/env python3
"""Exact SymPy verification of F_k = Psi_k o F_0 o Phi_k."""
import sympy as sp

x, y, z, k = sp.symbols("x y z k")

# Announced base map in the public (a,b,c) target coordinates.
P = (1 + x*y)**3*z + y**2*(1 + x*y)*(4 + 3*x*y)
Q = y + 3*x*(1 + x*y)**2*z + 3*x*y**2*(4 + 3*x*y)
R = 2*x - 3*x**2*y - x**3*z
F0 = sp.Matrix([sp.expand(P), sp.expand(Q), sp.expand(R)])

# Canonical bounded-support residual representative.
t = y + 1/x
w_k = 2*x - 3*x**2*y + k*x**2
c_k = sp.expand(w_k - x**3*z)
h_k = c_k*t**3 - (2 + k*c_k)*t**2
hT_k = 3*c_k*t**2 - 2*(2 + k*c_k)*t
b_k = sp.cancel(2/x - hT_k)
a_k = sp.cancel((h_k + t*b_k)/2)
assert sp.denom(a_k) == 1 and sp.denom(b_k) == 1
Fk = sp.Matrix([sp.expand(a_k), sp.expand(b_k), c_k])

# Phi_k(x,y,z) = (x, y-k/3, z).
F0_Phi = sp.Matrix([
    sp.expand(f.subs({x: x, y: y-k/3, z: z}, simultaneous=True))
    for f in F0
])

# Psi_k(a,b,c) = (a+k b/6+k^2/9+k^3 c/54,
#                 b+4k/3+k^2 c/3,
#                 c).
a, b, c = F0_Phi
Psi_F0_Phi = sp.Matrix([
    a + k*b/6 + k**2/9 + k**3*c/54,
    b + 4*k/3 + k**2*c/3,
    c,
])

assert all(sp.expand(e) == 0 for e in Fk - Psi_F0_Phi)
assert sp.factor(Fk.jacobian((x, y, z)).det()) == -2

A, B, C = sp.symbols("A B C")
Phi = sp.Matrix([x, y-k/3, z])
Psi = sp.Matrix([
    A + k*B/6 + k**2/9 + k**3*C/54,
    B + 4*k/3 + k**2*C/3,
    C,
])
assert Phi.jacobian((x, y, z)).det() == 1
assert Psi.jacobian((A, B, C)).det() == 1

print("Verified exactly: F_k = Psi_k o F_0 o Phi_k")
