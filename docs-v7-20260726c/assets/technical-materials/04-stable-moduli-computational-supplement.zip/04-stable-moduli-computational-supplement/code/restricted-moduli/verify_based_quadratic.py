#!/usr/bin/env python3
"""Exact symbolic checks for the based w20 family and quadratic cubic-frame stratum."""
from __future__ import annotations

import json
from pathlib import Path
import sympy as sp

x, y, z, k, lam = sp.symbols("x y z k lam", nonzero=False)
X = (x, y, z)

# Announced map in original (P,Q,R) target coordinates.
Axy = 1 + x*y
Bxy = Axy**2*z + y**2*(4 + 3*x*y)
P = sp.expand(Axy*Bxy)
Q = sp.expand(y + 3*x*Bxy)
R = sp.expand(2*x - 3*x**2*y - x**3*z)
F0 = sp.Matrix([P, Q, R])
JF0 = F0.jacobian(X)
assert sp.factor(JF0.det()) == -2

# Based normalization at p_k=(0,-k/3,0).
pk_sub = {x: 0, y: -k/sp.Integer(3), z: 0}
pk = sp.Matrix([0, -k/sp.Integer(3), 0])
Fpk = sp.simplify(F0.subs(pk_sub))
Jpk = sp.simplify(JF0.subs(pk_sub))
Fshift = F0.subs(y, y-k/sp.Integer(3))
Hk = sp.Matrix([sp.expand(v) for v in Jpk.inv()*(Fshift-Fpk)])
assert Hk.subs({x:0,y:0,z:0}) == sp.zeros(3,1)
assert Hk.jacobian(X).subs({x:0,y:0,z:0}) == sp.eye(3)
assert sp.factor(Hk.jacobian(X).det()) == 1
assert Fpk == sp.Matrix([4*k**2/sp.Integer(9), -k/sp.Integer(3), 0])

# Weighted scaling: H_{k/lambda}=S_lambda H_k S_lambda^{-1}.
S = sp.diag(lam, 1/lam, 1/lam**2)
Sinv_point = {x: x/lam, y: lam*y, z: lam**2*z}
left = Hk.subs(k, k/lam)
right = S * Hk.subs(Sinv_point, simultaneous=True)
for i in range(3):
    assert sp.cancel(sp.expand(left[i]-right[i])) == 0

# Fiber polynomial over F0(p_k), and the jump 1 -> 3.
T = sp.symbols("T")
fiber_poly = sp.expand(-2*T**2 - (k/sp.Integer(3))*T - 8*k**2/sp.Integer(9))
assert sp.factor(sp.discriminant(fiber_poly, T)) == -7*k**2
# At k=0, the x!=0 chart has no simple root; x=0 gives only (0,0,0).
assert sp.factor(fiber_poly.subs(k,0)) == -2*T**2
# At k != 0 there are two simple finite roots plus p_k on x=0.
assert sp.resultant(fiber_poly, sp.diff(fiber_poly,T), T) == -14*k**2

# First coefficient of the unique based formal source conjugacy H_k=H_0 o phi_k.
H0 = Hk.subs(k,0)
H1 = sp.Matrix([sp.expand(v).coeff(k,1) for v in Hk])
JH0 = H0.jacobian(X)
assert sp.factor(JH0.det()) == 1
v1 = sp.Matrix([sp.expand(v) for v in JH0.adjugate()*H1])
assert sp.Matrix([sp.expand(v) for v in JH0*v1-H1]) == sp.zeros(3,1)
assert v1.subs({x:0,y:0,z:0}) == sp.zeros(3,1)
assert v1.jacobian(X).subs({x:0,y:0,z:0}) == sp.zeros(3,3)
v1_degrees = [sp.Poly(v, *X).total_degree() for v in v1]
v1_terms = [len(sp.Poly(v, *X).terms()) for v in v1]
assert v1_degrees == [14,12,14]

# General normalized quadratic coefficient stratum.
C, U, V = sp.symbols("C U V")
alpha, beta = sp.symbols("alpha beta")
t = y + 1/x
r = sp.Rational(2)/x
w0 = 2*x - 3*x**2*y
c = sp.expand(w0 - x**3*z)
AA = C + alpha*C**2
BB = -2 - 4*alpha*C + beta*C**2
h = AA*T**3 + BB*T**2
bout = sp.expand(sp.cancel(r - sp.diff(h,T).subs({T:t,C:c})))
aout = sp.expand(sp.cancel((h.subs({T:t,C:c}) + t*bout)/2))
G = sp.Matrix([aout,bout,c])
assert sp.factor(G.jacobian(X).det()) == -2
assert [sp.Poly(e,*X).total_degree() for e in G] == [11,10,4]
assert sp.factor(aout.subs(x,0) - (z + 4*y**2 + 2*alpha*y - 2*beta)) == 0
assert sp.factor(bout.subs(x,0) - (y + 4*alpha)) == 0
assert c.subs(x,0) == 0

# Scaling action (alpha,beta)->(lambda alpha, lambda^2 beta).
sigma = {x:x/lam, y:lam*y, z:lam**2*z}
G_scaled_input = G.subs(sigma, simultaneous=True)
G_new_params = G.subs({alpha:lam*alpha, beta:lam**2*beta}, simultaneous=True)
tauG = sp.Matrix([lam**2*G[0], lam*G[1], G[2]/lam])
for i in range(3):
    assert sp.cancel(sp.expand(G_new_params[i].subs(sigma, simultaneous=True)-tauG[i])) == 0

# Cubic discriminant and missing-root fiber.
poly = sp.expand(AA*T**3 + BB*T**2 + V*T - 2*U)
Disc = sp.factor(sp.discriminant(poly,T))
cstar = -1/alpha
Bstar = sp.factor(BB.subs(C,cstar))
assert Bstar == (2*alpha**2+beta)/alpha**2
Disc_star = sp.factor(Disc.subs(C,cstar))
expected_star = sp.factor(Bstar**2 * (V**2 + 8*Bstar*U))
assert sp.factor(Disc_star-expected_star) == 0

# Triple-root parameterization.
t0 = sp.factor(-BB/(3*AA))
V0 = sp.factor(BB**2/(3*AA))
U0 = sp.factor(-BB**3/(54*AA**2))
triple = sp.expand(AA*(T-t0)**3)
assert sp.factor(sp.together(triple-poly.subs({U:U0,V:V0}))) == 0

# Save compact machine data.
out = {
    "based_family": {
        "F0_at_pk": [str(e) for e in Fpk],
        "JF0_at_pk": [[str(e) for e in row] for row in Jpk.tolist()],
        "zero_fiber_discriminant": str(sp.factor(sp.discriminant(fiber_poly,T))),
        "formal_source_v1_degrees": v1_degrees,
        "formal_source_v1_terms": v1_terms,
    },
    "quadratic_stratum": {
        "A": str(AA),
        "B": str(BB),
        "component_degrees_generic_alpha_nonzero": [11,10,4],
        "scaling_weights_alpha_beta": [1,2],
        "missing_root": str(cstar),
        "B_at_missing_root": str(Bstar),
        "coarse_invariant": "beta/alpha**2",
    },
}
Path(__file__).with_name("data").mkdir(exist_ok=True)
Path(__file__).with_name("data").joinpath("based_quadratic.json").write_text(json.dumps(out,indent=2)+"\n")
print("ALL BASED/QUADRATIC CHECKS PASSED")
print("v1 degrees:",v1_degrees,"terms:",v1_terms)
