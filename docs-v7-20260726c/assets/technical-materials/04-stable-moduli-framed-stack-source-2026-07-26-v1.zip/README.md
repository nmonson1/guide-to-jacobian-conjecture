# Program 4 framed-moduli source bundle

This archive contains the two standalone research notes that define the
fixed-boundary-length quotient stack, together with exact symbolic checks.

The notes define the open parameter scheme U_N, its weighted G_m action,
the normalized framed-completion moduli problem, and the quotient
[U_N/G_m].  They do not construct the still-open compactification or the
transition between boundary lengths when roots escape to infinity.

Representative replay:

    uv run --with sympy==1.14.0 python code/verify_jet_residue.py
    uv run --with sympy==1.14.0 python code/verify_triple_cover_conductor.py
    uv run --with sympy==1.14.0 python code/verify_q_full_orbit.py

The symbolic checks support the displayed identities.  The geometric
classification and stack arguments remain ordinary mathematical proofs and
have not received independent specialist review.
