# Full maximal-support propagation and \(C_5\)-equivariant normal windows for the \(F_2\) chain

**Working exact calculation — 22 July 2026.**

This note carries out the support-and-window calculation for the complete chain

\[
(5,20)\longrightarrow (7/5,2),\qquad (m,n)=(3,5).
\]

The source data are the standard-pair rectangles, the initial edge with lower endpoint \((1,0)\), the single approximate-root shear of denominator five, and the terminal direction \((25,-17)\).  The output is the **maximal Newton-bounded** coefficient model.  It deliberately does not impose every linear relation among coefficients inherited from descending the sheared pair back to \(K[x,y]\); this enlarges the gluing problem and is therefore conservative for a future nonexistence proof.

## 1. Source rectangles and the initial shear

For \(P\), the standard rectangle is

\[
0\le i\le15,\qquad 0\le j\le60,
\]

and the initial supporting edge from \((3,0)\) to \((15,60)\) gives

\[
5i-j\le15.
\]

For \(Q\), the corresponding conditions are

\[
0\le i\le25,\qquad 0\le j\le100,
\qquad 5i-j\le25.
\]

Apply

\[
\Phi_\lambda(x)=x,\qquad
\Phi_\lambda(y)=y+\lambda x^{-1/5},
\qquad \lambda\ne0.
\]

A monomial expands as

\[
x^iy^j\longmapsto
\sum_{J=0}^j\binom jJ\lambda^{j-J}
 x^{(5i-j+J)/5}y^J.
\]

Write a post-shear exponent as \((a/5,J)\) and put

\[
w=a-J=5i-j.
\]

Let \(\langle w\rangle_5\in\{0,1,2,3,4\}\) denote the least residue of \(w\) modulo five.  Since the upper source bounds \(60\) and \(100\) are multiples of five, a pair \((w,J)\) occurs in the exact shear expansion precisely when

\[
J\le Y-\langle w\rangle_5,
\]

where \(Y=60\) for \(P\) and \(Y=100\) for \(Q\).  This is the five-periodic upper-edge sawtooth that is lost if one replaces the support by its convex hull.

## 2. Exact propagated maximal supports

The terminal face has direction \((25,-17)\).  Its leading weights are

\[
v_{25,-17}(P)=3,\qquad
v_{25,-17}(Q)=5.
\]

Consequently the exact propagated maximal supports are

\[
\boxed{
S_P=
\left\{(a,J)\in\mathbf Z\times\mathbf Z_{\ge0}:
\begin{array}{l}
-60\le w=a-J\le15,\\
0\le J\le60-\langle w\rangle_5,\\
5a-17J\le3
\end{array}
\right\},}
\]

\[
\boxed{
S_Q=
\left\{(a,J)\in\mathbf Z\times\mathbf Z_{\ge0}:
\begin{array}{l}
-100\le w=a-J\le25,\\
0\le J\le100-\langle w\rangle_5,\\
5a-17J\le5
\end{array}
\right\}.}
\]

Exact enumeration gives

\[
|S_P|=4433,
\qquad
|S_Q|=12340.
\]

The convex hull vertices, displayed in the actual exponent coordinates \((a/5,J)\), are

\[
\operatorname{Newt}(P)=
\operatorname{conv}\left
\{(-12,0),(0,0),(4/5,1),(21/5,6),(15,60),(0,60)\right\},
\]

\[
\operatorname{Newt}(Q)=
\operatorname{conv}\left
\{(-20,0),(1/5,0),(7,10),(25,100),(0,100)\right\}.
\]

The sawtooth removes 150 lattice positions for \(P\) and 250 for \(Q\) relative to the saturated lattice points of these polygonal bounds.  Imposing the terminal half-space removes 53 and 136 additional exponent positions, respectively, from the direct shear envelopes.

## 3. Terminal uniformizing chart and \(C_5\)-characters

Use

\[
x=t^{-25},\qquad y=t^{17}z,
\qquad u=z^5.
\]

Then

\[
P=t^{-3}\sum_{r\ge0}t^rA_r(z),
\qquad
Q=t^{-5}\sum_{r\ge0}t^rB_r(z).
\]

The exact ranges are

\[
0\le r\le1023\quad(P),
\qquad
0\le r\le1705\quad(Q),
\]

with 981 and 1663 nonempty orders, respectively.

The Galois group of the uniformizing cover over the denominator-five lattice contains

\[
C_5=\langle\gamma\rangle,
\qquad
\gamma(t,z)=(\xi t,\xi^3z),
\qquad \xi^5=1.
\]

Therefore

\[
A_r(\xi^3z)=\xi^{3-r}A_r(z),
\qquad
B_r(\xi^3z)=\xi^{-r}B_r(z).
\]

Equivalently, with least residues in \(\{0,1,2,3,4\}\),

\[
\epsilon_P(r)\equiv1-2r\pmod5,
\qquad
\epsilon_Q(r)\equiv-2r\pmod5,
\]

and

\[
\boxed{
A_r(z)=z^{\epsilon_P(r)}\bar A_r(u),
\qquad
B_r(z)=z^{\epsilon_Q(r)}\bar B_r(u).}
\]

## 4. Closed two-point window formulas

For integers \(a\le b\), write

\[
\mathcal W[a,b]
:=H^0\!\left(\mathbf P^1_u,
\mathcal O\bigl(b[\infty]-a[0]\bigr)\right)
=\bigoplus_{k=a}^bKu^k.
\]

An empty interval means the zero space.

### 4.1 The \(P\)-windows

Set

\[
j^-_P(r)=
\max\left(0,\left\lceil\frac{r-303}{12}\right\rceil\right),
\qquad
j^+_P(r)=
\min\left(60,\left\lfloor\frac{r+72}{12}\right\rfloor\right).
\]

Let

\[
k^-_P(r)=
\left\lceil\frac{j^-_P(r)-\epsilon_P(r)}5\right\rceil,
\qquad
\widetilde k^+_P(r)=
\left\lfloor\frac{j^+_P(r)-\epsilon_P(r)}5\right\rfloor.
\]

For the raw top candidate

\[
J_*=\epsilon_P(r)+5\widetilde k^+_P(r),
\qquad
w_*=\frac{3+12J_*-r}{5},
\]

put

\[
\delta_P(r)=
\begin{cases}
1,&J_*>60-\langle w_*\rangle_5,\\
0,&\text{otherwise}.
\end{cases}
\]

Then

\[
k^+_P(r)=\widetilde k^+_P(r)-\delta_P(r),
\]

and the exact window is

\[
\boxed{
\bar A_r\in\mathcal W[k^-_P(r),k^+_P(r)].}
\]

Only the highest candidate can fail the sawtooth test.  If it fails, lowering \(J\) by five always succeeds because the available upper-edge slack increases by five while a least residue is at most four.

### 4.2 The \(Q\)-windows

Similarly,

\[
j^-_Q(r)=
\max\left(0,\left\lceil\frac{r-505}{12}\right\rceil\right),
\qquad
j^+_Q(r)=
\min\left(100,\left\lfloor\frac{r+120}{12}\right\rfloor\right),
\]

\[
k^-_Q(r)=
\left\lceil\frac{j^-_Q(r)-\epsilon_Q(r)}5\right\rceil,
\qquad
\widetilde k^+_Q(r)=
\left\lfloor\frac{j^+_Q(r)-\epsilon_Q(r)}5\right\rfloor.
\]

With

\[
J_*=\epsilon_Q(r)+5\widetilde k^+_Q(r),
\qquad
w_*=\frac{5+12J_*-r}{5},
\]

set

\[
\delta_Q(r)=
\mathbf 1_{\{J_*>100-\langle w_*\rangle_5\}},
\qquad
k^+_Q(r)=\widetilde k^+_Q(r)-\delta_Q(r).
\]

Then

\[
\boxed{
\bar B_r\in\mathcal W[k^-_Q(r),k^+_Q(r)].}
\]

At order zero,

\[
A_0=z(c_0+c_1u),
\qquad
B_0=d_0+d_1u+d_2u^2.
\]

After the standard normalization, the rigid reduced cover is

\[
A_0=z(1-u),
\qquad
B_0=\frac15-\frac35u+\frac9{25}u^2.
\]

## 5. Determinant complex and output windows

Writing

\[
P=t^{-3}A(t,z),
\qquad
Q=t^{-5}B(t,z),
\]

and using

\[
dx\wedge dy=-25t^{-9}dt\wedge dz,
\]

gives the boundary-volume equation

\[
\boxed{
3AB_z-5A_zB+t(A_zB_t-A_tB_z)=25[P,Q].}
\]

At order \(r\),

\[
E_r=
\sum_{i+j=r}
\left((3-i)A_iB_j'+(j-5)A_i'B_j\right).
\]

The new variables enter through

\[
\boxed{
\mathscr D_r(a,b)=
(3-r)aB_0'-5a'B_0+3A_0b'+(r-5)A_0'b.}
\]

Every output coefficient has \(C_5\)-character \(\xi^{-r}\), or equivalently exponent residue

\[
\epsilon_W(r)\equiv3r\pmod5.
\]

Exact support convolution, including the possibility that the monomial determinant coefficient

\[
(3-i)B+(j-5)A
\]

vanishes, shows that every nonempty full forcing support and every nonempty linearized support is a complete arithmetic interval after factoring \(z^{\epsilon_W(r)}\).  Thus there are exact two-point bundles

\[
\mathcal D_r^{\rm supp}
=z^{\epsilon_W(r)}\mathcal W[d^-_r,d^+_r],
\qquad
\mathcal F_r
=z^{\epsilon_W(r)}\mathcal W[f^-_r,f^+_r].
\]

All \((d^-_r,d^+_r)\) and \((f^-_r,f^+_r)\) are serialized in the accompanying JSON and CSV files.

## 6. Exact linear ranks and the first genuine pole jump

Using the normalized \(A_0,B_0\), exact rational matrices were constructed for every one of the 2681 nonempty determinant layers.

There are one-dimensional internal cokernels at orders

\[
r=3,4,5,6,7.
\]

A separate symbolic recursion shows that the corresponding adjoint pairings with the nonlinear forcing vanish identically.  At \(r=8\) the operator is surjective, and exact rank calculations show surjectivity onto the full forcing window for every

\[
8\le r\le509.
\]

The first forcing monomial outside the support of \(\mathscr D_r\) appears at

\[
\boxed{r=510.}
\]

At that order,

\[
\bar A_{510}\in\mathcal W[4,9],
\qquad
\bar B_{510}\in\mathcal W[1,10],
\]

while

\[
\operatorname{supp}\mathscr D_{510}
=z^0\mathcal W[1,11],
\qquad
\mathcal F_{510}=z^0\mathcal W[0,11].
\]

Moreover,

\[
\operatorname{rank}\mathscr D_{510}=11.
\]

Hence the first external adjoint line is simply constant-term extraction:

\[
\boxed{
\omega_{510}=[u^0]F_{510}=[z^0]F_{510}.}
\]

Writing \([z^a]A_i=a_{i,a}\) and \([z^b]B_j=b_{j,b}\), this potential obstruction is

\[
\omega_{510}
=
\sum_{\substack{i+j=510\\i,j>0}}
\left(
(j-5)a_{i,1}b_{j,0}
+(3-i)a_{i,0}b_{j,1}
\right),
\]

where only terms supported by the windows are retained.  There are exactly 123 such bilinear terms: 63 of type \((1,0)\) and 60 of type \((0,1)\).

This identifies the first place where global polynomial termination can fail.  It does **not** establish that \(\omega_{510}\) is nonzero on every recursively solved jet.

## 7. Status and limitations

What is now exact:

1. the maximal post-shear support sets \(S_P,S_Q\), including the upper-edge sawtooth;
2. every \(C_5\)-character and every two-point quotient window for \(A_r,B_r\);
3. every full determinant forcing window and every linearized-output window;
4. the exact rational rank of every linear normal operator;
5. automatic compatibility through order seven and surjectivity through order 509;
6. the first external pole functional at order 510.

What remains:

1. recursively evaluate \(\omega_{510}\), modulo all kernel gauges and approximate-root transformations;
2. if it can vanish, continue the finite Kuranishi computation using the serialized windows;
3. prove that the maximal-window model is complete for the actual boundary-gluing functor, or retain it as a conservative enlargement;
4. integrate any persistent vanishing into an allowable strict Newton descent.

No planar Jacobian-conjecture conclusion follows from the window calculation alone.

## 8. Source premises

The standard-pair rectangles, complete-chain formalism, and the entry

\[
F_2:\quad A_0=(5,20),\quad A'_0=(1,0),\quad A_1=(7/5,2),\quad
(m,n)=(3,5),
\]

are taken from J. A. Guccione, J. J. Guccione, R. Horruitiner, and C. Valqui, *Some algorithms related to the Jacobian Conjecture*, arXiv:1708.07936, especially Theorem 2.20 and the tables in Sections 5-6. That paper records maximum degree 125 for this specialization. The sawtooth support formula, quotient windows, determinant-layer ranks, and order-510 pole jump are derived and verified in the present calculation.
