# F2 low-order Kuranishi audit

The one-dimensional cokernels at orders 3 through 7 are present in the linear complexes, but their pairings with the recursively generated nonlinear forcing vanish identically.

| r | rank | target dimension | left functional | pairing |
|---:|---:|---:|---|---|
| 3 | 2 | 3 | `(0, 3/5, 1)` | `0` |
| 4 | 2 | 3 | `(0, 3/4, 1)` | `0` |
| 5 | 3 | 4 | `(0, 1, 1, 1)` | `0` |
| 6 | 2 | 3 | `(9/5, 6/5, 1)` | `0` |
| 7 | 2 | 3 | `(9/2, 3/2, 1)` | `0` |
| 8 | 3 | 3 | `none` | `n/a` |

Every adjoint pairing at r=3,...,7 vanishes identically; r=8 has no cokernel.
