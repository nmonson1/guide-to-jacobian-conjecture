#!/usr/bin/env python3
"""Independent exact verifier for f2_omega520_exact_certificate.json."""
from __future__ import annotations
from fractions import Fraction as F
import json
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
CERT = Path(sys.argv[1]) if len(sys.argv) > 1 else BASE / 'f2_omega520_exact_certificate.json'
WIN = BASE / 'f2_support_windows.json'


def parse_poly(d):
    return {int(e): F(v) for e, v in d.items()}


def derivative(P):
    return {e - 1: F(e) * c for e, c in P.items() if e and c}


def add_product(out, X, Y, scale):
    for a, c in X.items():
        for b, d in Y.items():
            out[a + b] = out.get(a + b, F(0)) + scale * c * d


def determinant_layer(r, A, B):
    out = {}
    for i in range(r + 1):
        j = r - i
        Ai, Bj = A.get(i, {}), B.get(j, {})
        if not Ai or not Bj:
            continue
        add_product(out, Ai, derivative(Bj), F(3 - i))
        add_product(out, derivative(Ai), Bj, F(j - 5))
    return {e: v for e, v in out.items() if v}


def allowed_exponents(window):
    return set(range(window['J_min'], window['J_max'] + 1, 5))


def main():
    d = json.loads(CERT.read_text())
    w = json.loads(WIN.read_text())
    Pwin = {int(k): v for k, v in w['P_windows'].items()}
    Qwin = {int(k): v for k, v in w['Q_windows'].items()}

    A = {0: parse_poly(d['base']['A0'])}
    B = {0: parse_poly(d['base']['B0'])}
    seen = set()
    for rec in d['layers']:
        r = int(rec['r'])
        if r in seen:
            raise AssertionError(('duplicate layer', r))
        seen.add(r)
        A[r] = parse_poly(rec['A'])
        B[r] = parse_poly(rec['B'])
        if not set(A[r]).issubset(allowed_exponents(Pwin[r])):
            raise AssertionError(('P support', r, set(A[r]) - allowed_exponents(Pwin[r])))
        if not set(B[r]).issubset(allowed_exponents(Qwin[r])):
            raise AssertionError(('Q support', r, set(B[r]) - allowed_exponents(Qwin[r])))

    for r in range(1, 521):
        A.setdefault(r, {})
        B.setdefault(r, {})

    e0 = determinant_layer(0, A, B)
    if e0 != {0: F(-1)}:
        raise AssertionError(('E0', e0))
    for r in range(1, 521):
        q = determinant_layer(r, A, B)
        if q:
            raise AssertionError(('nonzero determinant layer', r, q))

    par = {k: F(v) for k, v in d['parameters'].items()}
    kur = {k: F(v) if k not in {'verified_omega510', 'verified_omega520'} else v
           for k, v in d['kuranishi_data'].items()}
    if par['mu_r260_free_index_0'] != -kur['omega510_base_C'] / kur['omega510_mu_coefficient_D']:
        raise AssertionError('mu relation')
    if kur['omega510_nu0_coefficient_E0'] + kur['omega510_nu1_coefficient_E1'] * par['order270_direction_ratio_v1']:
        raise AssertionError('order-270 null direction')
    if kur['omega520_at_lambda_0'] + kur['omega520_lambda_coefficient_L'] * par['lambda']:
        raise AssertionError('order-520 cancellation relation')
    if par['nu_r270_free_index_0'] != par['lambda']:
        raise AssertionError('nu0 relation')
    if par['nu_r270_free_index_1'] != par['lambda'] * par['order270_direction_ratio_v1']:
        raise AssertionError('nu1 relation')

    next_omega = determinant_layer(530, A, B).get(0, F(0))
    # A_530 and B_530 are absent, so this is the next forcing coefficient.
    if next_omega != kur['next_zero-slice_constant_omega530']:
        raise AssertionError('omega530 mismatch')

    print(json.dumps({
        'verified': True,
        'determinant_layers_checked': '0..520',
        'E0': '-1',
        'omega510': '0',
        'omega520': '0',
        'omega530_nonzero_on_zero-new-free-coordinate_slice': bool(next_omega),
        'support_windows_checked': True,
    }, indent=2))


if __name__ == '__main__':
    main()
