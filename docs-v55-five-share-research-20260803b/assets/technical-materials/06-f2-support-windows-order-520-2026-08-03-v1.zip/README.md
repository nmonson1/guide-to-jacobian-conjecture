# Lane 8 F2 support windows and order-520 recovery

This packet promotes two recovered exact computations for the degree-125
`F_2` complete-chain seed:

1. the maximal Newton-bounded support propagation, its `C_5`-isotypic normal
   windows, and the exact rational ranks of every linear normal complex; and
2. an exact rational weighted-slice jet satisfying the determinant identity
   through normal order `520`.

The support model contains `4433` propagated `P` exponents and `12340`
propagated `Q` exponents.  It has `981` nonempty `P` layers, `1663` nonempty
`Q` layers, and `2681` determinant-output layers.  Its first forcing window
external to the linearized image occurs at order `510`.

In the selected weighted slice, an order-260 parameter cancels the order-510
functional and an order-270 direction preserves that cancellation while a
scalar along it cancels the order-520 functional.  The independent verifier
checks all determinant layers from `0` through `520` and checks every
serialized coefficient against the support windows.

## Replay

From the public bundle root:

```bash
uv run python scripts/f2_support_windows.py --outdir /tmp/f2-support-replay
uv run python scripts/f2_kuranishi_linear.py \
  --windows /tmp/f2-support-replay/f2_support_windows.json \
  --outdir /tmp/f2-support-replay
uv run python verify_f2_omega520_certificate.py
```

The support scripts use exact integer and rational arithmetic.  The order-520
verifier uses only the Python standard library.

## Boundary

The support calculation is the maximal Newton-bounded
independent-coefficient enlargement.  It deliberately does not impose all
cross-layer coefficient relations inherited from descent through a fixed
approximate-root shear.  The order-520 certificate concerns one
`C_5`-invariant weighted slice of that model.

The nonzero order-530 coefficient reported after setting newly available
coordinates to zero is not an obstruction.  This packet does not establish
nonexistence of the `F_2` chain, complete the fresh-parameter recurrence at
order 530, or construct the adjacent-chart attachment.
