#!/usr/bin/env python3
"""Exact weighted Kuranishi elimination for the F2 normal-window model.

The script keeps:
  * eta = 1 in the first order-10 RREF kernel coordinate;
  * mu in the first order-260 kernel coordinate;
  * a one-dimensional rational direction in the first two order-270
    kernel coordinates that annihilates the order-510 functional.

It solves the order-510 equation with mu, then solves the order-520
functional with the order-270 direction, all over Q.  The resulting jet is
verified through order 520 and serialized as a standalone certificate.
"""
from __future__ import annotations

from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATA = BASE / 'f2_support_windows.json'
OUT = BASE / 'f2_omega520_exact_certificate.json'
SHA = BASE / 'f2_omega520_exact_certificate.sha256'

A0 = {1: F(1), 6: F(-1)}
B0 = {0: F(1, 5), 5: F(-3, 5), 10: F(9, 25)}


def exps(w):
    return list(range(w['J_min'], w['J_max'] + 1, 5))


def der(P):
    return {e - 1: F(e) * c for e, c in P.items() if e and c}


def add_product(out, X, Y, scale):
    if not scale:
        return
    for a, c in X.items():
        for b, d in Y.items():
            out[a + b] = out.get(a + b, F(0)) + scale * c * d


def positive_forcing(r, A, B):
    """Nonlinear forcing from positive orders i,j with i+j=r."""
    out = {}
    for i in range(1, r):
        j = r - i
        Ai = A.get(i, {})
        Bj = B.get(j, {})
        if not Ai or not Bj:
            continue
        add_product(out, Ai, der(Bj), F(3 - i))
        add_product(out, der(Ai), Bj, F(j - 5))
    return {e: c for e, c in out.items() if c}


def full_layer(r, A, B):
    """Complete determinant coefficient E_r, including i=0 or j=0."""
    out = {}
    for i in range(r + 1):
        j = r - i
        Ai = A.get(i, {})
        Bj = B.get(j, {})
        if not Ai or not Bj:
            continue
        add_product(out, Ai, der(Bj), F(3 - i))
        add_product(out, der(Ai), Bj, F(j - 5))
    return {e: c for e, c in out.items() if c}


def matrix(r, pwin, qwin, wwin):
    pexp = [] if pwin is None else exps(pwin)
    qexp = [] if qwin is None else exps(qwin)
    wexp = exps(wwin)
    widx = {e: i for i, e in enumerate(wexp)}
    cols = [('A', e) for e in pexp] + [('B', e) for e in qexp]
    M = [[F(0)] * len(cols) for _ in wexp]
    for c, (typ, e) in enumerate(cols):
        if typ == 'A':
            for b, coef in B0.items():
                out = e + b - 1
                scale = F((3 - r) * b - 5 * e) * coef
                if scale:
                    M[widx[out]][c] += scale
        else:
            for a, coef in A0.items():
                out = a + e - 1
                scale = F(3 * e + (r - 5) * a) * coef
                if scale:
                    M[widx[out]][c] += scale
    return M, cols, wexp


def rref_solve(M, b, free_assign=None):
    m = len(M)
    n = len(M[0]) if m else 0
    R = [M[i][:] + [b[i]] for i in range(m)]
    row = 0
    pivots = []
    for col in range(n):
        q = next((i for i in range(row, m) if R[i][col]), None)
        if q is None:
            continue
        R[row], R[q] = R[q], R[row]
        v = R[row][col]
        R[row] = [x / v for x in R[row]]
        for i in range(m):
            if i != row and R[i][col]:
                v = R[i][col]
                R[i] = [R[i][j] - v * R[row][j] for j in range(n + 1)]
        pivots.append(col)
        row += 1
        if row == m:
            break
    for i in range(row, m):
        if all(R[i][j] == 0 for j in range(n)) and R[i][n]:
            return None, None
    free = [j for j in range(n) if j not in pivots]
    x = [F(0)] * n
    for idx, val in (free_assign or {}).items():
        if idx < 0 or idx >= len(free):
            raise IndexError((idx, free))
        x[free[idx]] = F(val)
    for i, col in enumerate(pivots):
        x[col] = R[i][n] - sum(R[i][j] * x[j] for j in free)
    return x, free


def load_windows():
    d = json.loads(DATA.read_text())
    return (
        {int(k): v for k, v in d['P_windows'].items()},
        {int(k): v for k, v in d['Q_windows'].items()},
        {int(k): v for k, v in d['full_jacobian_output_windows'].items()},
    )


def solve(assignments, through):
    """Solve the chosen C5-invariant weighted slice through `through`."""
    Pwin, Qwin, Wwin = load_windows()
    A = {0: dict(A0)}
    B = {0: dict(B0)}
    records = []
    for r in range(1, through + 1):
        # All selected parameters have weights divisible by 10, hence the
        # recursively generated slice is supported only at such orders.
        if r % 10:
            A[r] = {}
            B[r] = {}
            continue
        Fnl = positive_forcing(r, A, B)
        M, cols, wexp = matrix(r, Pwin.get(r), Qwin.get(r), Wwin[r])
        rhs = [-Fnl.get(e, F(0)) for e in wexp]
        x, free = rref_solve(M, rhs, assignments.get(r, {}))
        if x is None:
            raise RuntimeError(('inconsistent', r, Fnl))
        Ar, Br = {}, {}
        for val, (typ, e) in zip(x, cols):
            if val:
                (Ar if typ == 'A' else Br)[e] = val
        A[r], B[r] = Ar, Br
        q = full_layer(r, A, B)
        if q:
            raise AssertionError((r, q))
        records.append({
            'r': r,
            'free_dim': len(free),
            'A': {str(e): str(v) for e, v in sorted(Ar.items())},
            'B': {str(e): str(v) for e, v in sorted(Br.items())},
        })
    return A, B, records


def omega(order, assignments):
    A, B, _ = solve(assignments, order - 10)
    return positive_forcing(order, A, B).get(0, F(0))


def mod_fraction(x, p=1_000_003):
    return (x.numerator % p) * pow(x.denominator % p, -1, p) % p


def main():
    eta = F(1)
    base = {10: {0: eta}}

    C = omega(510, base)
    D = omega(510, {10: {0: eta}, 260: {0: F(1)}}) - C
    if not D:
        raise AssertionError('order-260 coefficient vanished')
    mu = -C / D

    E0 = omega(510, {10: {0: eta}, 270: {0: F(1)}}) - C
    E1 = omega(510, {10: {0: eta}, 270: {1: F(1)}}) - C
    if not E1:
        raise AssertionError('second order-270 coefficient vanished')

    # Rational direction v=(1,v1,0,0,0) in ker(omega_510|K_270).
    v1 = -E0 / E1
    if E0 + E1 * v1:
        raise AssertionError('order-270 direction does not preserve omega510')

    def assignments(lam):
        return {
            10: {0: eta},
            260: {0: mu},
            270: {0: lam, 1: lam * v1},
        }

    Omega0 = omega(520, assignments(F(0)))
    Omega1 = omega(520, assignments(F(1)))
    L = Omega1 - Omega0
    if not L:
        raise AssertionError('order-520 functional is constant on chosen direction')
    # Since 2*270>520 and mu is fixed, the dependence is exactly linear.
    if omega(520, assignments(F(2))) != Omega0 + 2 * L:
        raise AssertionError('unexpected nonlinear dependence at order 520')
    lam = -Omega0 / L

    ass = assignments(lam)
    A, B, records = solve(ass, 520)
    if full_layer(0, A, B) != {0: F(-1)}:
        raise AssertionError(full_layer(0, A, B))
    if positive_forcing(510, {k: v for k, v in A.items() if k < 510},
                        {k: v for k, v in B.items() if k < 510}).get(0, F(0)):
        raise AssertionError('omega510 not zero')
    if positive_forcing(520, {k: v for k, v in A.items() if k < 520},
                        {k: v for k, v in B.items() if k < 520}).get(0, F(0)):
        raise AssertionError('omega520 not zero')

    omega530 = positive_forcing(530, A, B).get(0, F(0))

    cert = {
        'model': 'F2 maximal Newton-bounded independent-coefficient recursion; C5-invariant weighted slice',
        'claim': 'Exact rational jet satisfying the determinant identity through order 520',
        'base': {
            'A0': {str(e): str(v) for e, v in A0.items()},
            'B0': {str(e): str(v) for e, v in B0.items()},
        },
        'parameters': {
            'eta_r10_free_index_0': str(eta),
            'mu_r260_free_index_0': str(mu),
            'lambda': str(lam),
            'nu_r270_free_index_0': str(lam),
            'nu_r270_free_index_1': str(lam * v1),
            'order270_direction_ratio_v1': str(v1),
        },
        'kuranishi_data': {
            'omega510_base_C': str(C),
            'omega510_mu_coefficient_D': str(D),
            'omega510_nu0_coefficient_E0': str(E0),
            'omega510_nu1_coefficient_E1': str(E1),
            'omega520_at_lambda_0': str(Omega0),
            'omega520_lambda_coefficient_L': str(L),
            'verified_omega510': '0',
            'verified_omega520': '0',
            'next_zero-slice_constant_omega530': str(omega530),
        },
        'mod_1000003_checks': {
            'mu': mod_fraction(mu),
            'v1': mod_fraction(v1),
            'lambda': mod_fraction(lam),
            'nu0': mod_fraction(lam),
            'nu1': mod_fraction(lam * v1),
            'omega520_at_lambda_0': mod_fraction(Omega0),
            'omega520_lambda_coefficient_L': mod_fraction(L),
            'omega530': mod_fraction(omega530),
        },
        'layers': records,
    }
    OUT.write_text(json.dumps(cert, indent=2) + '\n')
    h = hashlib.sha256(OUT.read_bytes()).hexdigest()
    SHA.write_text(f'{h}  {OUT.name}\n')
    print(json.dumps({
        'verified_through': 520,
        'omega510': '0',
        'omega520': '0',
        'omega530_nonzero': bool(omega530),
        'mod_1000003': cert['mod_1000003_checks'],
        'certificate': str(OUT),
        'sha256': h,
    }, indent=2))


if __name__ == '__main__':
    main()
