#!/usr/bin/env python3
"""Exact low-order Kuranishi audit for the F2 normal windows.

This verifies that the one-dimensional cokernels at r=3,4,5,6,7 do not
produce an obstruction: after solving recursively at lower orders, their
adjoint pairings with the nonlinear forcing vanish identically.  It also
records exact left-cokernel functionals and a normalized recursive solution
through r=8.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sympy as sp

z=sp.symbols('z')
t,s=sp.symbols('t s')
A=[None]*9;B=[None]*9
A[0]=z-z**6
B[0]=sp.Rational(1,5)-sp.Rational(3,5)*z**5+sp.Rational(9,25)*z**10
A[1]=-sp.Rational(10,9)*t*z**4
B[1]=t*(-sp.Rational(8,9)*z**3+z**8)
A[2]=0
B[2]=s*(z**6-z)+sp.Rational(160,243)*t**2*z

Pex={3:[0,5],4:[3],5:[1,6],6:[4],7:[2],8:[0,5]}
Qex={3:[4,9],4:[2,7],5:[0,5,10],6:[3,8],7:[1,6],8:[4,9]}
Wex={3:[4,9,14],4:[2,7,12],5:[0,5,10,15],6:[3,8,13],7:[1,6,11],8:[4,9,14]}


def D(r,a,b):
    return sp.expand((3-r)*a*sp.diff(B[0],z)-5*sp.diff(a,z)*B[0]+3*A[0]*sp.diff(b,z)+(r-5)*sp.diff(A[0],z)*b)

def C(i,j):
    return sp.expand((3-i)*A[i]*sp.diff(B[j],z)+(j-5)*sp.diff(A[i],z)*B[j])

def forcing(r):
    return sp.expand(sum((C(i,r-i) for i in range(1,r)),sp.Integer(0)))

def poly_dict(expr):
    p=sp.Poly(sp.expand(expr),z)
    return {str(k[0]):str(v) for k,v in p.terms()}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--outdir',default='data')
    args=ap.parse_args()
    outdir=Path(args.outdir); outdir.mkdir(parents=True,exist_ok=True)
    records=[]
    new_parameters=[]
    for r in range(3,9):
        F=forcing(r)
        av=sp.symbols(f'a{r}_0:{len(Pex[r])}')
        bv=sp.symbols(f'b{r}_0:{len(Qex[r])}')
        vars=list(av)+list(bv)
        AA=sum((v*z**e for v,e in zip(av,Pex[r])),sp.Integer(0))
        BB=sum((v*z**e for v,e in zip(bv,Qex[r])),sp.Integer(0))
        expr=sp.Poly(sp.expand(D(r,AA,BB)+F),z)
        eq=[expr.coeff_monomial(z**e) for e in Wex[r]]
        M=sp.Matrix([[sp.diff(q,v) for v in vars] for q in eq])
        f=sp.Matrix([sp.expand(q.subs({v:0 for v in vars})) for q in eq])
        left=M.T.nullspace()
        pairings=[sp.factor((ell.T*f)[0]) for ell in left]
        sol=sp.linsolve(eq,vars)
        if sol==sp.EmptySet:
            raise RuntimeError(f'inconsistent at order {r}')
        tup=list(next(iter(sol)))
        # Replace free coordinate symbols retained by linsolve by named kappas.
        freevars=[v for v in vars if any(v in ex.free_symbols for ex in tup)]
        repl={}
        for v in freevars:
            nv=sp.symbols(f'kappa_{r}_{len(new_parameters)+1}')
            new_parameters.append(nv)
            repl[v]=nv
        tup=[sp.expand(ex.subs(repl)) for ex in tup]
        A[r]=sp.expand(AA.subs(dict(zip(vars,tup))))
        B[r]=sp.expand(BB.subs(dict(zip(vars,tup))))
        check=sp.expand(D(r,A[r],B[r])+F)
        if check!=0:
            raise AssertionError((r,check))
        records.append({
            'r':r,
            'target_exponents':Wex[r],
            'matrix_rank':int(M.rank()),
            'left_cokernel_basis':[[str(sp.factor(x)) for x in ell] for ell in left],
            'nonlinear_forcing':poly_dict(F),
            'adjoint_pairings':[str(x) for x in pairings],
            'all_pairings_identically_zero':all(x==0 for x in pairings),
            'A_r':str(A[r]),
            'B_r':str(B[r]),
        })

    out={
        'normalization':{
            'A0':str(A[0]),'B0':str(B[0]),
            'A1':str(A[1]),'B1':str(B[1]),
            'A2':str(A[2]),'B2':str(B[2]),
        },
        'records':records,
        'conclusion':'Every adjoint pairing at r=3,...,7 vanishes identically; r=8 has no cokernel.',
    }
    path=outdir/'f2_low_order_kuranishi.json'
    json.dump(out,open(path,'w'),indent=2)
    md=['# F2 low-order Kuranishi audit','',
        'The one-dimensional cokernels at orders 3 through 7 are present in the linear complexes, but their pairings with the recursively generated nonlinear forcing vanish identically.','',
        '| r | rank | target dimension | left functional | pairing |',
        '|---:|---:|---:|---|---|']
    for rec in records:
        lf='; '.join('('+', '.join(v)+')' for v in rec['left_cokernel_basis']) or 'none'
        pair='; '.join(rec['adjoint_pairings']) or 'n/a'
        md.append(f"| {rec['r']} | {rec['matrix_rank']} | {len(rec['target_exponents'])} | `{lf}` | `{pair}` |")
    md += ['',out['conclusion'],'']
    (outdir/'f2_low_order_kuranishi.md').write_text('\n'.join(md))
    print(json.dumps({'path':str(path),'orders':[r['r'] for r in records],'pairings_zero':all(r['all_pairings_identically_zero'] for r in records)},indent=2))


if __name__=='__main__':
    main()
