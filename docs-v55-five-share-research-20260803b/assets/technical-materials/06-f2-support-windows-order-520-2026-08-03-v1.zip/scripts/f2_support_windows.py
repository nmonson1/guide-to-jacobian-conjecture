#!/usr/bin/env python3
"""Exact support propagation and C5-equivariant normal windows for the F2 chain.

Chain: (5,20) -> (7/5,2), (m,n)=(3,5).

We work with the maximal Newton-bounded supports forced by:
  * standard rectangles for P and Q;
  * initial lower supporting line of direction (5,-1);
  * the approximate-root shear y -> y + lambda*x^(-1/5);
  * terminal lower supporting line of direction (25,-17).

Coordinates after the shear:
  exponent pair (a/5, j), a,j integers.
Terminal uniformizing chart:
  x = t^(-25), y = t^17 z.
Then
  P = t^(-3) sum_r t^r A_r(z),
  Q = t^(-5) sum_r t^r B_r(z).
The C5 subgroup t -> xi*t, z -> xi^(-17) z = xi^3 z
forces a single character in each normal layer.  With u=z^5,
  A_r(z)=z^epsP(r) Abar_r(u),
  B_r(z)=z^epsQ(r) Bbar_r(u).

The script enumerates the exact maximal propagated support, verifies closed
form window formulas, constructs the quotient line-bundle windows, and
computes the exact ambient Jacobian-layer windows.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from fractions import Fraction
from pathlib import Path
import argparse
import csv
import json
import math
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple


@dataclass(frozen=True)
class PairData:
    name: str
    degree_multiplier: int  # m for P, n for Q
    x_max: int
    y_max: int
    initial_weight_max: int  # v_(5,-1)
    initial_weight_min: int
    terminal_weight_max: int  # v_(25,-17)
    leading_pole: int


P_DATA = PairData(
    name="P", degree_multiplier=3,
    x_max=15, y_max=60,
    initial_weight_max=15, initial_weight_min=-60,
    terminal_weight_max=3, leading_pole=3,
)
Q_DATA = PairData(
    name="Q", degree_multiplier=5,
    x_max=25, y_max=100,
    initial_weight_max=25, initial_weight_min=-100,
    terminal_weight_max=5, leading_pole=5,
)


def ceil_div(a: int, b: int) -> int:
    assert b > 0
    return -((-a) // b)


def least_residue(a: int, mod: int = 5) -> int:
    return a % mod


def original_maximal_support(data: PairData) -> Set[Tuple[int, int]]:
    """Integer lattice support in the standard rectangle below initial face.

    Original exponents are (i,j) in Z^2.  The initial face has
    5*i-j = initial_weight_max and the polygon lies in the half-space <=.
    """
    out: Set[Tuple[int, int]] = set()
    for i in range(data.x_max + 1):
        for j in range(data.y_max + 1):
            if 5 * i - j <= data.initial_weight_max:
                out.add((i, j))
    return out


def shear_propagated_support(data: PairData) -> Set[Tuple[int, int]]:
    """Support after y -> y + lambda*x^(-1/5).

    Store exponent x^(a/5) y^J as integer pair (a,J).
    A source monomial x^i y^j contributes every J=0,...,j, with
        a = 5*i - j + J.
    We then impose the terminal supporting half-space
        5*a - 17*J <= terminal_weight_max.
    """
    out: Set[Tuple[int, int]] = set()
    for i, j in original_maximal_support(data):
        for J in range(j + 1):
            a = 5 * i - j + J
            if 5 * a - 17 * J <= data.terminal_weight_max:
                out.add((a, J))
    return out


def closed_support_set(data: PairData) -> Set[Tuple[int, int]]:
    """Closed-form characterization of the propagated maximal support.

    Besides the two supporting half-spaces, exact propagation remembers the
    upper edge of the source rectangle.  For fixed initial weight
    w=5i-j=a-J, the largest source y-exponent congruent to -w mod 5 is
    y_max-<w>_5.  Hence a propagated exponent J exists exactly when
    J <= y_max-<w>_5.
    """
    out: Set[Tuple[int, int]] = set()
    for J in range(data.y_max + 1):
        for w in range(data.initial_weight_min, data.initial_weight_max + 1):
            a = w + J
            if J > data.y_max - least_residue(w, 5):
                continue
            if 5 * a - 17 * J <= data.terminal_weight_max:
                out.add((a, J))
    return out


def layer_of(data: PairData, a: int, J: int) -> int:
    return data.terminal_weight_max - (5 * a - 17 * J)


def group_layers(data: PairData, support: Set[Tuple[int, int]]) -> Dict[int, List[int]]:
    layers: Dict[int, List[int]] = {}
    for a, J in support:
        r = layer_of(data, a, J)
        if r < 0:
            raise AssertionError("terminal half-space violation")
        layers.setdefault(r, []).append(J)
    for r in layers:
        layers[r] = sorted(set(layers[r]))
    return dict(sorted(layers.items()))


def raw_J_bounds(data: PairData, r: int) -> Tuple[int, int]:
    """Bounds before imposing the unique C5 residue class."""
    c = data.terminal_weight_max
    # w=(c+12J-r)/5 and w_min <= w <= w_max.
    lo = max(0, ceil_div(r + 5 * data.initial_weight_min - c, 12))
    hi = min(data.y_max, (r + 5 * data.initial_weight_max - c) // 12)
    return lo, hi


def character_residue(data: PairData, r: int) -> int:
    """Least J residue modulo 5 in layer r."""
    # r = c - 5a + 17J, hence r == c + 2J (mod 5).
    # inverse of 2 mod 5 is 3.
    return least_residue(3 * (r - data.terminal_weight_max), 5)


def arithmetic_window(data: PairData, r: int) -> Optional[Dict[str, int]]:
    jlo, jhi = raw_J_bounds(data, r)
    eps = character_residue(data, r)
    klo = ceil_div(jlo - eps, 5)
    khi = (jhi - eps) // 5
    if klo > khi:
        return None

    # Exact upper-edge correction.  The raw top candidate may fail to come
    # from a source monomial because the required source exponent j would
    # exceed y_max.  If it fails, moving down one C5 step always succeeds:
    # J decreases by 5 while the residue obstruction changes by at most 4.
    Jtop = eps + 5 * khi
    wtop_num = data.terminal_weight_max + 12 * Jtop - r
    if wtop_num % 5 != 0:
        raise AssertionError("character congruence failure")
    wtop = wtop_num // 5
    if Jtop > data.y_max - least_residue(wtop, 5):
        khi -= 1
    if klo > khi:
        return None

    Jmin = eps + 5 * klo
    Jmax = eps + 5 * khi
    return {
        "r": r,
        "eps": eps,
        "raw_J_min": jlo,
        "raw_J_max": jhi,
        "J_min": Jmin,
        "J_max": Jmax,
        "u_min": klo,
        "u_max": khi,
        "dimension": khi - klo + 1,
        "line_bundle_degree": khi - klo,
    }


def all_windows(data: PairData, layers: Dict[int, List[int]]) -> Dict[int, Dict[str, int]]:
    out: Dict[int, Dict[str, int]] = {}
    for r in range(max(layers) + 1):
        win = arithmetic_window(data, r)
        if win is not None:
            out[r] = win
    return out


def verify_windows(data: PairData, layers: Dict[int, List[int]], windows: Dict[int, Dict[str, int]]) -> None:
    if set(layers) != set(windows):
        missing_formula = sorted(set(layers) - set(windows))[:10]
        extra_formula = sorted(set(windows) - set(layers))[:10]
        raise AssertionError((missing_formula, extra_formula))
    for r, Js in layers.items():
        win = windows[r]
        expected = list(range(win["J_min"], win["J_max"] + 1, 5))
        if Js != expected:
            raise AssertionError(f"{data.name} layer {r}: {Js} != {expected}")


def bilinear_coeff(i: int, j: int, Aexp: int, Bexp: int) -> int:
    """Coefficient of z^(Aexp+Bexp-1) in layer i+j of volume identity.

    E = 3 A B_z - 5 A_z B + t(A_z B_t - A_t B_z).
    """
    return (3 - i) * Bexp + (j - 5) * Aexp


def jacobian_layer_exponents(
    r: int,
    p_layers: Dict[int, List[int]],
    q_layers: Dict[int, List[int]],
) -> List[int]:
    exps: Set[int] = set()
    for i in range(r + 1):
        j = r - i
        As = p_layers.get(i)
        Bs = q_layers.get(j)
        if not As or not Bs:
            continue
        for Aexp in As:
            for Bexp in Bs:
                # derivative of z^0 may vanish; the combined coefficient test
                # handles both derivative terms at once.
                c = bilinear_coeff(i, j, Aexp, Bexp)
                if c != 0:
                    exponent = Aexp + Bexp - 1
                    if exponent < 0:
                        raise AssertionError("nonzero negative z exponent")
                    exps.add(exponent)
    return sorted(exps)


def jacobian_windows(
    p_layers: Dict[int, List[int]],
    q_layers: Dict[int, List[int]],
) -> Dict[int, Dict[str, object]]:
    max_r = max(p_layers) + max(q_layers)
    out: Dict[int, Dict[str, object]] = {}
    for r in range(max_r + 1):
        exps = jacobian_layer_exponents(r, p_layers, q_layers)
        if not exps:
            continue
        eps = least_residue(3 * r, 5)  # output C5 character
        bad = [e for e in exps if e % 5 != eps]
        if bad:
            raise AssertionError((r, eps, bad[:10]))
        ks = sorted((e - eps) // 5 for e in exps)
        # Record whether the support is a full arithmetic interval.
        full = ks == list(range(min(ks), max(ks) + 1))
        out[r] = {
            "r": r,
            "eps": eps,
            "J_min": min(exps),
            "J_max": max(exps),
            "u_min": min(ks),
            "u_max": max(ks),
            "dimension": len(ks),
            "line_bundle_degree": max(ks) - min(ks),
            "full_interval": full,
            "missing_u_exponents": [] if full else sorted(set(range(min(ks), max(ks)+1)) - set(ks)),
        }
    return out


def linearized_layer_exponents(
    r: int,
    p_layers: Dict[int, List[int]],
    q_layers: Dict[int, List[int]],
) -> List[int]:
    """Support of D_r(A_r,B_r) using only pairs (r,0) and (0,r)."""
    exps: Set[int] = set()
    for i, j in [(r, 0), (0, r)]:
        As = p_layers.get(i)
        Bs = q_layers.get(j)
        if not As or not Bs:
            continue
        for Aexp in As:
            for Bexp in Bs:
                if bilinear_coeff(i, j, Aexp, Bexp) != 0:
                    exps.add(Aexp + Bexp - 1)
    return sorted(exps)


def linearized_windows(
    p_layers: Dict[int, List[int]],
    q_layers: Dict[int, List[int]],
) -> Dict[int, Dict[str, object]]:
    max_r = max(max(p_layers), max(q_layers))
    out: Dict[int, Dict[str, object]] = {}
    for r in range(max_r + 1):
        exps = linearized_layer_exponents(r, p_layers, q_layers)
        if not exps:
            continue
        eps = least_residue(3 * r, 5)
        ks = sorted((e - eps)//5 for e in exps)
        full = ks == list(range(min(ks), max(ks)+1))
        out[r] = {
            "r": r,
            "eps": eps,
            "J_min": min(exps),
            "J_max": max(exps),
            "u_min": min(ks),
            "u_max": max(ks),
            "dimension": len(ks),
            "line_bundle_degree": max(ks)-min(ks),
            "full_interval": full,
            "missing_u_exponents": [] if full else sorted(set(range(min(ks), max(ks)+1))-set(ks)),
        }
    return out


def compress_piecewise(rows: Dict[int, Dict[str, int]], fields: Sequence[str]) -> List[Dict[str, object]]:
    """Compress consecutive r where selected fields are affine with fixed first differences.

    This is mostly for human-readable diagnostics, not a theorem prover.
    """
    rs = sorted(rows)
    if not rs:
        return []
    segments: List[Dict[str, object]] = []
    start = rs[0]
    prev = rs[0]
    prev_vals = tuple(rows[prev][f] for f in fields)
    diffs: Optional[Tuple[int, ...]] = None
    for r in rs[1:]:
        vals = tuple(rows[r][f] for f in fields)
        contiguous = r == prev + 1
        newdiff = tuple(vals[k] - prev_vals[k] for k in range(len(fields)))
        if not contiguous or (diffs is not None and newdiff != diffs):
            segments.append({
                "r_start": start,
                "r_end": prev,
                "start_values": {f: rows[start][f] for f in fields},
                "end_values": {f: rows[prev][f] for f in fields},
                "step": None if start == prev else {f: diffs[k] for k, f in enumerate(fields)},
            })
            start = r
            diffs = None
        if start == prev + 1 and diffs is None:
            diffs = newdiff
        elif start == r:
            diffs = None
        prev = r
        prev_vals = vals
    segments.append({
        "r_start": start,
        "r_end": prev,
        "start_values": {f: rows[start][f] for f in fields},
        "end_values": {f: rows[prev][f] for f in fields},
        "step": None if start == prev else {f: diffs[k] for k, f in enumerate(fields)},
    })
    return segments


def summarize_windows(windows: Dict[int, Dict[str, int]]) -> Dict[str, object]:
    dims = [row["dimension"] for row in windows.values()]
    maxdim = max(dims)
    maxrows = [r for r,row in windows.items() if row["dimension"] == maxdim]
    return {
        "first_layer": min(windows),
        "last_layer": max(windows),
        "number_of_nonempty_layers": len(windows),
        "max_dimension": maxdim,
        "max_dimension_first_layer": min(maxrows),
        "max_dimension_last_layer": max(maxrows),
        "total_coefficients": sum(dims),
    }


def write_csv(path: Path, p_windows, q_windows, lin_windows, jac_windows) -> None:
    fields = [
        "r",
        "P_eps","P_J_min","P_J_max","P_u_min","P_u_max","P_dim",
        "Q_eps","Q_J_min","Q_J_max","Q_u_min","Q_u_max","Q_dim",
        "D_eps","D_J_min","D_J_max","D_u_min","D_u_max","D_dim","D_full",
        "W_eps","W_J_min","W_J_max","W_u_min","W_u_max","W_dim","W_full",
        "virtual_excess_W_minus_PQ",
    ]
    maxr = max(max(p_windows), max(q_windows), max(jac_windows))
    with path.open("w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=fields)
        wr.writeheader()
        for r in range(maxr+1):
            p=p_windows.get(r,{}); q=q_windows.get(r,{}); d=lin_windows.get(r,{}); w=jac_windows.get(r,{})
            row={"r":r}
            for pref,obj in [("P",p),("Q",q),("D",d),("W",w)]:
                for key,outkey in [("eps","eps"),("J_min","J_min"),("J_max","J_max"),("u_min","u_min"),("u_max","u_max"),("dimension","dim")]:
                    row[f"{pref}_{outkey}"]=obj.get(key,"")
                if pref in ("D","W"):
                    row[f"{pref}_full"]=obj.get("full_interval","")
            if p and q and w:
                row["virtual_excess_W_minus_PQ"] = w["dimension"] - p["dimension"] - q["dimension"]
            else:
                row["virtual_excess_W_minus_PQ"] = ""
            wr.writerow(row)


def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument("--outdir", default="data")
    args=parser.parse_args()
    outdir=Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    results={}
    layer_data={}
    window_data={}
    for data in (P_DATA,Q_DATA):
        orig=original_maximal_support(data)
        prop=shear_propagated_support(data)
        closed=closed_support_set(data)
        if prop != closed:
            raise AssertionError(f"closed support mismatch for {data.name}: {len(prop)} vs {len(closed)}")
        layers=group_layers(data,prop)
        windows=all_windows(data,layers)
        verify_windows(data,layers,windows)
        layer_data[data.name]=layers
        window_data[data.name]=windows
        results[data.name]={
            "metadata":asdict(data),
            "original_support_size":len(orig),
            "propagated_support_size":len(prop),
            "summary":summarize_windows(windows),
            "leading_layer_J":layers[0],
            "support_vertices_in_a_over_5_J": None,
        }

    # Convex hull vertices are inserted explicitly after exact derivation.
    results["P"]["support_vertices_in_a_over_5_J"]=[
        ["-12","0"],["0","0"],["4/5","1"],["21/5","6"],["15","60"],["0","60"]
    ]
    results["Q"]["support_vertices_in_a_over_5_J"]=[
        ["-20","0"],["1/5","0"],["7","10"],["25","100"],["0","100"]
    ]

    jac=jacobian_windows(layer_data["P"],layer_data["Q"])
    lin=linearized_windows(layer_data["P"],layer_data["Q"])

    # Basic exact checks.
    assert layer_data["P"][0] == [1,6]
    assert layer_data["Q"][0] == [0,5,10]
    assert all(row["full_interval"] for row in jac.values())
    # The linearized support can have endpoint holes due to vanishing monomial coefficients;
    # retain exact missing lists rather than asserting fullness.

    # Serialize compact windows (all layers) and representative first/transition/last tables.
    payload={
        "chain":{
            "A0":[5,20],"A0_prime":[1,0],"A1":["7/5",2],
            "m_n":[3,5],"initial_direction":[5,-1],"terminal_direction":[25,-17],"gap":5,
        },
        "coordinates":{
            "post_shear_lattice":"x^(a/5) y^J",
            "terminal_chart":"x=t^(-25), y=t^17 z, u=z^5",
            "expansions":"P=t^(-3) sum t^r A_r(z), Q=t^(-5) sum t^r B_r(z)",
            "C5_action":"t -> xi t, z -> xi^3 z",
        },
        "support":results,
        "P_windows":window_data["P"],
        "Q_windows":window_data["Q"],
        "linearized_output_windows":lin,
        "full_jacobian_output_windows":jac,
        "P_character":"eps_P(r) = (1-2r) mod 5",
        "Q_character":"eps_Q(r) = (-2r) mod 5",
        "output_character":"eps_W(r) = 3r mod 5",
    }
    with (outdir/"f2_support_windows.json").open("w") as f:
        json.dump(payload,f,indent=2,sort_keys=True)

    write_csv(outdir/"f2_support_windows.csv",window_data["P"],window_data["Q"],lin,jac)

    # Human-readable selected layers.
    selected=set(range(0,31))
    for r in [60,120,240,300,303,304,360,480,600,720,900,1023,1024,1200,1500,1705,2728]:
        selected.add(r)
    selected=sorted(selected)
    lines=[]
    lines.append("# Selected F2 normal-window layers\n")
    lines.append("| r | P: eps; u-range; dim | Q: eps; u-range; dim | D_r support u-range; dim | full layer W_r u-range; dim | excess dim W-P-Q |")
    lines.append("|---:|---|---|---|---|---:|")
    for r in selected:
        p=window_data["P"].get(r); q=window_data["Q"].get(r); d=lin.get(r); w=jac.get(r)
        def fmt(obj):
            if not obj: return "—"
            return f"{obj['eps']}; [{obj['u_min']},{obj['u_max']}]; {obj['dimension']}"
        excess="—"
        if p and q and w:
            excess=str(w["dimension"]-p["dimension"]-q["dimension"])
        lines.append(f"| {r} | {fmt(p)} | {fmt(q)} | {fmt(d)} | {fmt(w)} | {excess} |")
    (outdir/"selected_layers.md").write_text("\n".join(lines)+"\n")

    # Compact theorem-style report generated from exact data.
    report=[]
    report.append("# Exact maximal-support propagation and C5 windows for F2\n")
    report.append("This file is generated by `f2_support_windows.py`.\n")
    report.append("## Exact support\n")
    report.append("After the shear, write a monomial as `x^(a/5)y^J` and set `w=a-J`. The maximal Newton-bounded supports are")
    report.append("\n\\[S_P=\\{(a,J):-60\\le w\\le15,\\ 0\\le J\\le60-\\langle w\\rangle_5,\\ 5a-17J\\le3\\},\\]")
    report.append("\\[S_Q=\\{(a,J):-100\\le w\\le25,\\ 0\\le J\\le100-\\langle w\\rangle_5,\\ 5a-17J\\le5\\}.\\]\n")
    report.append("The five-periodic upper bounds retain the exact source-rectangle sawtooth; they are not replaceable by the convex-hull inequalities.\n")
    report.append(f"They contain respectively **{len(shear_propagated_support(P_DATA))}** and **{len(shear_propagated_support(Q_DATA))}** lattice monomials.\n")
    report.append("## Terminal chart and characters\n")
    report.append("Use \\(x=t^{-25}, y=t^{17}z, u=z^5\\). Then")
    report.append("\\[P=t^{-3}\\sum_{r\\ge0}t^rA_r(z),\\qquad Q=t^{-5}\\sum_{r\\ge0}t^rB_r(z).\\]")
    report.append("For \\(\\xi^5=1\\), the deck action is \\(t\\mapsto\\xi t, z\\mapsto\\xi^3z\\). Hence")
    report.append("\\[A_r(z)=z^{\\epsilon_P(r)}\\bar A_r(u),\\quad \\epsilon_P(r)\\equiv1-2r\\pmod5,\\]")
    report.append("\\[B_r(z)=z^{\\epsilon_Q(r)}\\bar B_r(u),\\quad \\epsilon_Q(r)\\equiv-2r\\pmod5.\\]\n")
    report.append("## Closed window formulas\n")
    report.append("For P put")
    report.append("\\[j_P^-(r)=\\max\\left(0,\\left\\lceil\\frac{r-303}{12}\\right\\rceil\\right),\\qquad j_P^+(r)=\\min\\left(60,\\left\\lfloor\\frac{r+72}{12}\\right\\rfloor\\right).\\]")
    report.append("Let \\(\\epsilon_P(r)\\in\\{0,1,2,3,4\\}\\) be the residue above and define")
    report.append("\\[k_P^-(r)=\\left\\lceil\\frac{j_P^-(r)-\\epsilon_P(r)}5\\right\\rceil,\\qquad \\widetilde k_P^+(r)=\\left\\lfloor\\frac{j_P^+(r)-\\epsilon_P(r)}5\\right\\rfloor.\\]")
    report.append("For \\(J_*=\\epsilon_P+5\\widetilde k_P^+\\) and \\(w_*=(3+12J_*-r)/5\\), subtract one from \\(\\widetilde k_P^+\\) exactly when \\(J_*>60-\\langle w_*\\rangle_5\\); call the result \\(k_P^+\\). Then")
    report.append("\\[\\bar A_r\\in H^0\\!\\left(\\mathbf P^1_u,\\mathcal O(k_P^+(r)[\\infty]-k_P^-(r)[0])\\right).\\]")
    report.append("For Q the same formula holds with")
    report.append("\\[j_Q^-(r)=\\max\\left(0,\\left\\lceil\\frac{r-505}{12}\\right\\rceil\\right),\\qquad j_Q^+(r)=\\min\\left(100,\\left\\lfloor\\frac{r+120}{12}\\right\\rfloor\\right),\\]")
    report.append("\\(\\epsilon_Q(r)\\equiv-2r\\pmod5\\), and the analogous top correction using \\(w_*=(5+12J_*-r)/5\\) and \\(J_*\\le100-\\langle w_*\\rangle_5\\).\n")
    report.append("The leading windows are \\(A_0=z(c_0+c_1u)\\) and \\(B_0=d_0+d_1u+d_2u^2\\), agreeing with the rigid degree-six reduced cover.\n")
    report.append("## Volume-identity output\n")
    report.append("The transformed determinant equation is")
    report.append("\\[3AB_z-5A_zB+t(A_zB_t-A_tB_z)=25[P,Q].\\]")
    report.append("At layer r the new variables enter through")
    report.append("\\[\\mathscr D_r(a,b)=(3-r)aB_0'-5a'B_0+3A_0b'+(r-5)A_0'b.\\]")
    report.append("Every full layer has character \\(3r\\pmod5\\). Exact full-layer and linearized output windows are serialized in the JSON/CSV files.\n")
    report.append("## Verification summary\n")
    report.append(f"- P supported orders span 0 through {max(layer_data['P'])}; {len(layer_data['P'])} orders are nonempty, with {sum(len(v) for v in layer_data['P'].values())} coefficients.\n")
    report.append(f"- Q supported orders span 0 through {max(layer_data['Q'])}; {len(layer_data['Q'])} orders are nonempty, with {sum(len(v) for v in layer_data['Q'].values())} coefficients.\n")
    report.append(f"- Full determinant layers: 0 through {max(jac)}; every output support is a complete arithmetic interval after quotienting by C5.\n")
    report.append("- Enumeration from the source rectangles agrees exactly with the closed support inequalities and with every corrected window formula.\n")
    (outdir/"f2_support_windows_report.md").write_text("\n".join(report)+"\n")

    print(json.dumps({
        "outdir":str(outdir),
        "P":results["P"],
        "Q":results["Q"],
        "linearized_nonempty_layers":len(lin),
        "jacobian_nonempty_layers":len(jac),
        "jacobian_last_layer":max(jac),
        "all_jacobian_windows_full":all(x["full_interval"] for x in jac.values()),
        "linearized_windows_with_holes":sum(not x["full_interval"] for x in lin.values()),
    },indent=2))


if __name__ == "__main__":
    main()
