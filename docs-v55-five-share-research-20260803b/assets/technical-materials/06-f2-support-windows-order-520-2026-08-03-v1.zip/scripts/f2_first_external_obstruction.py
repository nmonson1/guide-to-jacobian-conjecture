#!/usr/bin/env python3
"""Describe the first external F2 normal-window obstruction at r=510."""
from __future__ import annotations
import argparse
import json
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--windows', default='data/f2_support_windows.json')
    ap.add_argument('--outdir', default='data')
    args = ap.parse_args()

    d = json.load(open(args.windows))
    P = {int(k): list(range(v['J_min'], v['J_max'] + 1, 5)) for k, v in d['P_windows'].items()}
    Q = {int(k): list(range(v['J_min'], v['J_max'] + 1, 5)) for k, v in d['Q_windows'].items()}
    r = 510
    terms = []
    for i in range(1, r):
        j = r - i
        for A in P.get(i, []):
            for B in Q.get(j, []):
                if A + B - 1 != 0:
                    continue
                coeff = (3 - i) * B + (j - 5) * A
                if coeff:
                    terms.append({
                        'i': i, 'j': j,
                        'A_exponent': A, 'B_exponent': B,
                        'coefficient': coeff,
                    })
    groups = {
        'A1_B0': [x for x in terms if x['A_exponent'] == 1],
        'A0_B1': [x for x in terms if x['A_exponent'] == 0],
    }
    out = {
        'order': 510,
        'full_target_window': 'u^0,...,u^11',
        'linearized_target_window': 'u^1,...,u^11',
        'adjoint_functional': 'constant coefficient [u^0]=[z^0]',
        'term_count': len(terms),
        'groups': groups,
        'formula': {
            'A1_B0': 'sum_{i+j=510}(j-5) [z]A_i [1]B_j',
            'A0_B1': 'sum_{i+j=510}(3-i) [1]A_i [z]B_j',
        },
    }
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / 'f2_first_external_obstruction.json'
    json.dump(out, open(path, 'w'), indent=2)
    print(json.dumps({
        'path': str(path), 'term_count': len(terms),
        'A1_B0': len(groups['A1_B0']), 'A0_B1': len(groups['A0_B1']),
        'first': terms[:3], 'last': terms[-3:],
    }, indent=2))


if __name__ == '__main__':
    main()
