import sympy as s
x,y,z,e=s.symbols('x y z e')

def monoms(d):
    return [x**i*y**j*z**(d-i-j) for i in range(d+1) for j in range(d+1-i)]

def coeff_eq(poly):
    return [c for _,c in s.Poly(s.expand(poly),x,y,z).terms()]

def attack(G,name):
    print('\n===',name,G,'===')
    m2=monoms(2); m1=[x,y,z]
    av=s.symbols('a0:6'); bv=s.symbols('b0:6'); lv=s.symbols('r0:3')
    A=sum(c*m for c,m in zip(av,m2)); B=sum(c*m for c,m in zip(bv,m2)); ell=lv[0]*x+lv[1]*y  # z coefficient forced by membership in (x,y)^2
    lv=(lv[0],lv[1])
    eq=coeff_eq(y*A-x*B-G*ell)
    varsAB=list(av)+list(bv)
    sol=s.linsolve(eq,varsAB)
    tup=next(iter(sol))
    # parameter free symbols excluding ell
    free=sorted(set().union(*[v.free_symbols for v in tup]) - set(lv),key=str)
    print('AB free',len(free),free)
    A=s.expand(A.subs(dict(zip(varsAB,tup))));B=s.expand(B.subs(dict(zip(varsAB,tup))))
    print('A=',s.factor(A));print('B=',s.factor(B))
    H3=s.Matrix([2*x*A,y*A+x*B,2*y*B])
    # H2 equation
    uv=s.symbols('u0:6'); vv=s.symbols('v0:6'); wv=s.symbols('w0:6')
    U=sum(c*m for c,m in zip(uv,m2));V=sum(c*m for c,m in zip(vv,m2));W=sum(c*m for c,m in zip(wv,m2))
    eq2=coeff_eq(y**2*U-2*x*y*V+x**2*W-G*ell**2)
    vars2=list(uv)+list(vv)+list(wv)
    sol2=s.linsolve(eq2,vars2); tup2=next(iter(sol2))
    free2=sorted(set().union(*[v.free_symbols for v in tup2])-set(lv),key=str)
    print('H2 free',len(free2),free2)
    sub2=dict(zip(vars2,tup2)); U=s.expand(U.subs(sub2));V=s.expand(V.subs(sub2));W=s.expand(W.subs(sub2)); H2=s.Matrix([U,V,W])
    # arbitrary L
    ls=s.symbols('l0:9'); L=s.Matrix(3,3,ls); LX=L*s.Matrix([x,y,z])
    # S3
    nvec=s.Matrix([y**2,-2*x*y,x**2])
    bil=lambda X,Y:s.expand(X[0]*Y[2]+X[2]*Y[0]-2*X[1]*Y[1])
    S3=s.expand(G*(nvec.dot(LX))+bil(H3,H2))
    eq3=coeff_eq(S3)
    sol3=s.solve(eq3,ls,dict=True,simplify=False)
    print('L solutions',len(sol3))
    if not sol3: return
    subL=sol3[0]; print('L solved',len(subL),'free L',[q for q in ls if q not in subL])
    # substitute
    L=L.subs(subL); LX=L*s.Matrix([x,y,z])
    # S4 and delta invariance
    S4=s.expand(U*W-V**2+bil(H3,LX))
    Gz=s.diff(G,z)
    delta=lambda f:s.expand(x*Gz*s.diff(f,x)+y*Gz*s.diff(f,y)+(z*Gz-4*G)*s.diff(f,z))
    eq4=coeff_eq(delta(S4))
    print('S4 equations',len(eq4),'unique',len(set(map(str,map(s.factor,eq4)))))
    # dump equations factors
    for q in list(dict.fromkeys([s.factor(q) for q in eq4]))[:30]: print(' ',q)

attack(x*z+y**2,'smooth_through_p')
