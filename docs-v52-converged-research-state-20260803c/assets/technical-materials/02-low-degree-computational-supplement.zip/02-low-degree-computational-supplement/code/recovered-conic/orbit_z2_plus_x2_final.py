# setup
from pathlib import Path
src=Path(__file__).with_name('orbit_z2_plus_x2_stage.py').read_text(); cut=src.split("# identify symbols by names")[0]; exec(cut)
e=s.symbols('e')
v1,v2,v4=s.symbols('v1 v2 v4');w1,w2,w4=s.symbols('w1 w2 w4')
subr={w1:-4*b1*a,w4:-4*b4*a,v2:2*b2*b,v1:2*b1*b,v4:w2+2*a*b2+2*b*b4}
H2r=s.simplify(H2.subs(subr));H3r=H3;Lr=s.simplify(L.subs(subr));H4=s.Matrix([G*x**2,G*x*y,G*y**2]);K=H4+e*H3r+e**2*H2r+e**3*(Lr*s.Matrix([x,y,z]));Phi=s.expand(K[0]*K[2]-K[1]**2)
JJ=s.Matrix([[s.diff(K[i],u) for u in (x,y,z)] for i in range(2)]+[[s.diff(Phi,u) for u in (x,y,z)]])
expr=s.expand(JJ.det()-e**9*Lr.det()*K[0]);pe=s.Poly(expr,e)
print('detL',s.factor(Lr.det()))
print('ecoefs',[(j,len(s.Poly(co,x,y,z).terms())) for (j,),co in pe.terms()])
for j in range(0,12):
 co=pe.coeff_monomial(e**j)
 if co!=0:
  print('E',j,s.factor(co))
