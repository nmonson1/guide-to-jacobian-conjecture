import sympy as s
x,y,z,e=s.symbols('x y z e')
G=z**2+x*y
# parameters
a,b,c0,c1,c2,t,m,n=s.symbols('a b c0 c1 c2 t m n') # t=w3, m=l22, n=l32
C=c0*x+c1*y+c2*z
A=x*C+a*x**2+b*z**2
B=y*C-a*z**2-b*y**2
H3=s.Matrix([2*x*A, y*A+x*B, 2*y*B])
# H2 reduced
w1=-3*a**2-4*a*c0
v3=-2*b**2+2*b*c1
w4=-4*a*c2
v4=2*b*c2
w3=t
v1=t-a*b+2*a*c1+2*b*c0
U=(2*a*b+2*v1-w3)*x**2 +(b**2+2*v3)*x*y+2*v4*x*z+b**2*z**2
V=(-a**2/2+w1/2)*x**2+v1*x*y+(w4/2)*x*z+v3*y**2+v4*y*z-a*b*z**2
W=w1*x*y+w3*y**2+w4*y*z+a**2*z**2
H2=s.Matrix([s.expand(U),s.expand(V),s.expand(W)])
# L entries reduced
l11=2*(-a*b**2+2*a*b*c1+b**2*c0+m)
l12=2*b**2*(-b+c1)
l13=2*b**2*c2
l21=-(2*a**2*b+2*a**2*c1+4*a*b*c0-n)/2
l22=m
l23=-2*a*b*c2
l31=2*a**2*(a+c0)
l32=n
l33=2*a**2*c2
L=s.Matrix([[l11,l12,l13],[l21,l22,l23],[l31,l32,l33]])
X=s.Matrix([x,y,z])
H4=s.Matrix([G*x**2,G*x*y,G*y**2])
K=H4+e*H3+e**2*H2+e**3*(L*X)
Phi=s.expand(K[0]*K[2]-K[1]**2)
J=s.Matrix([[s.diff(K[i],v) for v in (x,y,z)] for i in range(2)] + [[s.diff(Phi,v) for v in (x,y,z)]])
expr=s.expand(J.det()-e**9*L.det()*K[0])
pe=s.Poly(expr,e)
print('e degrees',pe.degree(), 'terms',len(pe.terms()))
for (ke,),coef in sorted(pe.terms(), reverse=True):
    if coef!=0:
        p=s.Poly(coef,x,y,z)
        print('E',ke,'source degree',p.total_degree(),'nterms',len(p.terms()))
        fs=[]
        for mon,cc in p.terms():
            ff=s.factor(cc)
            if ff not in fs and -ff not in fs: fs.append(ff)
        print(' unique',len(fs))
        for ff in fs[:20]: print('  ',ff)
print('detL=',s.factor(L.det()))
