# Degree-four conic leading forms with a reduced nonsingular quadratic factor

## Statement

Let

\[
F=LX+H_2+H_3+H_4:\mathbb A^3_{\mathbb C}\to\mathbb A^3_{\mathbb C},
\qquad \det JF\in\mathbb C^*,
\]

where \(L\in\operatorname{GL}_3(\mathbb C)\) and \(H_i\) is homogeneous of degree \(i\). Suppose that, after independent linear source and target changes,

\[
H_4=G(x,y,z)(x^2,xy,y^2),
\]

where \(G\) is a reduced quadratic form and the point

\[
p=[0:0:1]
\]

is nonsingular on the conic \(G=0\) (with the convention that a point outside the conic is also allowed). Then no such Keller map exists.

Equivalently, in the conic stratum \((e,r,k)=(2,1,2)\), a degree-four Keller map can survive only when either

1. \(G\) is nonreduced; or
2. \(p\) is the singular point of the reduced rank-two conic \(G=0\).

Under the stabilizer of the pencil \(\langle x,y\rangle\), the four eliminated normal forms are

\[
G=z^2+xy,\qquad G=xz+y^2,\qquad G=z^2+x^2,\qquad G=xz.
\]

The three remaining quadratic-factor orbits are

\[
G=xy,\qquad G=z^2,\qquad G=x^2.
\]

The proof below is computer-assisted only in the final finite coefficient calculations. No division by a parameter is used.

---

## 1. The characteristic derivation

Put

\[
v=(x^2,xy,y^2),\qquad n=(y^2,-2xy,x^2)^T,
\]

so that \(H_4=Gv\) and \(n\) is a left kernel vector of \(JH_4\). A polynomial right-kernel derivation is

\[
\delta_G
=xG_z\partial_x+yG_z\partial_y+(zG_z-4G)\partial_z.
\]

Indeed, \(\delta_G(H_{4,i})=0\) for all three components. Moreover,

\[
\delta_G(y^2)=2G_z y^2,
\qquad
\delta_G(Gy^2)=0,
\qquad
\delta_G(x/y)=0.
\]

For each of the four normal forms above one has

\[
\ker_{\mathbb C(x,y,z)}\delta_G
=
\mathbb C\!\left(\frac{x}{y},Gy^2\right).
\tag{1.1}
\]

For \(G=xz+y^2\) and \(G=xz\), this follows by writing the full function field as a rational extension of the displayed field. For \(G=z^2+xy\) and \(G=z^2+x^2\), after setting \(r=x/y\), \(u=y\), and \(w=yz\), the generic fiber is

\[
w^2+r u^4=s
\quad\text{or}\quad
w^2+r^2u^4=s,
\]

which is geometrically integral; hence the displayed invariant field is relatively algebraically closed in the full function field.

The two generators in (1.1) have ordinary scalar degrees \(0\) and \(4\). Consequently an invariant rational function that is homogeneous of degree not divisible by four must vanish.

---

## 2. The first three normal deformations vanish

Write

\[
H_3=(P,Q,R),
\qquad
M=n\cdot H_3.
\]

The highest nonautomatic Keller equation is

\[
n^T JH_3\,\delta_G=0.
\]

Since \(\delta_G(n)=2G_z n\), this is

\[
\delta_G(M)=2G_zM,
\qquad
\delta_G(M/y^2)=0.
\]

The rational function \(M/y^2\) is homogeneous of degree three. By (1.1),

\[
M=0.
\]

The syzygy module of \((y^2,-2xy,x^2)\) therefore gives

\[
H_3=T(A,B):=(2xA,\;yA+xB,\;2yB),
\tag{2.1}
\]

for quadratic forms \(A,B\).

Introduce

\[
K_\varepsilon
=H_4+\varepsilon H_3+\varepsilon^2H_2+\varepsilon^3LX
\]

and

\[
\Phi(Y)=Y_1Y_3-Y_2^2.
\]

Because \(\Phi(H_4)=0\), write

\[
\Phi(K_\varepsilon)
=\varepsilon^2S_2+\varepsilon^3S_3+\varepsilon^4S_4+
\varepsilon^5S_5+\varepsilon^6S_6.
\]

The exact chain-rule identity is

\[
\operatorname{Jac}(K_{\varepsilon,1},K_{\varepsilon,2},
\Phi(K_\varepsilon))
=
K_{\varepsilon,1}\det JK_\varepsilon.
\tag{2.2}
\]

For a Keller map,

\[
\det JK_\varepsilon=\varepsilon^9\det L.
\tag{2.3}
\]

The coefficients of \(\varepsilon^2\) and \(\varepsilon^3\) in (2.2), using successively the preceding vanishings, give

\[
\delta_G(S_2)=0,
\qquad
\delta_G(S_3)=0.
\]

Here \(S_2\) and \(S_3\) have homogeneous degrees six and five. Equation (1.1) therefore gives

\[
S_2=S_3=0.
\tag{2.4}
\]

Now

\[
S_2=G\,n\cdot H_2-(yA-xB)^2.
\]

Since all four displayed \(G\)'s are squarefree,

\[
yA-xB=G\ell,
\qquad
n\cdot H_2=G\ell^2
\tag{2.5}
\]

for a linear form \(\ell\). Membership in the ideal \((x,y)^2\) forces

\[
\ell=ax+by.
\]

A convenient universal parametrization of the second equation in (2.5) is

\[
H_2=G(b^2,-ab,a^2)+T(U,V),
\tag{2.6}
\]

where \(U,V\) are linear forms.

The first equation in (2.5) has the following exhaustive solutions, with \(C\) an arbitrary linear form:

\[
\begin{array}{c|c|c}
G&A&B\\ \hline
z^2+xy&xC+ax^2+bz^2&yC-az^2-by^2\\
 xz+y^2&xC+axy+bG&yC-axz\\
 z^2+x^2&xC+bG&yC-aG\\
 xz&xC+bG&yC-aG.
\end{array}
\tag{2.7}
\]

---

## 3. The fourth normal deformation

The coefficient of \(\varepsilon^4\) in (2.2) gives

\[
\delta_G(S_4)=0.
\tag{3.1}
\]

Substitute (2.6)--(2.7), retain an arbitrary \(3\times3\) linear part \(L\), and first solve \(S_3=0\) linearly for seven of the nine entries of \(L\). The remaining equations (3.1) are finite coefficient identities. Their exact solutions are recorded in the certificate scripts.

No parameter is inverted. The only branching occurs for \(G=xz+y^2\), where (3.1) has the set-theoretically exhaustive alternatives

\[
a=0
\qquad\text{or}\qquad
[c_z]C=[x]C.
\tag{3.2}
\]

After these equations, the coefficient of \(\varepsilon^6\) in (2.2) and the determinant of the retained linear part take the forms in the following table. The symbols \(A_0,B_0,m,n,q,k\) are free scalar parameters left by the preceding linear equations; their exact definitions appear immediately below the table and in the scripts.

\[
\begin{array}{c|c|c}
G&[\varepsilon^6]\bigl(\text{left side of (2.2)}-
\varepsilon^9(\det L)K_{\varepsilon,1}\bigr)&\det L\\ \hline
z^2+xy&x^2zG(A_0x+2B_0y)^2&c_2(-bA_0+2aB_0)^2\\[1mm]
 xz+y^2,\ c_2=c_0&\frac12x^3G(A_0x-2my)^2&c_2(bA_0+2am)^2\\[1mm]
 xz+y^2,\ a=0&\frac12x^3G\bigl(nx+(4b^2(c_2-c_0)-2m)y\bigr)^2&b^2c_2n^2\\[1mm]
 z^2+x^2&x^2zG(A_0x+B_0y)^2&c_2(bA_0-aB_0)^2\\[1mm]
 xz&\frac12x^3G(A_0x+B_0y)^2&c_2(bA_0-aB_0)^2.
\end{array}
\tag{3.3}
\]

For the first row, write

\[
C=c_0x+c_1y+c_2z,
\]

and use scalar parameters \(k,m,n\). Then

\[
A_0=n-6a^2b-2a^2c_1+4ak,
\qquad
B_0=-m-2ab^2-2abc_1+2bk.
\]

For the second row,

\[
A_0=2a^3+2a^2c_1+n.
\]

For the last two rows, with \(q\) the remaining coefficient in \(H_2\),

\[
A_0=6a^2c_1+2aq+n,
\qquad
B_0=4abc_1+2bq-2m.
\]

Each coefficient in the middle column of (3.3) must vanish. Since the polynomial ring is a domain, its displayed linear form must vanish. The determinant in the last column then vanishes identically. This contradicts

\[
L\in\operatorname{GL}_3(\mathbb C).
\]

Hence none of the four leading-form orbits can occur for a Keller map.

---

## 4. What remains in the conic stratum

The stabilizer classification of the quadratic factor leaves exactly

\[
G=xy,\qquad G=z^2,\qquad G=x^2.
\]

They require a different argument:

- for \(G=xy\) and \(G=x^2\), the characteristic derivation has polynomial invariants of odd degree, so \(M\) need not vanish;
- for \(G=z^2\), degree-six invariants survive, so \(S_2\) need not vanish and the later deformation equations are coupled to it.

Thus the proof above cannot be extended to these cases by a formal specialization.
