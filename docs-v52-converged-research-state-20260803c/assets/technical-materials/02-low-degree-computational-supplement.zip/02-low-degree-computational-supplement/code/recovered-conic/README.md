# Reproducibility files

The theorem note is `conic_reduced_nonsingular_theorem.md`.

The `*_stage.py` scripts construct the exhaustive cubic and quadratic normal forms, retain a general invertible linear part, solve the `S_3=0` equations, and factor the equations `delta_G(S_4)=0`.

The `*_final.py` scripts substitute the exact solutions of those equations into the implicit-conic identity and print the decisive epsilon-six coefficient together with `det L`.

Some scripts print large higher-order coefficients because they are retained for audit. The decisive lines begin with `E 6` and `detL`.
