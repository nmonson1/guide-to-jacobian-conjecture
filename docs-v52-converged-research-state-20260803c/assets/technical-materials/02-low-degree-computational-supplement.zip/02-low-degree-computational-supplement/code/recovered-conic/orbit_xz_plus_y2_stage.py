from pathlib import Path
exec(Path(__file__).with_name('common_generic_orbit.py').read_text().replace("attack(x*z+y**2,'smooth_through_p')",''))
# replicate with accessible return omitted - write direct by exec? We'll just use symbolic setup concise.
import sympy as s
x,y,z=s.symbols('x y z'); G=x*z+y**2
b1,b2,b4,a,b=s.symbols('b1 b2 b4 a b')
C=b4*x+b2*y+b1*z
A=x*C+a*x*y+b*G
B=y*C-a*x*z
H3=s.Matrix([2*x*A,y*A+x*B,2*y*B])
mons=[x**2,x*y,x*z,y**2,y*z,z**2]
u=s.symbols('u0:6');v=s.symbols('v0:6');w=s.symbols('w0:6')
U=sum(c*m for c,m in zip(u,mons));V=sum(c*m for c,m in zip(v,mons));W=sum(c*m for c,m in zip(w,mons))
eq=[c for _,c in s.Poly(y**2*U-2*x*y*V+x**2*W-G*(a*x+b*y)**2,x,y,z).terms()]
tup=next(iter(s.linsolve(eq,list(u)+list(v)+list(w))))
sub=dict(zip(list(u)+list(v)+list(w),tup));U=s.expand(U.subs(sub));V=s.expand(V.subs(sub));W=s.expand(W.subs(sub));H2=s.Matrix([U,V,W])
print('H2 vars')
for q,val in sub.items():
 if q!=val: print(q,'=',val)
ls=s.symbols('l0:9');L=s.Matrix(3,3,ls);LX=L*s.Matrix([x,y,z]);nvec=s.Matrix([y**2,-2*x*y,x**2])
bil=lambda X,Y:s.expand(X[0]*Y[2]+X[2]*Y[0]-2*X[1]*Y[1])
S3=s.expand(G*nvec.dot(LX)+bil(H3,H2)); eq3=[c for _,c in s.Poly(S3,x,y,z).terms()]
sl=s.solve(eq3,ls,dict=True,simplify=False)[0]; L=L.subs(sl);LX=L*s.Matrix([x,y,z])
S4=s.expand(U*W-V**2+bil(H3,LX))
delta=lambda f:s.expand(x*s.diff(G,z)*s.diff(f,x)+y*s.diff(G,z)*s.diff(f,y)+(z*s.diff(G,z)-4*G)*s.diff(f,z))
eq4=list(dict.fromkeys([s.factor(c) for _,c in s.Poly(delta(S4),x,y,z).terms()]))
# identify free symbols names
v1,v2,v4=s.symbols('v1 v2 v4'); w1,w2,w4=s.symbols('w1 w2 w4')
sub1={w4:-4*b4*a,w1:-4*b1*a,v1:2*b1*b}
print('after first')
r=[]
for f in eq4:
 q=s.factor(f.subs(sub1))
 if q and q not in r and -q not in r:r.append(q)
for q in r:print(q)
sub2={v4:2*b*b1}
print('after second')
r2=[]
for f in r:
 q=s.factor(f.subs(sub2))
 if q and q not in r2 and -q not in r2:r2.append(q)
for q in r2:print(q)
