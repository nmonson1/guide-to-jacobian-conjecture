from pathlib import Path
src=Path(__file__).with_name('orbit_z2_plus_xy_final.py').read_text()
# execute only setup through expr construction
exec(src.split("pe=s.Poly(expr,e)")[0])
k=s.symbols('k')
coef=s.Poly(expr,e).coeff_monomial(e**6)
coef=s.factor(coef.subs(t,2*k-4*a*c1))
A0=s.factor(n-6*a**2*b-2*a**2*c1+4*a*k)
B0=s.factor(-m-2*a*b**2-2*a*b*c1+2*b*k)
print('E6 =',coef)
print('E6 expected difference =',s.factor(coef-x**2*z*G*(A0*x+2*B0*y)**2))
det=s.factor(L.det().subs(t,2*k-4*a*c1))
print('detL =',det)
print('det expected difference =',s.factor(det-c2*(-b*A0+2*a*B0)**2))
