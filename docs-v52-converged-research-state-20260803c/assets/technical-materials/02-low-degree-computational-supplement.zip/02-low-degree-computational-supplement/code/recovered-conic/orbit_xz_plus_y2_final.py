# setup
from pathlib import Path
src=Path(__file__).with_name('orbit_xz_plus_y2_stage.py').read_text(); cut=src.split('# identify free symbols names')[0]; exec(cut)
e=s.symbols('e')
# original free symbols already in expressions
v1,v3,v4=s.symbols('v1 v3 v4');w1,w3,w4=s.symbols('w1 w3 w4')
base={w4:-4*b4*a,w1:-4*b1*a,v1:2*b1*b,v4:2*b*b1}
branches={
 'd0':{b4:b1,w3:-a**2-2*a*b2,v3:a*b+2*b*b2},
 'a0':{a:0,w3:2*b*(b1-b4),v3:2*b*b2},
}
for nm,br in branches.items():
 H2r=s.simplify(H2.subs(base).subs(br));H3r=s.simplify(H3.subs(base).subs(br));Lr=s.simplify(L.subs(base).subs(br));
 H4=s.Matrix([G*x**2,G*x*y,G*y**2]);X=s.Matrix([x,y,z]);K=H4+e*H3r+e**2*H2r+e**3*(Lr*X)
 Phi=s.expand(K[0]*K[2]-K[1]**2)
 JJ=s.Matrix([[s.diff(K[i],u) for u in (x,y,z)] for i in range(2)]+[[s.diff(Phi,u) for u in (x,y,z)]])
 expr=s.expand(JJ.det()-e**9*Lr.det()*K[0])
 print('\nBRANCH',nm,'detL=',s.factor(Lr.det()))
 pe=s.Poly(expr,e)
 print('edeg',pe.degree(),'n ecoeff',len(pe.terms()))
 for (j,),co in sorted(pe.terms()):
  fac=s.factor(co)
  print('E',j,'=',fac)
