# Structural reduction for target-span-two quartic leading forms

Let

\[
H_4=(P,Q,0),
\qquad P,Q\in\mathbb C[x,y,z]_4
\]

with \(P,Q\) algebraically independent, and write the third cubic component of \(H_3\) as \(R\). The highest Keller equation is

\[
\operatorname{Jac}(P,Q,R)=0.
\tag{1}
\]

Put

\[
G=\gcd(P,Q),\qquad P=GA,\quad Q=GB,
\qquad n=\deg A=\deg B=4-\deg G.
\]

Set

\[
t=A/B=P/Q,
\qquad
w=R^4/Q^3.
\]

A weighted-homogeneous relation among \(P,Q,R\), with weights \(4,4,3\), shows that \(w\) is algebraic over \(\mathbb C(t)\). The one-variable field

\[
\mathbb C(t,w)\subset\mathbb C(\mathbb P^2)
\]

is rational, so write it as \(\mathbb C(s)\), with

\[
s=A_0/B_0,
\qquad
\deg A_0=
\deg B_0=d,
\qquad
t=\mathcal R(s),
\qquad e=\deg\mathcal R.
\]

Reducedness gives

\[
n=ed.
\tag{2}
\]

Consequently the nonprimitive possibilities are exactly

\[
\begin{array}{c|c|c}
\deg G&n&(e,d)\\ \hline
0&4&(4,1),(2,2)\\
1&3&(3,1)\\
2&2&(2,1).
\end{array}
\]

Whenever \(d=1\), valuation along irreducible divisors shows that both the fixed component \(G\) and the cubic \(R\) are binary in the same two linear forms as \(A_0,B_0\). The only genuinely nonbinary composite case is therefore

\[
\deg G=0,
\qquad
P=U(a_2,b_2),
\qquad
Q=V(a_2,b_2),
\]

where \(a_2,b_2\) are coprime quadrics and \(U,V\) are binary quadratics.

In the primitive coprime case \(G=1\), one has \(w=\rho(t)\). For a pencil fiber \(P-\xi Q\), let a component occur with multiplicity \(m\), and define adjusted orders \(c_\xi\) by adding the denominator contribution three at infinity. Then

\[
4\nu(R)=c_\xi m,
\qquad c_\xi\ge0,
\qquad \sum_{\xi\in\mathbb P^1}c_\xi=3.
\]

Some \(c_\xi\) is odd. For that fiber, every component multiplicity is divisible by four; hence the fiber is

\[
\ell^4.
\]

Thus every target-span-two survivor lies in one of the following exact classes:

1. a binary quartic pencil, with \(R\) binary in the same two linear forms;
2. the quadratic-source-pencil case \((e,d)=(2,2)\);
3. a primitive coprime pencil containing a fourth power \(\ell^4\);
4. a primitive pencil with fixed components supported on special fibers.

This is a finite geometric reduction, not yet an elimination theorem.
