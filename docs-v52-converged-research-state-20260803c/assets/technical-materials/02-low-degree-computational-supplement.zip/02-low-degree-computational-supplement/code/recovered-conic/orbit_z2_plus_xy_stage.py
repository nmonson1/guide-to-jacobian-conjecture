import sympy as s
x,y,z=s.symbols('x y z')
G=z**2+x*y
# params H3
c0,c1,c2,aa,bb=s.symbols('c0 c1 c2 aa bb')
C=c0*x+c1*y+c2*z
A=x*C+aa*x**2+bb*z**2
B=y*C-aa*z**2-bb*y**2
H31=2*x*A
H32=y*A+x*B
H33=2*y*B
D=s.expand(y*A-x*B)
print('D-factor:',s.factor(D))
# general H2 quadratic components
mons2=[x**2,x*y,x*z,y**2,y*z,z**2]
u=s.symbols('u0:6'); v=s.symbols('v0:6'); w=s.symbols('w0:6')
U=sum(a*m for a,m in zip(u,mons2));V=sum(a*m for a,m in zip(v,mons2));W=sum(a*m for a,m in zip(w,mons2))
Llin=aa*x+bb*y
expr=s.Poly(s.expand(y**2*U-2*x*y*V+x**2*W-G*Llin**2),x,y,z)
eqs=[c for mon,c in expr.terms()]
sol=s.linsolve(eqs, list(u)+list(v)+list(w))
print('H2 solution dimension tuple count',len(sol.args))
tup=next(iter(sol))
free=sorted(set().union(*[e.free_symbols for e in tup]) - {aa,bb}, key=str)
print('free count',len(free),free)
for var,val in zip(list(u)+list(v)+list(w),tup):
    if val!=var:
        print(var,'=',val)
# substitute H2 solution
sub=dict(zip(list(u)+list(v)+list(w),tup))
U=s.expand(U.subs(sub));V=s.expand(V.subs(sub));W=s.expand(W.subs(sub))
l=s.symbols('l11 l12 l13 l21 l22 l23 l31 l32 l33')
L1=l[0]*x+l[1]*y+l[2]*z
L2=l[3]*x+l[4]*y+l[5]*z
L3=l[6]*x+l[7]*y+l[8]*z
S3=s.expand(G*(y**2*L1-2*x*y*L2+x**2*L3)+(H31*W+H33*U-2*H32*V))
p3=s.Poly(S3,x,y,z)
print('S3 terms',len(p3.terms()))
# linear solve for l entries
s3eq=[coef for mon,coef in p3.terms()]
solL=s.solve(s3eq,l, dict=True, simplify=False)
print('solL count',len(solL))
if solL:
 for k,vv in solL[0].items(): print(k,'=',s.factor(vv))
 rem=[s.factor(e.subs(solL[0])) for e in s3eq if s.factor(e.subs(solL[0]))!=0]
 print('remaining constraints',len(rem))
 print(rem)
Ls=solL[0]
L1s=s.expand(L1.subs(Ls));L2s=s.expand(L2.subs(Ls));L3s=s.expand(L3.subs(Ls))
S4=s.expand(U*W-V**2 + (H31*L3s+H33*L1s-2*H32*L2s))
# delta
def delta(f):
 return s.expand(2*x*z*s.diff(f,x)+2*y*z*s.diff(f,y)-2*(z**2+2*x*y)*s.diff(f,z))
dS4=s.Poly(delta(S4),x,y,z)
print('dS4 terms',len(dS4.terms()))
conds4=[s.factor(co) for mon,co in dS4.terms() if co!=0]
# unique
uniq=[]
for e in conds4:
 if e not in uniq and -e not in uniq: uniq.append(e)
print('unique conds4',len(uniq))
for e in uniq: print(s.factor(e))
# try groebner factor common/simple solve for l22,l32 etc perhaps
v1,v3,v4=s.symbols('v1 v3 v4'); w1,w3,w4=s.symbols('w1 w3 w4')
sub_basic={w1:-3*aa**2-4*aa*c0, v3:-2*bb**2+2*bb*c1}
rem4=[]
for e in uniq:
 ee=s.factor(e.subs(sub_basic))
 if ee!=0 and ee not in rem4 and -ee not in rem4: rem4.append(ee)
print('after basic',len(rem4))
for e in rem4: print(s.factor(e))
E0=aa*bb-2*aa*c1-2*bb*c0+v1-w3
sub_more={w4:-4*aa*c2,v4:2*bb*c2}
print('after more')
for e in rem4:
 ee=s.factor(e.subs(sub_more))
 if ee!=0: print(ee, ' quotientE=',s.factor(ee/E0**2) if s.rem(s.Poly(ee,*[aa,bb,c0,c1,c2,v1,w3]),s.Poly(E0**2,*[aa,bb,c0,c1,c2,v1,w3]))==0 else '')
# choose w3=t0 free, v1= w3-aa*bb+2aa*c1+2bb*c0
sub_all={w1:-3*aa**2-4*aa*c0, v3:-2*bb**2+2*bb*c1,w4:-4*aa*c2,v4:2*bb*c2,v1:w3-aa*bb+2*aa*c1+2*bb*c0}
S4r=s.factor(S4.subs(sub_all))
print('S4/G=',s.factor(S4r/G))
# L expressions reduced
print('L reduced')
for kk,vv in Ls.items(): print(kk,s.factor(vv.subs(sub_all)))
