# Rank-one quartic leading forms in dimension three

All structural arguments are over an algebraically closed field `k` of characteristic zero. The determinant identities are verified exactly over `Q` by `rank_one_binary_identities.py`.

## Main theorem

Let

\[
F=LX+H_2+H_3+H_4:\mathbb A^3_{\mathbb C}\longrightarrow\mathbb A^3_{\mathbb C},
\qquad \det JF\in k^*,
\]

where `L` is invertible and each `H_i` is homogeneous of degree `i`. Suppose that the highest homogeneous map has target rank one:

\[
H_4=v h
\]

for a nonzero constant vector `v` and a nonzero ternary quartic `h`. Then `F` is a polynomial automorphism.

In particular, none of the binary scalar types

\[
\ell^2mn,\qquad \ell mnp,
\]

and no fixed-component cubic-pencil case can occur in a degree-four counterexample.

The theorem is stronger than a classification by the factorization of `h`: the quartic `h` need not factor into linear forms and need not initially be binary.

---

## 1. Two coordinate reductions

A component of a Keller map has no critical point, since a row of an invertible Jacobian matrix cannot vanish.

### 1.1 Quadratic coordinate lemma

If `f` has degree at most two and no critical point, then `f` is a coordinate. Write

\[
f=\tfrac12X^TAX+b^TX+c
\]

with `A` symmetric. If `b` belonged to `im A`, the equation `AX+b=0` would have a solution. Hence `b\notin im A`. Since `im A=(ker A)^\perp`, there is `u\in ker A` with `b^Tu\ne0`. Thus the directional derivative `D_u f` is a nonzero constant, and a linear change followed by a triangular change sends `f` to a variable.

### 1.2 Cubic-cube coordinate lemma

If `f` has degree at most three, no critical point, and highest form

\[
f_3=\lambda\ell^3,\qquad \lambda\ne0,
\]

then `f` is a coordinate. Put `\ell=x` and write the other variables as `w\in k^2`. Since there are no cubic terms involving `w`,

\[
\nabla_w f=Mw+ax+b
\]

with `M` symmetric.

If this affine system is never solvable, linear algebra yields a vector `u\in ker M` with `u^Ta=0` and `u^Tb\ne0`, so `D_u f` is constant. If it is solvable, then either variation along `ker M` makes `f_x` vanish, or substitution of a solution `w=w(x)` leaves a genuine quadratic equation in `x` whose leading coefficient is `3\lambda`; over an algebraically closed field it has a root, producing a critical point. Therefore the constant-direction alternative is forced, and `f` is a coordinate.

The straightening automorphisms in these two lemmas, and their inverses, may be chosen of degree at most three. Straightening such a component of a degree-four Keller map reduces the other two components to a plane Keller map over `k(t)` of degree at most twelve. The known plane degree bound rules out a counterexample at this degree. The original map is then birational, and a birational Keller map is a polynomial automorphism.

Consequently, in the proof below we may discard either of the following situations:

* the first two cubic components are linearly dependent, because a target combination then has degree at most two;
* their pencil contains the cube of a linear form, because a target combination then satisfies the cubic-cube lemma.

---

## 2. The highest equation and the transverse cubic pencil

After a target linear change, write

\[
H_4=(0,0,h),\qquad H_3=(P,Q,R),
\]

where `P,Q` are homogeneous cubics. The highest nonautomatic Keller equation is

\[
dP\wedge dQ\wedge dh=0.
\tag{2.1}
\]

Assume that `P,Q` are linearly independent. Because they are homogeneous of the same degree, they are algebraically independent: a homogeneous algebraic relation in two variables factors into linear forms and would make `P,Q` proportional. Hence (2.1) says that `h` is algebraic over `k(P,Q)`.

We next reduce every independent pencil to either a cube-containing pencil or a binary pencil.

---

## 3. Coprime cubic pencils

### Proposition 3.1

Assume

\[
\gcd(P,Q)=1
\]

and (2.1). Then either the pencil `\langle P,Q\rangle` contains a cube of a linear form, or there are independent linear forms `a,b` such that

\[
P,Q\in k[a,b]_3.
\]

### Proof

Put

\[
t=P/Q,\qquad w=h^3/Q^4.
\]

The scalar action on the source fixes `t,w` and gives `Q` weight three. Since `h` is algebraic over `k(t,Q)`, so is `w`. The monic minimal polynomial of `w` over `k(t,Q)` is fixed by the scalar action; its coefficients therefore lie in the fixed field `k(t)`. Hence

\[
w\text{ is algebraic over }k(t).
\tag{3.1}
\]

Let `M=k(\mathbb P^2)` be the degree-zero function field.

First suppose that `k(t)` is relatively algebraically closed in `M`. Since `w\in M`, equation (3.1) gives

\[
w=R(t),\qquad R\in k(t)^*.
\tag{3.2}
\]

For `\xi\in\mathbb P^1`, let `F_\xi=P-\xi Q`, with `F_\infty=Q`, and put

\[
r_\xi=\operatorname{ord}_\xi R,
\qquad
c_\xi=r_\xi+4\mathbf 1_{\xi=\infty}.
\]

If an irreducible factor `g` occurs in `F_\xi` with multiplicity `m_g`, the `g`-valuation of (3.2) is

\[
3\nu_g(h)=c_\xi m_g.
\tag{3.3}
\]

Thus `c_\xi\ge0`. If `F_\xi` is not a cube, some component multiplicity is prime to three, so (3.3) forces

\[
c_\xi\in3\mathbb Z_{\ge0}.
\]

But

\[
\sum_{\xi\in\mathbb P^1}c_\xi
=
\sum_\xi r_\xi+4
=4,
\]

which is impossible if no fiber is a cube.

Now suppose that `k(t)` is not relatively algebraically closed in `M`. Its relative algebraic closure is the function field of a rational curve, so choose a parameter `s=A/B`, with `A,B` coprime homogeneous forms of the same degree `d`, and write

\[
t=\mathcal R(s)=U(A,B)/V(A,B),
\]

where `U,V` are coprime binary forms of degree `e>1`. Reducedness of the two ratios gives

\[
P=U(A,B),\qquad Q=V(A,B)
\]

up to a common scalar. Taking degrees yields

\[
3=ed.
\]

Primality of three gives `e=3,d=1`; hence `A,B` are linear and the pencil is binary. ∎

---

## 4. Fixed-component cubic pencils

This is the additional reduction needed to cover arbitrary ternary quartics.

### Proposition 4.1

Assume (2.1), `P,Q` independent, and

\[
G=\gcd(P,Q)\ne1.
\]

Then either the pencil contains a cube of a linear form, or `P,Q,h` are all polynomials in two independent linear forms.

### Proof

Write

\[
P=GA,\qquad Q=GB,
\qquad \gcd(A,B)=1.
\]

Since `P,Q` are independent, `g=\deg G` is either one or two. Again put

\[
t=A/B=P/Q,\qquad w=h^3/Q^4.
\]

The scalar-minimal-polynomial argument of Proposition 3.1 shows that `w` is algebraic over `k(t)`.

### Case `g=2`

Here `A,B` are independent linear forms, so `k(t)` is relatively algebraically closed in `k(\mathbb P^2)`, and

\[
w=R(t).
\tag{4.1}
\]

Let `e` be an irreducible factor of `G`, of multiplicity `m\in\{1,2\}`. If `t` is nonconstant along `e=0`, then `e\nmid B` and

\[
\nu_e(R(t))=0.
\]

Taking the `e`-valuation of (4.1) gives

\[
3\nu_e(h)=4m,
\]

which is impossible. Thus `t` is constant on every irreducible component of `G`. Each such component is therefore a fiber of the linear pencil `\langle A,B\rangle`, hence is itself a line in that pencil. Consequently

\[
G\in k[A,B],
\]

so `P,Q` are binary in `A,B`. Since their planar Jacobian is nonzero, equation (2.1) then forces `h` to be binary in the same two forms.

### Case `g=1`

Write `G=\ell`; then `A,B` are coprime quadrics.

First suppose that `k(t)` is relatively algebraically closed. Again `w=R(t)`. If `t` is nonconstant on `\ell=0`, then

\[
\nu_\ell(R(t))=0,
\qquad
\nu_\ell(Q)=1,
\]

and hence `3\nu_\ell(h)=4`, impossible. Thus `t` is constant on `\ell=0`. After a linear change of the pencil parameter, write

\[
A=\ell m
\]

with `m` linear and `\ell\nmid B`.

If `m` is proportional to `\ell`, then

\[
P=\ell A=\ell^3
\]

is a cube. Otherwise let `r=\operatorname{ord}_0R`. At `m=0` and `\ell=0`, respectively, valuation of `w=R(A/B)` gives

\[
3\nu_m(h)=r,
\qquad
3\nu_\ell(h)=r+4,
\]

which is impossible modulo three.

It remains to suppose that `k(t)` is not relatively algebraically closed. Since the reduced pencil `A/B` has degree two, primality of two gives independent linear forms `a,b` and binary quadratics `U,V` such that

\[
A=U(a,b),\qquad B=V(a,b),
\]

and the relative algebraic closure is `k(a/b)`. Thus

\[
w\in k(a/b).
\]

If `a/b` is nonconstant on `\ell=0`, then `\nu_\ell(w)=0` and `\nu_\ell(Q)=1`, again giving `3\nu_\ell(h)=4`. Therefore `a/b` is constant on `\ell=0`, so

\[
\ell\in\langle a,b\rangle.
\]

It follows that `P,Q` are binary in `a,b`; equation (2.1) then forces `h` to be binary as well. ∎

Combining Propositions 3.1 and 4.1, every serious independent transverse cubic pencil is binary.

---

## 5. Universal binary determinant identities

Choose source coordinates `x,y,z` so that

\[
P,Q\in k[x,y]_3,
\qquad
h\in k[x,y]_4.
\]

The nonzero planar Jacobian is

\[
W=J(P,Q),
\]

and put

\[
U=J(P,h),\qquad V=J(Q,h).
\]

Write all possible `z`-dependent lower terms as

\[
\begin{aligned}
(H_2)_1&=A_0(x,y)+z a(x,y)+\alpha z^2,\\
(H_2)_2&=B_0(x,y)+z b(x,y)+\beta z^2,\\
(H_2)_3&=C_0(x,y)+z r(x,y)+c z^2,\\
(H_3)_3&=R_0(x,y)+z q(x,y)+z^2\ell(x,y)+\rho z^3,
\end{aligned}
\tag{5.1}
\]

where `a,b,r,\ell` are linear and `q` is quadratic. The first two components of `H_3` are `P,Q`, and `H_4=(0,0,h)`.

For an arbitrary invertible linear part `L`, introduce `T`:

\[
\det\bigl(L+T JH_2+T^2JH_3+T^3JH_4\bigr)
=
\det L+\sum_{j=1}^7T^jE_j.
\]

Exact expansion gives:

\[
[z^2]E_6=3\rho W,
\tag{5.2}
\]

and, after `\rho=0`,

\[
[z]E_6=2\bigl(W\ell+\alpha V-\beta U\bigr),
\tag{5.3}
\]

\[
[z^0]E_6=Wq+Va-Ub.
\tag{5.4}
\]

Put

\[
S=\alpha Q-\beta P.
\]

Still with `\rho=0`,

\[
[z^3]E_5=-2J(\ell,S).
\tag{5.5}
\]

After `\alpha=\beta=\ell=\rho=0`, the next three identities are

\[
\begin{aligned}
[z]E_5={}&-4J(a,b)h-qJ(a,Q)+3QJ(a,q)\\
&+qJ(b,P)-3P J(b,q)+2cW,
\end{aligned}
\tag{5.6}
\]

\[
[z^2]E_4=-J(a,b)q+2c\bigl(J(a,Q)-J(b,P)\bigr),
\tag{5.7}
\]

\[
[z^3]E_3=2cJ(a,b).
\tag{5.8}
\]

The accompanying script verifies (5.2)--(5.8) symbolically over `Q`, retaining arbitrary coefficients in all forms and in `L`.

---

## 6. The first syzygy is trivial unless the pencil contains a cube

Equation (5.2) gives `\rho=0`. Equations (5.3) and (5.5) give

\[
W\ell+J(S,h)=0,
\qquad
J(\ell,S)=0.
\tag{6.1}
\]

Assume that the pencil `\langle P,Q\rangle` contains no cube.

If `\ell\ne0`, the second equation in (6.1) implies

\[
S=\lambda\ell^3.
\]

Cube-freeness gives `S=0`; independence of `P,Q` gives `\alpha=\beta=0`, and the first equation then gives `W\ell=0`, a contradiction.

Thus `\ell=0`. The first equation becomes

\[
J(S,h)=0.
\]

For nonzero homogeneous binary forms of coprime degrees three and four, vanishing Jacobian forces them to be powers of a common linear form. Hence a nonzero `S` would be a cube. Therefore `S=0`, and independence gives

\[
\boxed{\rho=\ell=\alpha=\beta=0.}
\tag{6.2}
\]

---

## 7. The second syzygy is also trivial unless the pencil contains a cube

Let

\[
D=J(a,b)\in k.
\]

If `D\ne0`, equations (5.8), (5.7), and (5.6), in that order, give

\[
c=0,\qquad q=0,\qquad -4Dh=0,
\]

which is impossible. Hence `D=0`.

If `a=b=0`, equation (5.4) gives `q=0`, and (5.6) then gives `c=0`.

Otherwise `a,b` are dependent. A `GL_2` row operation on the first two target coordinates puts

\[
b=0,\qquad a\ne0,
\]

without changing the cubic pencil. Equation (5.7) becomes

\[
2cJ(a,Q)=0.
\]

If `c\ne0`, then `Q` is a scalar multiple of `a^3`, a cube. Thus `c=0` in the cube-free branch.

Equation (5.6) is now

\[
-qJ(a,Q)+3QJ(a,q)=0.
\tag{7.1}
\]

If `q=0`, equation (5.4) gives `J(Q,h)=0`; coprimality of degrees three and four again makes `Q` a cube.

If `q\ne0`, choose coordinates with `a=x`. Equation (7.1) reads

\[
qQ_y-3Qq_y=0,
\]

so

\[
\partial_y(Q/q^3)=0.
\]

Homogeneity gives

\[
Q/q^3=\lambda x^{-3},
\qquad
x^3Q=\lambda q^3.
\]

Unique factorization then forces `Q` to be a cube. This contradiction proves

\[
\boxed{a=b=q=c=0.}
\tag{7.2}
\]

---

## 8. Terminal triangular reduction

After (6.2) and (7.2), the entire map has the form

\[
\begin{aligned}
F_1&=f_1(x,y)+\gamma z,\\
F_2&=f_2(x,y)+\phi z,\\
F_3&=f_3(x,y)+(\mu+r(x,y))z,
\end{aligned}
\tag{8.1}
\]

where `r` is linear, `\deg f_1,\deg f_2\le3`, and `\deg f_3\le4`. Exact determinant expansion gives

\[
[z]\det JF
=J\bigl(r,\phi f_1-\gamma f_2\bigr).
\tag{8.2}
\]

Its highest homogeneous part is

\[
J\bigl(r,\phi P-\gamma Q\bigr).
\]

If `(\gamma,\phi)\ne(0,0)` and `r\ne0`, equation (8.2) says that the nonzero cubic `\phi P-\gamma Q` is a polynomial in the linear form `r`; it is therefore a cube, contradicting cube-freeness. Hence `r=0`.

The coefficient vector `(\gamma,\phi,\mu)` is nonzero. A target linear transformation sends it to the third basis vector, putting the map into the form

\[
(G_1(x,y),G_2(x,y),z+G_3(x,y)).
\]

The plane pair has constant nonzero Jacobian and degree at most four, hence is a polynomial automorphism.

If `\gamma=\phi=0`, then

\[
\det JF=J(f_1,f_2)(\mu+r).
\]

A product of two polynomials equal to a nonzero constant has both factors constant. Thus `r=0`, the plane pair has constant Jacobian and degree at most three, and the map is again triangular over a plane automorphism.

This finishes the binary cube-free branch and hence the main theorem.

---

## 9. Consequences for the requested three cases

The preceding proof closes all three remaining rank-one tasks simultaneously.

| Requested case | Reduction | Result |
|---|---|---|
| Binary `2+1+1`, `h=\ell^2mn` | Universal binary identities | Eliminated |
| Square-free binary quartic | Universal binary identities | Eliminated |
| General ternary quartic with fixed-component cubic pencil | Proposition 4.1 reduces to cube or binary | Eliminated |

Therefore every degree-four Keller counterexample, if one exists, must have a highest homogeneous map of target rank two. The next leading strata are the nonlinear composite-pencil types

\[
(e,r,k)=(2,1,2),\ (1,1,3),\ (0,1,4),\ (0,2,2),
\]

and the imprimitive rank-two line-image cases.

---

## 10. Certificate scope

`rank_one_binary_identities.py` is a deterministic exact certificate generator. It verifies all determinant identities (5.2)--(5.8) and the terminal identity (8.2) over `Q`. The projective pencil reductions and valuation arguments are human proofs and do not depend on numerical or modular evidence.

The theorem should still be independently audited before publication, especially:

1. the scalar-fixed-field step in Propositions 3.1 and 4.1;
2. the relative-algebraic-closure/composite-pencil reduction;
3. the cubic-cube coordinate lemma and its degree bound after straightening.
