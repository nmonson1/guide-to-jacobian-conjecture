# Completion of the rank-one quartic attack

This directory contains a proof draft and exact symbolic certificate for the theorem:

> A three-dimensional degree-four Keller map whose highest homogeneous map is a constant target vector times an arbitrary ternary quartic is a polynomial automorphism.

Files:

- `rank_one_quartic_theorem.md`: complete structural proof draft.
- `rank_one_binary_identities.py`: exact SymPy verification of the universal determinant identities.
- `rank_one_binary_identities_output.txt`: stored output from a clean run.
- `sha256.txt`: integrity manifest.

The result closes, in particular, the binary `2+1+1`, square-free binary, and fixed-component ternary cubic-pencil cases.
