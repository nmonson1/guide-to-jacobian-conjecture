"""Exact symbolic verifier for the universal binary rank-one quartic identities.

All arithmetic is exact over Q.  The script keeps:
  * arbitrary binary cubics P,Q;
  * an arbitrary binary quartic h;
  * every binary lower term relevant to H_2,H_3;
  * every possible z-dependent lower term;
  * an arbitrary 3x3 linear part L.

It expands det(L + T JH_2 + T^2 JH_3 + T^3 JH_4) and verifies the
coefficient identities used in the rank-one quartic theorem.
"""
from __future__ import annotations

import sympy as s

x, y, z, T = s.symbols("x y z T")
X = s.Matrix([x, y, z])

# Arbitrary transverse binary cubics and scalar binary quartic.
p30, p21, p12, p03 = s.symbols("p30 p21 p12 p03")
q30, q21, q12, q03 = s.symbols("q30 q21 q12 q03")
h40, h31, h22, h13, h04 = s.symbols("h40 h31 h22 h13 h04")
P = p30*x**3 + p21*x**2*y + p12*x*y**2 + p03*y**3
Q = q30*x**3 + q21*x**2*y + q12*x*y**2 + q03*y**3
h = h40*x**4 + h31*x**3*y + h22*x**2*y**2 + h13*x*y**3 + h04*y**4

# Arbitrary binary quadratic terms in H_2.
A20, A11, A02, B20, B11, B02, C20, C11, C02 = s.symbols(
    "A20 A11 A02 B20 B11 B02 C20 C11 C02"
)
A0 = A20*x**2 + A11*x*y + A02*y**2
B0 = B20*x**2 + B11*x*y + B02*y**2
C0 = C20*x**2 + C11*x*y + C02*y**2

# All z-dependent terms in H_2.
a10, a01, b10, b01, r10, r01 = s.symbols(
    "a10 a01 b10 b01 r10 r01"
)
a = a10*x + a01*y
b = b10*x + b01*y
r = r10*x + r01*y
alpha, beta, c = s.symbols("alpha beta c")
H2 = s.Matrix([
    A0 + z*a + alpha*z**2,
    B0 + z*b + beta*z**2,
    C0 + z*r + c*z**2,
])

# The first two cubic components are P,Q.  Keep the full third cubic.
R30, R21, R12, R03 = s.symbols("R30 R21 R12 R03")
R0 = R30*x**3 + R21*x**2*y + R12*x*y**2 + R03*y**3
q20, q11, q02 = s.symbols("q20 q11 q02")
q = q20*x**2 + q11*x*y + q02*y**2
ell10, ell01, rho = s.symbols("ell10 ell01 rho")
ell = ell10*x + ell01*y
H3 = s.Matrix([P, Q, R0 + z*q + z**2*ell + rho*z**3])
H4 = s.Matrix([0, 0, h])

# Completely arbitrary linear part.
l11, l12, l13, l21, l22, l23, l31, l32, l33 = s.symbols(
    "l11 l12 l13 l21 l22 l23 l31 l32 l33"
)
L = s.Matrix([
    [l11, l12, l13],
    [l21, l22, l23],
    [l31, l32, l33],
])


def J(f: s.Expr, g: s.Expr) -> s.Expr:
    return s.expand(s.diff(f, x)*s.diff(g, y) - s.diff(f, y)*s.diff(g, x))


def zcoeff(f: s.Expr, degree: int) -> s.Expr:
    return s.expand(s.Poly(s.expand(f), z).coeff_monomial(z**degree))


def assert_zero(f: s.Expr, label: str) -> None:
    remainder = s.expand(f)
    if remainder != 0:
        raise AssertionError(f"{label} failed: {remainder}")
    print(f"verified: {label}")


J2, J3, J4 = (H.jacobian(X) for H in (H2, H3, H4))
scaled_det = s.expand((L + T*J2 + T**2*J3 + T**3*J4).det())
PT = s.Poly(scaled_det, T)
E = {i: s.expand(PT.coeff_monomial(T**i)) for i in range(1, 8)}

W = J(P, Q)
U = J(P, h)
V = J(Q, h)
S1 = s.expand(W*ell + alpha*V - beta*U)
S0 = s.expand(W*q + V*a - U*b)
S = s.expand(alpha*Q - beta*P)

# Highest equations.
assert_zero(zcoeff(E[6], 2) - 3*rho*W, "[z^2] E_6 = 3 rho W")
E6_rho0 = s.expand(E[6].subs(rho, 0))
assert_zero(zcoeff(E6_rho0, 1) - 2*S1, "[z] E_6 = 2 S_1 after rho=0")
assert_zero(zcoeff(E6_rho0, 0) - S0, "[1] E_6 = S_0 after rho=0")
E5_rho0 = s.expand(E[5].subs(rho, 0))
assert_zero(
    zcoeff(E5_rho0, 3) + 2*J(ell, S),
    "[z^3] E_5 = -2 J(ell, alpha Q-beta P)",
)

# Identities after the first syzygy has been shown to be trivial in the
# cube-free branch: alpha=beta=ell=rho=0.
high_zero = {rho: 0, alpha: 0, beta: 0, ell10: 0, ell01: 0}
E5_reduced = s.expand(E[5].subs(high_zero))
E4_reduced = s.expand(E[4].subs(high_zero))
E3_reduced = s.expand(E[3].subs(high_zero))

expected_E5_z = s.expand(
    -4*J(a, b)*h
    - q*J(a, Q) + 3*Q*J(a, q)
    + q*J(b, P) - 3*P*J(b, q)
    + 2*c*W
)
expected_E4_z2 = s.expand(-J(a, b)*q + 2*c*(J(a, Q) - J(b, P)))
expected_E3_z3 = s.expand(2*c*J(a, b))

assert_zero(zcoeff(E5_reduced, 1) - expected_E5_z, "[z] E_5 reduced identity")
assert_zero(zcoeff(E4_reduced, 2) - expected_E4_z2, "[z^2] E_4 reduced identity")
assert_zero(zcoeff(E3_reduced, 3) - expected_E3_z3, "[z^3] E_3 reduced identity")

# Terminal determinant identity.  After all nonlinear z terms above vanish,
# write F_1=f_1+gamma*z, F_2=f_2+phi*z,
# F_3=f_3+(mu+r)*z.  Its z coefficient is J(r, phi*f_1-gamma*f_2).
f10, f11, f12, f13, f14, f15 = s.symbols("f10 f11 f12 f13 f14 f15")
g10, g11, g12, g13, g14, g15 = s.symbols("g10 g11 g12 g13 g14 g15")
k10, k11, k12, k13, k14, k15 = s.symbols("k10 k11 k12 k13 k14 k15")
# Generic polynomials are enough for the determinant identity; degree is immaterial.
f1 = f10 + f11*x + f12*y + f13*x**2 + f14*x*y + f15*y**2 + P
g1 = g10 + g11*x + g12*y + g13*x**2 + g14*x*y + g15*y**2 + Q
f3 = k10 + k11*x + k12*y + k13*x**2 + k14*x*y + k15*y**2 + h
gamma, phi, mu = s.symbols("gamma phi mu")
Fterminal = s.Matrix([
    f1 + gamma*z,
    g1 + phi*z,
    f3 + (mu + r)*z,
])
terminal_det = s.expand(Fterminal.jacobian(X).det())
assert_zero(
    zcoeff(terminal_det, 1) - J(r, phi*f1 - gamma*g1),
    "terminal z coefficient",
)

print("ALL UNIVERSAL RANK-ONE BINARY IDENTITIES VERIFIED EXACTLY OVER Q")
