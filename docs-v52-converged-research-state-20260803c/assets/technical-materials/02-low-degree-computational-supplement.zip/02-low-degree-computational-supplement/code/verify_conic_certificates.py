"""Exact certificates for the four reduced conic orbits in the paper.

The recovered exploratory scripts printed the decisive factorizations.  This
checker reconstructs the same normal forms and fails unless all of the
following hold identically over Q:

* y*A - x*B = G*ell and n.H2 = G*ell**2;
* the S_2 and S_3 normal equations vanish;
* delta_G(S_4) vanishes after the stated parameter reductions;
* the smooth-through-the-base-point calculation has the exhaustive
  set-theoretic split a=0 or [z]C=[x]C;
* the epsilon-six coefficient and det(L) have the five factorizations
  displayed in the manuscript.

No random specialization, numerical arithmetic, or division by a parameter
is used.
"""

from __future__ import annotations

import sympy as s

x, y, z, epsilon = s.symbols("x y z epsilon")
XYZ = (x, y, z)
X = s.Matrix(XYZ)
nvec = s.Matrix([y**2, -2*x*y, x**2])


def assert_zero(expr: s.Expr, label: str) -> None:
    remainder = s.expand(expr)
    if remainder != 0:
        raise AssertionError(f"{label} failed: {s.factor(remainder)}")


def coefficients(expr: s.Expr) -> list[s.Expr]:
    return [
        s.factor(coefficient)
        for _, coefficient in s.Poly(s.expand(expr), *XYZ).terms()
        if coefficient != 0
    ]


def contains_scalar_multiple(
    expressions: list[s.Expr], target: s.Expr, label: str
) -> None:
    target = s.factor(target)
    for expression in expressions:
        ratio = s.cancel(expression / target)
        if ratio != 0 and not ratio.free_symbols:
            return
    raise AssertionError(f"{label}: no scalar multiple of {target} was found")


def bilinear(first: s.Matrix, second: s.Matrix) -> s.Expr:
    return s.expand(
        first[0]*second[2] + first[2]*second[0]
        - 2*first[1]*second[1]
    )


def delta(G: s.Expr, function: s.Expr) -> s.Expr:
    Gz = s.diff(G, z)
    return s.expand(
        x*Gz*s.diff(function, x)
        + y*Gz*s.diff(function, y)
        + (z*Gz - 4*G)*s.diff(function, z)
    )


def build_linear_reduction(
    G: s.Expr,
    A: s.Expr,
    B: s.Expr,
    ell: s.Expr,
    quadratic_monomials: list[s.Expr],
) -> tuple[s.Matrix, s.Matrix, s.Matrix]:
    """Solve n.H2=G*ell^2 and S3=0 without parameter division."""

    H3 = s.Matrix([2*x*A, y*A + x*B, 2*y*B])

    u = s.symbols("u0:6")
    v = s.symbols("v0:6")
    w = s.symbols("w0:6")
    U = sum(c*m for c, m in zip(u, quadratic_monomials))
    V = sum(c*m for c, m in zip(v, quadratic_monomials))
    W = sum(c*m for c, m in zip(w, quadratic_monomials))
    variables = list(u) + list(v) + list(w)
    equations = coefficients(y**2*U - 2*x*y*V + x**2*W - G*ell**2)
    solutions = s.linsolve(equations, variables)
    if len(solutions.args) != 1:
        raise AssertionError("quadratic normal equation is not one affine family")
    solution = next(iter(solutions))
    substitution = dict(zip(variables, solution))
    H2 = s.Matrix(
        [
            s.expand(U.subs(substitution)),
            s.expand(V.subs(substitution)),
            s.expand(W.subs(substitution)),
        ]
    )

    linear_symbols = s.symbols("l0:9")
    L = s.Matrix(3, 3, linear_symbols)
    S3 = s.expand(G*nvec.dot(L*X) + bilinear(H3, H2))
    linear_solutions = s.solve(
        coefficients(S3), linear_symbols, dict=True, simplify=False
    )
    if len(linear_solutions) != 1:
        raise AssertionError("S3=0 is not one affine linear family")
    L = s.simplify(L.subs(linear_solutions[0]))
    return H3, H2, L


def normal_data(
    G: s.Expr, H3: s.Matrix, H2: s.Matrix, L: s.Matrix
) -> tuple[s.Expr, s.Expr, s.Expr, s.Expr]:
    H4 = s.Matrix([G*x**2, G*x*y, G*y**2])
    K = H4 + epsilon*H3 + epsilon**2*H2 + epsilon**3*(L*X)
    Phi = s.expand(K[0]*K[2] - K[1]**2)
    phi_poly = s.Poly(Phi, epsilon)
    S2 = s.expand(phi_poly.coeff_monomial(epsilon**2))
    S3 = s.expand(phi_poly.coeff_monomial(epsilon**3))
    S4 = s.expand(phi_poly.coeff_monomial(epsilon**4))

    chain_jacobian = s.Matrix(
        [
            [s.diff(K[index], variable) for variable in XYZ]
            for index in range(2)
        ]
        + [[s.diff(Phi, variable) for variable in XYZ]]
    )
    residual = s.expand(
        chain_jacobian.det() - epsilon**9*L.det()*K[0]
    )
    E6 = s.expand(s.Poly(residual, epsilon).coeff_monomial(epsilon**6))
    return S2, S3, S4, E6


def certify(
    label: str,
    G: s.Expr,
    A: s.Expr,
    B: s.Expr,
    ell: s.Expr,
    H3: s.Matrix,
    H2: s.Matrix,
    L: s.Matrix,
    expected_E6: s.Expr,
    expected_det: s.Expr,
) -> None:
    assert_zero(y*A - x*B - G*ell, f"{label}: cubic normal form")
    assert_zero(nvec.dot(H2) - G*ell**2, f"{label}: quadratic normal form")
    S2, S3, S4, E6 = normal_data(G, H3, H2, L)
    assert_zero(S2, f"{label}: S2")
    assert_zero(S3, f"{label}: S3")
    assert_zero(delta(G, S4), f"{label}: delta(S4)")
    assert_zero(E6 - expected_E6, f"{label}: epsilon-six factorization")
    assert_zero(L.det() - expected_det, f"{label}: determinant factorization")
    print(f"verified: {label}")


def certify_z2_plus_xy() -> None:
    G = z**2 + x*y
    a, b, c0, c1, c2, t, m, n, k = s.symbols(
        "a b c0 c1 c2 t m n k"
    )
    C = c0*x + c1*y + c2*z
    ell = a*x + b*y
    A = x*C + a*x**2 + b*z**2
    B = y*C - a*z**2 - b*y**2
    H3 = s.Matrix([2*x*A, y*A + x*B, 2*y*B])

    w1 = -3*a**2 - 4*a*c0
    v3 = -2*b**2 + 2*b*c1
    w4 = -4*a*c2
    v4 = 2*b*c2
    w3 = t
    v1 = t - a*b + 2*a*c1 + 2*b*c0
    U = (
        (2*a*b + 2*v1 - w3)*x**2
        + (b**2 + 2*v3)*x*y
        + 2*v4*x*z
        + b**2*z**2
    )
    V = (
        (-a**2/2 + w1/2)*x**2
        + v1*x*y
        + (w4/2)*x*z
        + v3*y**2
        + v4*y*z
        - a*b*z**2
    )
    W = w1*x*y + w3*y**2 + w4*y*z + a**2*z**2
    H2 = s.Matrix([s.expand(U), s.expand(V), s.expand(W)])

    L = s.Matrix(
        [
            [
                2*(-a*b**2 + 2*a*b*c1 + b**2*c0 + m),
                2*b**2*(-b + c1),
                2*b**2*c2,
            ],
            [
                -(2*a**2*b + 2*a**2*c1 + 4*a*b*c0 - n)/2,
                m,
                -2*a*b*c2,
            ],
            [2*a**2*(a + c0), n, 2*a**2*c2],
        ]
    )
    terminal_substitution = {t: 2*k - 4*a*c1}
    H2 = s.simplify(H2.subs(terminal_substitution))
    L = s.simplify(L.subs(terminal_substitution))
    A0 = n - 6*a**2*b - 2*a**2*c1 + 4*a*k
    B0 = -m - 2*a*b**2 - 2*a*b*c1 + 2*b*k
    certify(
        "G=z^2+xy",
        G,
        A,
        B,
        ell,
        H3,
        H2,
        L,
        x**2*z*G*(A0*x + 2*B0*y)**2,
        c2*(-b*A0 + 2*a*B0)**2,
    )


def certify_xz_plus_y2() -> None:
    G = x*z + y**2
    a, b, b1, b2, b4 = s.symbols("a b b1 b2 b4")
    C = b4*x + b2*y + b1*z
    ell = a*x + b*y
    A = x*C + a*x*y + b*G
    B = y*C - a*x*z
    monomials = [x**2, x*y, x*z, y**2, y*z, z**2]
    H3, H2, L = build_linear_reduction(G, A, B, ell, monomials)

    v1, v3, v4 = s.symbols("v1 v3 v4")
    w1, w3, w4 = s.symbols("w1 w3 w4")
    l4, l7 = s.symbols("l4 l7")
    base = {w4: -4*b4*a, w1: -4*b1*a, v1: 2*b1*b, v4: 2*b*b1}

    # One coefficient of delta(S4) is a nonzero scalar multiple of
    # a^2*(b1-b4)^2, so over C the solution set is covered by a=0 and
    # b1=b4.  On each branch two further square coefficients force the
    # substitutions used below.
    _, _, S4, _ = normal_data(G, H3, H2, L)
    stage_coefficients = coefficients(delta(G, S4).subs(base))
    contains_scalar_multiple(
        stage_coefficients,
        a**2*(b1 - b4)**2,
        "smooth-through-p primary branch split",
    )

    d0_coefficients = [
        s.factor(value.subs({b4: b1})) for value in stage_coefficients
    ]
    contains_scalar_multiple(
        d0_coefficients,
        (a**2 + 2*a*b2 + w3)**2,
        "smooth-through-p b1=b4 branch: w3",
    )
    contains_scalar_multiple(
        d0_coefficients,
        (-a*b - 2*b*b2 + v3)**2,
        "smooth-through-p b1=b4 branch: v3",
    )

    a0_coefficients = [
        s.factor(value.subs({a: 0})) for value in stage_coefficients
    ]
    contains_scalar_multiple(
        a0_coefficients,
        (w3 - 2*b*(b1 - b4))**2,
        "smooth-through-p a=0 branch: w3",
    )
    contains_scalar_multiple(
        a0_coefficients,
        (v3 - 2*b*b2)**2,
        "smooth-through-p a=0 branch: v3",
    )

    branch_d0 = {
        b4: b1,
        w3: -a**2 - 2*a*b2,
        v3: a*b + 2*b*b2,
    }
    H2_d0 = s.simplify(H2.subs(base).subs(branch_d0))
    L_d0 = s.simplify(L.subs(base).subs(branch_d0))
    A0 = 2*a**3 + 2*a**2*b2 + l7
    certify(
        "G=xz+y^2, [z]C=[x]C",
        G,
        A.subs(branch_d0),
        B.subs(branch_d0),
        ell,
        H3.subs(branch_d0),
        H2_d0,
        L_d0,
        s.Rational(1, 2)*x**3*G*(A0*x - 2*l4*y)**2,
        b1*(b*A0 + 2*a*l4)**2,
    )

    branch_a0 = {
        a: 0,
        w3: 2*b*(b1 - b4),
        v3: 2*b*b2,
    }
    H2_a0 = s.simplify(H2.subs(base).subs(branch_a0))
    L_a0 = s.simplify(L.subs(base).subs(branch_a0))
    forced_line = l7*x + (4*b**2*(b1 - b4) - 2*l4)*y
    certify(
        "G=xz+y^2, a=0",
        G,
        A.subs(branch_a0),
        B.subs(branch_a0),
        ell.subs(branch_a0),
        H3.subs(branch_a0),
        H2_a0,
        L_a0,
        s.Rational(1, 2)*x**3*G*forced_line**2,
        b**2*b1*l7**2,
    )


def certify_generic_orbit(G: s.Expr, label: str, half: bool) -> None:
    a, b, b1, b2, b4 = s.symbols("a b b1 b2 b4")
    C = b4*x + b2*y + b1*z
    ell = a*x + b*y
    A = x*C + b*G
    B = y*C - a*G
    monomials = [z**2, y*z, y**2, x*z, x*y, x**2]
    H3, H2, L = build_linear_reduction(G, A, B, ell, monomials)
    v1, v2, v4 = s.symbols("v1 v2 v4")
    w1, w2, w4 = s.symbols("w1 w2 w4")
    l4, l7 = s.symbols("l4 l7")
    reduction = {
        w1: -4*b1*a,
        w4: -4*b4*a,
        v2: 2*b2*b,
        v1: 2*b1*b,
        v4: w2 + 2*a*b2 + 2*b*b4,
    }
    H2 = s.simplify(H2.subs(reduction))
    L = s.simplify(L.subs(reduction))
    A0 = 6*a**2*b2 + 2*a*w2 + l7
    B0 = 4*a*b*b2 + 2*b*w2 - 2*l4
    E6 = x**2*z*G*(A0*x + B0*y)**2
    if half:
        E6 = s.Rational(1, 2)*x**3*G*(A0*x + B0*y)**2
    certify(
        label,
        G,
        A,
        B,
        ell,
        H3,
        H2,
        L,
        E6,
        b1*(b*A0 - a*B0)**2,
    )


def main() -> None:
    certify_z2_plus_xy()
    certify_xz_plus_y2()
    certify_generic_orbit(z**2 + x**2, "G=z^2+x^2", half=False)
    certify_generic_orbit(x*z, "G=xz", half=True)
    print("ALL FIVE CONIC CERTIFICATE CHARTS VERIFIED EXACTLY OVER Q")


if __name__ == "__main__":
    main()
