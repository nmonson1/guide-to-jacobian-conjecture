# Reproducibility supplement

This archive accompanies *Low-Degree Rigidity Around an Announced Three-Dimensional Keller Map* (version 0.1, 20 July 2026).

## Verification status

The scripts use exact rational, integer, or finite-field arithmetic. They do not use floating-point determinant cancellation or approximate collisions. The Groebner scripts recompute bases whose sole element is `1`; they are certificate generators, not exported extended-basis Bezout identities. Independent verification in a second CAS remains recommended before treating the computer-assisted statements as archival theorems.

Environment used for the audit:

- Python 3.13.5
- SymPy 1.14.0

## Core scripts

Run from the archive root with Python:

```bash
python scripts/core/check_all.py
python scripts/core/structural_identities.py
python scripts/core/d4_test.py
python scripts/core/step1_cubic_frame_complete.py
python scripts/core/step2_d5_equivariant_exact.py
python scripts/core/step3_d6_equivariant_exact.py
python scripts/core/step3_laurent_nonmonomial.py
python scripts/core/audit_step4_target_orbit.py
```

Expected wall times in the audited environment were approximately 2 s, 2 s, 7 s, 2 s, 7 s, 26 s, 2 s, and 2 s, respectively. Peak memory was below 350 MB.

`audit_step4_target_orbit.py` writes its JSON certificate to `certificates/target_orbit_minor_certificate.json`.

## Directory map

- `note_source/`: LaTeX source of the note.
- `scripts/core/`: scripts supporting claims promoted in the note.
- `scripts/exploratory/`: finite-field scans and restricted searches not promoted to characteristic-zero theorems.
- `certificates/`: target-orbit minor data and the earlier compact rank record.
- `logs/`: successful audit output for the core scripts.
- `notes/`: detailed quartic composite-pencil reduction.

## Main exact outputs

1. `check_all.py`: determinant `-2`, degrees `(7,6,4)`, and the displayed three-point collision.
2. `d4_test.py`: three saturated Groebner computations force the two nontrivial coefficients of the first equivariant coordinate to vanish.
3. `step2_d5_equivariant_exact.py`: four exhaustive nonconstant-`f` branches have unit ideals over `QQ`.
4. `step3_d6_equivariant_exact.py`: seven Groebner-covered nonconstant-`f` branches have unit ideals over `QQ`; the remaining branch is handled by the quotient argument in the note.
5. `step1_cubic_frame_complete.py`: pole conditions, exact degrees, determinant, and affine equivalence of the residual family.
6. `audit_step4_target_orbit.py`: an explicit nonzero `81 x 81` minor modulo `1,000,003`, with determinant `704803`, and exact kernel checks for `1,Q,R`.

## Exploratory outputs

The files under `scripts/exploratory/` record searches whose negative output is not a characteristic-zero theorem. In particular, finite-field absence of rational points and failure to lift modulo `p^2` should not be read as global nonexistence results.
