# Quartic leading-form reduction

Let

\[
F=X+H_2+H_3+H_4:\mathbb A^3_\mathbb C\to\mathbb A^3_\mathbb C,
\qquad \det JF=1,
\]

with each \(H_i\) homogeneous of degree \(i\). Put
\(A=JH_2\), \(B=JH_3\), and \(C=JH_4\).

## 1. Composite-pencil census

The highest Keller equation is \(\det C=0\). Remove the gcd \(G\) of the
three components of \(H_4\), and put \(e=\deg G\).

If the projective image of \([H_4]:\mathbb P^2\dashrightarrow\mathbb P^2\)
is a point, then

\[
H_4=v h_4
\]

for a constant vector \(v\ne0\) and a quartic form \(h_4\).

Otherwise its normalization is a rational curve. There are coprime
homogeneous forms \(a,b\) of the same degree \(r\), and coprime binary
forms \(B_1,B_2,B_3\) of the same degree \(k\), such that

\[
H_{4,i}=G B_i(a,b),\qquad e+rk=4.
\]

The possible triples are

\[
\begin{array}{c|c}
e&(r,k)\\ \hline
0&(1,4),(2,2),(4,1)\\
1&(1,3),(3,1)\\
2&(1,2),(2,1)\\
3&(1,1).
\end{array}
\]

The representation has the intrinsic \(\mathrm{PGL}_2\)-gauge
\((a,b)\mapsto M(a,b)\), with inverse precomposition on the binary forms.
After the affine normalization \(JF(0)=I\), the actual source/target linear
action is only conjugation \(F\mapsto L^{-1}F(LX)\); it must not be
replaced by independent source and target groups.

## 2. Highest deformation equations

For the symmetric polarized determinant \(\Delta\), normalized by
\(\Delta(M,M,M)=\det M\), the three highest equations are

\[
\Delta(C,C,C)=0,
\qquad
\Delta(C,C,B)=0,
\qquad
\Delta(C,C,A)+\Delta(C,B,B)=0.
\]

Numerical multinomial factors are irrelevant because the right sides are zero.

## 3. Primitive line-image theorem

Assume the components of \(H_4\) have a constant linear relation and generic
Jacobian rank two. After conjugation write

\[
H_4=(P_4,Q_4,0).
\]

Assume in addition that the generic fiber of
\((P_4,Q_4):\mathbb A^3\to\mathbb A^2\) is geometrically integral; equivalently,
\(\mathbb C(P_4,Q_4)\) is relatively algebraically closed in
\(\mathbb C(x_1,x_2,x_3)\).

Then the degree-eight equation is

\[
J(P_4,Q_4,H_{3,3})=0.
\]

Thus \(H_{3,3}\) is algebraic over \(\mathbb C(P_4,Q_4)\), hence belongs to
that field. A rational function of two degree-four homogeneous forms can be a
homogeneous semi-invariant only in a degree divisible by four. Since
\(\deg H_{3,3}=3\), this forces \(H_{3,3}=0\).

The degree-seven equation now reduces to

\[
J(P_4,Q_4,H_{2,3})=0,
\]

and the same scaling argument, with degree two in place of degree three,
forces \(H_{2,3}=0\). Therefore the third coordinate of \(F\) is exactly
linear.

Over \(\mathbb C(x_3)\), the remaining two coordinates form a plane Keller
map of degree at most four, hence a plane automorphism. The full map is then
birational, and the birational Keller theorem makes it a polynomial
automorphism.

Consequently every possible degree-four counterexample in a line-image
quartic stratum must have a non-geometrically-integral (imprimitive) generic
fiber. In particular this restricts all four \(k=1\) rows of the census.

## 4. Rank-one quartic theorem

Assume instead

\[
H_4=(0,0,h_4).
\]

The first nonautomatic top equation is

\[
J(H_{3,1},H_{3,2},h_4)=0.
\]

If \(H_{3,1},H_{3,2}\) are algebraically independent and their generic fiber
is geometrically integral, then \(h_4\in\mathbb C(H_{3,1},H_{3,2})\). The
same semi-invariant argument is impossible for degrees \(3,3,4\). Hence no
such Keller map exists.

Thus every rank-one quartic survivor has a transverse cubic pair that is
either algebraically dependent or imprimitive.

## 5. Surviving quartic strata

1. Nonlinear projective-image curves: \((e,r,k)=(0,1,4),(0,2,2),
   (1,1,3),(2,1,2)\), including their degenerate subloci.
2. Line-image cases with non-geometrically-integral generic fiber.
3. Rank-one quartics \(v h_4\) whose transverse cubic pair is dependent or
   imprimitive.

These are the strata on which collision equations and modular elimination
should next be concentrated.
