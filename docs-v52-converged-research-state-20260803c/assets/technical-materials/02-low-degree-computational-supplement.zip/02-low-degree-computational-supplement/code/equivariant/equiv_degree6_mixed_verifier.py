#!/usr/bin/env python3
"""Exact characteristic-zero verifier for the g_11 != 0 branch of the
ordinary-degree <= 6 grading-equivariant Keller equations.

The script:
  * constructs the full coefficient equations over QQ;
  * normalizes g_11=1 and eliminates the three universal linear variables;
  * checks the factor identities used in the exhaustive branch tree;
  * computes exact Groebner bases for the four terminal branches.

A basis [1] on every terminal branch proves that the mixed vt case has no
solutions over an algebraically closed field of characteristic zero.
"""
from __future__ import annotations
import time
import sympy as s

v,t=s.symbols('v t')
a02,a11,a12,a20,a21,a30,a40=s.symbols('a02 a11 a12 a20 a21 a30 a40')
b01,b02,b11,b20,b21,b30=s.symbols('b01 b02 b11 b20 b21 b30')
g01,g10,g20=s.symbols('g01 g10 g20')
g11=s.Integer(1)

alpha=t+a02*t**2+a11*t*v+a12*t**2*v+a20*v**2+a21*t*v**2+a30*v**3+a40*v**4
beta=v+b01*t+b02*t**2+b11*t*v+b20*v**2+b21*t*v**2+b30*v**3
gamma=1+g01*t+g10*v+g11*t*v+g20*v**2
J=lambda f,q:s.diff(f,v)*s.diff(q,t)-s.diff(f,t)*s.diff(q,v)
K=s.Poly(s.expand(gamma*J(beta,alpha)+2*alpha*J(beta,gamma)+beta*J(gamma,alpha)-1),v,t)
D=dict(K.terms())

# Universal linear eliminations.
a11e=s.solve(D[(1,0)],a11)[0]
a02e=s.solve(s.expand(D[(0,1)].subs(a11,a11e)),a02)[0]
a21e=s.solve(s.expand(D[(2,0)].subs({a11:a11e,a02:a02e})),a21)[0]
low={a11:a11e,a02:a02e,a21:a21e}
R={m:s.factor(c.subs(low)) for m,c in K.terms()}

# Highest-coefficient products that start the exhaustive cover.
assert s.factor(R[(6,1)]+6*a40*b21)==0
assert s.factor(R[(3,3)]-6*a12*b21)==0
assert s.factor(R[(1,4)]+5*a12*b02)==0

# If b21=0 and a12 != 0, the next two coefficients force b30=b11=0
# after b02=0; this is terminal cover E.
assert s.factor(R[(4,2)].subs({b21:0,b02:0})-13*a12*b30)==0
assert s.factor(R[(2,3)].subs({b21:0,b02:0,b30:0})-2*a12*b11)==0
# If b21=a12=0 and a40 != 0, these force b30=b02=0; terminal cover D.
assert s.factor(R[(7,0)].subs({b21:0,a12:0})-2*a40*b30)==0
assert s.factor(R[(4,2)].subs({b21:0,a12:0,b30:0})+16*a40*b02)==0

Y2=2*a20*b01**2-2*b01*b20-b01*g10-b11-3*g01
Y=a21e
Z=a20*b01-b20-g10

# Helpers for exact sequential reduction.
def unique_equations(sub:dict[s.Symbol,s.Expr]):
    out=[]
    for _,c in K.terms():
        q=s.factor(c.subs(sub))
        if q and not any(s.expand(q-r)==0 or s.expand(q+r)==0 for r in out):
            out.append(q)
    return out

def unit_gb(name,eqs,vars):
    # Clear rational denominators without changing the zero set over QQ.
    eqs=[s.Poly(q,*vars,domain=s.QQ).clear_denoms()[1].as_expr() for q in eqs]
    st=time.time()
    G=s.groebner(eqs,*vars,order='grevlex',method='f5b')
    elapsed=time.time()-st
    one=any(p.as_expr()==1 for p in G.polys)
    print(f'{name}: equations={len(eqs)}, variables={len(vars)}, seconds={elapsed:.3f}, basis_length={len(G.polys)}, unit={one}')
    if not one:
        raise AssertionError(f'{name} did not reduce to the unit ideal')
    return elapsed

# Terminal E: b21=b02=b30=b11=0.
baseE={b21:0,b02:0,b30:0,b11:0}
subE=dict(low);subE.update(baseE)
eqE=unique_equations(subE)
varsE=[a12,a20,a30,a40,b01,b20,g01,g10,g20]

# Terminal D2: D plus b11=0.
baseD2={b21:0,a12:0,b30:0,b02:0,b11:0}
subD2=dict(low);subD2.update(baseD2)
eqD2=unique_equations(subD2)
varsD2=[a20,a30,a40,b01,b20,g01,g10,g20]

# Terminal D1b: D, a40=0, b11 != 0 forces Y2=0, Y=0, then a30=0.
baseDpre={b21:0,a12:0,b30:0,b02:0,a40:0}
b11D=s.solve(Y2,b11)[0]
g20Dpre=s.solve(s.expand(Y.subs(baseDpre).subs(b11,b11D)),g20)[0]
baseD1=dict(baseDpre); baseD1[a30]=0
g20D=s.factor(g20Dpre.subs(a30,0))
def redD1(q):
    q=q.subs(baseD1).subs(b11,b11D).subs(g20,g20D)
    q=q.subs(a11,a11e).subs(a02,a02e).subs(a21,a21e)
    q=q.subs(baseD1).subs(b11,b11D).subs(g20,g20D)
    return s.factor(q)
eqD1=[]
for _,c in K.terms():
    q=redD1(c)
    if q and not any(s.expand(q-r)==0 or s.expand(q+r)==0 for r in eqD1):eqD1.append(q)
varsD1=[a20,b01,b20,g01,g10]

# Terminal GZ: A with a21=a30=Y2=Z=0.
baseG={a12:0,a40:0,a30:0,b20:a20*b01-g10}
g20G=s.solve(s.expand(Y.subs(baseG)),g20)[0]
b11G=s.solve(Y2.subs(baseG),b11)[0]
def redG(q):
    q=q.subs(baseG).subs(g20,g20G).subs(b11,b11G)
    q=q.subs(a11,a11e).subs(a02,a02e).subs(a21,a21e)
    q=q.subs(baseG).subs(g20,g20G).subs(b11,b11G)
    return s.factor(q)
eqG=[]
for _,c in K.terms():
    q=redG(c)
    if q and not any(s.expand(q-r)==0 or s.expand(q+r)==0 for r in eqG):eqG.append(q)
varsG=[a20,b01,b02,b21,b30,g01,g10]

# Check the later branch factors explicitly.
# D contains a40*b11=0.
assert s.factor(R[(5,1)].subs({b21:0,a12:0,b30:0,b02:0})+8*a40*b11)==0
# On D1, Y2=Y=0 gives -6*a30*b11.
expr_D1=D[(4,1)].subs(baseDpre).subs(b11,b11D).subs(g20,g20Dpre)
expr_D1=expr_D1.subs(a11,a11e).subs(a02,a02e).subs(a21,a21e)
expr_D1=expr_D1.subs(baseDpre).subs(b11,b11D).subs(g20,g20Dpre)
assert s.factor(expr_D1+6*a30*b11D)==0
# On A, b21*Y=0.
assert s.factor(R[(4,2)].subs({a40:0,a12:0})-b21*Y)==0
# After a21=a30=Y2=0, the three factors are b21*Z,b02*Z,b30*Z.
# Build this reduction without imposing Z=0.
baseH={a12:0,a40:0,a30:0}
g20H=s.solve(Y.subs(baseH),g20)[0]
b11H=s.solve(Y2,b11)[0]
def redH(q):
    q=q.subs(baseH).subs(g20,g20H).subs(b11,b11H)
    q=q.subs(a11,a11e).subs(a02,a02e).subs(a21,a21e)
    q=q.subs(baseH).subs(g20,g20H).subs(b11,b11H)
    return s.factor(q)
assert s.factor(redH(D[(3,2)])-6*b21*Z)==0
assert s.factor(redH(D[(1,3)])+12*b02*Z)==0
assert s.factor(redH(D[(4,1)]).subs({b21:0,b02:0})-18*b30*Z)==0

print('linear eliminations:')
print('  a11 =',s.factor(a11e))
print('  a02 =',s.factor(a02e))
print('  a21 =',s.factor(a21e))
print('branch identities: verified')
unit_gb('E',eqE,varsE)
unit_gb('D2',eqD2,varsD2)
unit_gb('D1b-a30=0',eqD1,varsD1)
unit_gb('GZ',eqG,varsG)
print('RESULT: the normalized g11=1 mixed-vt Keller system is empty over characteristic zero.')
