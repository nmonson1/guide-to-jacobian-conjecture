import sympy as s
x,y,z=s.symbols('x y z')
P=(1+x*y)**3*z+y**2*(1+x*y)*(4+3*x*y)
Q=y+3*x*(1+x*y)**2*z+3*x*y**2*(4+3*x*y)
R=2*x-3*x**2*y-x**3*z
F=[s.expand(P),s.expand(Q),s.expand(R)]
print(F)
print([s.Poly(f,x,y,z).total_degree() for f in F])
J=s.Matrix(F).jacobian([x,y,z])
print('det',s.factor(J.det()))
pts=[(0,0,s.Rational(-1,4)),(1,s.Rational(-3,2),s.Rational(13,2)),(-1,s.Rational(3,2),s.Rational(13,2))]
for pt in pts:
 print(pt,[s.simplify(f.subs(dict(zip((x,y,z),pt)))) for f in F])
S=(1+x*y)**2*z+y**2*(4+3*x*y)
print('P relation',s.expand(P-(1+x*y)*S))
print('Q relation',s.expand(Q-(y+3*x*S)))
# invariant chart
u,v,rho,a=s.symbols('u v rho a')
# a=1+xy,u=x^2z,rho=5-3a-u
# formulas
subs_uv={y:(a-1)/x,z:u/x**2}
print('R inv',s.simplify(R.subs(subs_uv)))
print('Q inv',s.factor(s.together(Q.subs(subs_uv))))
print('P inv',s.factor(s.together(P.subs(subs_uv))))
# replace u=5-3a-rho
print('Q arho',s.factor(s.together(Q.subs(subs_uv).subs(u,5-3*a-rho))))
print('P arho',s.factor(s.together(P.subs(subs_uv).subs(u,5-3*a-rho))))
# primitive relation target p,q,r
p,q,r,t=s.symbols('p q r t')
# derive equations from formulas t=a
# p*x^2=t*(t+1-t**2*rho), q*x=4*t+2-3*t**2*rho, r=x*rho
# rho=r/x
E1=s.expand(p*x**3 - x*t*(t+1)+r*t**3)
E2=s.expand(q*x**2 - x*(4*t+2)+3*r*t**2)
res=s.factor(s.resultant(E1,E2,t))
print('resultant',res)
A=27*p**2*r**2-18*p*q*r+16*p+q**3*r-q**2
cub=s.expand(A*x**3+(4-3*q*r)*x-2*r)
print('res/cub',s.factor(res/cub))
# subresultants
subres=s.subresultants(E1,E2,t)
print('subresultants lengths/degrees')
for sr in subres: print(s.degree(sr,t),s.factor(sr))
# check t reconstruction formula
tr=x*((q-9*p*r)*x-2)/((4-3*q*r)*x-3*r)
# reduce E1/E2 modulo cubic after substituting t
for Ei in [E1,E2]:
 num=s.together(Ei.subs(t,tr)).as_numer_denom()[0]
 print('recon rem',s.factor(s.rem(s.Poly(num,x),s.Poly(cub,x)).as_expr()))
# generic specialization p=1,q=0,r=1
spec=s.factor(cub.subs({p:1,q:0,r:1}))
print('spec cubic',spec,s.Poly(spec,x).factor_list())
# second fiber factor
print('fiber factor',s.factor(cub.subs({p:22,q:34,r:-2})))
