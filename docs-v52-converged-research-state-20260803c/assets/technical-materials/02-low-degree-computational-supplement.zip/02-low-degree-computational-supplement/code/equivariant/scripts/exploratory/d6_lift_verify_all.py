import itertools
import sympy as s
u,v=s.symbols('u v')
a2,a3,a4,b2,b3,b4,b5,b6,c1,c2,c3,c4,c5,c6,c7=s.symbols('a2 a3 a4 b2 b3 b4 b5 b6 c1 c2 c3 c4 c5 c6 c7')
vars=[a2,a3,a4,b2,b3,b4,b5,b6,c1,c2,c3,c4,c5,c6,c7]
a1=-1-a2-a3-a4;b1=-1-b2-b3-b4-b5-b6
f=1+a1*u+a2*v+a3*u**2+a4*u*v
g=u+b1*v+b2*u**2+b3*u*v+b4*u**3+b5*v**2+b6*u**2*v
h=v+c1*u**2+c2*u*v+c3*u**3+c4*v**2+c5*u**2*v+c6*u**4+c7*u*v**2
J=lambda A,B:s.diff(A,u)*s.diff(B,v)-s.diff(A,v)*s.diff(B,u)
eqs=[coef for ex,coef in s.Poly(s.expand(g*J(f,h)-2*h*J(f,g)+f*J(g,h)-1),u,v).terms()]
Jac=s.Matrix(eqs).jacobian(vars)

def rank_consistency(A,b,p=5):
    M=[[int(A[i,j])%p for j in range(A.cols)]+[int(b[i])%p] for i in range(A.rows)]
    r=0
    for j in range(A.cols):
        pivot=next((i for i in range(r,A.rows) if M[i][j]),None)
        if pivot is None: continue
        M[r],M[pivot]=M[pivot],M[r]
        inv=pow(M[r][j],-1,p)
        M[r]=[(q*inv)%p for q in M[r]]
        for i in range(A.rows):
            if i!=r and M[i][j]:
                q=M[i][j]
                M[i]=[(M[i][k]-q*M[r][k])%p for k in range(A.cols+1)]
        r+=1
    consistent=not any(all(M[i][j]==0 for j in range(A.cols)) and M[i][-1] for i in range(r,A.rows))
    return r,consistent

cands=[
([0,0,4,0,0,0,4,0],[4,0,0,0,0,0,4]),
([0,2,2,0,0,3,0,1],[0,0,0,0,0,0,0]),
]
free3=[2,0,4,1,0,0,0,0]
# exact affine family previously inferred, validate all five
fam3=[[1,3,0,1,3,0,0],[2,4,2,0,4,1,0],[3,0,4,4,0,2,0],[4,1,1,3,1,3,0],[0,2,3,2,2,4,0]]
cands += [(free3,c) for c in fam3]
for idx,(fg,cv) in enumerate(cands,1):
    vals=fg+cv; sub=dict(zip(vars,vals))
    ev=[int(e.subs(sub)) for e in eqs]
    assert all(e%5==0 for e in ev), (idx,[e%5 for e in ev])
    A=Jac.subs(sub)
    rhs=s.Matrix([(-e//5)%5 for e in ev])
    rank,ok=rank_consistency(A,rhs)
    print(idx,'fg=',fg,'c=',cv,'rank=',rank,'mod25_lift=',ok)
