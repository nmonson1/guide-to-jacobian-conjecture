"""Exact coefficient certificates for the degree-5 equivariant theorem.

Weights are (-1,1,2).  In invariant variables u=xy, v=x^2 z,
  X=x f(u,v), Y=x^{-1}g(u,v), Z=x^{-2}h(u,v),
and the Keller identity is
  g J(f,h)-2 h J(f,g)+f J(g,h)=1.

The script verifies all nonconstant-f branches after the boundary lemma
  g h' - 2 h g' = const != 0  ==> deg(g)<=1.
Each printed Groebner basis is [1] over QQ.
"""
import sympy as s
import time

u, v = s.symbols("u v")
a,b,c,p,q,r,ss,t,A,B,C,D,E = s.symbols("a b c p q r ss t A B C D E")
f = 1+a*u+b*v+c*u**2
g = u+p*v+q*u**2+r*u*v+ss*u**3+t*v**2
h = v+A*u**2+B*u*v+C*u**3+D*v**2+E*u**2*v
J = lambda X,Y: s.diff(X,u)*s.diff(Y,v)-s.diff(X,v)*s.diff(Y,u)
K = s.expand(g*J(f,h)-2*h*J(f,g)+f*J(g,h)-1)

def coeffs(expr):
    return list(dict.fromkeys(s.factor(co) for _,co in s.Poly(expr,u,v).terms() if co != 0))

def check(name, equations, variables, extra=()):
    st=time.time()
    G=s.groebner(list(equations)+list(extra), *variables, order="grevlex", domain=s.QQ)
    ok=G.contains(s.Integer(1))
    print(f"{name}: equations={len(equations)+len(extra)}, variables={len(variables)}, "
          f"unit={ok}, seconds={time.time()-st:.3f}")
    assert ok and len(G.polys)==1

# b != 0: scale b=1.  On f=0, the boundary lemma makes g affine.
# If c != 0 this forces t=0, q=ar+cp, ss=cr.
sub={b:1,t:0,q:a*r+c*p,ss:c*r}
eq=coeffs(K.subs(sub))
T=s.symbols("T")
check("b=1,c!=0",eq,[T,A,B,C,D,E,a,c,p,r],[T*c-1])

# If c=0 the affine restriction gives q=-a^2 t+ar, ss=0.
sub={b:1,c:0,q:-a**2*t+a*r,ss:0}
eq=coeffs(K.subs(sub))
check("b=1,c=0",eq,[A,B,C,D,E,a,p,r,t])

# b=0 and f nonconstant.  On every component of f=0, the same lemma forces t=0.
sub={b:0,t:0}
eq0=coeffs(K.subs(sub))
check("b=0,c!=0",eq0,[T,A,B,C,D,E,a,c,p,q,r,ss],[T*c-1])

eq1=coeffs(K.subs({b:0,t:0,c:0}))
check("b=0,c=0,a!=0",eq1,[T,A,B,C,D,E,a,p,q,r,ss],[T*a-1])

print("All nonconstant-f degree-5 equivariant branches are empty over QQ.")
