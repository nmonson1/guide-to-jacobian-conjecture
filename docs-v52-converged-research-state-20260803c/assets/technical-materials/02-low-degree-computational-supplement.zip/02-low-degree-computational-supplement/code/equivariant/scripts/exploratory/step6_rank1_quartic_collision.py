"""Exact/modular elimination in a collision-normalized rank-one quartic stratum.

Normalize F(0)=F(q)=0, JF(0)=I and H4=(0,0,x^4).  Its stabilizer
has three q-orbits e1,e2,e3.  The script proves over QQ (and modulo 5,7):
  * q=e2,e3: no solution with H3=(0,0,h3), h3 arbitrary cubic;
  * q=e1: no solution in the full sub-stratum H3=(0,0,x*q2), q2 arbitrary quadratic.
"""
from __future__ import annotations
import gc,time
import sympy as s
x,y,z=s.symbols('x y z'); xyz=(x,y,z)
def mons(d):
    return [x**i*y**j*z**(d-i-j) for i in range(d,-1,-1) for j in range(d-i,-1,-1)]
m2=mons(2);m3=mons(3)

def make_system(q_index,divisible):
    a=s.symbols('a0:18')
    H2=[sum(a[6*i+j]*m2[j] for j in range(6)) for i in range(3)]
    if divisible:
        b=s.symbols('b0:6'); h3=x*sum(b[j]*m2[j] for j in range(6))
    else:
        b=s.symbols('b0:10'); h3=sum(b[j]*m3[j] for j in range(10))
    F=[x+H2[0],y+H2[1],z+H2[2]+h3+x**4]
    det=s.Poly(s.expand(s.Matrix([[s.diff(Fi,w) for w in xyz] for Fi in F]).det()-1),x,y,z)
    if q_index==0: sub={a[0]:-1,a[6]:0,a[12]:-b[0]-1}
    elif q_index==1: sub={a[3]:0,a[9]:-1,a[15]:-b[6]}
    else: sub={a[5]:0,a[11]:0,a[17]:-b[9]-1}
    eq=list(dict.fromkeys(s.factor(co.subs(sub)) for _,co in det.terms() if s.expand(co.subs(sub))!=0))
    variables=[v for v in a if v not in sub]+list(b)
    return eq,variables,sub

def run_one(name,q_index,divisible):
    eq,variables,sub=make_system(q_index,divisible)
    print(f'{name}: equations={len(eq)}, variables={len(variables)}, collision_sub={sub}',flush=True)
    for label,opts in [('F5',{'modulus':5}),('F7',{'modulus':7}),('QQ',{'domain':s.QQ})]:
        st=time.time();G=s.groebner(eq,*variables,order='grevlex',**opts)
        ok=G.contains(s.Integer(1))
        print(f'  {label}: unit={ok}, basis_length={len(G.polys)}, seconds={time.time()-st:.3f}',flush=True)
        assert ok and len(G.polys)==1
    del eq,variables;gc.collect();s.core.cache.clear_cache()

run_one('q=e2, arbitrary h3',1,False)
run_one('q=e3, arbitrary h3',2,False)
run_one('q=e1, x divides h3',0,True)
print('All stated collision strata are empty over QQ.',flush=True)
