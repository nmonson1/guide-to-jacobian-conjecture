"""Finite-field rank certificate for the unbounded target-orbit theorem.

Let A=QQ[x,y,z], B=QQ[P,Q,R] for the announced cubic Keller map, and
K=Frac(B).  The script proves the linear-algebra part of

    K intersect A_{<=6} = span_QQ{1,Q,R}.

It evaluates the T and T^2 coefficients of all 84 source monomials of
ordinary degree <=6 in K[T]/(R*T^3-2*T^2+Q*T-2*P) at 41 fixed good target
points modulo p=1,000,003.  The resulting 82 x 84 matrix has rank 81.
The three displayed vectors 1,Q,R lie in its kernel, so the characteristic-0
kernel is exactly their span.

The ring-theoretic bridge A intersect K=B is proved separately by fpqc descent
from the open image of any Keller map; it is not a numerical assumption.
"""
from __future__ import annotations
import sympy as s

PRIME=1_000_003
POINTS=[
(60527,-51474,-965),(84796,4173,5793),(-27475,22536,-98153),
(-45392,94340,16666),(51677,-67018,66425),(96639,-54885,-37448),
(2326,58013,-75353),(56809,46331,-3326),(-24806,28792,-97668),
(36297,81636,-54908),(53078,-30327,-55381),(-78326,-57540,4145),
(10174,-96846,56173),(-50699,57310,-12466),(38277,-98867,-25687),
(31650,-86992,45061),(-30542,-7246,74336),(-4896,12742,40274),
(24845,-87308,-58564),(75882,-49105,-70771),(50961,-91527,-6101),
(22813,68334,-87844),(86708,58022,-57761),(-61022,-17943,-94644),
(-45680,-97616,-36787),(-1170,51275,-95370),(98361,72429,-75626),
(-26211,-16876,-52922),(94637,-92275,-57577),(9248,61226,62532),
(1140,84948,-54128),(-90215,64826,96449),(77756,-19110,41145),
(39348,-90442,18649),(44079,8723,12813),(93307,44851,-71520),
(-84146,15031,-97852),(-30398,78912,-38224),(26122,-5409,12017),
(-85268,77843,32707),(-77098,-64639,-92114),
]

# Source monomial basis, total degree first.
MONS=[]
for total in range(7):
    for i in range(total+1):
        for j in range(total-i+1):
            MONS.append((i,j,total-i-j))
assert len(MONS)==84
INDEX={m:i for i,m in enumerate(MONS)}

def mul(v,w,A,B,C,p=PRIME):
    """Multiply in F_p[T]/(T^3-A*T^2-B*T-C), coefficient order 1,T,T^2."""
    raw=[0]*5
    for i in range(3):
        for j in range(3):
            raw[i+j]=(raw[i+j]+v[i]*w[j])%p
    q=raw[4]
    raw[3]=(raw[3]+q*A)%p; raw[2]=(raw[2]+q*B)%p; raw[1]=(raw[1]+q*C)%p
    q=raw[3]
    raw[2]=(raw[2]+q*A)%p; raw[1]=(raw[1]+q*B)%p; raw[0]=(raw[0]+q*C)%p
    return tuple(raw[:3])

def solve3(M,b,p=PRIME):
    aug=[[(M[i][j]%p) for j in range(3)]+[b[i]%p] for i in range(3)]
    for col in range(3):
        pivot=next(i for i in range(col,3) if aug[i][col])
        aug[col],aug[pivot]=aug[pivot],aug[col]
        inv=pow(aug[col][col],p-2,p)
        aug[col]=[(q*inv)%p for q in aug[col]]
        for i in range(3):
            if i!=col and aug[i][col]:
                q=aug[i][col]
                aug[i]=[(aug[i][j]-q*aug[col][j])%p for j in range(4)]
    return tuple(aug[i][3] for i in range(3))

def inverse_vec(d,A,B,C):
    cols=[mul(d,e,A,B,C) for e in ((1,0,0),(0,1,0),(0,0,1))]
    M=[[cols[j][i] for j in range(3)] for i in range(3)]
    return solve3(M,(1,0,0))

def sample(a,b,c):
    p=PRIME; a%=p; b%=p; c%=p
    assert c
    disc=(27*a*a*c*c-18*a*b*c+16*a+b*b*b*c-b*b)%p
    assert disc
    ci=pow(c,p-2,p)
    # T^3=(2/c)T^2-(b/c)T+(2a/c).
    A=2*ci%p; B=-b*ci%p; C=2*a*ci%p
    d=(b%p,-4%p,3*c%p)  # P'(T)
    invd=inverse_vec(d,A,B,C)
    xvec=tuple(2*q%p for q in invd)
    inv2=pow(2,p-2,p); inv8=pow(8,p-2,p)
    yvec=((-b*inv2)%p,3%p,(-3*c*inv2)%p)
    # z=P'(T)^2/2-(3/2)yP'(T)-cP'(T)^3/8, reduced once and hard-coded.
    zvec=(
      -(108*a*a*c*c-36*a*b*c+208*a+b*b*b*c-10*b*b)*inv8%p,
      -(-54*a*b*c*c-108*a*c+6*b*b*c-12*b)*inv8%p,
      -(9*b*b*c*c+6*b*c)*inv8%p,
    )
    one=(1,0,0); xp=[one];yp=[one];zp=[one]
    for _ in range(6):
        xp.append(mul(xp[-1],xvec,A,B,C))
        yp.append(mul(yp[-1],yvec,A,B,C))
        zp.append(mul(zp[-1],zvec,A,B,C))
    rows=[[],[]]
    for i,j,k in MONS:
        value=mul(mul(xp[i],yp[j],A,B,C),zp[k],A,B,C)
        rows[0].append(value[1]); rows[1].append(value[2])
    return rows

class RowBasis:
    def __init__(self,n,p=PRIME): self.n=n; self.p=p; self.rows={}
    def add(self,row):
        p=self.p; r=[x%p for x in row]
        for j in sorted(self.rows):
            if r[j]:
                q=r[j]; base=self.rows[j]
                r=[(x-q*y)%p for x,y in zip(r,base)]
        try: j=next(i for i,x in enumerate(r) if x)
        except StopIteration: return False
        inv=pow(r[j],p-2,p); r=[x*inv%p for x in r]
        for k,base in list(self.rows.items()):
            if base[j]:
                q=base[j]; self.rows[k]=[(x-q*y)%p for x,y in zip(base,r)]
        self.rows[j]=r; return True

rows=[]; basis=RowBasis(84)
for pt in POINTS:
    for row in sample(*pt):
        rows.append(row); basis.add(row)
rank=len(basis.rows)
assert rank==81

# Coefficient vectors of 1,Q,R in the source monomial basis.
x,y,z=s.symbols('x y z')
Q=y+3*x*(1+x*y)**2*z+3*x*y**2*(4+3*x*y)
R=2*x-3*x**2*y-x**3*z

def coeff_vector(poly):
    P=s.Poly(s.expand(poly),x,y,z)
    out=[0]*84
    for mon,co in P.terms():
        assert mon in INDEX and co.q==1
        out[INDEX[mon]]=int(co)
    return out

kernel_vectors=[coeff_vector(1),coeff_vector(Q),coeff_vector(R)]
for vec in kernel_vectors:
    assert all(sum(a*b for a,b in zip(row,vec))%PRIME==0 for row in rows)
# Independence is immediate from distinct linear/leading terms; verify mod p as well.
Kmat=s.Matrix([[v[j] for v in kernel_vectors] for j in range(84)])
assert Kmat.rank()==3

print('prime:',PRIME)
print('points:',len(POINTS),'rows:',len(rows),'columns:',84)
print('rank modulo prime:',rank,'nullity:',84-rank)
print('verified kernel basis candidates: 1, Q, R')
print('nonpivot columns:',sorted(set(range(84))-set(basis.rows)))
