import sympy as s
u,v=s.symbols('u v')
def J(a,b): return s.diff(a,u)*s.diff(b,v)-s.diff(a,v)*s.diff(b,u)
for D in [4,5,6,7]:
    # supports from formulas cost and polynomiality
    fs=[]; gs=[]; hs=[]
    # broad i,j range
    for i in range(10):
      for j in range(10):
        # X x exponent automatically >=0
        if 1+2*i+3*j<=D: fs.append((i,j))
        if i+2*j>=1 and -1+2*i+3*j<=D: gs.append((i,j))
        if i+2*j>=2 and -2+2*i+3*j<=D: hs.append((i,j))
    fs=sorted(fs,key=lambda ij:(1+2*ij[0]+3*ij[1],ij[1],ij[0]))
    gs=sorted(gs,key=lambda ij:(-1+2*ij[0]+3*ij[1],ij[1],ij[0]))
    hs=sorted(hs,key=lambda ij:(-2+2*ij[0]+3*ij[1],ij[1],ij[0]))
    # remove fixed linear terms from params: f(0,0)=1; g u=1; h v=1
    fpars=[ij for ij in fs if ij!=(0,0)]
    gpars=[ij for ij in gs if ij!=(1,0)]
    hpars=[ij for ij in hs if ij!=(0,1)]
    coeffs=s.symbols(f'a0:{len(fpars)+len(gpars)+len(hpars)}')
    k=0
    f=s.Integer(1)
    for ij in fpars: f+=coeffs[k]*u**ij[0]*v**ij[1]; k+=1
    g=u
    for ij in gpars:g+=coeffs[k]*u**ij[0]*v**ij[1];k+=1
    h=v
    for ij in hpars:h+=coeffs[k]*u**ij[0]*v**ij[1];k+=1
    E=s.Poly(s.expand(g*J(f,h)-2*h*J(f,g)+f*J(g,h)-1),u,v)
    print('D',D,'supports',fs,gs,hs)
    print('params',len(coeffs),'eqs',len(E.terms()),'uv monomials',[ex for ex,c in E.terms()])
