"""Exact verifier for the cubic Jacobian-neutral frame.

The script verifies:
  * the pole-cancellation equations for a general cubic frame after the
    standard target/source gauges;
  * the normalized one-parameter family F_mu;
  * det JF_mu = -2 and coordinate degrees (7,6,4);
  * the affine equivalence F_mu = T_{mu/3} o F_0 o S_{mu/3}.

All arithmetic is over QQ[mu].
"""
import sympy as s

x, y, z, mu = s.symbols("x y z mu")
alpha, beta, alpha2 = s.symbols("alpha beta alpha2", nonzero=True)
kappa, eta = s.symbols("kappa eta")

# Pole equations after gauging away the T and constant terms of h,
# translating c so w(0,y)=0, and writing w=x*k.
# A(C)=alpha*C+alpha2*C^2+..., B(C)=beta0+beta*C+...
beta0 = s.symbols("beta0")
pole_b = 2 - 3*alpha*kappa - 2*beta0
pole_a0 = 1 - alpha*kappa - beta0/2
sol0 = s.solve([pole_b, pole_a0], [kappa, beta0], dict=True)[0]
assert s.simplify(sol0[kappa] - 2/alpha) == 0
assert s.simplify(sol0[beta0] + 2) == 0

# The x-derivative condition for divisibility of the first coordinate by x^2.
# eta is k_x(0,y); it is necessarily affine in y.
eta_required = -3*y/alpha - (alpha*beta + 4*alpha2)/alpha**3
print("pole conditions:")
print("  beta0 =", sol0[beta0])
print("  k(0,y) =", sol0[kappa])
print("  k_x(0,y) =", eta_required)

# Degree <= 7 forces alpha2=0 and all higher C-powers to vanish;
# it also forces B to be affine in C.  After scaling alpha=1 and putting
# beta=-mu, the normalized frame is the following.
t = y + 1/x
w = 2*x + mu*x**2 - 3*x**2*y
c = s.expand(w - x**3*z)
T, C = s.symbols("T C")
h = C*T**3 + (-2 - mu*C)*T**2
h_t = s.diff(h, T).subs({T: t, C: c})
b = s.cancel(2/x - h_t)
a = s.cancel((h.subs({T: t, C: c}) + t*b)/2)
Fmu = [s.expand(s.cancel(a)), s.expand(s.cancel(b)), c]

assert all(fi.is_polynomial(x, y, z, mu) for fi in Fmu)
J = s.Matrix([[s.diff(fi, q) for q in (x, y, z)] for fi in Fmu])
assert s.expand(J.det()) == -2

def total_degree_xyz(poly):
    return s.Poly(poly, x, y, z, domain=s.QQ.frac_field(mu)).total_degree()

degrees = tuple(total_degree_xyz(fi) for fi in Fmu)
assert degrees == (7, 6, 4)
assert s.Poly(Fmu[0], x, y, z).coeff_monomial(x**3*y**3*z) == 1

# Base map.
P = (1+x*y)**3*z + y**2*(1+x*y)*(4+3*x*y)
Q = y + 3*x*(1+x*y)**2*z + 3*x*y**2*(4+3*x*y)
R = 2*x - 3*x**2*y - x**3*z
assert [s.expand(fi.subs(mu, 0)) for fi in Fmu] == [s.expand(P), s.expand(Q), s.expand(R)]

# Affine equivalence.  Put s0=mu/3,
# S_s(x,y,z)=(x,y-s,z),
# T_s(A,B,C)=(A+sB/2+s^3C/2+s^2, B+3s^2C+4s, C).
s0 = s.symbols("s0")
P0 = s.expand(P.subs(y, y-s0))
Q0 = s.expand(Q.subs(y, y-s0))
R0 = s.expand(R.subs(y, y-s0))
TsF0 = [
    s.expand(P0 + s0*Q0/2 + s0**3*R0/2 + s0**2),
    s.expand(Q0 + 3*s0**2*R0 + 4*s0),
    R0,
]
assert all(s.expand(Fmu[i].subs(mu, 3*s0) - TsF0[i]) == 0 for i in range(3))

print("normalized family degrees:", degrees)
print("determinant:", s.expand(J.det()))
print("coefficient [x^3 y^3 z] F_mu,1 =", s.Poly(Fmu[0], x, y, z).coeff_monomial(x**3*y**3*z))
print("affine equivalence verified: F_mu = T_{mu/3} o F_0 o S_{mu/3}")
