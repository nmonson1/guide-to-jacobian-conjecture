import sympy as s, time
x,y,z=s.symbols('x y z')
a21,a30,b10,b12,b21,c02,c11,c13,c20=s.symbols('a21 a30 b10 b12 b21 c02 c11 c13 c20')
vars=[a21,a30,b10,b12,b21,c02,c11,c13,c20]
X=x+a21*x**2*y+a30*x**3*z
Y=y+b10*x*z+b12*x*y**2+b21*x**2*y*z
Z=z+c02*y**2+c11*x*y*z+c13*x*y**3+c20*x**2*z**2
D=s.Poly(s.expand(s.Matrix([X,Y,Z]).jacobian([x,y,z]).det()-1),x,y,z)
eqs=[s.expand(c) for ex,c in D.terms()]
# sort maybe by source monomial degree descending
print('n eq',len(eqs))
for ex,c in D.terms(): print(ex,s.factor(c))
# groebner saturations
for name,extra in [
 ('a21_nonzero_a30zero',[a30,s.Symbol('t')*a21-1]),
 ('a30_nonzero_a21zero',[a21,s.Symbol('t')*a30-1]),
 ('both_nonzero',[s.Symbol('t')*a21*a30-1])]:
    t=s.Symbol('t')
    vs=[t]+vars
    print('start',name,flush=True); st=time.time()
    G=s.groebner(eqs+extra,*vs,order='grevlex',domain=s.QQ)
    print(name,'secs',time.time()-st,'contains1',G.contains(s.Integer(1)),'len',len(G.polys))
# after a=0 solve determinant equations and verify branches
E0=[s.factor(e.subs({a21:0,a30:0})) for e in eqs]
E0=list(dict.fromkeys([e for e in E0 if e!=0]))
print('E0',len(E0))
for e in E0:print(s.factor(e))
