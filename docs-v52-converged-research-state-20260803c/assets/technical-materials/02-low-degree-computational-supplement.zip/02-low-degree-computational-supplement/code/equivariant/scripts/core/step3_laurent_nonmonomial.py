"""Exact nonmonomial solutions of the degree-6 Laurent boundary equation.

For E=s*d/ds, verifies g E(h)-2 h E(g)=1.  This disproves the tempting
claim that low-width Laurent solutions force g to be a monomial.
"""
import sympy as sp
s,A,B=sp.symbols('s A B', nonzero=True)
g=(A*s**-2+B*s**-1+sp.Rational(2,3)*B**2/A
   -sp.Rational(2,3)*B**3/A**2*s
   +sp.Rational(4,9)*B**4/A**3*s**2)
h=(sp.Rational(1,6)/A*s**2
   -sp.Rational(2,21)*B/A**2*s**3
   +sp.Rational(2,63)*B**2/A**3*s**4)
E=lambda f:sp.expand(s*sp.diff(f,s))
identity=sp.factor(sp.expand(g*E(h)-2*h*E(g)))
assert identity==1
print('g =',g)
print('h =',h)
print('g E(h)-2 h E(g) =',identity)
