import sympy as s
a,r=s.symbols('a r');A0,A1,A2,C0,C1,b,d,r0,lam,k,T=s.symbols('A0 A1 A2 C0 C1 b d r0 lam k T')
A=A0+A1*a+A2*a**2;B=b*a**3;C=C0+C1*a;D=d*a**2
p=A+B*r;q=C+D*r
E=s.expand(s.diff(p,a)*(q+r*s.diff(q,r))-s.diff(q,a)*(2*p+r*s.diff(p,r)))
# coefficient equations E=k
Epoly=s.Poly(E-k,a,r)
eqs=[coef for ex,coef in Epoly.terms()]
# pole at a=1,r=r0 and directional p_a+lam p_r
base={a:1,r:r0}
eqs += [s.expand(p.subs(base)),s.expand(q.subs(base)),s.expand((s.diff(p,a)+lam*s.diff(p,r)).subs(base))]
eqs += [T*A1*b*d-1]
vs=[T,lam,r0,k,C1,C0,A2,A0,A1,d,b]
print('eqs',len(eqs));G=s.groebner(eqs,*vs,order='grevlex',domain=s.QQ);print('len',len(G.polys),'one',G.contains(s.Integer(1)))
rels=[A0,A2-A1,b*r0+2*A1,b*lam-3*A1,3*b*C0-2*A1*d,3*b*C1-4*A1*d,3*b*k-2*A1**2*d]
for rel in rels:
 rem=s.factor(G.reduce(rel)[1]);print(rel,'->',rem)
