import sympy as s
from itertools import product
from time import time
u,v=s.symbols('u v')
a1,a2,a3,b1,b2,b3,b4,b5,c1,c2,c3,c4,c5=s.symbols('a1 a2 a3 b1 b2 b3 b4 b5 c1 c2 c3 c4 c5')
cvars=[c1,c2,c3,c4,c5]
f=1+a1*u+a2*v+a3*u**2
g=u+b1*v+b2*u**2+b3*u*v+b4*u**3+b5*v**2
h=v+c1*u**2+c2*u*v+c3*u**3+c4*v**2+c5*u**2*v
J=lambda A,B:s.diff(A,u)*s.diff(B,v)-s.diff(A,v)*s.diff(B,u)
E=s.Poly(s.expand(g*J(f,h)-2*h*J(f,g)+f*J(g,h)-1),u,v)
eqs=[coef for ex,coef in E.terms()]
print('eqs',len(eqs))
strata={
 '11':({a1:-1-a2-a3,b1:-1-b2-b3-b4-b5},[a2,a3,b2,b3,b4,b5]),
 '10':({a1:-1-a3,b2:-1-b4},[a2,a3,b1,b3,b4,b5]),
 '01':({a2:-1,b1:-b5},[a1,a3,b2,b3,b4,b5]),
}
def rank_mod(mat,p):
    A=[[(int(x)%p) for x in row] for row in mat]
    m=len(A); n=len(A[0]) if m else 0; r=0
    for j in range(n):
      pivot=next((i for i in range(r,m) if A[i][j]),None)
      if pivot is None: continue
      A[r],A[pivot]=A[pivot],A[r]
      inv=pow(A[r][j],-1,p)
      A[r]=[(x*inv)%p for x in A[r]]
      for i in range(m):
        if i!=r and A[i][j]:
          q=A[i][j]; A[i]=[(A[i][k]-q*A[r][k])%p for k in range(n)]
      r+=1
      if r==m: break
    return r
for name,(sub,free) in strata.items():
    ee=[s.expand(e.subs(sub)) for e in eqs]
    A=[[s.diff(e,c) for c in cvars] for e in ee]
    const=[e.subs({c:0 for c in cvars}) for e in ee]
    fun=s.lambdify(free,[item for row in A for item in row]+const,'math')
    p=7; count=0; first=None; st=time()
    for vals in product(range(p),repeat=len(free)):
      data=fun(*vals)
      M=[data[i*5:(i+1)*5] for i in range(len(ee))]
      aug=[M[i]+[-data[len(ee)*5+i]] for i in range(len(ee))]
      if rank_mod(M,p)==rank_mod(aug,p):
        count+=1
        if first is None:first=vals
    print(name,'count',count,'first',first,'sec',time()-st)
