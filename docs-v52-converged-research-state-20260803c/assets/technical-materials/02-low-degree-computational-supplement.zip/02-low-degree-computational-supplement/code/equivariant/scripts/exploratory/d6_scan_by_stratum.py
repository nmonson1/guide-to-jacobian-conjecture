import sympy as s
from itertools import product
from time import time
u,v=s.symbols('u v')
a1,a2,a3,a4,b1,b2,b3,b4,b5,b6,c1,c2,c3,c4,c5,c6,c7=s.symbols('a1 a2 a3 a4 b1 b2 b3 b4 b5 b6 c1 c2 c3 c4 c5 c6 c7')
cvars=[c1,c2,c3,c4,c5,c6,c7]
f=1+a1*u+a2*v+a3*u**2+a4*u*v
g=u+b1*v+b2*u**2+b3*u*v+b4*u**3+b5*v**2+b6*u**2*v
h=v+c1*u**2+c2*u*v+c3*u**3+c4*v**2+c5*u**2*v+c6*u**4+c7*u*v**2
J=lambda A,B:s.diff(A,u)*s.diff(B,v)-s.diff(A,v)*s.diff(B,u)
E=s.Poly(s.expand(g*J(f,h)-2*h*J(f,g)+f*J(g,h)-1),u,v)
eqs=[coef for ex,coef in E.terms()]
print('eqs',len(eqs),flush=True)
strata={
 '11':({a1:-1-a2-a3-a4,b1:-1-b2-b3-b4-b5-b6},[a2,a3,a4,b2,b3,b4,b5,b6]),
 '10':({a1:-1-a3,b2:-1-b4},[a2,a3,a4,b1,b3,b4,b5,b6]),
 '01':({a2:-1,b1:-b5},[a1,a3,a4,b2,b3,b4,b5,b6]),
}
def consistent_aug(flat,nrow,nc,p):
    # flat consists A rows then constants; eliminate augmented directly and detect [0..0|nonzero]
    A=[]; off=nrow*nc
    for i in range(nrow):
      A.append([int(flat[i*nc+j])%p for j in range(nc)]+[(-int(flat[off+i]))%p])
    r=0
    for j in range(nc):
      pivot=None
      for i in range(r,nrow):
        if A[i][j]: pivot=i;break
      if pivot is None: continue
      A[r],A[pivot]=A[pivot],A[r]
      inv=pow(A[r][j],-1,p)
      for k in range(j,nc+1): A[r][k]=(A[r][k]*inv)%p
      for i in range(nrow):
        if i!=r and A[i][j]:
          q=A[i][j]
          for k in range(j,nc+1): A[i][k]=(A[i][k]-q*A[r][k])%p
      r+=1
    for i in range(r,nrow):
      if all(A[i][j]==0 for j in range(nc)) and A[i][nc]!=0:return False
    return True
import sys
for name in sys.argv[1:] or strata:
    sub,free=strata[name]
    ee=[s.expand(e.subs(sub)) for e in eqs]
    A=[[s.diff(e,c) for c in cvars] for e in ee]
    const=[e.subs({c:0 for c in cvars}) for e in ee]
    fun=s.lambdify(free,[item for row in A for item in row]+const,'math')
    p=5;count=0;first=None;st=time()
    for idx,vals in enumerate(product(range(p),repeat=len(free))):
      data=fun(*vals)
      if consistent_aug(data,len(ee),len(cvars),p):
        count+=1
        if first is None:first=vals
    print(name,'count',count,'first',first,'sec',time()-st,flush=True)
