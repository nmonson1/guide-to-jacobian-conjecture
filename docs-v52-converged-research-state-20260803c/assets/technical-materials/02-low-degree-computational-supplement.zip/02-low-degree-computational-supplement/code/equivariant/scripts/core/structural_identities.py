"""Exact checks of the equivariant determinant and quotient identities.

This is a small, human-auditable companion to the branch-elimination scripts.
"""
import sympy as sp

x,y,z,u,v=sp.symbols('x y z u v')
f=sp.Function('f')(u,v)
g=sp.Function('g')(u,v)
h=sp.Function('h')(u,v)

# Work first in coordinates (x,u,v), where y=u/x and z=v/x**2.
# The source change (x,y,z)->(x,u,v) has determinant x**3.
X=x*f
Y=g/x
Z=h/x**2
Jxuv=sp.Matrix([[sp.diff(q,r) for r in (x,u,v)] for q in (X,Y,Z)]).det()
planar=lambda A,B: sp.diff(A,u)*sp.diff(B,v)-sp.diff(A,v)*sp.diff(B,u)
E=g*planar(f,h)-2*h*planar(f,g)+f*planar(g,h)
assert sp.simplify(x**3*Jxuv-E)==0

U=f*g
V=f**2*h
assert sp.simplify(planar(U,V)-f**2*E)==0

# Exhaustive invariant supports from ordinary total degree.
def supports(D, coordinate):
    # coordinate=1,2,3 corresponds to x*f, x^-1*g, x^-2*h.
    shift={1:1,2:-1,3:-2}[coordinate]
    out=[]
    for i in range(10):
        for j in range(10):
            xexp=shift+i+2*j
            total=shift+2*i+3*j
            if xexp>=0 and total<=D:
                out.append((i,j,total))
    return sorted(out,key=lambda q:(q[2],q[0]+q[1],q[0],q[1]))

for D in (4,5,6):
    print(f'D={D}')
    for coordinate,name in ((1,'f'),(2,'g'),(3,'h')):
        print(name,supports(D,coordinate))

print('Equivariant Keller identity and J(fg,f^2h)=f^2*E verified exactly.')
