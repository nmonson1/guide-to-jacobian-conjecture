"""Exact certificates for the degree-6 (-1,1,2)-equivariant theorem.

The script covers:
  (i) the uv term d of f is nonzero (two scaling charts b=0,1), saturated
      by smoothness of f=0;
  (ii) d=0 but the v term b is nonzero (normalize b=1 and split the
       boundary-restriction charts, including the exceptional c=0,k!=0
       chart);
  (iii) prints/verifies the quotient formulas used for the remaining
        b=d=0 conceptual divisibility proof.
All Groebner computations are over QQ and return [1].
"""
import sympy as s
import time

u,v=s.symbols('u v')
a,b,c,d,p,q,r,ss,t,k,A,B,C,D,E,F,G=s.symbols(
    'a b c d p q r ss t k A B C D E F G')
f=1+a*u+b*v+c*u**2+d*u*v
g=u+p*v+q*u**2+r*u*v+ss*u**3+t*v**2+k*u**2*v
h=v+A*u**2+B*u*v+C*u**3+D*v**2+E*u**2*v+F*u**4+G*u*v**2
J=lambda X,Y:s.diff(X,u)*s.diff(Y,v)-s.diff(X,v)*s.diff(Y,u)
K=s.expand(g*J(f,h)-2*h*J(f,g)+f*J(g,h)-1)

def coeffs(expr):
    return list(dict.fromkeys(s.factor(co) for _,co in s.Poly(expr,u,v).terms() if co != 0))

def check(name,equations,variables,extra=()):
    st=time.time()
    GB=s.groebner(list(equations)+list(extra),*variables,order='grevlex',domain=s.QQ)
    ok=GB.contains(s.Integer(1))
    print(f'{name}: equations={len(equations)+len(extra)}, variables={len(variables)}, '
          f'unit={ok}, seconds={time.time()-st:.3f}')
    assert ok and len(GB.polys)==1

T=s.symbols('T')

# d != 0. Independent invariant scalings normalize d=1 and b to 0 or 1.
# Smoothness of C={f=0}, forced by the Keller identity, is Delta != 0.
for bval in (0,1):
    eq=coeffs(K.subs({d:1,b:bval}))
    Delta=1-a*bval+c*bval**2
    variables=[T,A,B,C,D,E,F,G,a,c,p,q,r,ss,t,k]
    check(f'd=1,b={bval},Delta!=0',eq,variables,[T*Delta-1])

# d=0,b!=0. Normalize b=1.
# For c!=0, restriction to f=0 and the polynomial boundary lemma force
#   k=ct, q=-a^2t+ar+cp-ct, ss=-act+cr.
sub_cnz={
    d:0,b:1,
    k:c*t,
    q:-a**2*t+a*r+c*p-c*t,
    ss:-a*c*t+c*r,
}
eq_cnz=coeffs(K.subs(sub_cnz))
branches_cnz=[
    ('d=0,b=1,c!=0,t=0',{t:0},(T*c-1,),[T,A,B,C,D,E,F,G,a,c,p,r]),
    # In the t!=0 chart a coefficient equation gives G=0; substitute it
    # after adjoining (t*c)^(-1).
    ('d=0,b=1,c!=0,t!=0',{G:0},(T*t*c-1,),[T,A,B,C,D,E,F,a,c,p,r,t]),
]
for name,sub,extra,variables in branches_cnz:
    eq=list(dict.fromkeys(s.factor(e.subs(sub)) for e in eq_cnz if s.expand(e.subs(sub))!=0))
    check(name,eq,variables,extra)

# For c=0 the boundary restriction is different and must retain k:
#   ss=a*k, q=-a^2t+ar+k.
sub_c0={d:0,b:1,c:0,ss:a*k,q:-a**2*t+a*r+k}
eq_c0=coeffs(K.subs(sub_c0))

# k=0: split t=0 and t!=0. In the latter chart a coefficient equation
# gives G=0.
branches_c0_k0=[
    ('d=0,b=1,c=0,k=0,t=0',{k:0,t:0},(),[A,B,C,D,E,F,G,a,p,r]),
    ('d=0,b=1,c=0,k=0,t!=0',{k:0,G:0},(T*t-1,),[T,A,B,C,D,E,F,a,p,r,t]),
]
for name,sub,extra,variables in branches_c0_k0:
    eq=list(dict.fromkeys(s.factor(e.subs(sub)) for e in eq_c0 if s.expand(e.subs(sub))!=0))
    check(name,eq,variables,extra)

# k!=0: the remaining u-scaling fixes k=1. The full coefficient ideal is
# already the unit ideal; no further saturation is needed.
sub_k1={k:1}
eq_k1=list(dict.fromkeys(s.factor(e.subs(sub_k1)) for e in eq_c0 if s.expand(e.subs(sub_k1))!=0))
check('d=0,b=1,c=0,k!=0 (k=1)',eq_k1,[A,B,C,D,E,F,G,a,p,r,t])

# d=b=0: quotient calculation used in the hand proof.
# Write g=n(u)+m(u)v and h=L(u)+j(u)v+N(u)v^2.
ff,nn,mm,LL,jj,NN,U=s.symbols('ff nn mm LL jj NN U')
v_of_U=(U/ff-nn)/mm
V=s.expand(ff**2*(LL+jj*v_of_U+NN*v_of_U**2))
Vpoly=s.Poly(V,U)
assert s.simplify(Vpoly.coeff_monomial(U**2)-NN/mm**2)==0
assert s.simplify(Vpoly.coeff_monomial(U)-(ff*jj/mm-2*ff*NN*nn/mm**2))==0
assert s.simplify(Vpoly.coeff_monomial(1)-(
    ff**2*LL-ff**2*jj*nn/mm+ff**2*NN*nn**2/mm**2))==0
print('b=d=0 quotient coefficients verified:')
print('  [U^2]V = N/m^2')
print('  [U]V   = f*j/m - 2*f*N*n/m^2')
print('  dV/du|_U = -f/m follows from J(U,V)=f^2 and U_v=f*m.')
print('All Groebner-covered degree-6 nonconstant-f branches are empty over QQ.')
