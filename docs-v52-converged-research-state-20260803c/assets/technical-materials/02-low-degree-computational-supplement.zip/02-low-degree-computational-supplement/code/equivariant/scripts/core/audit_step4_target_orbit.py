"""Audited finite-field certificate for the filtered target algebra.

Constructs the 82 x 84 evaluation matrix without a hard-coded z reduction,
extracts an explicit 81 x 81 nonzero minor modulo p, and verifies that the
source polynomials 1,Q,R lie in the kernel.
"""
from __future__ import annotations
import json
from pathlib import Path
import sympy as sp

P_MOD = 1_000_003
POINTS = [
(60527,-51474,-965),(84796,4173,5793),(-27475,22536,-98153),
(-45392,94340,16666),(51677,-67018,66425),(96639,-54885,-37448),
(2326,58013,-75353),(56809,46331,-3326),(-24806,28792,-97668),
(36297,81636,-54908),(53078,-30327,-55381),(-78326,-57540,4145),
(10174,-96846,56173),(-50699,57310,-12466),(38277,-98867,-25687),
(31650,-86992,45061),(-30542,-7246,74336),(-4896,12742,40274),
(24845,-87308,-58564),(75882,-49105,-70771),(50961,-91527,-6101),
(22813,68334,-87844),(86708,58022,-57761),(-61022,-17943,-94644),
(-45680,-97616,-36787),(-1170,51275,-95370),(98361,72429,-75626),
(-26211,-16876,-52922),(94637,-92275,-57577),(9248,61226,62532),
(1140,84948,-54128),(-90215,64826,96449),(77756,-19110,41145),
(39348,-90442,18649),(44079,8723,12813),(93307,44851,-71520),
(-84146,15031,-97852),(-30398,78912,-38224),(26122,-5409,12017),
(-85268,77843,32707),(-77098,-64639,-92114),
]
MONS=[]
for total in range(7):
    for i in range(total+1):
        for j in range(total-i+1):
            MONS.append((i,j,total-i-j))
assert len(MONS)==84
INDEX={m:i for i,m in enumerate(MONS)}

# Arithmetic in F_p[T]/(T^3-A T^2-B T-C), vectors ordered 1,T,T^2.
def add(v,w,p=P_MOD): return tuple((v[i]+w[i])%p for i in range(3))
def scale(c,v,p=P_MOD): return tuple(c*q%p for q in v)
def mul(v,w,A,B,C,p=P_MOD):
    raw=[0]*5
    for i in range(3):
        for j in range(3): raw[i+j]=(raw[i+j]+v[i]*w[j])%p
    q=raw[4]
    raw[3]=(raw[3]+q*A)%p; raw[2]=(raw[2]+q*B)%p; raw[1]=(raw[1]+q*C)%p
    q=raw[3]
    raw[2]=(raw[2]+q*A)%p; raw[1]=(raw[1]+q*B)%p; raw[0]=(raw[0]+q*C)%p
    return tuple(raw[:3])
def powv(v,n,A,B,C):
    out=(1,0,0)
    for _ in range(n): out=mul(out,v,A,B,C)
    return out

def solve3(M,b,p=P_MOD):
    aug=[[M[i][j]%p for j in range(3)]+[b[i]%p] for i in range(3)]
    for col in range(3):
        pivot=next(i for i in range(col,3) if aug[i][col])
        aug[col],aug[pivot]=aug[pivot],aug[col]
        inv=pow(aug[col][col],p-2,p)
        aug[col]=[(q*inv)%p for q in aug[col]]
        for i in range(3):
            if i != col and aug[i][col]:
                q=aug[i][col]
                aug[i]=[(aug[i][j]-q*aug[col][j])%p for j in range(4)]
    return tuple(aug[i][3] for i in range(3))

def invv(d,A,B,C):
    es=((1,0,0),(0,1,0),(0,0,1))
    cols=[mul(d,e,A,B,C) for e in es]
    M=[[cols[j][i] for j in range(3)] for i in range(3)]
    return solve3(M,(1,0,0))

def sample(a,b,c):
    p=P_MOD; a%=p; b%=p; c%=p
    assert c
    disc=(27*a*a*c*c-18*a*b*c+16*a+b*b*b*c-b*b)%p
    assert disc
    ci=pow(c,p-2,p)
    # T^3=(2/c)T^2-(b/c)T+(2a/c).
    A=2*ci%p; B=-b*ci%p; C=2*a*ci%p
    T=(0,1,0)
    der=(b%p,-4%p,3*c%p) # P'(T)
    xvec=scale(2,invv(der,A,B,C))
    inv2=pow(2,p-2,p); inv4=pow(4,p-2,p); inv8=pow(8,p-2,p)
    yvec=add(T,scale(-inv2,der))
    der2=mul(der,der,A,B,C); der3=mul(der2,der,A,B,C)
    zvec=add(add(scale(5*inv4%p,der2), scale(-3*inv2%p,mul(T,der,A,B,C))),
             scale(-c*inv8%p,der3))
    one=(1,0,0); xp=[one]; yp=[one]; zp=[one]
    for _ in range(6):
        xp.append(mul(xp[-1],xvec,A,B,C))
        yp.append(mul(yp[-1],yvec,A,B,C))
        zp.append(mul(zp[-1],zvec,A,B,C))
    rows=[[],[]]
    for i,j,k in MONS:
        val=mul(mul(xp[i],yp[j],A,B,C),zp[k],A,B,C)
        rows[0].append(val[1]); rows[1].append(val[2])
    return rows

class RowBasis:
    def __init__(self,n,p=P_MOD): self.n=n; self.p=p; self.rows={}
    def add(self,row):
        p=self.p; r=[q%p for q in row]
        for j in sorted(self.rows):
            if r[j]:
                q=r[j]; base=self.rows[j]
                r=[(x-q*y)%p for x,y in zip(r,base)]
        try: j=next(i for i,x in enumerate(r) if x)
        except StopIteration: return False
        inv=pow(r[j],p-2,p); r=[x*inv%p for x in r]
        for k,base in list(self.rows.items()):
            if base[j]:
                q=base[j]; self.rows[k]=[(x-q*y)%p for x,y in zip(base,r)]
        self.rows[j]=r
        return True

def det_mod(M,p=P_MOD):
    A=[list(map(lambda q:q%p,row)) for row in M]
    n=len(A); det=1
    for col in range(n):
        pivot=next((i for i in range(col,n) if A[i][col]),None)
        if pivot is None: return 0
        if pivot!=col:
            A[col],A[pivot]=A[pivot],A[col]; det=(-det)%p
        pv=A[col][col]; det=det*pv%p; inv=pow(pv,p-2,p)
        for i in range(col+1,n):
            if A[i][col]:
                q=A[i][col]*inv%p
                for j in range(col,n): A[i][j]=(A[i][j]-q*A[col][j])%p
    return det

rows=[]; selected=[]; basis=RowBasis(84)
for pi,pt in enumerate(POINTS):
    for component,row in enumerate(sample(*pt),start=1):
        idx=len(rows); rows.append(row)
        if basis.add(row): selected.append(idx)
assert len(basis.rows)==81 and len(selected)==81
pivots=sorted(basis.rows)
minor=[[rows[i][j] for j in pivots] for i in selected]
det=det_mod(minor)
assert det != 0

x,y,z=sp.symbols('x y z')
Q=y+3*x*(1+x*y)**2*z+3*x*y**2*(4+3*x*y)
R=2*x-3*x**2*y-x**3*z
def coeff_vector(poly):
    pp=sp.Poly(sp.expand(poly),x,y,z)
    out=[0]*84
    for mon,co in pp.terms(): out[INDEX[mon]]=int(co)
    return out
for vec in map(coeff_vector,(1,Q,R)):
    assert all(sum(a*b for a,b in zip(row,vec))%P_MOD==0 for row in rows)

cert={
    'prime':P_MOD,
    'matrix_shape':[len(rows),84],
    'rank_lower_bound':81,
    'selected_row_indices_zero_based':selected,
    'pivot_column_indices_zero_based':pivots,
    'pivot_column_monomials_xyz':[MONS[j] for j in pivots],
    'minor_determinant_mod_prime':det,
    'nonpivot_columns':sorted(set(range(84))-set(pivots)),
    'nonpivot_monomials_xyz':[MONS[j] for j in sorted(set(range(84))-set(pivots))],
}
out_path = Path(__file__).resolve().parents[2] / 'certificates' / 'target_orbit_minor_certificate.json'
with out_path.open('w') as fh:
    json.dump(cert,fh,indent=2)
print(json.dumps({k:cert[k] for k in ('prime','matrix_shape','rank_lower_bound','minor_determinant_mod_prime','nonpivot_columns','nonpivot_monomials_xyz')},indent=2))
