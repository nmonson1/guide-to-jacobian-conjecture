import sympy as s
from collections import defaultdict
x,y,z=s.symbols('x y z')
P=s.expand((1+x*y)**3*z+y**2*(1+x*y)*(4+3*x*y))
Q=s.expand(y+3*x*(1+x*y)**2*z+3*x*y**2*(4+3*x*y))
R=s.expand(2*x-3*x**2*y-x**3*z)
max_target=8; max_source=6
mons=[]
polys=[]
for n in range(max_target+1):
    for i in range(n+1):
      for j in range(n-i+1):
        k=n-i-j
        mons.append((i,j,k)); polys.append(s.Poly(s.expand(P**i*Q**j*R**k),x,y,z))
print('ncols',len(mons))
rows=defaultdict(dict)
for col,poly in enumerate(polys):
    for ex,coef in poly.terms():
        if sum(ex)>max_source:
            rows[ex][col]=coef
rowkeys=sorted(rows)
print('nrows',len(rowkeys))
M=s.MutableSparseMatrix(len(rowkeys),len(mons),{})
for ri,ex in enumerate(rowkeys):
    for col,coef in rows[ex].items(): M[ri,col]=coef
print('built nnz',len(M.todok()))
rank=M.rank()
print('rank',rank,'nullity',len(mons)-rank)
ns=M.nullspace()
print('ns len',len(ns))
for v in ns:
    expr=0
    for c,(i,j,k) in zip(v,mons):
        if c: expr += c*s.Symbol('p')**i*s.Symbol('q')**j*s.Symbol('r')**k
    print(s.factor(expr))
