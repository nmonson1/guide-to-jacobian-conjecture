# Fixed-factor conic leading maps in degrees five and six

This note records a hand argument extending the conic mechanism in
*Quartic Keller Maps and Leading Curves at Infinity*.

Throughout, `k` is algebraically closed of characteristic zero,
`R = k[x,y,z]`, and

\[
\mathsf M(Y)=\begin{pmatrix}Y_1&Y_2\\Y_2&Y_3\end{pmatrix},
\qquad \Phi(Y)=\det \mathsf M(Y)=Y_1Y_3-Y_2^2.
\]

For column vectors `p,q`, write

\[
\operatorname{sym}(p,q)=pq^T+qp^T,
\qquad p\wedge q=p_1q_2-p_2q_1.
\]

## 1. The invariant-degree lemma

Let `G,A,B` be homogeneous, with

\[
\deg G=g>0,\qquad \deg A=\deg B=e,\qquad D=g+2e,
\]

and set

\[
H_D=G(A^2,AB,B^2).
\]

Assume that `G` is squarefree and that for some irreducible component
`Gamma` of `G`, the rational function `A/B` is nonconstant on
`Gamma=0`.

Define the polynomial two-form

\[
\Omega=A\,dG\wedge dB-B\,dG\wedge dA+2G\,dA\wedge dB.
\]

A direct calculation gives

\[
d(GA^2)\wedge d(GAB)=GA^2\Omega.
\]

Let `delta` be the polynomial derivation corresponding to `Omega` under
`Omega = i_delta(dx\wedge dy\wedge dz)`. If a homogeneous polynomial
`P` satisfies

\[
\operatorname{Jac}(GA^2,GAB,P)=0,
\]

then `delta(P)=0`.

Write `G=Gamma G'`, `h=deg Gamma`, and

\[
P=\Gamma^r Q,\qquad \Gamma\nmid Q,\qquad \deg P=m.
\]

The derivation preserves `Gamma=0`. On its function field, both the
induced derivation and the Euler derivation `E` annihilate `A/B`.
Because `A/B` is nonconstant, their common kernel direction is
one-dimensional, so

\[
\bar\delta=cE
\]

for some nonzero rational function `c` on `Gamma=0`.

Since `delta(GB^2)=0`, reduction modulo `Gamma` gives

\[
\overline{\frac{\delta\Gamma}{\Gamma}}
=-c(D-h).
\]

Reducing `delta(P)=0` modulo `Gamma` therefore gives

\[
0=c(m-rh)\bar Q-r c(D-h)\bar Q
  =c(m-rD)\bar Q.
\]

Hence

\[
\boxed{m=rD.}
\]

In particular, every nonzero homogeneous polynomial invariant has degree
divisible by `D`.

Now let

\[
K_\varepsilon=H_D+\varepsilon H_{D-1}+\cdots+
\varepsilon^{D-2}H_2+\varepsilon^{D-1}LX
\]

be a Keller jet and write

\[
\Phi(K_\varepsilon)=\sum_{j\ge1}\varepsilon^jS_j.
\]

The chain rule gives

\[
\operatorname{Jac}(K_{\varepsilon,1},K_{\varepsilon,2},
\Phi(K_\varepsilon))
=K_{\varepsilon,1}\det JK_\varepsilon.
\]

Inductively, if `S_1,...,S_{j-1}` vanish, the coefficient of
`epsilon^j`, for `j<D`, gives

\[
\operatorname{Jac}(H_{D,1},H_{D,2},S_j)=0.
\]

But

\[
\deg S_j=2D-j,
\]

which is strictly between `D` and `2D` for `1<=j<=D-1` and therefore is
not divisible by `D`. Thus

\[
\boxed{S_1=S_2=\cdots=S_{D-1}=0.}
\]

This elementary valuation argument replaces orbit-by-orbit invariant-field
computations on the stated open locus.

## 2. The regular-sequence hypothesis

For the matrix lifting below, assume

\[
V_{\mathbf P^2}(G,A,B)=\varnothing.
\]

Equivalently, the classes of `A,B` form a homogeneous regular sequence in
`R/(G)`. The following standard syzygies are then available both in `R`
and, with the appropriate degree restrictions, modulo `G`:

* `Au_2-Bu_1=0` implies `(u_1,u_2)=c(A,B)`;
* `B^2m_{11}-2ABm_{12}+A^2m_{22}=0` implies

  \[
  \begin{pmatrix}m_{11}&m_{12}\\m_{12}&m_{22}\end{pmatrix}
  =\operatorname{sym}\left(\binom AB,\binom rs\right).
  \]

These are the Koszul and Hilbert--Burch syzygies for the complete
intersection `(A,B)` and its square.

## 3. Degree five, `deg G=1`, `deg A=deg B=2`

Write

\[
M_i=\mathsf M(H_{5-i}),\qquad i=0,\dots,4,
\]

so `M_0=Gvv^T`, where `v=(A,B)^T`, and set `q=(B,-A)^T`.
The invariant-degree lemma gives `S_1=S_2=S_3=S_4=0`.

Successive use of the two syzygies gives parameters

\[
C\in k,\quad r,u\in R_1^2,\quad t\in k^2
\]

such that

\[
\begin{aligned}
M_1&=2Cvv^T+G\operatorname{sym}(v,r),\\
M_2&=Grr^T+\operatorname{sym}(v,u),\\
M_3&=\operatorname{sym}(v,t)+\operatorname{sym}(r,u)-2Crr^T.
\end{aligned}
\]

Put

\[
q_0=u-2Cr,\qquad
P=v+\varepsilon r,\qquad
Q=q_0+\varepsilon t,\qquad
R=M_4-\operatorname{sym}(r,t).
\]

Then the jet has the exact form

\[
\mathsf M(K_\varepsilon)
=(G+2\varepsilon C)PP^T
+\varepsilon^2\operatorname{sym}(P,Q)
+\varepsilon^4R.
\]

The equation `S_4=0` is

\[
(v\wedge q_0)^2=Gq^TRq.
\]

Modulo `G`, the degree-one syzygy `q^TRq=0` must be zero; hence

\[
R=GR_0,
\qquad R_0\in\operatorname{Sym}_2(k).
\]

The same equation implies `G | v wedge q_0`. Since `q_0` has degree one
while `A,B` have degree two, reduction modulo `G` forces

\[
q_0=Gs
\]

for a constant vector `s`. Cancellation then gives

\[
(v\wedge s)^2=q^TR_0q,
\]

and algebraic independence of `A,B` yields

\[
R_0=ss^T.
\]

Define

\[
\widetilde P=v+\varepsilon r+\varepsilon^2s,
\qquad T=t-2Cs.
\]

Adding the source-independent target correction

\[
\varepsilon^5\bigl(\operatorname{sym}(s,t)-2Css^T\bigr)
\]

produces a jet with the same source Jacobian and the exact factorization

\[
\widehat{\mathsf M}_\varepsilon
=(G+2\varepsilon C)\widetilde P\widetilde P^T
+\varepsilon^3\operatorname{sym}(\widetilde P,T).
\]

Therefore

\[
\Phi(\widehat K_\varepsilon)
=-\varepsilon^6(\widetilde P\wedge T)^2.
\]

The chain rule and

\[
\det J\widehat K_\varepsilon=\varepsilon^{12}\det L
\]

give

\[
\varepsilon^6(\det L)\widehat K_{\varepsilon,1}
=-2\Delta\,
\operatorname{Jac}(\widehat K_{\varepsilon,1},
\widehat K_{\varepsilon,2},\Delta),
\qquad \Delta=\widetilde P\wedge T.
\]

If `det L` is nonzero, every irreducible factor of `Delta` other than
`epsilon` would divide both first two target coordinates and hence the
Jacobian determinant, which is impossible. Since `Delta` has total degree
two, it would have to be a scalar multiple of `epsilon^2`. Its constant
coefficient `v wedge T` then vanishes, forcing `T=0`; hence `Delta=0`,
again impossible. Thus `det L=0`.

## 4. Degree five, `deg G=3`, `deg A=deg B=1`

Let `v=(A,B)^T`, with `A,B` independent linear forms. The same vanishing
`S_1=...=S_4=0` yields

\[
\begin{aligned}
M_1&=2Cvv^T+G\operatorname{sym}(v,r),\\
M_2&=Grr^T+\operatorname{sym}(v,u),\\
M_3&=\operatorname{sym}(v,t)+\operatorname{sym}(r,u)-2Crr^T,
\end{aligned}
\]

where `deg C=2`, `r` is constant, `deg u=2`, and `deg t=1`.
The fourth normal equation forces

\[
u-2Cr=C_1v,
\qquad
M_4-\operatorname{sym}(r,t)=\operatorname{sym}(v,a_0),
\]

with `deg C_1=1` and `a_0` constant.

For an arbitrary constant `d`, set

\[
\begin{aligned}
a_\varepsilon&=G+2\varepsilon C+2\varepsilon^2C_1+2\varepsilon^3d,\\
P&=v+\varepsilon r,\\
T&=t-C_1r-dv,\\
U&=a_0-dr.
\end{aligned}
\]

After adding the constant correction

\[
\varepsilon^5\bigl(2drr^T+\operatorname{sym}(r,U)\bigr),
\]

one obtains

\[
\widehat{\mathsf M}_\varepsilon
=a_\varepsilon PP^T
+\varepsilon^3\operatorname{sym}(P,T+\varepsilon U).
\]

Thus

\[
\Phi(\widehat K_\varepsilon)
=-\varepsilon^6\bigl(P\wedge(T+\varepsilon U)\bigr)^2.
\]

The same divisibility argument makes the wedge a scalar multiple of
`epsilon^2`. Its constant term implies `T=cv` for a constant `c`; absorb
`c` into the free parameter `d`. The next coefficient then forces `U=0`,
which makes the wedge zero. This again contradicts `det L != 0`.

Consequently, every basepoint-free reduced conic leading form in degree
five is excluded. Indeed, after extracting square factors from the common
scalar, a full-span conic form of odd degree five has exactly one of the
two degree patterns `(g,e)=(1,2)` or `(3,1)`.

## 5. Degree six, `deg G=2`, `deg A=deg B=2`

Write `M_i=\mathsf M(H_{6-i})`, `i=0,...,5`. The invariant-degree lemma
gives

\[
S_1=S_2=S_3=S_4=S_5=0.
\]

The first three equations give

\[
\begin{aligned}
M_1&=2Cvv^T+G\operatorname{sym}(v,r),\\
M_2&=Grr^T+\operatorname{sym}(v,u),\\
M_3&=\operatorname{sym}(v,t)+\operatorname{sym}(r,u)-2Crr^T,
\end{aligned}
\]

where `deg C=1`, `deg r=1`, `deg u=2`, and `deg t=1`.
Put

\[
q_0=u-2Cr,
\qquad R=M_4-\operatorname{sym}(r,t).
\]

The fourth equation gives

\[
q_0=dv+Gs,
\qquad
R=\operatorname{sym}(v,a_0)+Gss^T
\]

for `d in k` and constant vectors `s,a_0`.
Define

\[
T=t-2Cs-dr,
\qquad U=a_0-2ds.
\]

The fifth coefficient can be written exactly as

\[
S_5=Gq^TWq,
\]

where

\[
W=M_5-
\bigl(
2Css^T+2d\operatorname{sym}(r,s)
+\operatorname{sym}(s,T)+\operatorname{sym}(r,U)
\bigr).
\]

The entries of `W` have degree one, below the first possible degree of a
nonzero syzygy of `(B^2,-2AB,A^2)`, so `W=0`.

Set

\[
\begin{aligned}
a_\varepsilon&=G+2\varepsilon C+2d\varepsilon^2,\\
P&=v+\varepsilon r+\varepsilon^2s,\\
Q&=T+\varepsilon U.
\end{aligned}
\]

Adding the source-independent correction

\[
\varepsilon^6\bigl(\operatorname{sym}(s,U)+2dss^T\bigr)
\]

gives

\[
\widehat{\mathsf M}_\varepsilon
=a_\varepsilon PP^T
+\varepsilon^3\operatorname{sym}(P,Q),
\]

and therefore

\[
\Phi(\widehat K_\varepsilon)
=-\varepsilon^6(P\wedge Q)^2.
\]

Since `det J widehat K = epsilon^15 det L`, the chain rule gives the same
factor-divisibility contradiction. Here `P wedge Q` has total degree three.
It would have to be a scalar multiple of `epsilon^3`; successively its
constant and linear coefficients force `T=0` and `U=0`, hence the wedge
vanishes.

## 6. Degree six, `deg G=4`, `deg A=deg B=1`

Let `v=(A,B)^T` with independent linear entries. The first four normal
equations reduce the jet to parameters

\[
C_3\in R_3,
\quad C_2\in R_2,
\quad r\in k^2,
\quad t\in R_2^2,
\quad a_1\in R_1^2.
\]

For freely chosen `D_1 in R_1` and `d in k`, put

\[
\begin{aligned}
a_\varepsilon
&=G+2\varepsilon C_3+2\varepsilon^2C_2
 +2\varepsilon^3D_1+2\varepsilon^4d,\\
P&=v+\varepsilon r,\\
T&=t-C_2r-D_1v,\\
U&=a_1-D_1r-dv.
\end{aligned}
\]

The fifth normal equation says that

\[
W:=M_5-2D_1rr^T-2d\operatorname{sym}(v,r)
-\operatorname{sym}(r,U)
\]

is a degree-one syzygy of `(B^2,-2AB,A^2)`. Hence

\[
W=\operatorname{sym}(v,s_0)
\]

for a constant vector `s_0`.

After adding

\[
\varepsilon^6\bigl(2drr^T+\operatorname{sym}(r,s_0)\bigr),
\]

one obtains

\[
\widehat{\mathsf M}_\varepsilon
=a_\varepsilon PP^T
+\varepsilon^3\operatorname{sym}
\bigl(P,T+\varepsilon U+\varepsilon^2s_0\bigr).
\]

Again the determinant is `-epsilon^6` times a square. The divisibility
argument first makes `T` a scalar polynomial multiple of `v`; absorb it
into the free parameter `D_1`. It then makes `U` a constant multiple of
`v`; absorb it into `d`. Finally it forces `s_0=0`, a contradiction.

## 7. Consequences and residual strata

The argument proves the following open-locus exclusions.

1. **Degree five:** every conic leading form

   \[
   H_5=G(A^2,AB,B^2)
   \]

   with squarefree `G` and no base point on `G=0` is impossible. The only
   full-span degree patterns are `(deg G,deg A)=(1,2)` and `(3,1)`.

2. **Degree six:** the two fixed-factor conic patterns

   \[
   (\deg G,\deg A)=(2,2),\qquad (4,1)
   \]

   are impossible on the same basepoint-free locus.

The genuinely new remaining conic loci are therefore:

* the basepoint boundary `V(G,A,B) != empty`;
* in degree six, the no-fixed-factor pattern

  \[
  H_6=(A_3^2,A_3B_3,B_3^2),
  \]

  where degree-three characteristic invariants create a real resonance.

The basepoint boundary is the natural next target. In degree five it has a
small normal-form list: on a linear fixed component, the restrictions of
the two quadrics have gcd of degree one or two; for a cubic fixed component
and linear `A,B`, the unique parameter base point lies on the cubic. The
failure of the lifting argument is supported exactly at those points, so a
blow-up/Rees analysis should reduce it to finitely many weighted local
models.
