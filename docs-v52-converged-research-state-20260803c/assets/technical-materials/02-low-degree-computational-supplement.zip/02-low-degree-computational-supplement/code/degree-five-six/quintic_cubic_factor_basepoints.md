# Quintic conic leading maps with a cubic fixed factor

This note continues the conic-leading-map analysis for a degree-five Keller
jet over an algebraically closed field of characteristic zero.

Write

\[
\mathsf M(Y)=\begin{pmatrix}Y_1&Y_2\\Y_2&Y_3\end{pmatrix},
\qquad \Phi(Y)=\det \mathsf M(Y),
\]

and suppose

\[
H_5=G(x,y,z)(x^2,xy,y^2),\qquad \deg G=3,
\]

with `G` squarefree. Put

\[
v=\binom{x}{y},\qquad q=\binom{y}{-x},\qquad
M_i=\mathsf M(H_{5-i}).
\]

Assume some irreducible component of `G=0` carries a nonconstant rational
function `x/y`. The component-valuation argument then gives

\[
S_1=S_2=S_3=S_4=0,
\qquad
\Phi(K_\varepsilon)=\sum_{j\ge1}\varepsilon^jS_j.
\]

The conclusion of this note is

> **Theorem.** If `G` is not a binary cubic in `x,y`, then no degree-five
> Keller jet can have leading form
> \[
> H_5=G(x,y,z)(x^2,xy,y^2).
> \]
> Thus the only cubic-fixed-factor conic locus not eliminated here is the
> binary overlap `G in k[x,y]`.

The proof is by rank-one matrix lifting, local order, and selected exact
coefficient identities. No large coefficient-ideal or terminal Gröbner
calculation is required; one residual nodal subcase reduces to a handful of
scalar eliminations.

## 1. The first two normal equations

From `S_1=0`,

\[
M_1=\operatorname{sym}(v,a)
\]

for a cubic two-vector `a`. From `S_2=0`,

\[
(v\wedge a)^2=Gq^TM_2q.
\]

Since `G` is squarefree,

\[
v\wedge a=G\ell,\qquad q^TM_2q=G\ell^2,
\tag{1.1}
\]

where `ell` is linear.

Let `p=[0:0:1]`, the common zero of `x` and `y`.  If `G(p) != 0`, the
basepoint-free fixed-factor conic theorem applies.  Suppose therefore that
`G(p)=0`.

If `p` is a smooth point of `G=0`, then
`q^T M_2 q` has local order at least two while `G` has order one. Equation
(1.1) therefore forces `ell(p)=0`.  Write `ell=v wedge r`; after the
corresponding affine source translation the first deformation becomes purely
radial.  The second normal equation then has no torsion term, so this is the
`d=0` rank-one Hensel branch and is excluded by the deformed-conic
divisibility argument.

At a double point there are two branches:

1. `ell(p)=0`, called the regular branch;
2. `ell(p) != 0`, called the unit branch.

Both are excluded below.

## 2. The unit branch at a reduced double point

After absorbing the binary part of `ell` and scaling, take `ell=z`. For each
reduced double-point normal form choose a symmetric linear matrix `R` such
that

\[
q^TRq=G,
\qquad w=-Rq,
\qquad v\wedge w=G.
\]

The first two normal equations can then be written

\[
M_1=2Cvv^T+z\operatorname{sym}(v,w),
\qquad
M_2=z^2R+\operatorname{sym}(v,u),
\tag{2.1}
\]

with `C` quadratic and `u` a quadratic two-vector. Let `M_3` and `M_4` be
arbitrary symmetric matrices of quadratic and linear forms, respectively.

Write locally

\[
G=z g_2(x,y)+g_3(x,y).
\]

If the tangent cone `g_2` has rank two, the coefficient `[z^6]S_4` is
`det(R_2)`, where `q^T R_2q=g_2`; it is nonzero.  If `g_2` has rank one,
normalize it to `y^2`.  Writing

\[
g_3=\alpha x^3+\beta x^2y+\gamma xy^2+\delta y^3,
\]

the coefficient `[xz^5]S_4` is `alpha`.  Thus only `alpha=0` remains;
squarefreeness then forces `beta != 0`, the tangent line--conic case.
After the permitted linear and translation normalizations, the following
five representatives are convenient:

| Type | `G` | `R` |
|---|---|---|
| node | `z(y^2-x^2)-x^3` | `diag(z,-z-x)` |
| cusp | `y^2 z-x^3` | `diag(z,-x)` |
| transverse line-conic | `xyz-x^3` | `[[0,-z/2],[-z/2,-x]]` |
| three lines, two through `p` | `xyz` | `[[0,-z/2],[-z/2,0]]` |
| tangent line-conic | `y^2z-x^2y` | `diag(z,-y)` |

For the first four representatives, the preceding invariant obstruction is
visible as the following parameter-independent monomial:

| Type | Forced coefficient |
|---|---|
| node | `[z^6]S_4=-1` |
| cusp | `[xz^5]S_4=-1` |
| transverse line-conic | `[z^6]S_4=-1/4` |
| `xyz` | `[z^6]S_4=-1/4` |

Thus `S_4=0` is impossible.

For the tangent line-conic type, a residual term `kappa y^3` may be retained
in `G`; the calculation below is independent of `kappa`.  Solving `S_3=0`
and inspecting two coefficients of `S_4` gives, with `u_{2,z^2}` denoting the `z^2` coefficient
of the second component of `u`,

\[
[u_{2,z^2}\text{-equation}]\colon\quad u_{2,z^2}^2=0,
\qquad
[yz^5]S_4=2u_{2,z^2}-1=0,
\]

which is again impossible.

Hence the unit branch never occurs at a reduced double point.

## 3. The regular branch

When `ell(p)=0`, write `ell=v wedge r` with `r` constant. An affine source
translation kills `r`. The four normal equations then reduce the jet to

\[
\begin{aligned}
M_0&=Gvv^T,\\
M_1&=2Cvv^T,\\
M_2&=\operatorname{sym}(v,C_1v+dw),\\
M_3&=\operatorname{sym}(v,t),\\
M_4&=d^2R+\operatorname{sym}(v,a_0),
\end{aligned}
\tag{3.1}
\]

where `C` is quadratic, `C_1` is linear, `t` is a vector of linear forms,
`a_0` is constant, and `d` is constant. The case `d=0` is exactly the
rank-one Hensel branch already handled by the deformed-conic divisibility
argument. Hence assume `d != 0`.

Write

\[
C=C_2+c_{10}xz+c_{01}yz+c_{00}z^2.
\]

The coefficient of `epsilon^5` in the full source Jacobian determinant is

\[
10dG^2\left(
2c_{00}dz+c_{01}dy+c_{10}dx+t_{1,z}y-t_{2,z}x
\right).
\tag{3.2}
\]

Consequently

\[
c_{00}=0,
\qquad t_{1,z}=-dc_{01},
\qquad t_{2,z}=dc_{10}.
\tag{3.3}
\]

The remaining reduced double-point types are eliminated by very small
coefficient systems.

### 3.1 Cusp

For `G=y^2z-x^3`, restriction to the basepoint axis gives

\[
c_{10}=c_{01}=0.
\]

The `xz` and `yz` coefficients of the `epsilon^10` Keller equation are

\[
d^4(C_1)_z=0,
\qquad
4(a_0)_2d^2(C_1)_z-d^5=0,
\]

which contradict `d != 0`.

### 3.2 Node

For `G=z(y^2-x^2)-x^3`, the axis equations give

\[
c_{01}^2=c_{10}^2,
\qquad
4(a_0)_1c_{01}+4(a_0)_2c_{10}-d^2c_{01}=0.
\tag{3.4}
\]

If `(c_{01},c_{10}) != (0,0)`, the symmetry `y -> -y` lets us take
`c_{01}=c_{10}=h`. Then (3.4) says

\[
(a_0)_1+(a_0)_2=\frac{d^2}{4}.
\]

The `xz^2` coefficient of the `epsilon^9` equation is

\[
-8d^3h\bigl(d-(C_1)_z\bigr),
\]

whereas the `xyz^2` coefficient of the `epsilon^8` equation is

\[
8d^2h^2\bigl(4d-(C_1)_z\bigr).
\]

Thus `(C_1)_z=d=4d`, contradicting `d != 0`.

If `c_{01}=c_{10}=0`, the `x^4z^2` coefficient of the
`epsilon^6` equation is

\[
12d^2(C_1)_z,
\]

while the `x^2z^2` coefficient of the `epsilon^8` equation is

\[
8d^2\bigl(d-(C_1)_z\bigr)\bigl(d+(C_1)_z\bigr).
\]

The first forces `(C_1)_z=0`; the second then forces `d=0`, again a
contradiction.

### 3.3 Transverse line-conic and `xyz`

For `G=xyz-x^3` or `G=xyz`, the axis equations force

\[
c_{10}=c_{01}=0.
\]

Invertibility of the linear part gives both entries of `a_0` nonzero. The
`xz` and `yz` coefficients of the `epsilon^10` equation then give

\[
(C_1)_z=\frac d2,
\qquad
(C_1)_z=-\frac d2,
\]

contradicting `d != 0`.

### 3.4 Tangent line-conic

For `G=y^2z-x^2y`, the axis equations force `c_{10}=0`. Put
`h=c_{01}`.

If `h=0`, selected `epsilon^6` equations give

\[
(C_1)_z=0,
\qquad
(C_1)_x=\frac{(a_0)_2}{d},
\qquad
(C_1)_y=-\frac{(a_0)_1}{d}.
\]

An `epsilon^8` coefficient then becomes

\[
3d^2\left(2(a_0)_2-d^2\right)=0,
\]

while

\[
\det L=(a_0)_2d^2\left(2(a_0)_2-d^2\right),
\]

so the linear part cannot be invertible.

If `h != 0`, successive high-`z` coefficients give

\[
(C_1)_z=\frac{h^2}{2},
\qquad
t_{21}=-\frac{dh}{2},
\qquad
[c_{20}]C=-\frac h2.
\]

After these substitutions, the `x^4` coefficient of the
`epsilon^8` equation is `h^4`, a contradiction.

## 4. Residual cubic-fixed-factor locus

A squarefree cubic through `p` of multiplicity three is a binary cubic in
`x,y`, and every irreducible component has constant `x/y`. The invariant-gap
argument therefore does not apply. In this case

\[
H_5=G(x,y)(x^2,xy,y^2)
\]

is a binary leading map with a fixed divisor. It should be treated with the
binary Hilbert--Burch/ramification module rather than as a genuinely
three-variable conic stratum.

Thus all genuinely three-variable cubic-fixed-factor quintic conic maps are
excluded.
