"""Exact symbolic checks for the degree-5 and degree-6 conic Hensel identities.

This verifies only the universal 2x2 symmetric-matrix algebra.  The
commutative-algebra steps (regular-sequence syzygies and the invariant-degree
lemma) are separate hand arguments.
"""
from __future__ import annotations

import sympy as sp


def symm(p: sp.Matrix, q: sp.Matrix) -> sp.Matrix:
    return p * q.T + q * p.T


def wedge(p: sp.Matrix, q: sp.Matrix) -> sp.Expr:
    return sp.expand(p[0] * q[1] - p[1] * q[0])


def assert_zero_matrix(m: sp.Matrix) -> None:
    assert all(sp.expand(entry) == 0 for entry in m), m


def check_degree_5() -> None:
    e = sp.symbols("e")
    G, C = sp.symbols("G C")
    A, B = sp.symbols("A B")
    r1, r2, s1, s2, t1, t2 = sp.symbols("r1 r2 s1 s2 t1 t2")

    v = sp.Matrix([A, B])
    r = sp.Matrix([r1, r2])
    s = sp.Matrix([s1, s2])
    t = sp.Matrix([t1, t2])

    u = 2 * C * r + G * s
    M0 = G * v * v.T
    M1 = 2 * C * v * v.T + G * symm(v, r)
    M2 = G * r * r.T + symm(v, u)
    M3 = symm(v, t) + symm(r, u) - 2 * C * r * r.T
    M4 = symm(r, t) + G * s * s.T
    M = M0 + e * M1 + e**2 * M2 + e**3 * M3 + e**4 * M4

    P = v + e * r + e**2 * s
    T = t - 2 * C * s
    correction = symm(s, t) - 2 * C * s * s.T
    lifted = (G + 2 * e * C) * P * P.T + e**3 * symm(P, T)

    assert_zero_matrix(sp.simplify(M + e**5 * correction - lifted))
    assert sp.expand(lifted.det() + e**6 * wedge(P, T) ** 2) == 0


def check_degree_6() -> None:
    e = sp.symbols("e")
    G, C, d = sp.symbols("G C d")
    A, B = sp.symbols("A B")
    r1, r2, s1, s2 = sp.symbols("r1 r2 s1 s2")
    T1, T2, U1, U2 = sp.symbols("T1 T2 U1 U2")

    v = sp.Matrix([A, B])
    r = sp.Matrix([r1, r2])
    s = sp.Matrix([s1, s2])
    T = sp.Matrix([T1, T2])
    U = sp.Matrix([U1, U2])

    scalar = G + 2 * e * C + 2 * d * e**2
    P = v + e * r + e**2 * s
    Q = T + e * U
    correction = symm(s, U) + 2 * d * s * s.T
    lifted = scalar * P * P.T + e**3 * symm(P, Q)
    M = sp.expand(lifted - e**6 * correction)

    # M has no terms beyond e^5, as required for a sextic Keller jet.
    for i in range(2):
        for j in range(2):
            assert sp.expand(M[i, j]).coeff(e, 6) == 0
            assert all(sp.expand(M[i, j]).coeff(e, k) == 0 for k in range(7, 10))

    assert_zero_matrix(sp.simplify(M + e**6 * correction - lifted))
    assert sp.expand(lifted.det() + e**6 * wedge(P, Q) ** 2) == 0


def check_degree_6_S5_identity() -> None:
    """Check the pre-normal-form identity S5 = G q^T W q."""
    e = sp.symbols("e")
    G, C, d = sp.symbols("G C d")
    A, B = sp.symbols("A B")
    r1, r2, s1, s2 = sp.symbols("r1 r2 s1 s2")
    T1, T2, U1, U2 = sp.symbols("T1 T2 U1 U2")
    w11, w12, w22 = sp.symbols("w11 w12 w22")

    v = sp.Matrix([A, B])
    q = sp.Matrix([B, -A])
    r = sp.Matrix([r1, r2])
    s = sp.Matrix([s1, s2])
    T = sp.Matrix([T1, T2])
    U = sp.Matrix([U1, U2])
    W = sp.Matrix([[w11, w12], [w12, w22]])

    scalar = G + 2 * e * C + 2 * d * e**2
    P = v + e * r + e**2 * s
    Q = T + e * U
    base = scalar * P * P.T + e**3 * symm(P, Q)
    # Insert an arbitrary degree-one residual W at order e^5.  The e^6 term is
    # irrelevant to the coefficient S5.
    trial = base + e**5 * W
    S5 = sp.expand(trial.det()).coeff(e, 5)
    expected = G * (q.T * W * q)[0]
    assert sp.expand(S5 - expected) == 0




def check_degree_5_linear_parameter() -> None:
    """Degree 5: deg(G)=3 and deg(v)=1."""
    e = sp.symbols("e")
    G, C, C1, d = sp.symbols("G C C1 d")
    A, B = sp.symbols("A B")
    r1, r2, t1, t2, a01, a02 = sp.symbols("r1 r2 t1 t2 a01 a02")

    v = sp.Matrix([A, B])
    r = sp.Matrix([r1, r2])
    t = sp.Matrix([t1, t2])
    a0 = sp.Matrix([a01, a02])

    u = 2 * C * r + C1 * v
    M0 = G * v * v.T
    M1 = 2 * C * v * v.T + G * symm(v, r)
    M2 = G * r * r.T + symm(v, u)
    M3 = symm(v, t) + symm(r, u) - 2 * C * r * r.T
    M4 = symm(r, t) + symm(v, a0)
    M = M0 + e * M1 + e**2 * M2 + e**3 * M3 + e**4 * M4

    scalar = G + 2 * e * C + 2 * e**2 * C1 + 2 * e**3 * d
    P = v + e * r
    T = t - C1 * r - d * v
    U = a0 - d * r
    correction = 2 * d * r * r.T + symm(r, U)
    lifted = scalar * P * P.T + e**3 * symm(P, T + e * U)

    assert_zero_matrix(sp.simplify(M + e**5 * correction - lifted))
    assert sp.expand(lifted.det() + e**6 * wedge(P, T + e * U) ** 2) == 0


def check_degree_6_linear_parameter() -> None:
    """Degree 6: deg(G)=4 and deg(v)=1."""
    e = sp.symbols("e")
    G, C3, C2, D1, d = sp.symbols("G C3 C2 D1 d")
    A, B = sp.symbols("A B")
    r1, r2, t1, t2, a11, a12, s01, s02 = sp.symbols(
        "r1 r2 t1 t2 a11 a12 s01 s02"
    )

    v = sp.Matrix([A, B])
    r = sp.Matrix([r1, r2])
    t = sp.Matrix([t1, t2])
    a1 = sp.Matrix([a11, a12])
    s0 = sp.Matrix([s01, s02])

    u = 2 * C3 * r + C2 * v
    T = t - C2 * r - D1 * v
    U = a1 - D1 * r - d * v
    M5 = 2 * D1 * r * r.T + 2 * d * symm(v, r) + symm(r, U) + symm(v, s0)

    M0 = G * v * v.T
    M1 = 2 * C3 * v * v.T + G * symm(v, r)
    M2 = G * r * r.T + symm(v, u)
    M3 = symm(v, t) + symm(r, u) - 2 * C3 * r * r.T
    M4 = symm(r, t) + symm(v, a1)
    M = M0 + e * M1 + e**2 * M2 + e**3 * M3 + e**4 * M4 + e**5 * M5

    scalar = G + 2 * e * C3 + 2 * e**2 * C2 + 2 * e**3 * D1 + 2 * e**4 * d
    P = v + e * r
    Q = T + e * U + e**2 * s0
    correction = 2 * d * r * r.T + symm(r, s0)
    lifted = scalar * P * P.T + e**3 * symm(P, Q)

    assert_zero_matrix(sp.simplify(M + e**6 * correction - lifted))
    assert sp.expand(lifted.det() + e**6 * wedge(P, Q) ** 2) == 0


if __name__ == "__main__":
    check_degree_5()
    check_degree_5_linear_parameter()
    check_degree_6()
    check_degree_6_linear_parameter()
    check_degree_6_S5_identity()
    print("All fixed-factor degree-5 and degree-6 conic Hensel identities verified exactly.")
