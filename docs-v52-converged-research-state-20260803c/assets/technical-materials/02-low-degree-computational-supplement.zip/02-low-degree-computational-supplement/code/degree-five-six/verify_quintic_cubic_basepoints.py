"""Exact checks for the selected coefficient identities in
quintic_cubic_factor_basepoints.md.

The script verifies the finite 2x2 matrix and 3x3 Keller-determinant
coefficients used in the note.  It is not a Groebner-basis proof.
"""
from __future__ import annotations

from itertools import permutations
import sympy as sp

x, y, z, eps = sp.symbols("x y z eps")


def symm(p: sp.Matrix, q: sp.Matrix) -> sp.Matrix:
    return p * q.T + q * p.T


def triple(M: sp.Matrix) -> sp.Matrix:
    return sp.Matrix([M[0, 0], M[0, 1], M[1, 1]])


def det_coeff(Js: list[sp.Matrix], k: int) -> sp.Expr:
    """Coefficient of eps^k in det(sum eps^i Js[i])."""
    out = 0
    for perm in permutations(range(3)):
        inv = sum(
            perm[i] > perm[j]
            for i in range(3)
            for j in range(i + 1, 3)
        )
        sign = -1 if inv % 2 else 1
        for i0 in range(len(Js)):
            for i1 in range(len(Js)):
                i2 = k - i0 - i1
                if 0 <= i2 < len(Js):
                    out += (
                        sign
                        * Js[i0][0, perm[0]]
                        * Js[i1][1, perm[1]]
                        * Js[i2][2, perm[2]]
                    )
    return sp.expand(out)


def coeff(poly: sp.Expr, monomial: sp.Expr) -> sp.Expr:
    P = sp.Poly(sp.expand(poly), x, y, z)
    powers = sp.Poly(monomial, x, y, z).monoms()[0]
    return sp.factor(P.coeff_monomial(powers))


def check_unit_branch() -> None:
    v = sp.Matrix([x, y])
    q = sp.Matrix([y, -x])
    b2 = [x**2, x * y, y**2, x * z, y * z, z**2]
    b1 = [x, y, z]

    cc = sp.symbols("c0:6")
    C = sum(c * m for c, m in zip(cc, b2))
    u1c = sp.symbols("u10:16")
    u2c = sp.symbols("u20:26")
    u = sp.Matrix(
        [sum(c * m for c, m in zip(u1c, b2)),
         sum(c * m for c, m in zip(u2c, b2))]
    )

    m11c = sp.symbols("m110:116")
    m12c = sp.symbols("m120:126")
    m22c = sp.symbols("m220:226")
    M3 = sp.Matrix(
        [
            [sum(c * m for c, m in zip(m11c, b2)),
             sum(c * m for c, m in zip(m12c, b2))],
            [sum(c * m for c, m in zip(m12c, b2)),
             sum(c * m for c, m in zip(m22c, b2))],
        ]
    )

    n11c = sp.symbols("n110:113")
    n12c = sp.symbols("n120:123")
    n22c = sp.symbols("n220:223")
    M4 = sp.Matrix(
        [
            [sum(c * m for c, m in zip(n11c, b1)),
             sum(c * m for c, m in zip(n12c, b1))],
            [sum(c * m for c, m in zip(n12c, b1)),
             sum(c * m for c, m in zip(n22c, b1))],
        ]
    )

    cases = {
        "node": (
            z * (y**2 - x**2) - x**3,
            sp.Matrix([[z, 0], [0, -z - x]]),
            z**6,
            -1,
        ),
        "cusp": (
            y**2 * z - x**3,
            sp.Matrix([[z, 0], [0, -x]]),
            x * z**5,
            -1,
        ),
        "transverse": (
            x * y * z - x**3,
            sp.Matrix([[0, -z / 2], [-z / 2, -x]]),
            z**6,
            sp.Rational(-1, 4),
        ),
        "xyz": (
            x * y * z,
            sp.Matrix([[0, -z / 2], [-z / 2, 0]]),
            z**6,
            sp.Rational(-1, 4),
        ),
    }

    for name, (G, R, mon, expected) in cases.items():
        assert sp.expand((q.T * R * q)[0] - G) == 0, name
        w = -R * q
        M0 = G * v * v.T
        M1 = 2 * C * v * v.T + z * symm(v, w)
        M2 = z**2 * R + symm(v, u)
        M = M0 + eps * M1 + eps**2 * M2 + eps**3 * M3 + eps**4 * M4
        S4 = sp.expand(M.det()).coeff(eps, 4)
        assert coeff(S4, mon) == expected, (name, coeff(S4, mon))

    # Tangent line-conic: retain the residual kappa*y^3 term, solve S3
    # linearly, then compare two S4 coefficients.  The obstruction is
    # independent of kappa.
    kappa = sp.symbols("kappa")
    G = y**2 * z - x**2 * y + kappa * y**3
    R = sp.Matrix([[z + kappa * y, 0], [0, -y]])
    w = -R * q
    M0 = G * v * v.T
    M1 = 2 * C * v * v.T + z * symm(v, w)
    M2 = z**2 * R + symm(v, u)
    M = M0 + eps * M1 + eps**2 * M2 + eps**3 * M3 + eps**4 * M4
    detM = sp.expand(M.det())
    S3 = sp.Poly(detM.coeff(eps, 3), x, y, z)
    vars3 = list(m11c + m12c + m22c) + [cc[3], cc[4], cc[5]]
    sol = sp.solve([c for _, c in S3.terms()], vars3, dict=True, simplify=False)
    assert len(sol) == 1
    S4 = sp.expand(detM.coeff(eps, 4).subs(sol[0]))
    assert coeff(S4, x**2 * z**4) == -u2c[5] ** 2
    assert coeff(S4, y * z**5) == 2 * u2c[5] - 1


def regular_matrices(G: sp.Expr, R: sp.Matrix):
    d = sp.symbols("d", nonzero=True)
    a, b = sp.symbols("a b")
    c20, c11, c02, c10, c01 = sp.symbols("c20 c11 c02 c10 c01")
    C = c20 * x**2 + c11 * x * y + c02 * y**2 + c10 * x * z + c01 * y * z
    l1, l2, l3 = sp.symbols("l1 l2 l3")
    C1 = l1 * x + l2 * y + l3 * z
    t11, t12, t21, t22 = sp.symbols("t11 t12 t21 t22")
    t = sp.Matrix(
        [t11 * x + t12 * y - c01 * d * z,
         t21 * x + t22 * y + c10 * d * z]
    )
    v = sp.Matrix([x, y])
    q = sp.Matrix([y, -x])
    w = -R * q
    a0 = sp.Matrix([a, b])
    u = C1 * v + d * w
    Ms = [
        G * v * v.T,
        2 * C * v * v.T,
        symm(v, u),
        symm(v, t),
        d**2 * R + symm(v, a0),
    ]
    Js = [triple(M).jacobian([x, y, z]) for M in Ms]
    params = locals()
    return Js, params


def check_regular_easy_cases() -> None:
    # Cusp.
    G = y**2 * z - x**3
    R = sp.Matrix([[z, 0], [0, -x]])
    Js, p = regular_matrices(G, R)
    d, a, b = p["d"], p["a"], p["b"]
    c10, c01, l3 = p["c10"], p["c01"], p["l3"]
    k10 = det_coeff(Js, 10).subs({c10: 0, c01: 0})
    assert coeff(k10, x * z) == 2 * d**4 * l3
    assert coeff(k10, y * z) == 2 * d**2 * (4 * b * l3 - d**3)

    # Node.  The axis equations split into a nonzero and a zero branch.
    G = z * (y**2 - x**2) - x**3
    R = sp.Matrix([[z, 0], [0, -z - x]])
    Js, p = regular_matrices(G, R)
    d, a, b = p["d"], p["a"], p["b"]
    c10, c01, l3 = p["c10"], p["c01"], p["l3"]
    h = sp.symbols("h")
    nonzero = {c01: h, c10: h, a: d**2 / 4 - b}
    k9 = det_coeff(Js, 9).subs(nonzero)
    k8 = det_coeff(Js, 8).subs(nonzero)
    assert coeff(k9, x * z**2) == -8 * d**3 * h * (d - l3)
    assert coeff(k8, x * y * z**2) == 8 * d**2 * h**2 * (4 * d - l3)
    zero = {c01: 0, c10: 0}
    k6 = det_coeff(Js, 6).subs(zero)
    k8 = det_coeff(Js, 8).subs(zero)
    assert coeff(k6, x**4 * z**2) == 12 * d**2 * l3
    assert coeff(k8, x**2 * z**2) == 8 * d**2 * (d - l3) * (d + l3)

    # Transverse line-conic and xyz.
    for G, R in [
        (x * y * z - x**3, sp.Matrix([[0, -z / 2], [-z / 2, -x]])),
        (x * y * z, sp.Matrix([[0, -z / 2], [-z / 2, 0]])),
    ]:
        Js, p = regular_matrices(G, R)
        d, a, b = p["d"], p["a"], p["b"]
        c10, c01, l3 = p["c10"], p["c01"], p["l3"]
        k10 = det_coeff(Js, 10).subs({c10: 0, c01: 0})
        assert coeff(k10, x * z) == -2 * b * d**2 * (d - 2 * l3)
        assert coeff(k10, y * z) == 2 * a * d**2 * (d + 2 * l3)

    # Tangent line-conic, h=0 and h!=0 selected identities.
    G = y**2 * z - x**2 * y
    R = sp.Matrix([[z, 0], [0, -y]])
    Js, p = regular_matrices(G, R)
    d, a, b = p["d"], p["a"], p["b"]
    c20, c10, c01 = p["c20"], p["c10"], p["c01"]
    l1, l2, l3 = p["l1"], p["l2"], p["l3"]
    t21 = p["t21"]
    # Axis already imposes c10=0.
    Js = [J.subs(c10, 0) for J in Js]
    k6, k8 = det_coeff(Js, 6), det_coeff(Js, 8)
    h0 = {c01: 0, l3: 0, l1: b / d, l2: -a / d}
    assert coeff(k8.subs(h0), y**3 * z) == 3 * d**2 * (2 * b - d**2)
    h = c01
    subs = {l3: h**2 / 2, t21: -d * h / 2, c20: -h / 2}
    assert sp.factor(coeff(k8.subs(subs), x**4)) == d**2 * h**4


def main() -> None:
    check_unit_branch()
    check_regular_easy_cases()
    print("Selected quintic cubic-factor basepoint identities verified exactly.")


if __name__ == "__main__":
    main()
