# Computation index

The supplement separates theorem-bearing exact elimination from exploratory
finite-field searches.

| Mathematical role | Files | What is checked |
| --- | --- | --- |
| Rank-one quartic theorem | `code/rank-one/` | universal determinant identities for arbitrary binary cubics, binary quartic, lower terms, and linear part |
| Reduced nonsingular conics | `code/recovered-conic/` | exhaustive normal forms for four conic orbits and their decisive terminal factorizations |
| Unified conic certificate | `code/verify_conic_certificates.py` | reconstructs the five terminal charts without random specialization |
| Bounded equivariant threshold | `code/equivariant/scripts/core/` | exact degree-\(4,5,6\) eliminations and the target-orbit rank certificate |
| Degree-five/six fixed factors | `code/degree-five-six/` | four graded Hensel identities and the decisive coefficients in the genuinely three-variable quintic boundary |
| Exploratory searches | `code/equivariant/scripts/exploratory/` | modular scans retained as research evidence, not promoted to characteristic-zero theorems |

Minimal replay begins with:

```bash
uv run --with sympy==1.14.0 python code/rank-one/rank_one_binary_identities.py
uv run --with sympy==1.14.0 python code/verify_conic_certificates.py
uv run --with sympy==1.14.0 python code/degree-five-six/verify_conic_hensel_d5_d6.py
uv run --with sympy==1.14.0 python code/degree-five-six/verify_quintic_cubic_basepoints.py
cd code/equivariant
uv run --with sympy==1.14.0 python scripts/core/check_all.py
uv run --with sympy==1.14.0 python scripts/core/step2_d5_equivariant_exact.py
uv run --with sympy==1.14.0 python scripts/core/step3_d6_equivariant_exact.py
```

Imported SHA-256 identifiers:

- `conic_fixed_factor_d5_d6_proof_note.md`:
  `c278f56ba66b4ee39ec7bae4c2821962a3c8269c8017b817bd3907041c9e4471`;
- `verify_conic_hensel_d5_d6.py`:
  `bda8b334986c9920a6599f84cd0b917c09a2ed0909982c5afaaea2e083efae09`;
- `quintic_cubic_factor_basepoints.md`:
  `c2dbfba35f60fc14e1a49410b6452cb8ccb5c2e027085f1f6b7b726537f62a43`;
- `verify_quintic_cubic_basepoints.py`:
  `160c683a7f3f11bc0750f887bb909219053a07ccc7812e424d5d2e037ee6ddc5`.

The scripts do not prove the conventional composite-pencil, orbit-list, or
invariant-field lemmas identified in the paper.
