"""Exact certificates for the h=x^2*y^2, Delta_23 != 0 binary chart.

Normal form
-----------
    h = x^2*y^2,
    P = a*x^3 + b*x^2*y + x*y^2,
    Q = c*x^3 + d*x^2*y + y^3.

The script verifies over QQ:
  * the S1 rank-drop locus is the union of a common-factor component and a
    cubic-pencil component;
  * det(S0)=1296*(a*d-b*c)*Phi_22;
  * the common-factor S1 component is eliminated by exact degree-five
    coefficients of the complete Keller determinant;
  * every chart of a*d-b*c=0 is eliminated (apart from cube charts, which are
    displayed explicitly);
  * every chart of Phi_22=0 with a*d-b*c != 0 is eliminated, including the
    rank-five incidence locus 3*a*b-c=0.

All lower homogeneous coefficients are retained in the degree-five
coefficient calculation.  No floating-point or modular inference is used.
"""
from __future__ import annotations
from itertools import combinations
import sympy as s

x, y, z = s.symbols("x y z")
a, b, c, d = s.symbols("a b c d")
h = x**2 * y**2
P = a*x**3 + b*x**2*y + x*y**2
Q = c*x**3 + d*x**2*y + y**3


def J(f, g):
    return s.expand(s.diff(f, x)*s.diff(g, y) - s.diff(f, y)*s.diff(g, x))


def coeff_matrix(poly, unknowns, degree):
    pp = s.Poly(s.expand(poly), x, y)
    return s.Matrix([
        [s.diff(pp.coeff_monomial(x**(degree-i)*y**i), u) for u in unknowns]
        for i in range(degree+1)
    ])


def syzygy_matrices(P0, Q0):
    W, U, V = J(P0, Q0), J(P0, h), J(Q0, h)
    l0, l1, alpha, beta = s.symbols("l0 l1 alpha beta")
    M1 = coeff_matrix(
        W*(l0*x+l1*y) + alpha*V - beta*U,
        [l0, l1, alpha, beta], 5,
    )
    q0, q1, q2, A0, A1, B0, B1 = s.symbols("q0 q1 q2 A0 A1 B0 B1")
    M0 = coeff_matrix(
        W*(q0*x**2+q1*x*y+q2*y**2)
        + V*(A0*x+A1*y) - U*(B0*x+B1*y),
        [q0, q1, q2, A0, A1, B0, B1], 6,
    )
    return M1, M0


M1, M0 = syzygy_matrices(P, Q)
Delta = a*d-b*c
Phi = (
    81*a**3 - 18*a**2*d - 3*a*b**2*d + 27*a*b*c + a*d**2
    + 3*b**3*c - b*c*d - 3*c**2
)


def degree5_poly(P0, Q0, Az, Bz, Rz, *, Azz=0, Bzz=0, Rz2=0):
    """Degree-five homogeneous coefficient of det J(H2+H3+H4).

    This is exactly the total-degree-five part of det JF for arbitrary
    invertible linear part.  Every otherwise unrestricted coefficient of
    H2 and H3 is retained.
    """
    T = s.symbols("Tscale")
    m2b = [x**2, x*y, y**2]
    m2 = [x**2, x*y, x*z, y**2, y*z, z**2]
    m3b = [x**3, x**2*y, x*y**2, y**3]
    aa = s.symbols("aa0:3")
    bb = s.symbols("bb0:3")
    cc = s.symbols("cc0:6")
    rr = s.symbols("rr0:4")
    Abar = sum(q*m for q, m in zip(aa, m2b))
    Bbar = sum(q*m for q, m in zip(bb, m2b))
    C2 = sum(q*m for q, m in zip(cc, m2))
    Rbar = sum(q*m for q, m in zip(rr, m3b))
    H2 = [Abar + z*Az + Azz*z**2,
          Bbar + z*Bz + Bzz*z**2,
          C2]
    H3 = [P0, Q0, Rbar + z*Rz + z**2*Rz2]
    H4 = [0, 0, h]
    mats = [s.Matrix([[s.diff(f, w) for w in (x, y, z)] for f in H])
            for H in (H2, H3, H4)]
    expr = s.expand((T*mats[0] + T**2*mats[1] + T**3*mats[2]).det())
    e5 = s.Poly(expr, T).coeff_monomial(T**5)
    return s.Poly(s.expand(e5), x, y, z), cc[5]


def cf(poly, mon):
    return s.factor(poly.coeff_monomial(x**mon[0]*y**mon[1]*z**mon[2]))


def assert_kernel(M, vec, substitutions=None):
    MM = M if substitutions is None else M.subs(substitutions)
    assert all(s.factor(e) == 0 for e in MM*s.Matrix(vec))


def check_linear_algebra():
    assert s.factor(M0.det() - 1296*Delta*Phi) == 0

    minors = []
    for rows in combinations(range(M1.rows), 4):
        e = s.expand(M1[list(rows), :].det())
        if e != 0:
            minors.append(e)
    G = s.groebner(minors, a, b, c, d, order="grevlex", domain=s.QQ)
    for consequence in (
        c-6*a*b,
        d-s.Rational(9, 2)*a-3*b**2,
        a*(3*a-2*b**2),
    ):
        assert G.reduce(consequence)[1] == 0

    common = {a: 0, c: 0, d: 3*b**2}
    cube = {a: s.Rational(2, 3)*b**2, c: 4*b**3, d: 6*b**2}
    assert all(s.factor(e.subs(common)) == 0 for e in minors)
    assert all(s.factor(e.subs(cube)) == 0 for e in minors)
    assert s.expand((Q+6*b*P).subs(cube) - (y+2*b*x)**3) == 0
    print("linear algebra and S1 rank-drop decomposition verified")


def check_common_component():
    # b != 0 is normalized to b=1.  b=0 contains Q=y^3.
    P0 = x**2*y+x*y**2
    Q0 = 3*x**2*y+y**3
    M1c, M0c = syzygy_matrices(P0, Q0)
    m1 = [-s.Rational(1, 3), 0, -s.Rational(1, 6), 1]
    v1 = [2, 2, 0, 3, 1, 0, 0]
    v2 = [-s.Rational(1, 3), 0, 0, -s.Rational(1, 6), 0, 1, 0]
    v3 = [s.Rational(1, 3), 0, 0, s.Rational(1, 2), 0, 0, 1]
    assert_kernel(M1c, m1)
    for vv in (v1, v2, v3):
        assert_kernel(M0c, vv)

    tau, u, v, w = s.symbols("tau u v w")
    vv = [u*v1[i]+v*v2[i]+w*v3[i] for i in range(7)]
    poly, czz = degree5_poly(
        P0, Q0,
        vv[3]*x+vv[4]*y,
        vv[5]*x+vv[6]*y,
        vv[0]*x**2+vv[1]*x*y,
        Azz=tau*m1[2], Bzz=tau*m1[3], Rz2=tau*m1[0]*x,
    )
    assert s.factor(cf(poly, (2, 0, 3))+tau**2) == 0
    p0 = s.Poly(poly.as_expr().subs(tau, 0), x, y, z)
    assert s.factor(cf(p0, (4, 0, 1)) + (6*u-v+w)**2/s.Integer(2)) == 0
    assert s.factor(cf(p0, (0, 4, 1))-6*(czz-u**2)) == 0
    assert s.factor(cf(p0, (1, 3, 1))
                    + 2*(-6*czz+6*u**2-u*v-u*w)) == 0
    expected22 = -(108*czz+144*u**2-36*u*v+36*u*w+v**2+2*v*w+5*w**2)/6
    assert s.factor(cf(p0, (2, 2, 1))-expected22) == 0

    # After the square coefficient gives 6u-v+w=0, these exact equations
    # have only the origin.
    equations = [
        6*u-v+w,
        czz-u**2,
        -6*czz+6*u**2-u*v-u*w,
        108*czz+144*u**2-36*u*v+36*u*w+v**2+2*v*w+5*w**2,
    ]
    GG = s.groebner(equations, u, v, w, czz, order="grevlex", domain=s.QQ)
    basis = [s.factor(g) for g in GG.polys]
    assert GG.reduce(v**2)[1] == 0
    assert GG.reduce(w**2)[1] == 0
    assert GG.reduce(czz**2)[1] == 0
    assert GG.reduce(u-v/s.Integer(6)+w/s.Integer(6))[1] == 0
    print("common-factor S1 component eliminated")


def check_delta_divisor():
    lam, mu, t = s.symbols("lam mu t")

    # Chart (a,b) != (0,0), a != 0: c=t*a, d=t*b.
    vec = [
        s.Rational(2, 3), -2*b/(9*a), 0,
        2*(3*a-b**2)/(9*a), -b/(9*a), -2*b**2*t/(9*a), 1,
    ]
    assert_kernel(M0, vec, {c: t*a, d: t*b})
    P0 = P.subs({c: t*a, d: t*b})
    Q0 = Q.subs({c: t*a, d: t*b})
    poly, czz = degree5_poly(
        P0, Q0,
        lam*(vec[3]*x+vec[4]*y),
        lam*(vec[5]*x+vec[6]*y),
        lam*(vec[0]*x**2+vec[1]*x*y),
    )
    assert s.factor(cf(poly, (4, 0, 1))+s.Rational(2, 3)*lam**2*(-3*a+b*t)) == 0
    assert s.factor(cf(poly, (1, 3, 1))-12*b*czz) == 0
    assert s.factor(cf(poly, (0, 4, 1))-2*(81*a**2*czz-b**2*lam**2)/(27*a**2)) == 0
    # b != 0: the last two force czz=lam=0.  b=0: the first is 2*a*lam^2.

    # Chart a=0,b=1,c=0,d=t.  t=0 contains Q=y^3.
    P1 = x**2*y+x*y**2
    Q1 = t*x**2*y+y**3
    _, M01 = syzygy_matrices(P1, Q1)
    w1 = [0, 1/t, 0, 1/t, s.Rational(1, 2)/t, 1, 0]
    w2 = [s.Rational(1, 3), 0, 0, s.Rational(1, 2), 0, 0, 1]
    assert_kernel(M01, w1)
    assert_kernel(M01, w2)
    vv = [lam*w1[i]+mu*w2[i] for i in range(7)]
    poly, czz = degree5_poly(P1, Q1, vv[3]*x+vv[4]*y,
                              vv[5]*x+vv[6]*y,
                              vv[0]*x**2+vv[1]*x*y)
    assert s.factor(cf(poly, (4, 0, 1))+t*mu**2/6) == 0
    assert s.factor(cf(poly, (0, 4, 1))-3*(4*czz*t**2-lam**2)/(2*t**2)) == 0
    assert s.factor(cf(poly, (2, 2, 1))+(36*czz*t**2+24*lam*mu+5*t*mu**2-3*lam**2)/(6*t)) == 0

    # Chart a=b=0,c != 0.
    P2 = x*y**2
    Q2 = c*x**3+d*x**2*y+y**3
    _, M02 = syzygy_matrices(P2, Q2)
    w0 = [s.Rational(2, 3), -2*d/(9*c), 0,
          s.Rational(2, 3), -d/(9*c), -2*d**2/(9*c), 1]
    assert_kernel(M02, w0)
    poly, czz = degree5_poly(P2, Q2,
                              lam*(w0[3]*x+w0[4]*y),
                              lam*(w0[5]*x+w0[6]*y),
                              lam*(w0[0]*x**2+w0[1]*x*y))
    assert s.factor(cf(poly, (4, 0, 1))+2*d*lam**2/3) == 0
    assert s.factor(cf(poly, (3, 1, 1))+4*(81*c**2*czz+2*d**2*lam**2)/(27*c)) == 0
    assert s.factor(cf(poly, (2, 2, 1))+2*(243*c**2*czz*d+27*c**2*lam**2-d**3*lam**2)/(81*c**2)) == 0

    # Subchart a=b=c=0,d != 0.
    Q3 = d*x**2*y+y**3
    _, M03 = syzygy_matrices(P2, Q3)
    w1 = [0, 1/d, 0, 0, s.Rational(1, 2)/d, 1, 0]
    w2 = [s.Rational(1, 3), 0, 0, s.Rational(1, 2), 0, 0, 1]
    assert_kernel(M03, w1)
    assert_kernel(M03, w2)
    vv = [lam*w1[i]+mu*w2[i] for i in range(7)]
    poly, czz = degree5_poly(P2, Q3, vv[3]*x+vv[4]*y,
                              vv[5]*x+vv[6]*y,
                              vv[0]*x**2+vv[1]*x*y)
    assert s.factor(cf(poly, (4, 0, 1))+d*mu**2/6) == 0
    assert s.factor(cf(poly, (0, 4, 1))-3*(4*czz*d**2-lam**2)/(2*d**2)) == 0
    assert s.factor(cf(poly, (2, 2, 1))+(36*czz*d**2+5*d*mu**2-3*lam**2)/(6*d)) == 0
    print("all Delta=0 charts eliminated, modulo displayed cube/common charts")


def check_phi_generic_chart():
    lam = s.symbols("lam")
    E = 3*a*b-c
    N = 9*a**2+6*a*b**2-a*d-b*c
    A0 = N/(2*E)
    A1 = s.Rational(1, 2)
    B0 = (3*a*b*d+9*a*c+3*b**2*c-2*c*d)/(2*E)
    B1 = 3*(9*a**2-a*d+b*c)/(2*E)
    vec = [0, 1, 0, A0, A1, B0, B1]
    residual = M0*s.Matrix(vec)
    for entry in residual:
        numerator = s.together(entry).as_numer_denom()[0]
        assert s.rem(s.Poly(numerator, d), s.Poly(Phi, d)).as_expr() == 0

    poly, czz = degree5_poly(
        P, Q, lam*(A0*x+A1*y), lam*(B0*x+B1*y), lam*x*y
    )
    C04 = cf(poly, (0, 4, 1))
    C22 = cf(poly, (2, 2, 1))
    C13 = cf(poly, (1, 3, 1))
    assert s.factor(C04-s.Rational(3, 2)*(4*czz-lam**2)) == 0
    C22_on = s.factor(C22.subs(czz, lam**2/4))
    assert s.factor(C22_on + lam**2*(9*a+d)
                    + 3*a*lam**2*Phi/E**2) == 0
    assert s.factor(C13.subs(czz, lam**2/4)
                    - 3*a*lam**2*(9*a+3*b**2-d)/E) == 0

    # If lam != 0, the two coefficients force d=-9a and
    # a*(6a+b^2)=0.  The a=0 branch is a cube; the other branch has E=0.
    assert s.factor(Phi.subs({a: 0, d: 0}) - 3*c*(b**3-c)) == 0
    assert s.expand((P+Q/(3*b)).subs({a: 0, d: 0, c: b**3})
                    - (b*x+y)**3/(3*b)) == 0
    assert s.factor(Phi.subs({a: -b**2/6, d: s.Rational(3, 2)*b**2})
                    + s.Rational(3, 4)*(b**3+2*c)**2) == 0
    assert s.factor((3*a*b-c).subs({a: -b**2/6, c: -b**3/2})) == 0
    print("Phi=0, Delta!=0, 3ab-c!=0 chart eliminated")


def check_phi_special_chart():
    # E=3ab-c=0.  On Phi=0 and Delta!=0 one has
    # c=3ab, d=9a+3b^2, a!=0.
    lam, mu = s.symbols("lam mu")
    K = 3*a+2*b**2
    substitutions = {c: 3*a*b, d: 9*a+3*b**2}
    assert s.factor(Phi.subs(c, 3*a*b)-a*(9*a+3*b**2-d)**2) == 0
    assert s.factor(Delta.subs(substitutions)-9*a**2) == 0

    P0, Q0 = P.subs(substitutions), Q.subs(substitutions)
    _, MM = syzygy_matrices(P0, Q0)
    v1 = [0, s.Rational(2, 3)/K, 0,
          s.Rational(2, 3)*b/K, s.Rational(1, 3)/K, 1, 0]
    v2 = [0, -s.Rational(2, 3)*b/K, 0,
          a/K, -s.Rational(1, 3)*b/K, 0, 1]
    assert_kernel(MM, v1)
    assert_kernel(MM, v2)
    vv = [lam*v1[i]+mu*v2[i] for i in range(7)]
    poly, czz = degree5_poly(P0, Q0,
                              vv[3]*x+vv[4]*y,
                              vv[5]*x+vv[6]*y,
                              vv[0]*x**2+vv[1]*x*y)
    delta0 = lam-b*mu
    C04 = cf(poly, (0, 4, 1))
    C31 = cf(poly, (3, 1, 1))
    C22 = cf(poly, (2, 2, 1))
    C13 = cf(poly, (1, 3, 1))
    assert s.factor(C04 - 2*(9*K**2*czz-delta0**2)/(3*K**2)) == 0
    relation = {czz: delta0**2/(9*K**2)}
    assert s.factor(C31.subs(relation)-4*a*mu*delta0/K) == 0
    assert s.factor(C13.subs(relation)
                    -4*delta0*((3*a+b**2)*mu+b*lam)/(3*K**2)) == 0
    assert s.factor(C22.subs({czz: 0, lam: b*mu})+4*mu**2/3) == 0
    assert s.factor(C22.subs({b: 0, mu: 0, czz: lam**2/(9*K**2)})
                    +4*a*lam**2/K**2) == 0

    # The denominator K=0 is a separate rank-five chart.
    K0 = {a: -s.Rational(2, 3)*b**2,
          c: -2*b**3,
          d: -3*b**2}
    P1, Q1 = P.subs(K0), Q.subs(K0)
    _, MM1 = syzygy_matrices(P1, Q1)
    u1 = [0, 2, 0, 2*b, 1, 0, 0]
    u2 = [0, 0, 0, s.Rational(1, 3), 0, b, 1]
    assert_kernel(MM1, u1)
    assert_kernel(MM1, u2)
    vv = [lam*u1[i]+mu*u2[i] for i in range(7)]
    poly, czz = degree5_poly(P1, Q1,
                              vv[3]*x+vv[4]*y,
                              vv[5]*x+vv[6]*y,
                              vv[0]*x**2+vv[1]*x*y)
    assert s.factor(cf(poly, (0, 4, 1))-6*(czz-lam**2)) == 0
    assert s.factor(cf(poly, (1, 3, 1))-4*(3*b*czz+lam*mu)) == 0
    assert s.factor(cf(poly, (2, 2, 1)) - s.Rational(2, 3)*(
        9*b**2*czz+9*b**2*lam**2-6*b*lam*mu-2*mu**2
    )) == 0
    print("Phi=0 incidence chart 3ab-c=0 eliminated, including K=0")


def main():
    check_linear_algebra()
    check_common_component()
    check_delta_divisor()
    check_phi_generic_chart()
    check_phi_special_chart()
    print("ALL NORMALIZED h=x^2*y^2 EXCEPTIONAL LOCI VERIFIED")


if __name__ == "__main__":
    main()
