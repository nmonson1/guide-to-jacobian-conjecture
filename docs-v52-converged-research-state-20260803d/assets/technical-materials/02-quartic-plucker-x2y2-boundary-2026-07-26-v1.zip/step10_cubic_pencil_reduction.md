# Cubic-pencil reduction for a rank-one quartic leading form

Let `k` be an algebraically closed field of characteristic zero and put

\[
S=k[x_0,x_1,x_2],\qquad L=k(x_0,x_1,x_2).
\]

## Theorem

Let \(P,Q\in S_3\) be algebraically independent homogeneous cubics and let
\(0\ne h\in S_4\).  Assume

\[
dP\wedge dQ\wedge dh=0.
\]

Then at least one of the following holds.

1. \(\gcd(P,Q)\ne1\).
2. The pencil \(\langle P,Q\rangle\) contains the cube of a linear form.
3. There are independent linear forms \(a,b\in S_1\) such that
   \[
   P,Q\in k[a,b]_3.
   \]

Thus, after removing fixed components and the cubic-coordinate branch, the
transverse cubic pencil is binary.

## Proof

The differential relation and characteristic zero imply

\[
\operatorname{trdeg}_k k(P,Q,h)=2,
\]

so \(h\) is algebraic over \(K=k(P,Q)\).

Assume from now on that \(\gcd(P,Q)=1\).  Put

\[
t=\frac PQ,\qquad w=\frac{h^3}{Q^4}.
\]

The scalar action \(x_i\mapsto \lambda x_i\) fixes \(t,w\) and sends
\(Q\mapsto\lambda^3Q\).  Since \(h\) is algebraic over
\(k(t,Q)\), so is \(w\).  Let \(m(Z)\in k(t,Q)[Z]\) be the monic minimal
polynomial of \(w\).  Applying every scalar automorphism gives another monic
minimal polynomial of the same element over the same field.  Uniqueness
therefore fixes every coefficient of \(m\).  The fixed field of the scalar
action on \(k(t,Q)\) is \(k(t)\).  Hence

\[
w\text{ is algebraic over }k(t).
\tag{1}
\]

Let

\[
M=L^{\mathbf G_m}=k(\mathbf P^2)
\]

be the degree-zero function field.  First suppose that \(k(t)\) is relatively
algebraically closed in \(M\).  Since \(w\in M\), (1) gives

\[
w=R(t)\qquad\text{for some }R\in k(t)^*.
\tag{2}
\]

For \(\xi\in\mathbf P^1\), let

\[
F_\xi=P-\xi Q\quad(\xi\ne\infty),\qquad F_\infty=Q,
\]

and set

\[
r_\xi=\operatorname{ord}_\xi R,
\qquad
c_\xi=r_\xi+4\,\mathbf 1_{\xi=\infty}.
\]

Distinct fibers \(F_\xi\) are coprime because \(\gcd(P,Q)=1\).  If an
irreducible polynomial \(g\) occurs in \(F_\xi\) with multiplicity \(m_g\),
then taking the \(g\)-valuation in (2) gives

\[
3\nu_g(h)=c_\xi m_g.
\tag{3}
\]

In particular \(c_\xi\ge0\).  A degree-three polynomial whose component
multiplicities all have common divisor divisible by three is the cube of a
linear form.  Consequently, if no member of the pencil is a cube, then for
every \(\xi\) at least one \(m_g\) is prime to three, and (3) forces

\[
c_\xi\in3\mathbf Z_{\ge0}.
\]

But

\[
\sum_{\xi\in\mathbf P^1}c_\xi
=
\sum_\xi r_\xi+4
=4,
\]

which is impossible for a sum of nonnegative multiples of three.  Therefore,
in the relatively algebraically closed case, the pencil contains a cube.

It remains to consider the case in which \(k(t)\) is not relatively
algebraically closed in \(M\).  Let \(k(C)\) be its relative algebraic closure inside \(M\).  The
curve \(C\) is dominated by \(\mathbf P^2\); restricting the rational map
to a general line gives a dominant rational map \(\mathbf P^1\dashrightarrow C\).
Thus \(C\) is unirational, hence rational in characteristic zero.  Choose a
parameter \(s\) with \(k(C)=k(s)\).  Then

\[
t=\mathcal R(s)
\]

for a rational map \(\mathcal R:\mathbf P^1\to\mathbf P^1\) of degree
\(e>1\).  Write

\[
s=\frac{A}{B}
\]

with coprime homogeneous forms \(A,B\) of the same degree \(d\), and write
\(\mathcal R=U/V\) with coprime binary forms \(U,V\) of degree \(e\).
Then

\[
\frac PQ=\frac{U(A,B)}{V(A,B)}.
\]

The two substituted forms \(U(A,B),V(A,B)\) are coprime: a common
irreducible divisor would make \([A:B]\) a common projective zero of \(U,V\),
or would divide both \(A,B\).  Cross multiplication and
\(\gcd(P,Q)=1\) therefore give, up to a common nonzero scalar,

\[
P=U(A,B),\qquad Q=V(A,B).
\]

Taking degrees yields

\[
3=ed.
\]

Since \(e>1\), primality of three gives \(e=3,d=1\).  Thus \(A,B\) are
independent linear forms and \(P,Q\in k[A,B]_3\), proving the third
alternative.  This completes the proof.

## Application to the degree-four Keller problem

For a rank-one highest part

\[
H_4=v h,
\]

move \(v\) to the third target direction and write the transverse cubic
components of \(H_3\) as \(P,Q\).  The highest nonautomatic Keller equation
is

\[
\operatorname{Jac}(P,Q,h)=0.
\]

The theorem reduces the analysis to:

* fixed-component cubic pencils \(\gcd(P,Q)\ne1\);
* the cubic-coordinate branch, already reducible to a low-degree plane
  Keller map;
* binary cubic pencils, for which \(h\) is also binary whenever
  \(P,Q\) are independent, since
  \[
  \operatorname{Jac}(P,Q,h)=J_{a,b}(P,Q)\,\partial_c h.
  \]

The last branch makes the five binary quartic root partitions exhaustive.
