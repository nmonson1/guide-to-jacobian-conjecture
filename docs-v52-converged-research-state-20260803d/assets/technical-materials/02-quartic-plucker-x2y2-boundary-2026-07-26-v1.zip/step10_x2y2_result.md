# The rank-one binary quartic stratum of type \(2+2\)

All structural arguments are over an algebraically closed field of
characteristic zero.  The coefficient certificates are over \(\mathbf Q\).

## 1. Scope

Normalize the scalar quartic and the leading target direction to

\[
h=x^2y^2,\qquad H_4=(0,0,h).
\]

After the cubic-pencil reduction in
`step10_cubic_pencil_reduction.md`, the non-fixed, non-cube branch has binary
transverse cubics

\[
H_3=(P(x,y),Q(x,y),R).
\]

Put

\[
W=J(P,Q),\qquad U=J(P,h),\qquad V=J(Q,h).
\]

The degree-six Keller equation has two syzygy parts

\[
WL+\alpha V-\beta U=0,
\tag{S1}
\]

\[
Wq+Va-Ub=0,
\tag{S0}
\]

where \(L,a,b\) are binary linear forms, \(q\) is binary quadratic, and
\(\alpha,\beta\) are scalars.  They encode every possible nonlinear
\(z\)-dependence in the first two quadratic coordinates and in the third
cubic coordinate.  Vanishing of all these parameters is the terminal
plane/triangular case in the pairing-orbit reduction used for the preceding
\(3+1\) theorem.

The exact scripts retain every otherwise unrestricted coefficient of
\(H_2,H_3\) when extracting the total-degree-five part of \(\det JF-1\).

---

## 2. Main Pluecker chart

On \(\Delta_{23}\ne0\), use target \(\operatorname{GL}_2\) to write

\[
P=ax^3+bx^2y+xy^2,
\qquad
Q=cx^3+dx^2y+y^3.
\tag{2.1}
\]

Let

\[
\Delta=ad-bc
\]

and

\[
\begin{aligned}
\Phi_{22}={}&81a^3-18a^2d-3ab^2d+27abc+ad^2\\
&+3b^3c-bcd-3c^2.
\end{aligned}
\tag{2.2}
\]

For columns \((l_0,l_1,\alpha,\beta)\), the matrix of (S1) is

\[
M_1=
\begin{pmatrix}
3\Delta&0&0&0\\
-6c&3\Delta&6c&-6a\\
9a-3d&-6c&2d&-2b\\
6b&9a-3d&0&2\\
3&6b&-6&0\\
0&3&0&0
\end{pmatrix}.
\tag{2.3}
\]

For columns \((q_0,q_1,q_2,A_0,A_1,B_0,B_1)\), the matrix of (S0) is

\[
M_0=
\begin{pmatrix}
3\Delta&0&0&0&0&0&0\\
-6c&3\Delta&0&6c&0&-6a&0\\
9a-3d&-6c&3\Delta&2d&6c&-2b&-6a\\
6b&9a-3d&-6c&0&2d&2&-2b\\
3&6b&9a-3d&-6&0&0&2\\
0&3&6b&0&-6&0&0\\
0&0&3&0&0&0&0
\end{pmatrix}.
\tag{2.4}
\]

A direct determinant calculation gives

\[
\boxed{\det M_0=1296\,\Delta\,\Phi_{22}.}
\tag{2.5}
\]

### 2.1 Rank drop of \(M_1\)

The maximal-minor ideal has exactly two set-theoretic components:

\[
\mathcal C:\quad a=c=0,\quad d=3b^2,
\tag{2.6}
\]

and

\[
\mathcal K:\quad
 a=\frac23b^2,\quad c=4b^3,\quad d=6b^2.
\tag{2.7}
\]

The second is the cubic-coordinate branch because

\[
Q+6bP=(y+2bx)^3.
\tag{2.8}
\]

On \(\mathcal C\), the case \(b=0\) also contains the cube \(Q=y^3\).
For \(b\ne0\), normalize \(b=1\).  Parameterize the one-dimensional
kernel of (S1) by \(\tau\), and the three-dimensional kernel of (S0) by
\(u,v,w\).  The complete degree-five determinant contains

\[
[x^2z^3]=-\tau^2.
\tag{2.9}
\]

After \(\tau=0\), put \(C=[z^2]H_{2,3}\).  The following exact coefficients
occur:

\[
[x^4z]=-rac12(6u-v+w)^2,
\tag{2.10}
\]

\[
[y^4z]=6(C-u^2),
\tag{2.11}
\]

\[
[xy^3z]=-2\bigl(-6C+6u^2-u(v+w)\bigr),
\tag{2.12}
\]

\[
[x^2y^2z]=-rac16
\left(108C+144u^2-36uv+36uw+v^2+2vw+5w^2\right).
\tag{2.13}
\]

Their zero set is only

\[
C=u=v=w=0.
\]

Thus the non-cube component of the (S1) rank drop is eliminated.

### 2.2 The divisor \(\Delta=0\)

Four rational charts cover this divisor.

| chart | parameterization | decisive degree-five coefficients |
|---:|---|---|
| I | \(c=ta,d=tb,a\ne0\) | \([xy^3z]=12bC\), \([y^4z]=2(81a^2C-b^2\lambda^2)/(27a^2)\), and for \(b=0\), \([x^4z]=2a\lambda^2\) |
| II | \(a=c=0,b=1,d=t\ne0\) | \([x^4z]=-t\mu^2/6\), \([y^4z]=3(4Ct^2-\lambda^2)/(2t^2)\), then \([x^2y^2z]=-\lambda^2/t\) |
| III | \(a=b=0,c\ne0\) | if \(d\ne0\), \([x^4z]=-2d\lambda^2/3\); if \(d=0\), \([x^3yz]=-12cC\) and \([x^2y^2z]=-2\lambda^2/3\) |
| IV | \(a=b=c=0,d\ne0\) | \([x^4z]=-d\mu^2/6\), \([y^4z]=3(4Cd^2-\lambda^2)/(2d^2)\), then \([x^2y^2z]=-\lambda^2/d\) |

The omitted zero parameters are cube charts; the overlap with (2.6) is
already treated.  Hence every non-cube solution on \(\Delta=0\) has zero
(S0) parameter.

### 2.3 The divisor \(\Phi_{22}=0\), \(\Delta\ne0\)

Put

\[
E=3ab-c.
\]

#### The chart \(E\ne0\)

A projective kernel vector of \(M_0\), modulo \(\Phi_{22}\), is

\[
\begin{aligned}
q&=xy,\\
a_z&=
\frac{9a^2+6ab^2-ad-bc}{2E}x+\frac12y,\\
b_z&=
\frac{3abd+9ac+3b^2c-2cd}{2E}x
+rac{3(9a^2-ad+bc)}{2E}y.
\end{aligned}
\tag{2.14}
\]

Let \(\lambda\) be its scale and again let \(C=[z^2]H_{2,3}\).  The
coefficient \([y^4z]\) gives

\[
C=\frac{\lambda^2}{4}.
\tag{2.15}
\]

Modulo \(\Phi_{22}\), two further coefficients become

\[
[x^2y^2z]=-\lambda^2(9a+d),
\tag{2.16}
\]

\[
[xy^3z]=
\frac{3a\lambda^2(9a+3b^2-d)}{E}.
\tag{2.17}
\]

If \(\lambda\ne0\), then \(d=-9a\) and

\[
a(6a+b^2)=0.
\]

If \(a=0\), the equations \(\Phi_{22}=0\), \(\Delta\ne0\) force
\(c=b^3\), and

\[
P+\frac{1}{3b}Q=\frac{(bx+y)^3}{3b}.
\]

If \(6a+b^2=0\), then \(\Phi_{22}=0\) forces \(c=-b^3/2\), which gives
\(E=0\), contradicting the chart.  Thus \(\lambda=0\).

#### The incidence chart \(E=0\)

Here

\[
c=3ab,
\qquad
\Phi_{22}=a(9a+3b^2-d)^2.
\]

Since \(\Delta\ne0\), one has

\[
a\ne0,
\qquad
d=9a+3b^2,
\qquad\Delta=9a^2.
\tag{2.18}
\]

Put

\[
K=3a+2b^2.
\]

For \(K\ne0\), the kernel is two-dimensional.  With parameters
\(\lambda,\mu\) and

\[
\delta=\lambda-b\mu,
\]

three degree-five equations are

\[
9K^2C-\delta^2=0,
\tag{2.19}
\]

\[
\mu\delta=0,
\tag{2.20}
\]

and, after \(\delta=0\),

\[
[x^2y^2z]=-rac43\mu^2.
\tag{2.21}
\]

If \(\delta\ne0\), (2.20) gives \(\mu=0\); another degree-five
coefficient gives \(b\lambda=0\), and when \(b=0\), (2.21)'s unreduced
form gives \(-4a\lambda^2/K^2\).  Hence again
\(C=\lambda=\mu=0\).

The denominator chart \(K=0\) has a separate integral kernel basis.  Its
three decisive coefficients are

\[
[y^4z]=6(C-\lambda^2),
\tag{2.22}
\]

\[
[xy^3z]=4(3bC+\lambda\mu),
\tag{2.23}
\]

\[
[x^2y^2z]=\frac23
\left(9b^2C+9b^2\lambda^2-6b\lambda\mu-2\mu^2\right).
\tag{2.24}
\]

They also have only the zero solution.

Therefore all three exceptional loci in the normalized chart are closed.

---

## 3. The Pluecker boundary

The chart \(\Delta_{23}\ne0\) is not globally exhaustive under the
stabilizer of \(x^2y^2\).  If \(\Delta_{23}=0\) but
\(\Delta_{01}\ne0\), interchange \(x,y\).  If both vanish, a cube-free
pencil has a basis

\[
P=Ax^3+x^2y,
\qquad
Q=xy^2+By^3.
\tag{3.1}
\]

The product \(AB\) is the residual diagonal invariant.

* If \(A,B\ne0\), normalize \(A=1,B=t\).  At \(t=1/9\),
  \[
  27P+9Q=(3x+y)^3.
  \]
  Away from that value, the (S0) kernel has dimension two.  Two exact
  degree-five coefficients are
  \[
  [x^4z]=\frac32\lambda^2(3t+1),
  \]
  \[
  [y^4z]=\frac38t^2(3t+1)(9\lambda t-\lambda-6\mu)^2.
  \]
  They eliminate all \(t\ne-1/3\).  At \(t=-1/3\), the remaining three
  equations are
  \[
  9C-5\lambda^2-6\lambda\mu=0,
  \]
  \[
  \lambda^2+3\lambda\mu+3\mu^2=0,
  \]
  \[
  9C-8\lambda^2-18\lambda\mu-9\mu^2=0,
  \]
  which force \(C=\lambda=\mu=0\).

* If exactly one of \(A,B\) is zero, symmetry reduces to \(A=0,B=1\).
  The degree-five coefficients successively force the (S1) parameter,
  all three (S0) parameters, and \(C\) to vanish.

* If \(A=B=0\), then
  \[
  \langle P,Q\rangle=xy\langle x,y\rangle
  \]
  has fixed component \(xy\).  The degree-five equations reduce the
  kernels to two residual (S0) parameters \(u_1,u_4\) satisfying
  \[
  9C+u_1^2-4u_1u_4+u_4^2=0.
  \tag{3.2}
  \]
  This fixed-component pencil is not eliminated by the present
  degree-five calculation.

## 4. Precise conclusion

The requested three loci in the main \(\Delta_{23}\ne0\) chart are
eliminated exactly.  Auditing the missing Pluecker boundary shows that every
cube-free boundary pencil without a fixed component is also eliminated.
Consequently:

\[
\boxed{
\begin{minipage}{0.82\linewidth}
In the binary rank-one quartic stratum \(h=x^2y^2\), the only cubic-pencil
orbit not removed by the high syzygies and the complete degree-five Keller
equations is the fixed-component pencil
\(\langle x^2y,xy^2\rangle=xy\langle x,y\rangle\).
\end{minipage}}
\]

This is a sharp restriction, not yet a complete elimination of the
\(2+2\) scalar factorization.  The remaining calculation must use the lower
Keller equations in the fixed-component branch, with pairing orbits and the
linear part treated explicitly.
