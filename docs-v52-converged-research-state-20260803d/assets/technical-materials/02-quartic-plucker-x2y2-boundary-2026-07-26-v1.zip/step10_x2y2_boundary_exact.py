"""Exact audit of the Pluecker boundary for h=x^2*y^2.

If both Delta_23 and Delta_01 vanish, a cube-free binary cubic pencil can be
put in the form

    P = A*x^3 + x^2*y,
    Q = x*y^2 + B*y^3.

The script eliminates all cases without a fixed component.  The sole
remaining boundary pencil is <x^2*y, x*y^2>, whose members have common factor
x*y.  This is deliberately reported as a surviving fixed-component stratum,
not as an eliminated case.
"""
from __future__ import annotations
from itertools import combinations
import sympy as s

x, y, z = s.symbols("x y z")
A, B = s.symbols("A B")
h = x**2*y**2


def J(f, g):
    return s.expand(s.diff(f, x)*s.diff(g, y)-s.diff(f, y)*s.diff(g, x))


def coeff_matrix(poly, unknowns, degree):
    pp = s.Poly(s.expand(poly), x, y)
    return s.Matrix([
        [s.diff(pp.coeff_monomial(x**(degree-i)*y**i), u) for u in unknowns]
        for i in range(degree+1)
    ])


def syzygy_matrices(P, Q):
    W, U, V = J(P, Q), J(P, h), J(Q, h)
    l0, l1, alpha, beta = s.symbols("l0 l1 alpha beta")
    M1 = coeff_matrix(W*(l0*x+l1*y)+alpha*V-beta*U,
                      [l0, l1, alpha, beta], 5)
    q0, q1, q2, a0, a1, b0, b1 = s.symbols("q0 q1 q2 a0 a1 b0 b1")
    M0 = coeff_matrix(
        W*(q0*x**2+q1*x*y+q2*y**2)
        + V*(a0*x+a1*y)-U*(b0*x+b1*y),
        [q0, q1, q2, a0, a1, b0, b1], 6,
    )
    return M1, M0


def assert_kernel(M, vec):
    assert all(s.factor(e) == 0 for e in M*s.Matrix(vec))


def degree5_poly(P, Q, Az, Bz, Rz, *, Azz=0, Bzz=0, Rz2=0):
    T = s.symbols("Tscale")
    m2b = [x**2, x*y, y**2]
    m2 = [x**2, x*y, x*z, y**2, y*z, z**2]
    m3b = [x**3, x**2*y, x*y**2, y**3]
    aa = s.symbols("aa0:3")
    bb = s.symbols("bb0:3")
    cc = s.symbols("cc0:6")
    rr = s.symbols("rr0:4")
    Abar = sum(q*m for q, m in zip(aa, m2b))
    Bbar = sum(q*m for q, m in zip(bb, m2b))
    C2 = sum(q*m for q, m in zip(cc, m2))
    Rbar = sum(q*m for q, m in zip(rr, m3b))
    H2 = [Abar+z*Az+Azz*z**2,
          Bbar+z*Bz+Bzz*z**2,
          C2]
    H3 = [P, Q, Rbar+z*Rz+z**2*Rz2]
    H4 = [0, 0, h]
    mats = [s.Matrix([[s.diff(f, w) for w in (x, y, z)] for f in H])
            for H in (H2, H3, H4)]
    expr = s.expand((T*mats[0]+T**2*mats[1]+T**3*mats[2]).det())
    e5 = s.Poly(expr, T).coeff_monomial(T**5)
    return s.Poly(s.expand(e5), x, y, z), cc[5]


def cf(poly, mon):
    return s.factor(poly.coeff_monomial(x**mon[0]*y**mon[1]*z**mon[2]))


def check_rank_locus():
    P = A*x**3+x**2*y
    Q = x*y**2+B*y**3
    M1, M0 = syzygy_matrices(P, Q)
    minors = []
    for rows in combinations(range(M1.rows), 4):
        e = s.expand(M1[list(rows), :].det())
        if e != 0:
            minors.append(e)
    G = s.groebner(minors, A, B, order="grevlex", domain=s.QQ)
    assert G.reduce(A*B*(9*A*B-1)**2)[1] == 0
    assert M0.det() == 0
    assert s.expand((27*P+9*Q).subs({A: 1, B: s.Rational(1, 9)})
                    -(3*x+y)**3) == 0
    print("boundary rank locus and cube value A*B=1/9 verified")


def check_generic_product_chart():
    t, lam, mu = s.symbols("t lam mu")
    P = x**3+x**2*y
    Q = x*y**2+t*y**3
    M1, M0 = syzygy_matrices(P, Q)
    v1 = [1, -(9*t+1)/6, t*(9*t-1)/2,
          (3*t-1)*(9*t+1)/4, t*(9*t-1)/2, 1, 0]
    v2 = [0, 1, -3*t, -(9*t-1)/2, -3*t, 0, 1]
    assert_kernel(M0, v1)
    assert_kernel(M0, v2)
    vv = [lam*v1[i]+mu*v2[i] for i in range(7)]
    poly, czz = degree5_poly(P, Q,
                              vv[3]*x+vv[4]*y,
                              vv[5]*x+vv[6]*y,
                              vv[0]*x**2+vv[1]*x*y+vv[2]*y**2)
    assert s.factor(cf(poly, (4, 0, 1))
                    - s.Rational(3, 2)*lam**2*(3*t+1)) == 0
    expected04 = s.Rational(3, 8)*t**2*(3*t+1)*(9*lam*t-lam-6*mu)**2
    assert s.factor(cf(poly, (0, 4, 1))-expected04) == 0

    # The sole extra value t=-1/3 is eliminated by three degree-five
    # coefficients.
    sub = {t: -s.Rational(1, 3)}
    C31 = s.factor(cf(poly, (3, 1, 1)).subs(sub))
    C22 = s.factor(cf(poly, (2, 2, 1)).subs(sub))
    C13 = s.factor(cf(poly, (1, 3, 1)).subs(sub))
    assert s.factor(C31-s.Rational(4, 3)*(9*czz-5*lam**2-6*lam*mu)) == 0
    assert s.factor(C22+s.Rational(8, 3)*(lam**2+3*lam*mu+3*mu**2)) == 0
    assert s.factor(C13+s.Rational(4, 9)*(9*czz-8*lam**2-18*lam*mu-9*mu**2)) == 0
    # C31=C13=0 implies lam*(lam+4mu)+3mu^2=0; with C22 it gives
    # lam*mu=0, hence lam=mu=0.
    print("generic boundary product chart eliminated, including t=-1/3")


def check_one_zero_chart():
    # A=0,B!=0 is normalized to B=1.  B=0,A!=0 is its x<->y image.
    tau, u, v, w = s.symbols("tau u v w")
    P = x**2*y
    Q = x*y**2+y**3
    M1, M0 = syzygy_matrices(P, Q)
    m1 = [s.Rational(2, 3), -4, -4, 1]
    v1 = [0, s.Rational(1, 3), 1, s.Rational(1, 2), 1, 0, 0]
    v2 = [s.Rational(2, 3), -4, 0, -4, 0, 1, 0]
    v3 = [0, 2, 0, 2, 0, 0, 1]
    assert_kernel(M1, m1)
    for vv in (v1, v2, v3):
        assert_kernel(M0, vv)
    vv = [u*v1[i]+v*v2[i]+w*v3[i] for i in range(7)]
    poly, czz = degree5_poly(
        P, Q,
        vv[3]*x+vv[4]*y,
        vv[5]*x+vv[6]*y,
        vv[0]*x**2+vv[1]*x*y+vv[2]*y**2,
        Azz=-4*tau, Bzz=tau,
        Rz2=tau*(s.Rational(2, 3)*x-4*y),
    )
    assert s.factor(cf(poly, (2, 0, 3))-s.Rational(4, 3)*tau**2) == 0
    p0 = s.Poly(poly.as_expr().subs(tau, 0), x, y, z)
    assert s.factor(cf(p0, (4, 0, 1))-s.Rational(2, 3)*v**2) == 0
    assert s.factor(cf(p0, (0, 4, 1))-s.Rational(3, 2)*u**2) == 0
    assert s.factor(cf(p0, (1, 3, 1)).subs({u: 0, v: 0})-12*czz) == 0
    assert s.factor(cf(p0, (2, 2, 1)).subs({u: 0, v: 0, czz: 0})+2*w**2) == 0
    print("one-zero boundary charts eliminated")


def check_fixed_component_residual():
    # A=B=0: P=x^2*y, Q=x*y^2 have common factor x*y.
    t1, t2, u1, u2, u3, u4 = s.symbols("t1 t2 u1 u2 u3 u4")
    P = x**2*y
    Q = x*y**2
    M1, M0 = syzygy_matrices(P, Q)
    m11 = [0, s.Rational(2, 3), 1, 0]
    m12 = [s.Rational(2, 3), 0, 0, 1]
    v1 = [0, s.Rational(2, 3), 0, 1, 0, 0, 0]
    v2 = [0, 0, s.Rational(2, 3), 0, 1, 0, 0]
    v3 = [s.Rational(2, 3), 0, 0, 0, 0, 1, 0]
    v4 = [0, s.Rational(2, 3), 0, 0, 0, 0, 1]
    for vv in (m11, m12):
        assert_kernel(M1, vv)
    for vv in (v1, v2, v3, v4):
        assert_kernel(M0, vv)
    mm = [t1*m11[i]+t2*m12[i] for i in range(4)]
    vv = [u1*v1[i]+u2*v2[i]+u3*v3[i]+u4*v4[i] for i in range(7)]
    poly, czz = degree5_poly(
        P, Q,
        vv[3]*x+vv[4]*y,
        vv[5]*x+vv[6]*y,
        vv[0]*x**2+vv[1]*x*y+vv[2]*y**2,
        Azz=mm[2], Bzz=mm[3], Rz2=mm[0]*x+mm[1]*y,
    )
    assert s.factor(cf(poly, (2, 0, 3))-s.Rational(4, 3)*t2**2) == 0
    assert s.factor(cf(poly, (0, 2, 3))-s.Rational(4, 3)*t1**2) == 0
    p0 = s.Poly(poly.as_expr().subs({t1: 0, t2: 0}), x, y, z)
    assert s.factor(cf(p0, (4, 0, 1))-s.Rational(2, 3)*u3**2) == 0
    assert s.factor(cf(p0, (0, 4, 1))-s.Rational(2, 3)*u2**2) == 0
    residual = s.factor(cf(p0, (2, 2, 1)).subs({u2: 0, u3: 0}))
    assert s.factor(residual-s.Rational(2, 3)*(9*czz+u1**2-4*u1*u4+u4**2)) == 0
    print("fixed-component residual isolated: <x^2*y,x*y^2>")


def main():
    check_rank_locus()
    check_generic_product_chart()
    check_one_zero_chart()
    check_fixed_component_residual()
    print("BOUNDARY AUDIT COMPLETE; ONLY THE FIXED-COMPONENT PENCIL REMAINS")


if __name__ == "__main__":
    main()
