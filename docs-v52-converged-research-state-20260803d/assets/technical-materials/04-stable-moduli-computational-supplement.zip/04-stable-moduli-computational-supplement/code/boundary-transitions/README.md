# Cross-length boundary transitions

`build_transition_packet.py` verifies the elementary boundary chart obtained
when one root of the length-`N` polynomial `Q` escapes to infinity:

```bash
uv run python build_transition_packet.py /new/output/directory
```

It records the general polynomial-division/Tschirnhaus formula and exact
`N=2 -> 1` and `N=3 -> 2` transitions, including resultant invariance and
weighted equivariance. The output directory must not exist.

The calculation does not construct the full compactification. Simultaneous
escapes, the nonunit boundary, and relative-Jacobian gluing remain open.
