#!/usr/bin/env python3
"""Verify the first cross-length boundary transitions for framed moduli.

On the coefficient closure of the length-N chart, q_N=0 makes one root of
Q escape to infinity.  On q_{N-1} != 0, polynomial division removes the now
redundant top coefficient of R by an explicit Tschirnhaus gauge.  This script
checks the general formulas and records N=2->1 and N=3->2 exactly.

The calculation identifies the elementary codimension-one transition.  It
does not construct the full compactification or handle simultaneous escapes,
the resultant boundary, or the relative-Jacobian gluing data.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import sympy as sp


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path: Path, text: str) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite {path}")
    path.write_text(text, encoding="utf-8")


def check_transition(length: int) -> dict[str, Any]:
    if length < 2:
        raise ValueError("length must be at least two")
    c, lam = sp.symbols("c lam", nonzero=True)
    q = (sp.Integer(1),) + sp.symbols(f"q1:{length}")
    r = sp.symbols(f"r0:{length}")
    top_q = q[length - 1]
    kappa = sp.cancel(r[length - 1] / top_q)
    remainder_coefficients = tuple(
        sp.cancel(r[index] - kappa * q[index])
        for index in range(length - 1)
    )
    polynomial_q = sp.expand(
        sum(q[index] * c**index for index in range(length))
    )
    polynomial_r = sp.expand(
        sum(r[index] * c**index for index in range(length))
    )
    remainder = sp.expand(
        sum(
            remainder_coefficients[index] * c**index
            for index in range(length - 1)
        )
    )
    if sp.factor(polynomial_r - remainder - kappa * polynomial_q) != 0:
        raise AssertionError("polynomial division identity failed")

    polynomial_a = c * polynomial_q
    b_high = -2 - 4 * q[1] * c + c**2 * polynomial_r
    b_low = -2 - 4 * q[1] * c + c**2 * remainder
    difference = sp.factor(b_high - b_low)
    if sp.factor(difference - kappa * c * polynomial_a) != 0:
        raise AssertionError("boundary gauge identity failed")
    phi = sp.cancel(kappa * c / 3)
    if sp.factor(difference - 3 * polynomial_a * phi) != 0:
        raise AssertionError("Tschirnhaus normalization failed")

    resultant_high = sp.factor(sp.resultant(polynomial_q, b_high, c))
    resultant_low = sp.factor(sp.resultant(polynomial_q, b_low, c))
    resultant_multiplier = (-1) ** (length - 1) * top_q
    if sp.factor(resultant_high - resultant_multiplier * resultant_low) != 0:
        raise AssertionError("unexpected resultant normalization factor")

    scaling = {q[index]: lam**index * q[index] for index in range(1, length)}
    scaling.update(
        {r[index]: lam ** (index + 2) * r[index] for index in range(length)}
    )
    if sp.factor(kappa.subs(scaling, simultaneous=True) - lam**2 * kappa) != 0:
        raise AssertionError("kappa does not have weight two")
    for index, coefficient in enumerate(remainder_coefficients):
        expected = lam ** (index + 2) * coefficient
        if sp.factor(coefficient.subs(scaling, simultaneous=True) - expected) != 0:
            raise AssertionError(f"remainder coefficient {index} has wrong weight")

    inverse_r = tuple(
        sp.expand(remainder_coefficients[index] + kappa * q[index])
        for index in range(length - 1)
    ) + (sp.expand(kappa * top_q),)
    for found, expected in zip(inverse_r, r):
        if sp.factor(found - expected) != 0:
            raise AssertionError("coordinate change is not invertible")

    return {
        "transition": f"{length}->{length - 1}",
        "boundary_equation": f"q{length}=0",
        "open_conditions": [
            f"q{length - 1} != 0",
            "Resultant(Q,B) != 0",
        ],
        "Q": sp.sstr(polynomial_q),
        "R_high": sp.sstr(polynomial_r),
        "kappa": sp.sstr(kappa),
        "R_low": sp.sstr(remainder),
        "remainder_coefficients": [
            sp.sstr(item) for item in remainder_coefficients
        ],
        "B_high_minus_B_low": sp.sstr(difference),
        "root_translation_phi": sp.sstr(phi),
        "resultant_low": sp.sstr(resultant_low),
        "resultant_high": sp.sstr(resultant_high),
        "resultant_multiplier": sp.sstr(resultant_multiplier),
        "weights": {
            "kappa": 2,
            "remainder_coefficients": list(range(2, length + 1)),
        },
        "equivariant_boundary_chart": (
            f"U_{length - 1} x A^1_kappa, with kappa of weight 2"
        ),
    }


def report(transitions: list[dict[str, Any]]) -> str:
    first, second = transitions
    return f"""# Program 4 cross-length boundary transitions

## General calculation

Write the length-`N` normal form as

```text
Q = 1 + q1*c + ... + qN*c^N,
R = r0 + r1*c + ... + r_(N-1)*c^(N-1),
A = c*Q,
B = -2 - 4*q1*c + c^2*R.
```

In the affine coefficient closure, the divisor `qN=0` is the locus where
one root of `Q` escapes to infinity. On its open part `q_(N-1) != 0`, put

```text
kappa = r_(N-1)/q_(N-1),
R_low = R - kappa*Q.
```

Then `deg(R_low) <= N-2` and

```text
B_high - B_low = kappa*c^2*Q = kappa*c*A = 3*A*(kappa*c/3).
```

The last expression is exactly the allowed polynomial root-translation
gauge with `phi=kappa*c/3`. Because the displayed degree of `B` drops by
one, the Sylvester resultant changes by the normalization factor
`(-1)^(N-1)*q_(N-1)`. This factor is a unit on the transition chart, so the
resultant/unit condition is unchanged. The coefficient change is invertible,
and under the weighted scaling action `kappa` has weight 2. Therefore the
elementary boundary stratum is equivariantly

```text
U_(N-1) x A^1_kappa,
```

and its map to length-`N-1` orbit data contracts the gauge line.

## The first two transitions

For `{first['transition']}`:

```text
kappa = {first['kappa']}
R_low = {first['R_low']}
phi = {first['root_translation_phi']}
```

For `{second['transition']}`:

```text
kappa = {second['kappa']}
R_low = {second['R_low']}
phi = {second['root_translation_phi']}
```

The exact resultants, coordinate formulas, and weight checks are in
`transitions.json`.

## Mathematical boundary

This identifies the simplest codimension-one cross-length transition and
explains why the naive coefficient closure has one redundant affine gauge
direction over the lower-length moduli problem. It is not yet the desired
compactification: simultaneous root escapes (`q_(N-1)=0`), the nonunit
resultant boundary, and compatibility with the weighted relative-Jacobian
marking still require separate gluing constructions.
"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError(f"refusing to overwrite {output}")
    output.mkdir(parents=True)

    transitions = [check_transition(2), check_transition(3)]
    write_new(
        output / "transitions.json",
        json.dumps(
            {
                "format": 1,
                "general_formula": {
                    "kappa": "r_(N-1)/q_(N-1)",
                    "r'_j": "r_j-kappa*q_j for 0<=j<=N-2, with q_0=1",
                    "gauge": "B_high-B_low=kappa*c*A=3*A*(kappa*c/3)",
                    "equivariant_chart": "U_(N-1) x A^1(weight 2)",
                },
                "transitions": transitions,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
    )
    write_new(output / "REPORT.md", report(transitions))

    files = []
    for path in sorted(output.iterdir()):
        files.append(
            {
                "path": path.name,
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
        )
    manifest = {
        "format": 1,
        "release_id": "program4-boundary-transitions-v1-20260726b",
        "files": files,
        "verified_transitions": ["2->1", "3->2"],
    }
    write_new(
        output / "manifest.json",
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
    )
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
