# Program 4 cross-length boundary transitions

## General calculation

Write the length-`N` normal form as

```text
Q = 1 + q1*c + ... + qN*c^N,
R = r0 + r1*c + ... + r_(N-1)*c^(N-1),
A = c*Q,
B = -2 - 4*q1*c + c^2*R.
```

In the affine coefficient closure, the divisor `qN=0` is the locus where
one root of `Q` escapes to infinity. On its open part `q_(N-1) != 0`, put

```text
kappa = r_(N-1)/q_(N-1),
R_low = R - kappa*Q.
```

Then `deg(R_low) <= N-2` and

```text
B_high - B_low = kappa*c^2*Q = kappa*c*A = 3*A*(kappa*c/3).
```

The last expression is exactly the allowed polynomial root-translation
gauge with `phi=kappa*c/3`. Because the displayed degree of `B` drops by
one, the Sylvester resultant changes by the normalization factor
`(-1)^(N-1)*q_(N-1)`. This factor is a unit on the transition chart, so the
resultant/unit condition is unchanged. The coefficient change is invertible,
and under the weighted scaling action `kappa` has weight 2. Therefore the
elementary boundary stratum is equivariantly

```text
U_(N-1) x A^1_kappa,
```

and its map to length-`N-1` orbit data contracts the gauge line.

## The first two transitions

For `2->1`:

```text
kappa = r1/q1
R_low = r0 - r1/q1
phi = c*r1/(3*q1)
```

For `3->2`:

```text
kappa = r2/q2
R_low = -c*q1*r2/q2 + c*r1 + r0 - r2/q2
phi = c*r2/(3*q2)
```

The exact resultants, coordinate formulas, and weight checks are in
`transitions.json`.

## Mathematical boundary

This identifies the simplest codimension-one cross-length transition and
explains why the naive coefficient closure has one redundant affine gauge
direction over the lower-length moduli problem. It is not yet the desired
compactification: simultaneous root escapes (`q_(N-1)=0`), the nonunit
resultant boundary, and compatibility with the weighted relative-Jacobian
marking still require separate gluing constructions.
