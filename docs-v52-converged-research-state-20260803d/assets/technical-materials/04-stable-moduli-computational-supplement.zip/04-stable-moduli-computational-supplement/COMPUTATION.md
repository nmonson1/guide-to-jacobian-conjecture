# Computation index

The principal stable modulus and the narrower framed or graded moduli are kept
separate.

| Mathematical role | Files | What is checked |
| --- | --- | --- |
| Stable \(q\)-classification | `code/main-modulus/verify_q_full_orbit.py` | discriminant, normalization, recovery identities, gradients, marked lines, special fiber, and determinant-one gauge |
| Reciprocal-family boundary | `code/reciprocal-family/` | exact image, elliptic line, and formal conjugacy calculations |
| Restricted moduli | `code/restricted-moduli/` | based quadratic parameter, weight-\(20\) identity, and the wall-surface probe |
| Weighted-lift moduli | `code/extensions/weighted_moduli_general_verifier.py` | quartic seed family, normalization map, critical-root invariants, and rank-two invariant map |
| Conductor and residue geometry | `code/extensions/verify_conductor_arrangements.py`, `verify_triple_cover_conductor.py`, `verify_jet_residue.py` | exact conductor arrangements and boundary-residue identities |
| Cross-length boundary | `code/boundary-transitions/build_transition_packet.py` | general one-root escape gauge, exact \(2\to1\) and \(3\to2\) charts, resultant multiplier, and weighted equivariance |
| Further structural probes | remaining `code/extensions/` files | higher-degree frames, formal arcs, hidden-kernel reduction, and quartic boundary-Torelli tests |

Representative replay:

```bash
uv run --with sympy==1.14.0 python code/main-modulus/verify_q_full_orbit.py
uv run --with sympy==1.14.0 python code/extensions/weighted_moduli_general_verifier.py
uv run --with sympy==1.14.0 python code/extensions/verify_conductor_arrangements.py
uv run --with sympy==1.14.0 python code/boundary-transitions/build_transition_packet.py /new/output/directory
```

The exact invariant calculation explains why the quartic-seed family already
has genuine fixed-degree moduli: two scale-invariant functions of the three
critical roots have generically independent differentials.
