# Program 5 global-collision calculation packet

## What was computed

On the affine chart `a7=1`, `v4=1`, the regular full-kernel pencil is written
without matrix denominators by replacing `T^(-1)` with `adj(T)/det(T)`.
The two tensor-integrability identities and the collision identity become 15
primitive integer polynomials in 16 variables. Their total degrees are
[5]; their term counts range from 177 to 298.

The relevant open set is

```text
det(T) * (u3-u4*v3) != 0.
```

The second factor is the determinant of the collision-adapted basis obtained
by adjoining `e0,e1,e2` to `(u,v)`. The exact polynomial list is in
`collision-system.json`; `collision-system.m2` defines the corresponding
saturation for a future Macaulay2 computation.

At the known F_11 point all 15 equations vanish and the Jacobian has rank
15. The selected 15-by-15 minor
is 1 modulo 11. This
reconfirms a smooth one-dimensional local collision locus on the stated open
chart; it does not describe every global component.

## First-normal samples

The exact first-normal system was evaluated at all 17 previously
enumerated rational collision-line points over F_7 and F_11. The first four
linearized characteristic identities have an invertible 60-by-60 matrix at
15/17 points. At those points the fifth
identity gives residual covariant ranks [3]. Full coefficient and
augmented ranks are recorded point by point in `omega-samples.json`. At the
remaining 2 points the first-four
coefficient/augmented rank profiles are [(59, 60)]; the full system
still has ranks (60,61). Thus those points are already inconsistent through
the fourth identity. The convenient fifth-residual formula defines `Omega`
only on the open locus where the first-four determinant is nonzero; globally
the obstruction should be treated as a determinantal/cokernel class.

## Mathematical boundary

This packet supplies the explicit global collision ideal that was previously
only described procedurally, plus reusable coefficient-level samples of the
first-normal obstruction. It also shows that a single globally defined
`Omega` obtained by inverting the first-four matrix is not the right object
on its determinant divisor. It does **not** compute the saturated ideal,
prove irreducibility of the collision locus, or prove that the full cokernel
obstruction is nowhere zero in characteristic zero. Those are still the
global theorem.
