#!/usr/bin/env python3
"""Generate the corrected exhaustive F5 records for the three-row search.

Q=I plus one nonzero off-diagonal entry in each of three distinct rows.
Only support graphs using all five vertices are retained.  Coefficients run
through all of F5^*={1,2,3,4}; unlike the earlier +/-1-only experiment, this
includes values with r^3-r != 0.

For each Q, solve exactly the normalized collision and trace-one equations
for the compressed 5x3 coefficient matrix B.  Serialize every nonempty
affine solution space for exhaust_three_row_f5.cpp.
"""
from __future__ import annotations
import itertools
import struct
from pathlib import Path
import numpy as np

p = 5
pairs = [(i, j) for i in range(5) for j in range(i, 5)]

def solve_affine(A, b):
    A = np.asarray(A, dtype=np.int64) % p
    b = np.asarray(b, dtype=np.int64).reshape(-1, 1) % p
    aug = np.concatenate([A, b], axis=1)
    m, n = A.shape
    row = 0
    piv = []
    for col in range(n):
        pivot = next((i for i in range(row, m) if aug[i, col]), None)
        if pivot is None:
            continue
        aug[[row, pivot]] = aug[[pivot, row]]
        aug[row] = aug[row]*pow(int(aug[row, col]), -1, p) % p
        for i in range(m):
            if i != row and aug[i, col]:
                aug[i] = (aug[i]-aug[i, col]*aug[row]) % p
        piv.append(col)
        row += 1
    for i in range(row, m):
        if not np.any(aug[i, :n]) and aug[i, n]:
            return None, None
    free = [j for j in range(n) if j not in piv]
    x0 = np.zeros(n, dtype=np.int64)
    for rr, col in enumerate(piv):
        x0[col] = aug[rr, n]
    N = np.zeros((n, len(free)), dtype=np.int64)
    for jj, f in enumerate(free):
        N[f, jj] = 1
        for rr, col in enumerate(piv):
            N[col, jj] = -aug[rr, f] % p
    return x0, N

def constraints(Q, active):
    # U_m=(row_m(Q) z)^3-row_m(Q) z^3 for active source rows.
    rows, rhs = [], []
    e0 = np.array([1,0,0,0,0], dtype=np.int64)
    e1 = np.array([0,1,0,0,0], dtype=np.int64)
    delta = []
    for i in active:
        q0 = int(Q[i]@e0) % p
        q1 = int(Q[i]@e1) % p
        delta.append((q0**3-q1**3-int(Q[i]@(e0-e1))) % p)
    target = np.array([-1,1,0,0,0], dtype=np.int64) % p
    for out in range(5):
        row = np.zeros(15, dtype=np.int64)
        for m in range(3):
            row[3*out+m] = delta[m]
        rows.append(row); rhs.append(target[out])

    # Coefficients of trace(JU*B) in the 15 quadratic monomials.
    for a, b in pairs:
        row = np.zeros(15, dtype=np.int64)
        for m, i in enumerate(active):
            # derivative of (q_i z)^3 - sum_j Q_ij z_j^3:
            # coefficient in derivative wrt output-coordinate k.
            for k in range(5):
                coeff = 3*Q[i,k]*Q[i,a]*Q[i,b]*(1 if a==b else 2)
                if a==b and k==a:
                    coeff -= 3*Q[i,a]
                row[3*k+m] = (row[3*k+m]+coeff) % p
        rows.append(row); rhs.append(0)
    return np.array(rows), np.array(rhs)

records = []
for active in itertools.combinations(range(5), 3):
    for heads in itertools.product(range(5), repeat=3):
        if any(i==j for i,j in zip(active, heads)):
            continue
        if len(set(active)|set(heads)) < 5:
            continue
        for values in itertools.product(range(1,5), repeat=3):
            Q = np.eye(5, dtype=np.int64)
            for i,j,v in zip(active,heads,values):
                Q[i,j] = v
            A,b = constraints(Q, active)
            x0,N = solve_affine(A,b)
            if x0 is not None:
                records.append((Q,active,x0,N))

assert len(records) == 528
assert {N.shape[1] for _,_,_,N in records} == {4}

out = Path(__file__).resolve().parent / "three_row_records_f5.bin"
with out.open("wb") as f:
    f.write(struct.pack("<I", len(records)))
    for Q,active,x0,N in records:
        f.write(bytes(np.asarray(Q,dtype=np.uint8).reshape(-1).tolist()))
        f.write(bytes(np.asarray(active,dtype=np.uint8).tolist()))
        f.write(bytes([N.shape[1]]))
        f.write(bytes(np.asarray(x0,dtype=np.uint8).tolist()))
        f.write(bytes(np.asarray(N,dtype=np.uint8).reshape(-1).tolist()))

print(f"[ok] wrote {len(records)} affine records to {out.name}")
print("[ok] every record has affine dimension 4, hence 625 candidate B matrices")
