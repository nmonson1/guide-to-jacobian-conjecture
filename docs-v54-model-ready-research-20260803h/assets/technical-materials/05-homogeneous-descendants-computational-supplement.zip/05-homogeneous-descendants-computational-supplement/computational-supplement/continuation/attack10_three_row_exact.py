#!/usr/bin/env python3
"""Attack 10: exact exclusion of the first three-row-defect square-zero family.

Study H_{C,Q}(z)=C((Qz)^{*3}-Q z^{*3}) in dimension five, after
normalizing a signed-permutation baseline to Q=I+R.  Assume R has exactly
three active rows and exactly one nonzero off-diagonal entry in each row.

If the support uses at most four vertices, the map is a triangular extension
of a <=4-dimensional cubic-homogeneous core.  This script handles the only
remaining case: all five vertices occur.  Trace-one plus the normalized
collision force three graph orbits; trace-square excludes every orbit.
"""
from __future__ import annotations
import itertools
import sympy as sp

z = sp.symbols("z0:5")
Z = sp.Matrix(z)
alpha, beta, gamma = sp.symbols("alpha beta gamma", nonzero=True)
params = (alpha, beta, gamma)
Bv = sp.symbols("B0:15")
B = sp.Matrix(5, 3, Bv)

# Single-edge trace lemma.
u, v, r, bi, bj = sp.symbols("u v r bi bj", nonzero=True)
Uedge = sp.expand((u+r*v)**3-u**3-r*v**3)
trace_edge = sp.expand(sp.diff(Uedge, u)*bi + sp.diff(Uedge, v)*bj)
Pedge = sp.Poly(trace_edge, u, v)
assert Pedge.coeff_monomial(u**2) == 3*r*bj
assert Pedge.coeff_monomial(u*v) == 6*r*bi + 6*r**2*bj
# Hence trace_edge=0 and r!=0 imply bj=bi=0.

# Enumerate the cover-all-five support graphs.
patterns = []
for rows in itertools.combinations(range(5), 3):
    for heads in itertools.product(range(5), repeat=3):
        if any(i == j for i, j in zip(rows, heads)):
            continue
        pos = tuple((i, j) for i, j in zip(rows, heads))
        if len(set(rows) | set(heads)) == 5:
            patterns.append(pos)
assert len(patterns) == 180

# Collision and trace-one force an edge u->0 and a distinct edge v->1,
# with u,v in {2,3,4}.  The third edge gives exactly three graph orbits.
forced = [
    p for p in patterns
    if any(i >= 2 and j == 0 for i, j in p)
    and any(i >= 2 and j == 1 for i, j in p)
]
assert len(forced) == 30

group = []
for swap in (False, True):
    for perm in itertools.permutations((2, 3, 4)):
        m = {0: 1 if swap else 0, 1: 0 if swap else 1}
        m.update(dict(zip((2, 3, 4), perm)))
        group.append(m)

def canonical(pos):
    return min(tuple(sorted((m[i], m[j]) for i, j in pos)) for m in group)

orbits = sorted(set(canonical(p) for p in forced))
assert orbits == [
    ((0, 2), (3, 0), (4, 1)),   # A: collision vertex -> remaining vertex
    ((2, 0), (3, 0), (4, 1)),   # B: remaining vertex -> collision vertex
    ((2, 0), (3, 1), (4, 2)),   # C: remaining vertex -> other active vertex
]

def build(edges):
    Q = sp.eye(5)
    active = []
    for ((i, j), coeff) in zip(edges, params):
        Q[i, j] = coeff
        active.append(i)
    qz = Q*Z
    Ufull = sp.Matrix([
        sp.expand(qz[i]**3 - sum(Q[i, j]*z[j]**3 for j in range(5)))
        for i in range(5)
    ])
    U = sp.Matrix([Ufull[i] for i in active])
    JU = U.jacobian(z)
    M = JU*B

    e0 = {x: 0 for x in z}; e0[z[0]] = 1
    e1 = {x: 0 for x in z}; e1[z[1]] = 1
    delta = sp.Matrix([sp.expand(f.subs(e0)-f.subs(e1)) for f in U])
    collision = list(B*delta-sp.Matrix([-1, 1, 0, 0, 0]))

    tr1 = [c for _, c in sp.Poly(sp.expand(sp.trace(M)), *z).terms()]
    linear = [sp.factor(e) for e in tr1+collision if e != 0]
    tr2 = sp.Poly(sp.expand(sp.trace(M*M)), *z)
    return active, delta, linear, tr2

def solved_coefficient(edges, mon, parameter_substitution=None):
    active, delta, linear, tr2 = build(edges)
    subp = parameter_substitution or {}
    equations = [sp.factor(e.subs(subp)) for e in linear]
    solution_set = sp.linsolve(equations, Bv)
    assert solution_set != sp.EmptySet
    solution = next(iter(solution_set))
    subB = {Bv[i]: solution[i] for i in range(15)}
    coefficient = tr2.coeff_monomial(mon)
    return sp.factor(coefficient.subs(subp).subs(subB)), delta

Aedges = ((0, 2), (3, 0), (4, 1))
Bedges = ((2, 0), (3, 0), (4, 1))
Cedges = ((2, 0), (3, 1), (4, 2))

# Orbit A. Collision forces beta^2!=1 and gamma^2!=1.
coefA, deltaA = solved_coefficient(Aedges, z[1]**2*z[3]**2)
assert deltaA == sp.Matrix([0, beta**3-beta, -gamma**3+gamma])
assert sp.factor(coefA - 18/(beta**2-1)) == 0

# Orbit C. Collision forces alpha^2!=1 and beta^2!=1.
coefC, deltaC = solved_coefficient(Cedges, z[0]**2*z[1]**2)
assert deltaC == sp.Matrix([alpha**3-alpha, -beta**3+beta, 0])
assert coefC == 18

# Orbit B, generic alpha and beta.
coefB1, deltaB = solved_coefficient(Bedges, z[3]**2*z[4]**2)
coefB2, _ = solved_coefficient(Bedges, z[2]**2*z[4]**2)
assert deltaB == sp.Matrix([
    alpha**3-alpha, beta**3-beta, -gamma**3+gamma
])
# Bv[4] is the (row 1, column 1) coefficient.
assert sp.factor(coefB1 - 18*beta*Bv[4]/(gamma**2-1)) == 0
assert sp.factor(
    coefB2 + 18*((beta**3-beta)*Bv[4]-1)
    / ((alpha**2-1)*(gamma**2-1))
) == 0
# trace-square=0 would force Bv[4]=0 and (beta^3-beta)Bv[4]=1.

# Exceptional branches. Gamma is never exceptional because collision row 0
# forces gamma^3-gamma !=0.
for eps in (1, -1):
    ca, _ = solved_coefficient(Bedges, z[0]*z[1]**2*z[3], {alpha: eps})
    assert sp.factor(ca - 36*beta/(beta**2-1)) == 0
    cb, _ = solved_coefficient(Bedges, z[0]*z[1]**2*z[2], {beta: eps})
    assert sp.factor(cb - 36*alpha/(alpha**2-1)) == 0

# If alpha^2=beta^2=1, the row-1 collision equation is 0=1.

print("[ok] 180 cover-all-five support patterns reduce to 30 patterns in 3 orbits")
print("[ok] trace-square excludes orbit A for every collision-compatible coefficient")
print("[ok] trace-square excludes orbit C for every collision-compatible coefficient")
print("[ok] generic and exceptional branches of orbit B are all excluded")
print("[result] no three-row, one-edge-per-row cover-all-five map has the normalized Keller collision")
