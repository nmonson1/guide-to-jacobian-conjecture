#!/usr/bin/env python3
"""Attack 7: a 52-cube lower bound for the fixed 19D cubic tensor.

Let
    W = span{partial_j H_i} subset Sym^2(V*).
For a vector-Waring decomposition H=sum b_nu ell_nu^3, put
    U = span{ell_nu^2}.
Then W subset U.

First layer:
  * dim W=39;
  * every q in W vanishes on a 12-dimensional subspace A;
  * JH has no nonzero constant right-kernel vector.
Thus the ell_nu span V*, their restrictions span A*, and
dim(U/W)>=12.  Hence dim U>=51.

Equality layer:
If dim U=51, then restriction U->Sym^2(A*) has dimension 12.  Choose a
basis alpha_1,...,alpha_12 among the restricted ell_nu.  Since the image is
spanned by their squares, every other restricted ell_nu is proportional to
one alpha_j.  Consequently the mixed projection
    C = projection_{B* tensor A*}(W),  V=B direct_sum A,
is invariant under all 12 coordinate projectors in a suitable basis of A*.
Its right stabilizer algebra would contain a conjugate of the full diagonal
algebra, so its commutant could contain no nonzero nilpotent.

Exact calculation contradicts this: the commutant contains the nonzero
square-zero matrix E_{5,0}.  Therefore equality 51 is impossible and every
decomposition uses at least 52 cubes.
"""
from __future__ import annotations
import sympy as sp
import base19_data as B

Z = B.Z
H = sp.Matrix(B.H)
n = len(Z)
assert n == 19

pairs = [(i, j) for i in range(n) for j in range(i, n)]
exps = []
for i, j in pairs:
    e = [0] * n
    e[i] += 1
    e[j] += 1
    exps.append(tuple(e))

# Derivative space W.
rows = []
for f in H:
    for z in Z:
        p = sp.Poly(sp.diff(f, z), *Z, domain=sp.QQ)
        row = [p.coeff_monomial(e) for e in exps]
        if any(row):
            rows.append(row)
W = sp.Matrix(rows)
assert W.shape == (88, 190)
assert W.rank() == 39
Wrref, _ = W.rref()
Wbasis = sp.Matrix([list(Wrref.row(i)) for i in range(39)])

# A maximal common totally isotropic coordinate subspace and complement B0.
Aidx = [2, 5, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17]
Bidx = [i for i in range(n) if i not in Aidx]
assert len(Aidx) == 12 and len(Bidx) == 7
AAcols = [pairs.index((i, j)) for ii, i in enumerate(Aidx) for j in Aidx[ii:]]
assert W[:, AAcols] == sp.zeros(W.rows, len(AAcols))

# No constant right-kernel direction for JH.
J = H.jacobian(Z)
kernel_rows = []
for out in range(n):
    pp = [sp.Poly(J[out, j], *Z, domain=sp.QQ) for j in range(n)]
    for e in exps:
        row = [p.coeff_monomial(e) for p in pp]
        if any(row):
            kernel_rows.append(row)
K = sp.Matrix(kernel_rows)
assert K.shape == (125, 19)
assert K.rank() == 19
selected = [0, 1, 2, 4, 6, 8, 10, 11, 13, 14, 16, 18, 20, 25, 28, 32, 34, 46, 66]
assert K[selected, :].det() == 18

# A rank-13 member of W bounds a common totally isotropic subspace by
# radical dimension 6 plus floor(13/2)=6, hence by 12.
x, y, z, a, b, c, d, q, s, h, k, w1, w2, w3, w4, w5, w6, w7, t = Z
qstar = -(
    3*a*c - 3*b*t + 3*b*z + 3*d*s - 3*d*y + 3*h*k - 3*h*x
    + 3*q*y - 12*t*w1 - 130*t*w3 + 3*t*w4 - 62*t*w6
    - 42*t*w7 + 3*x**2
) / 3
qvec = sp.Matrix([[
    sp.Poly(qstar, *Z, domain=sp.QQ).coeff_monomial(e) for e in exps
]])
assert W.rank() == W.col_join(qvec).rank()

S = sp.zeros(n)
pstar = sp.Poly(qstar, *Z, domain=sp.QQ)
for i in range(n):
    S[i, i] = pstar.coeff_monomial(Z[i]**2)
    for j in range(i + 1, n):
        cc = pstar.coeff_monomial(Z[i]*Z[j])
        S[i, j] = S[j, i] = cc/2
assert S.rank() == 13
I13 = list(range(12)) + [18]
assert S.extract(I13, I13).det() == -sp.Rational(1, 256)

# Equality obstruction at 51.
# Mixed B-A projection C(W), represented as a subspace of 7x12 matrices.
cross_pairs = [(b0, a0) if b0 < a0 else (a0, b0)
               for b0 in Bidx for a0 in Aidx]
cross_cols = [pairs.index(p) for p in cross_pairs]
Cspace = Wbasis[:, cross_cols]
assert Cspace.rank() == 24
Crref, Cpiv = Cspace.rref()
Cbasis = sp.Matrix([list(Crref.row(i)) for i in range(24)])

# Membership equations L*v=0 for the row space C.
nonpiv = [j for j in range(84) if j not in Cpiv]
L = sp.zeros(len(nonpiv), 84)
for rr, j in enumerate(nonpiv):
    L[rr, j] = 1
    for i, piv in enumerate(Cpiv):
        L[rr, piv] = -Crref[i, j]
assert L*Cbasis.T == sp.zeros(L.rows, Cbasis.rows)

# Right stabilizer E={T in End(A*): C T subset C}.
tv = sp.symbols("T0:144")
T = sp.Matrix(12, 12, tv)
equations = []
for row in range(Cbasis.rows):
    M = sp.Matrix(7, 12, list(Cbasis.row(row)))
    equations.extend(list(L*sp.Matrix(list(M*T))))
AT, _ = sp.linear_eq_to_matrix(equations, tv)
assert AT.shape == (1440, 144)
assert AT.rank() == 82
Ebasis = AT.nullspace()
assert len(Ebasis) == 62

# N=E_{5,0} is a nonzero square-zero element commuting with the whole
# stabilizer algebra.
N = sp.zeros(12)
N[5, 0] = 1
assert N != sp.zeros(12) and N*N == sp.zeros(12)
for vec in Ebasis:
    E = sp.Matrix(12, 12, list(vec))
    assert E*N == N*E

# For reference, the full commutant has dimension seven.
sv = sp.symbols("S0:144")
Sm = sp.Matrix(12, 12, sv)
commutator_equations = []
for vec in Ebasis:
    E = sp.Matrix(12, 12, list(vec))
    commutator_equations.extend(list(Sm*E-E*Sm))
AC, _ = sp.linear_eq_to_matrix(commutator_equations, sv)
assert 144-AC.rank() == 7

assert 39 + 12 == 51
LOWER_BOUND = 52

print("[ok] dim W=39; W vanishes on a maximal 12D common isotropic block")
print("[ok] JH has no nonzero constant right-kernel vector (minor det 18)")
print("[ok] first layer gives dim U>=51")
print("[ok] mixed-space stabilizer has dimension 62; its commutant contains E_{5,0}!=0, E_{5,0}^2=0")
print("[result] equality 51 is impossible; every vector-Waring decomposition uses at least 52 cubes")
