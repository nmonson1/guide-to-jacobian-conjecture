
#include <bits/stdc++.h>
using namespace std;
struct Rec{uint8_t Q[25],act[3],dim,x0[15];vector<uint8_t>N;};
static inline bool niltest(const uint8_t R[15],const uint8_t B[15]){
 int M[9]={};
 for(int i=0;i<3;i++)for(int j=0;j<3;j++){
   int s=0;for(int k=0;k<5;k++)s+=R[5*i+k]*B[3*k+j];
   M[3*i+j]=s%5;
 }
 int tr2=0;
 for(int i=0;i<3;i++)for(int j=0;j<3;j++)tr2+=M[3*i+j]*M[3*j+i];
 tr2%=5;if(tr2)return false;
 int M2[9]={};
 for(int i=0;i<3;i++)for(int j=0;j<3;j++){
   int s=0;for(int k=0;k<3;k++)s+=M[3*i+k]*M[3*k+j];
   M2[3*i+j]=s%5;
 }
 int tr3=0;for(int i=0;i<3;i++)for(int j=0;j<3;j++)tr3+=M2[3*i+j]*M[3*j+i];
 return tr3%5==0;
}
static inline void makeR(const Rec&r,const int z[5],uint8_t R[15]){
 int qz[5]={};
 for(int i=0;i<5;i++){for(int j=0;j<5;j++)qz[i]+=r.Q[5*i+j]*z[j];qz[i]%=5;}
 for(int a=0;a<3;a++){int i=r.act[a];for(int j=0;j<5;j++){
   int x=r.Q[5*i+j]*(qz[i]*qz[i]-z[j]*z[j]);
   x%=5;if(x<0)x+=5;R[5*a+j]=x;
 }}
}
int main(int argc,char**argv){
 if(argc<2)return 2;ifstream f(argv[1],ios::binary);uint32_t nr;f.read((char*)&nr,4);
 vector<Rec> recs(nr);
 for(auto&r:recs){
   f.read((char*)r.Q,25);f.read((char*)r.act,3);f.read((char*)&r.dim,1);
   f.read((char*)r.x0,15);r.N.resize(15*r.dim);f.read((char*)r.N.data(),r.N.size());
 }
 vector<array<int,5>> zs;
 // deterministic ordering: low support first, then all
 for(int support=1;support<=5;support++){
  for(int code=1;code<3125;code++){
    int q=code;array<int,5>z{};int sp=0;
    for(int i=4;i>=0;i--){z[i]=q%5;q/=5;if(z[i])sp++;}
    if(sp==support)zs.push_back(z);
  }
 }
 uint64_t total=0,quick=0,full=0;int recidx=0;
 for(auto&r:recs){
   uint64_t count=1;for(int j=0;j<r.dim;j++)count*=5;
   uint8_t B[15],RR[15];
   for(uint64_t code=0;code<count;code++){
     total++;uint64_t q=code;int al[7]={};
     for(int j=0;j<r.dim;j++){al[j]=q%5;q/=5;}
     for(int i=0;i<15;i++){
       int x=r.x0[i];for(int j=0;j<r.dim;j++)x+=r.N[i*r.dim+j]*al[j];
       B[i]=x%5;
     }
     bool ok=true;
     int lim=min<int>(30,zs.size());
     for(int zi=0;zi<lim;zi++){makeR(r,zs[zi].data(),RR);if(!niltest(RR,B)){ok=false;break;}}
     if(!ok)continue;quick++;
     for(auto&z:zs){makeR(r,z.data(),RR);if(!niltest(RR,B)){ok=false;break;}}
     if(ok){
       full++;
       cout<<"SOLUTION rec "<<recidx<<" dim "<<(int)r.dim<<" B";
       for(int i=0;i<15;i++)cout<<" "<<(int)B[i];cout<<"\n";
     }
   }
   recidx++;
 }
 cerr<<"records "<<nr<<" candidates "<<total<<" quick "<<quick<<" full "<<full<<"\n";
}
