#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

python3 attack7_waring52.py
python3 attack8_quartic_functional.py
python3 attack9_monomial_shifts.py
python3 attack10_three_row_exact.py
python3 attack11_target_cleanup.py
python3 verify_small_certificates.py
python3 generate_three_row_f5.py

c++ -O3 -std=c++17 exhaust_three_row_f5.cpp -o .exhaust_three_row_f5
./.exhaust_three_row_f5 three_row_records_f5.bin
rm -f .exhaust_three_row_f5
