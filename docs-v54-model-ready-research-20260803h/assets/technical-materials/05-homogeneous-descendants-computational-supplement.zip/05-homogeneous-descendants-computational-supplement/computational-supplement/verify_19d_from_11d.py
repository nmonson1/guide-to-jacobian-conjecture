#!/usr/bin/env python3
"""Exact verifier for a 19-dimensional cubic-homogeneous Keller counterexample.

Starting point: the public 11-variable degree-3 map of Spacerat
(gist 08b4a43f6b6ca57178efabc220170ce8, 2026-07-20).

The construction uses a rank-compressed cubic suspension.  If

    K(X) = X + K2(X) + B q(X),

where K2 is quadratic, q has r cubic components, and B is constant, then

    (X,w) |-> (X + K2(X) + B w, w - q(X))

is polynomially stably equivalent to K.  Homogenizing with one coordinate t
produces

    G(X,w,t) = (X + t K2(X) + t^2 B w, w - q(X), t),

whose nonlinear part is homogeneous cubic.  Here n=11 and r=7, so G acts on
19 variables.

All arithmetic is exact over Q.  No numerical approximation is used.
"""

from __future__ import annotations

from fractions import Fraction
from typing import Iterable, Sequence

import sympy as sp


def homogeneous_part(expr: sp.Expr, degree: int, variables: Sequence[sp.Symbol]) -> sp.Expr:
    poly = sp.Poly(sp.expand(expr), *variables)
    ans = sp.Integer(0)
    for monomial, coeff in poly.terms():
        if sum(monomial) == degree:
            term = coeff
            for variable, exponent in zip(variables, monomial):
                term *= variable**exponent
            ans += term
    return sp.expand(ans)


def evaluate(expressions: Iterable[sp.Expr], variables: Sequence[sp.Symbol], point: Sequence[sp.Expr]) -> tuple[sp.Expr, ...]:
    substitution = dict(zip(variables, point))
    return tuple(sp.expand(expr.subs(substitution)) for expr in expressions)


def polynomial_term_count(expr: sp.Expr, variables: Sequence[sp.Symbol]) -> int:
    if expr == 0:
        return 0
    return len(sp.Poly(sp.expand(expr), *variables).terms())


# ---------------------------------------------------------------------------
# 1. Public 11-variable cubic map Phi.
# ---------------------------------------------------------------------------

x, y, z, a, b, c, d, q0, s, h, k = sp.symbols("x y z a b c d q s h k")
X = [x, y, z, a, b, c, d, q0, s, h, k]
zero_X = {variable: 0 for variable in X}

Phi = sp.Matrix(
    [
        -a*c - a*d*z - 3*a*y**2 - 2*a*z
        - c*d**2 + d**2*z - d*s + 7*d*y**2
        + s*x*y + 3*x*y*z + 4*y**2 + z,

        -b*c - b*d*z - 3*b*y**2 - 2*b*z
        - 3*c*d*x - d*q0 + q0*x*y
        + 12*x*y**2 + 3*x*z + y,

        -h*k - h*x*z + k*x**2 - 3*x**2*y + 2*x,
        a - d**2 + 2*d*x*y,
        b + 3*x**2*y,
        c + x*y*z + 3*y**2 + 2*z,
        d - x*y,
        b*z + 3*c*x + q0,
        s + a*z + c*x*y - x*y*z - 7*y**2 + c*d - d*z,
        h - x**2,
        k + x*z,
    ]
).applyfunc(sp.expand)

assert max(sp.Poly(component, *X).total_degree() for component in Phi) == 3
assert sum(polynomial_term_count(component, X) for component in Phi) == 52

L = Phi.jacobian(X).subs(zero_X)
assert L.det() == -2

# Normalize the linear part by the target linear automorphism L^{-1}.
K = (L.inv() * Phi).applyfunc(sp.expand)
K1 = sp.Matrix([homogeneous_part(component, 1, X) for component in K])
K2 = sp.Matrix([homogeneous_part(component, 2, X) for component in K])
K3 = sp.Matrix([homogeneous_part(component, 3, X) for component in K])
assert K1 == sp.Matrix(X)
assert K == sp.Matrix(X) + K2 + K3

# The public 11-variable construction carries an explicit stable-equivalence
# certificate proving det(J Phi)=-2.  For the 19-variable output below we do
# not need to expand either 11x11 determinant: the exact nilpotency certificate
# (JH)^18=0 directly implies det(I+JH)=1.

# ---------------------------------------------------------------------------
# 2. Rank-seven factorization of the cubic part K3 = B q.
# ---------------------------------------------------------------------------

basis_rows = [0, 1, 2, 3, 4, 5, 8]
q = sp.Matrix([K3[index] for index in basis_rows])
B = sp.zeros(11, 7)
for column, row in enumerate(basis_rows):
    B[row, column] = 1
assert B * q == K3

# The seven selected coordinate cubics are linearly independent over Q.
q_monomials = sorted(
    {
        monomial
        for component in q
        for monomial, _ in sp.Poly(component, *X).terms()
    }
)
q_coefficients = sp.Matrix(
    [
        [sp.Poly(component, *X).coeff_monomial(monomial) for monomial in q_monomials]
        for component in q
    ]
)
assert q_coefficients.rank() == 7

# ---------------------------------------------------------------------------
# 3. Stable suspension and homogeneous cubic map in dimension 19.
# ---------------------------------------------------------------------------

w = list(sp.symbols("w1:8"))
t = sp.Symbol("t")
W = sp.Matrix(w)

# Stable map I+N on 18 variables.
I_plus_N = sp.Matrix(X) + K2 + B*W
I_plus_N = I_plus_N.col_join(W - q)

# Exact source/target certificate:
#   S(X,w) = (X, w-q(X));
#   T(U,V) = (U+B V, V);
# then T o (K x id_7) o S = I+N.
stabilized_after_source = K.col_join(W - q)
stable_result = (K + B*(W-q)).col_join(W-q)
assert stable_result == I_plus_N

# One-coordinate homogenization.  The nonlinear part H is homogeneous cubic.
H_X = t*K2 + t**2*B*W
H_W = -q
H = H_X.col_join(H_W).col_join(sp.Matrix([0]))
Z = X + w + [t]
G = sp.Matrix(Z) + H

for component in H:
    if component != 0:
        poly = sp.Poly(sp.expand(component), *Z)
        assert poly.is_homogeneous
        assert poly.total_degree() == 3

# Specialization t=1 is exactly the stable map, with the t-coordinate fixed.
assert G.subs({t: 1}) == I_plus_N.col_join(sp.Matrix([1]))

# ---------------------------------------------------------------------------
# 4. Explicit collision transfer.
# ---------------------------------------------------------------------------

p1 = (
    sp.Rational(0), sp.Rational(0), sp.Rational(-1, 4),
    sp.Rational(0), sp.Rational(0), sp.Rational(1, 2),
    sp.Rational(0), sp.Rational(0), sp.Rational(0),
    sp.Rational(0), sp.Rational(0),
)
p2 = (
    sp.Rational(1), sp.Rational(-3, 2), sp.Rational(13, 2),
    sp.Rational(-9, 4), sp.Rational(9, 2), sp.Rational(-10),
    sp.Rational(-3, 2), sp.Rational(3, 4), sp.Rational(-153, 8),
    sp.Rational(1), sp.Rational(-13, 2),
)
p3 = (
    sp.Rational(-1), sp.Rational(3, 2), sp.Rational(13, 2),
    sp.Rational(-9, 4), sp.Rational(-9, 2), sp.Rational(-10),
    sp.Rational(-3, 2), sp.Rational(-3, 4), sp.Rational(-153, 8),
    sp.Rational(1), sp.Rational(13, 2),
)

common_Phi_image = (sp.Rational(-1, 4),) + (sp.Rational(0),)*10
assert evaluate(Phi, X, p1) == common_Phi_image
assert evaluate(Phi, X, p2) == common_Phi_image
assert evaluate(Phi, X, p3) == common_Phi_image

common_K_image = evaluate(K, X, p1)
assert evaluate(K, X, p2) == common_K_image
assert evaluate(K, X, p3) == common_K_image

q_values = [evaluate(q, X, point) for point in (p1, p2, p3)]
lifted_points = [tuple(point) + tuple(q_value) + (sp.Rational(1),) for point, q_value in zip((p1,p2,p3), q_values)]
common_G_image = evaluate(G, Z, lifted_points[0])
assert len(set(lifted_points)) == 3
assert evaluate(G, Z, lifted_points[1]) == common_G_image
assert evaluate(G, Z, lifted_points[2]) == common_G_image

# ---------------------------------------------------------------------------
# 5. Exact Jacobian certificate and generic invariants.
# ---------------------------------------------------------------------------

JH = H.jacobian(Z)

power = sp.eye(19)
power_17 = None
for exponent in range(1, 19):
    power = (power * JH).applyfunc(sp.expand)
    if exponent == 17:
        power_17 = power.copy()

assert power == sp.zeros(19)
assert power_17 is not None
assert power_17[3, 18] == -18*t**16*x**10*y**6*z**2
assert power_17 != sp.zeros(19)

# Therefore JH has generic nilpotency index exactly 18 and det(I+JH)=1.
# Two explicit independent right-kernel vectors give rank(JH)<=17.
v1 = sp.zeros(19, 1)
v1[9] = 2*t*x                  # h-direction
v1[10] = 2*t*z                 # k-direction
v1[11] = x*k + z*h             # w1-direction
assert (JH*v1).applyfunc(sp.expand) == sp.zeros(19, 1)

E = x*y*(c + 2*z) + d**2*z + 3*d*y**2
v2 = sp.zeros(19, 1)
v2[3] = -t*x*y                 # a-direction
v2[8] = -t*(d*z + 3*y**2)      # s-direction
v2[13] = -E                    # w3-direction
v2[16] = 2*E                   # w6-direction
v2[17] = x*y*z                 # w7-direction
assert (JH*v2).applyfunc(sp.expand) == sp.zeros(19, 1)

# They are visibly independent (their supports are disjoint).  The all-ones
# specialization has rank 17, giving the matching generic lower bound.
assert {index for index, entry in enumerate(v1) if entry != 0}.isdisjoint(
    {index for index, entry in enumerate(v2) if entry != 0}
)
assert JH.subs({variable: 1 for variable in Z}).rank() == 17

# Span rank and support statistics.
all_monomials = sorted(
    {
        monomial
        for component in H
        for monomial, _ in sp.Poly(sp.expand(component), *Z).terms()
    }
)
H_coefficients = sp.Matrix(
    [
        [sp.Poly(sp.expand(component), *Z).coeff_monomial(monomial) for monomial in all_monomials]
        for component in H
    ]
)
span_rank = H_coefficients.rank()
monomial_occurrences = sum(polynomial_term_count(component, Z) for component in H)
coefficient_height = max(
    max(abs(sp.Rational(coeff).p), sp.Rational(coeff).q)
    for component in H
    for _, coeff in sp.Poly(sp.expand(component), *Z).terms()
)

assert span_rank == 18
assert monomial_occurrences == 56
assert len(all_monomials) == 40
assert coefficient_height == 14

print("[ok] 11D source map: degree 3, 52 terms, det = -2, three-point collision")
print("[ok] cubic span rank of normalized source = 7")
print("[ok] 19D G = I+H: H homogeneous cubic, det JG = 1")
print("[ok] collision transferred to three exact rational points")
print("[ok] generic nilpotency index JH = 18")
print("[ok] generic rank JH = 17")
print("[ok] complexity C(G) = (19, 18, 17, 18, 56, 14)")
print("[ok] distinct monomials = 40")
print("q(p1) =", q_values[0])
print("q(p2) =", q_values[1])
print("q(p3) =", q_values[2])
print("common image =", common_G_image)
