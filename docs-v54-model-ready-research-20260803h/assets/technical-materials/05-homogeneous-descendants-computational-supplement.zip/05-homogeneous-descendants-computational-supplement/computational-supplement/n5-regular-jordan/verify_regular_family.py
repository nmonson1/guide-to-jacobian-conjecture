#!/usr/bin/env python3
"""Exact symbolic certificate for the regular type-(5) collision-line stratum.

Checks:
  * the standard quartic kernel and cubic quotient pencil;
  * the 8-parameter full-kernel/osculating family;
  * the factorization K R = T N4;
  * nilpotence M^5=0 without expanding an inverse;
  * the underlying linear solution space has dimension 8;
  * the principal 5x5 pencil has no integrable two-plane embedding;
  * the Chern-class arithmetic used in the global rank-drop obstruction.
"""
from __future__ import annotations
import sympy as sp

s, t = sp.symbols("s t")
a = sp.symbols("a0:8")
a0,a1,a2,a3,a4,a5,a6,a7 = a

# Syzygy matrix of k=(s^4,s^3t,s^2t^2,st^3,t^4)^T.
Ks = sp.zeros(4,5)
Kt = sp.zeros(4,5)
for i in range(4):
    Ks[i,i+1] = 1
    Kt[i,i] = -1
K = s*Ks + t*Kt
k = sp.Matrix([s**4,s**3*t,s**2*t**2,s*t**3,t**4])
assert K*k == sp.zeros(4,1)

# Principal regular nilpotent quadratic pencil in dimension 4.
N4 = sp.Matrix([
    [-3*s*t, 3*s**2, 0, 0],
    [-t**2, -s*t, 2*s**2, 0],
    [0, -2*t**2, s*t, s**2],
    [0, 0, -3*t**2, 3*s*t],
])
assert sp.expand(N4**4) == sp.zeros(4)
assert sp.expand(N4**3) != sp.zeros(4)

T = sp.Matrix([
    [-a6+a7/sp.Integer(2), 3*a2, -3*a1, a0],
    [a5/sp.Integer(3), 3*a6-a7/sp.Integer(2), -3*a2, a1],
    [-a4/sp.Integer(3), -a5, -3*a6+a7, a2],
    [a3, a4, a5, a6],
])
Rs = sp.Matrix([
    [a7, -3*a2, 6*a1, -3*a0],
    [0, -3*a6+3*a7/sp.Integer(2), 6*a2, -3*a1],
    [0, a5, 6*a6-a7, -3*a2],
    [0, -a4, -2*a5, -3*a6+a7],
    [0, 3*a3, 2*a4, a5],
])
Rt = sp.Matrix([
    [3*a2, -6*a1, 3*a0, 0],
    [3*a6-a7/sp.Integer(2), -6*a2, 3*a1, 0],
    [-a5, -6*a6+2*a7, 3*a2, 0],
    [a4, 2*a5, 3*a6, 0],
    [-3*a3, -2*a4, -a5, a7],
])
R = s*Rs + t*Rt

# The essential identity.  If det(T) != 0 and M=R*T^{-1}*K, then
# M^j = R*N4^(j-1)*T^{-1}*K, hence M^5=0.
assert sp.expand(K*R - T*N4) == sp.zeros(4)

# This is the general solution of the linear lifting equation K R = T N4.
urs = sp.symbols("rS0:20")
urt = sp.symbols("rT0:20")
ut = sp.symbols("TT0:16")
Rsu = sp.Matrix(5,4,urs)
Rtu = sp.Matrix(5,4,urt)
Tu = sp.Matrix(4,4,ut)
expr = K*(s*Rsu+t*Rtu) - Tu*N4
eqs = []
for entry in expr:
    poly = sp.Poly(sp.expand(entry),s,t)
    eqs.extend([poly.coeff_monomial(s**2),poly.coeff_monomial(s*t),poly.coeff_monomial(t**2)])
L,_ = sp.linear_eq_to_matrix(eqs,list(urs)+list(urt)+list(ut))
assert L.shape == (48,56)
assert L.rank() == 48

# The displayed 8 parameter vectors span the nullspace.
param_vector = sp.Matrix(list(Rs)+list(Rt)+list(T))
P = param_vector.jacobian(a)
assert P.rank() == 8
assert L*P == sp.zeros(48,8)

# Principal dimension-5 pencil: integrability alone has no nonzero embedding.
A5 = sp.zeros(5); B5 = sp.zeros(5); C5 = sp.zeros(5)
for i in range(4):
    A5[i,i+1] = 4-i
    C5[i+1,i] = -(i+1)
for i,d in enumerate((-4,-2,0,2,4)):
    B5[i,i] = d
Iplane = B5.row_join(-2*A5).col_join((-2*C5).row_join(B5))
principal_det = sp.factor(Iplane.det())
assert principal_det == -sp.Integer(2)**16 * sp.Integer(3)**4

# Chern arithmetic for a globally constant regular type-(5) quadratic matrix.
degrees = [-4,-2,0,2,4]
assert sum(degrees) == 0
c2 = sum(degrees[i]*degrees[j] for i in range(5) for j in range(i+1,5))
assert c2 == -20

print("[ok] K*k=0 and N4 has nilpotency index 4")
print("[ok] K*R=T*N4 for the 8-parameter family")
print("[ok] lifting system rank 48 in 56 unknowns: nullity 8")
print("[ok] displayed parameters form a basis of the lifting nullspace")
print("[ok] principal 5D integrability determinant =", principal_det)
print("[ok] regular global filtration would have c2 coefficient", c2)
