#!/usr/bin/env python3
"""SymPy check that the F_11 pencil is regular over algebraic closure.

The gcd of all 4x4 minors of M(s,t) is 1 in F_11[s,t], so there is no
projective point over an algebraic extension at which rank drops below four.
"""
import sympy as sp
s,t=sp.symbols('s t')
p=11
A=sp.Matrix([
[0,5,8,1,3],[0,3,5,8,6],[0,6,9,7,10],[0,5,0,5,3],[0,5,7,8,5]])
B=sp.Matrix([
[6,3,4,6,7],[8,10,9,8,6],[5,2,2,4,3],[6,6,8,1,2],[6,0,4,10,3]])
C=sp.Matrix([
[0,6,2,4,0],[7,5,8,5,0],[0,2,8,8,0],[5,9,7,9,0],[4,10,7,8,0]])
M=s*s*A+s*t*B+t*t*C
mins=[]
for i in range(5):
    for j in range(5):
        N=M.copy();N.row_del(i);N.col_del(j)
        mins.append(sp.Poly(sp.expand(N.det()),s,t,modulus=p))
g=mins[0]
for q in mins[1:]:g=sp.gcd(g,q)
assert g.as_expr()==1
# M^5=0 identically and M^4 is nonzero.
M5=M
for _ in range(4):M5=M5*M
assert all(sp.Poly(sp.expand(q),s,t,modulus=p).is_zero for q in M5)
M4=M
for _ in range(3):M4=M4*M
assert any(not sp.Poly(sp.expand(q),s,t,modulus=p).is_zero for q in M4)
print('[ok] gcd of all 4x4 minors is 1 over F_11[s,t]')
print('[ok] pencil is regular nilpotent at every geometric projective point')
