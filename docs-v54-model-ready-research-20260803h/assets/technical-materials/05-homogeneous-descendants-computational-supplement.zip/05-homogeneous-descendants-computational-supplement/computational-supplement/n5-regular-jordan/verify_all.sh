#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python verify_regular_family.py
python verify_f11_hensel.py
python verify_f11_geometric.py
