# The regular Jordan stratum in dimension five

## Scope

This note attacks the first possible cubic-homogeneous dimension for a Keller
counterexample.  It studies a putative map

\[
F(x)=x+H(x),\qquad H\text{ cubic homogeneous},\qquad x\in k^5,
\]

under the assumption that the generic Jordan type of \(JH\) is the regular
nilpotent type \((5)\).

The main result is not a five-dimensional counterexample and not a
nonexistence theorem.  It is a sharp separation between the **collision-line
problem** and the **global Keller problem**:

* the regular collision-line equations have a smooth characteristic-zero
  family;
* therefore they cannot by themselves exclude dimension five;
* a global extension must develop a codimension-two rank-drop locus away from
  that collision line.

All example-specific statements are accompanied by executable exact
certificates.

---

# 1. Collision normalization

Let \(H(x)=T(x,x,x)\), with \(T:V^3\to V\) symmetric in its three inputs.
Suppose

\[
F(v+u)=F(v)
\]

with \(u,v\) linearly independent.  On the two-dimensional vector plane
\(P=\langle u,v\rangle\), write

\[
M(s,t)=JH(su+tv)=s^2A+stB+t^2C,
\]

where

\[
A=JH(u),\qquad B=6T(u,v,-),\qquad C=JH(v).
\]

Symmetry of \(T\) is equivalent, on this plane, to

\[
\boxed{Bu=2Av,\qquad Bv=2Cu.}
\]

The collision equation is

\[
\boxed{u+\frac13Au+Av+Cu=0.}
\]

Consequently the regular collision-line problem is finite-dimensional:
classify nilpotent quadratic pencils \(M(s,t)\) of type \((5)\), together with
independent \(u,v\) satisfying these fifteen scalar equations.

The two integrability identities are also sufficient for extending the
prescribed plane data to a symmetric trilinear tensor on all of \(V\).  They
do **not** ensure that the resulting global Jacobian is nilpotent away from
\(P\).

---

# 2. Vector-bundle constraints on an everywhere-regular line

Assume that \(M(s,t)\) has Jordan type \((5)\) for every
\([s:t]\in\mathbf P^1\).  Regard it as

\[
M:\mathcal O_{\mathbf P^1}^{5}\longrightarrow
  \mathcal O_{\mathbf P^1}^{5}(2).
\]

Let

\[
K_i=\ker M^i,\qquad L_i=K_i/K_{i-1}.
\]

Each \(K_i\) is a rank-\(i\) subbundle.  The induced maps

\[
L_i\longrightarrow L_{i-1}(2)
\]

are nowhere-zero maps of line bundles, hence isomorphisms.  If
\(\deg L_1=a\), then

\[
\deg L_i=a+2(i-1).
\]

Since \(\sum_i\deg L_i=0\),

\[
\boxed{
(\deg L_1,\ldots,\deg L_5)=(-4,-2,0,2,4).
}
\]

In particular, the right kernel is a line subbundle

\[
\mathcal O(-4)\hookrightarrow\mathcal O^5.
\]

## 2.1 Coordinate-span trichotomy

Let \(r\) be the dimension of the span of the five coordinate quartics of a
kernel generator.  After a constant basis change only the first \(r\)
coordinates need be nonzero.  If

\[
\mathcal E=\ker(\mathcal O^r\to\mathcal O(4)),
\]

then

\[
\mathcal E\simeq\bigoplus_{j=1}^{r-1}\mathcal O(-a_j),
\qquad a_j>0,\qquad\sum a_j=4.
\]

Degree-two syzygies are the sections of \(\mathcal E(2)\).  Pointwise rank
four forces the following alternatives:

\[
\boxed{
\begin{array}{c|c}
r&\text{possible syzygy splitting}\\ \hline
2&\text{impossible}\\
3&(2,2)\\
4&(1,1,2)\\
5&(1,1,1,1).
\end{array}}
\]

Indeed:

* for \(r=2\), the splitting is \((4)\), so there are no quadratic
  syzygies; only three free columns remain and rank four is impossible;
* for \(r=3\), the unbalanced splitting \((1,3)\) has only one pointwise
  syzygy direction, and two free columns again give rank at most three;
* the displayed splittings are the only remaining positive partitions of
  four.

Thus the everywhere-regular line has three residual strata: balanced
three-coordinate, four-coordinate, and full five-coordinate kernel span.

---

# 3. The full-kernel/osculating chart

Normalize the right kernel to

\[
k(s,t)=(s^4,s^3t,s^2t^2,st^3,t^4)^T.
\]

Its linear syzygy matrix is

\[
K(s,t)=
\begin{pmatrix}
-t&s&0&0&0\\
0&-t&s&0&0\\
0&0&-t&s&0\\
0&0&0&-t&s
\end{pmatrix}.
\]

The induced regular nilpotent quotient pencil is

\[
N_4(s,t)=
\begin{pmatrix}
-3st&3s^2&0&0\\
-t^2&-st&2s^2&0\\
0&-2t^2&st&s^2\\
0&0&-3t^2&3st
\end{pmatrix},
\qquad N_4^4=0,
\qquad N_4^3\ne0.
\]

Solving the linear lifting equation

\[
K(s,t)R(s,t)=T N_4(s,t)
\]

for a linear \(5\times4\) matrix \(R\) and a constant \(4\times4\) matrix
\(T\) gives a linear system of rank 48 in 56 unknowns.  Hence its solution
space has dimension eight.

For parameters \(a_0,\ldots,a_7\), one basis is:

\[
T=\begin{pmatrix}
-a_6+a_7/2&3a_2&-3a_1&a_0\\
a_5/3&3a_6-a_7/2&-3a_2&a_1\\
-a_4/3&-a_5&-3a_6+a_7&a_2\\
a_3&a_4&a_5&a_6
\end{pmatrix},
\]

and \(R=sR_s+tR_t\), where

\[
R_s=\begin{pmatrix}
a_7&-3a_2&6a_1&-3a_0\\
0&-3a_6+3a_7/2&6a_2&-3a_1\\
0&a_5&6a_6-a_7&-3a_2\\
0&-a_4&-2a_5&-3a_6+a_7\\
0&3a_3&2a_4&a_5
\end{pmatrix},
\]

\[
R_t=\begin{pmatrix}
3a_2&-6a_1&3a_0&0\\
3a_6-a_7/2&-6a_2&3a_1&0\\
-a_5&-6a_6+2a_7&3a_2&0\\
a_4&2a_5&3a_6&0\\
-3a_3&-2a_4&-a_5&a_7
\end{pmatrix}.
\]

On \(\det T\ne0\), define

\[
\boxed{M(s,t)=R(s,t)T^{-1}K(s,t).}
\]

The factorization gives

\[
M^j=R N_4^{j-1}T^{-1}K,
\]

and therefore

\[
\boxed{M^5=0.}
\]

Regularity is the additional open condition that the \(4\times4\) minors of
\(M\) have no common projective zero.

## 3.1 The principal pencil is not representative

For the most symmetric principal \(5\times5\) pencil, the integrability
matrix

\[
\begin{pmatrix}B&-2A\\-2C&B\end{pmatrix}
\]

has determinant

\[
\boxed{-2^{16}3^4=-5308416.}
\]

Thus the principal pencil admits no nonzero plane embedding.  This does not
exclude the eight-parameter family above.

---

# 4. A smooth characteristic-zero collision family

The following point over \(\mathbf F_{11}\) lies in the full-kernel chart:

\[
\boxed{a=(8,7,1,7,2,9,0,1),}
\]

\[
\boxed{u=(7,6,3,10,4),\qquad v=(8,9,7,9,1).}
\]

At this point \(\det T=1\).  The resulting coefficient matrices are

\[
A=\begin{pmatrix}
0&5&8&1&3\\0&3&5&8&6\\0&6&9&7&10\\0&5&0&5&3\\0&5&7&8&5
\end{pmatrix},
\]

\[
B=\begin{pmatrix}
6&3&4&6&7\\8&10&9&8&6\\5&2&2&4&3\\6&6&8&1&2\\6&0&4&10&3
\end{pmatrix},
\]

\[
C=\begin{pmatrix}
0&6&2&4&0\\7&5&8&5&0\\0&2&8&8&0\\5&9&7&9&0\\4&10&7&8&0
\end{pmatrix}.
\]

Exact arithmetic verifies

\[
Bu=2Av,\qquad Bv=2Cu,
\]

and

\[
u+\frac13Au+Av+Cu=0.
\]

The gcd of all \(4\times4\) minors of

\[
M(s,t)=s^2A+stB+t^2C
\]

is one in \(\mathbf F_{11}[s,t]\).  Hence the pencil has Jordan type
\((5)\) at every geometric point of \(\mathbf P^1_{\overline{\mathbf F}_{11}}\).

## 4.1 Smoothness and Hensel lifting

Fix

\[
a_7=1,\qquad v_4=1,
\]

and use the sixteen affine variables

\[
(a_0,\ldots,a_6,u_0,\ldots,u_4,v_0,\ldots,v_3).
\]

The ten integrability equations and five collision equations define a
15-component regular function on the open set \(\det T\ne0\).

At the displayed point its \(15\times16\) Jacobian has rank 15.  More
precisely, the minor obtained by omitting the last variable \(v_3\) has

\[
\boxed{\det=3\pmod {11}.}
\]

The tangent kernel is generated modulo 11 by

\[
(1,9,2,6,10,4,7,4,2,9,8,4,3,5,1,1),
\]

whose last component is one.  Thus \(v_3\) is a local parameter.  Fixing
\(v_3=9\), the multivariate Hensel lemma gives a unique
\(\mathbf Z_{11}\)-lift.  The supplied script verifies the lift through
modulus

\[
11^{12}=3138428376721.
\]

The lifted residue vector is

```text
975032660269, 1166914071088, 1132097078025, 2645513248781,
2490147814068, 585560787788, 315228184700, 2678133359557,
2707586605158, 2070991223172, 3004643365063, 63846186628,
2053897594130, 43686183803, 2589807566265, 9
```

modulo \(11^{12}\).

Because the geometric regularity condition is open and its reduction has no
rank-drop point, the lifted pencil remains regular at every geometric point
of the projective line.

Thus:

\[
\boxed{
\text{The everywhere-regular type-(5) collision-line equations have a
smooth characteristic-zero solution family.}
}
\]

This is a statement about necessary plane data.  It is **not** yet a
five-dimensional Keller counterexample.

---

# 5. A global Chern-class obstruction

Let \(M(x)\) now be a homogeneous quadratic \(5\times5\) nilpotent matrix on
\(\mathbf P^4\), with generic Jordan type \((5)\).  Let

\[
D=\{[x]\in\mathbf P^4:\operatorname{rank}M(x)\le3\}.
\]

## Proposition

\[
\boxed{\operatorname{codim}_{\mathbf P^4}D\le2.}
\]

### Proof

Assume \(\operatorname{codim}D\ge3\), and put \(U=\mathbf P^4\setminus D\).
On \(U\), the kernel filtration gives line quotients \(L_i\) with

\[
L_i\simeq L_1(2(i-1)).
\]

Since the complement has codimension at least three,

\[
\operatorname{Pic}(U)\simeq\operatorname{Pic}(\mathbf P^4),
\qquad
CH^2(U)\simeq CH^2(\mathbf P^4).
\]

The same first-Chern-class calculation gives

\[
L_i\simeq\mathcal O_U(-4+2(i-1)).
\]

By multiplicativity of Chern classes in the filtration of the trivial bundle,

\[
0=c_2(\mathcal O_U^5)
 =\sum_{i<j}(-4+2i)(-4+2j)h^2
 =-20h^2,
\]

where indices are \(i,j=0,\ldots,4\).  But \(h^2\ne0\) in \(CH^2(U)\), a
contradiction.  ∎

If a projective collision line is everywhere regular, it is disjoint from
\(D\).  A divisor in \(\mathbf P^4\) cannot be disjoint from a projective
line.  Hence any global extension of the regular collision-line family must
satisfy

\[
\boxed{\operatorname{codim}D=2.}
\]

This is the first genuinely global obstruction: the missing rank drop must
occur on a surface away from the collision line.

---

# 6. What remains to obtain or exclude a five-dimensional counterexample

The regular collision-line stratum is no longer the obstruction.  Starting
from a lifted plane point, one may choose coordinates with \(u=e_0\) and
\(v=e_1\).  The matrices \(A,B,C\) determine the 65 tensor entries whose
input triples contain at least two indices from \(\{0,1\}\).  There remain

\[
5\cdot22=110
\]

free symmetric tensor entries.

The unresolved condition is that the resulting global quadratic Jacobian be
nilpotent for every \(x\in k^5\).  Equivalently one must impose the
coefficients of

\[
\operatorname{tr}(JH(x)^j)=0,\qquad j=1,\ldots,5.
\]

Before dependencies, these contain

\[
15+70+210+495+1001=1791
\]

coefficient equations.  Any solution extending an everywhere-regular
collision line must additionally have a codimension-two rank-drop surface.

The next mathematically focused formulation is therefore:

> classify symmetric cubic tensors extending one of the smooth regular-line
> points for which the ideal of \(4\times4\) minors of \(JH\) has height two
> and all five trace identities vanish.

A negative result for this extension problem would eliminate the full-kernel
regular-line stratum.  A positive result would be a five-dimensional
cubic-homogeneous counterexample and would attain the known dimension lower
bound.

---

# 7. Verification files

* `verify_regular_family.py`: symbolic family, nullity-eight lifting system,
  principal-pencil obstruction, Chern arithmetic;
* `verify_f11_hensel.py`: pure-Python finite-field point, dual-number
  Jacobian, determinant-three minor, and Hensel lift;
* `verify_f11_geometric.py`: geometric regularity over
  \(\overline{\mathbf F}_{11}\) by the gcd of all maximal minors.
