#!/usr/bin/env bash
set -euo pipefail
export PYTHONHASHSEED=1
for f in attack1_n5.py attack2_compression.py attack3_jordan_degeneration.py attack4_hessian38.py attack5_druzkowski110.py; do
  echo "=== $f ==="
  python3 "$f"
done
echo '[ok] all five attacks passed'
