#!/usr/bin/env python3
"""Attack 5: catalecticant lower bound and exact 110D square-zero pairing."""
from __future__ import annotations
import json
from pathlib import Path
import sympy as sp
import base19_data as M

n = 19
# Derivative/catalecticant flattening: rows are dH_i/dz_j, columns are
# degree-two monomials.  Any H=sum b_r ell_r^3 has this row space contained
# in span{ell_r^2}, so its rank is a lower bound for the number of cubes.
quad_mons = []
for i in range(n):
    for j in range(i, n):
        ex = [0]*n
        ex[i] += 1
        ex[j] += 1
        quad_mons.append(tuple(ex))
rows = []
for Hi in M.H:
    for z in M.Z:
        p = sp.Poly(sp.diff(Hi, z), *M.Z, domain=sp.QQ)
        rows.append([p.coeff_monomial(mon) for mon in quad_mons])
Cat = sp.MutableSparseMatrix(rows)
cat_rank = Cat.rank()
assert cat_rank == 39

J = json.loads(Path(__file__).with_name("pairing_110.json").read_text())
B = sp.Matrix([[sp.Rational(x) for x in row] for row in J["B"]])
D = sp.Matrix([[sp.Rational(x) for x in row] for row in J["D"]])
N = D.rows
assert N == 110 and B.shape == (19, 110) and D.shape == (110, 19)
assert B.rank() == D.rank() == 19
assert B*D == sp.zeros(19)
A = D*B
assert A*A == sp.zeros(N)
assert A.rank() == 19
assert A[0,0]*A[7,7]-A[0,7]*A[7,0] == sp.Rational(1,576)
forms = D*sp.Matrix(M.Z)
assert (B*forms.applyfunc(lambda e: sp.expand(e**3))-M.H).applyfunc(sp.expand) == sp.zeros(19, 1)

# Construct a right inverse and verify the GZ pairing identity.
_, piv = B.rref()
assert len(piv) == 19
PB = B[:, list(piv)]
C = sp.zeros(N, 19)
Pinv = PB.inv()
for i, j in enumerate(piv):
    C[j, :] = Pinv[i, :]
assert B*C == sp.eye(19)
assert A*C == D

def DA(v):
    return v+(A*v).applyfunc(lambda e: sp.expand(e**3))
assert (B*DA(C*sp.Matrix(M.Z))-M.G).applyfunc(sp.expand) == sp.zeros(19, 1)

# Exact collision transfer.
p1 = (sp.Rational(0), sp.Rational(0), sp.Rational(-1,4), 0, 0,
      sp.Rational(1,2), 0, 0, 0, 0, 0)
p2 = (1, sp.Rational(-3,2), sp.Rational(13,2), sp.Rational(-9,4),
      sp.Rational(9,2), -10, sp.Rational(-3,2), sp.Rational(3,4),
      sp.Rational(-153,8), 1, sp.Rational(-13,2))
qeval = lambda p: M.q.subs(dict(zip(M.X, p)))
z1 = sp.Matrix(list(p1)+list(qeval(p1))+[1])
z2 = sp.Matrix(list(p2)+list(qeval(p2))+[1])
u = C*z1
v = C*z2
delta = DA(u)-DA(v)
v2 = v+delta
assert B*delta == sp.zeros(19, 1)
assert A*delta == sp.zeros(N, 1)
assert u != v2 and DA(u) == DA(v2)

# Exact scaled-Jacobian nilpotency index at the all-ones specialization.
E = sp.diag(*[e**2 for e in forms])*D
assert (3*B*E-M.JH).applyfunc(sp.expand) == sp.zeros(19)
E1 = E.subs({z:1 for z in M.Z})
BE = B*E1
assert BE**18 == sp.zeros(19)
witness = E1*(BE**17)*B
assert witness != sp.zeros(N)

support = len(A.todok())
height = max(max(abs(sp.Rational(v).p), sp.Rational(v).q)
             for v in A.todok().values())
print("[result] derivative catalecticant rank =", cat_rank)
print("[result] every vector Waring decomposition needs at least 39 cubes")
print("[ok] exact 110D full-rank square-zero GZ pairing")
print("[ok] A^2=0, rank A=19, corank A=91")
print("[ok] principal minor A[{1,8}] = 1/576, so A is not D-nilpotent")
print("[ok] scaled Jacobian nilpotency index=19")
print("[ok] explicit collision transferred")
print("[result] C(A)=(110,19,91,19,%d,%d)" % (support, height))
print("[result] constrained pairing interval: 39 <= N_pair <= 110")
