#!/usr/bin/env python3
"""Attack 4: explicit 38D Hessian-nilpotent quartic and inverse-ray data."""
from __future__ import annotations
from pathlib import Path
import sympy as sp
import base19_data as M

n = 19
I = sp.I
U = list(sp.symbols("u1:20"))
V = list(sp.symbols("v1:20"))
Xuv = sp.Matrix([U[j]+I*V[j] for j in range(n)])
Yuv = sp.Matrix([(U[j]-I*V[j])/2 for j in range(n)])
subuv = dict(zip(M.Z, Xuv))
Huv = M.H.subs(subuv)
Auv = M.JH.subs(subuv)

# Q(U,V)=1/2 (U-iV)^T H(U+iV).
Q38 = sp.expand((Yuv.T*Huv)[0])
polyQ = sp.Poly(Q38, *(U+V), extension=I)
assert all(sum(mon) == 4 for mon, _ in polyQ.terms())

# T^{-1}(p,q)=((p+2q)/2,-i(p-2q)/2).
Ntop = Huv
Nbot = Auv.T*Yuv
conj_nonlin = sp.Matrix([(Ntop[j]+2*Nbot[j])/2 for j in range(n)] +
                        [-I*(Ntop[j]-2*Nbot[j])/2 for j in range(n)])
gradQ = sp.Matrix([sp.diff(Q38, z) for z in U+V])
assert (gradQ-conj_nonlin).applyfunc(sp.expand) == sp.zeros(38, 1)

# Exact 19D kernel vectors and second-directional-derivative identities.
x,y,z,a,b,c,d,q0,s,h,k = M.X
t = M.t
v1 = sp.zeros(19, 1)
v1[9] = 2*t*x
v1[10] = 2*t*z
v1[11] = x*k+z*h
E = x*y*(c+2*z)+d**2*z+3*d*y**2
v2 = sp.zeros(19, 1)
v2[3] = -t*x*y
v2[8] = -t*(d*z+3*y**2)
v2[13] = -E
v2[16] = 2*E
v2[17] = x*y*z
for p, q in ((v1, v2), (v2, v2)):
    vals = sp.Matrix([(p.T*sp.hessian(Hi, M.Z)*q)[0] for Hi in M.H])
    assert vals.applyfunc(sp.expand) == sp.zeros(19, 1)

# A simple exact specialization certifies generic rank 35 and index 35.
one = {zv: sp.Integer(1) for zv in M.Z}
A1 = M.JH.subs(one)
yone = sp.ones(19, 1)
L1 = (M.JH.T*yone).jacobian(M.Z).subs(one)
N1 = A1.row_join(sp.zeros(19)).col_join(L1.row_join(A1.T))
assert N1.rank() == 35
N34 = N1**34
assert N34.rank() == 1 and N34[37, 18] == 648
assert N1**35 == sp.zeros(38)

# Collision lift.
p1 = (sp.Rational(0), sp.Rational(0), sp.Rational(-1,4), 0, 0,
      sp.Rational(1,2), 0, 0, 0, 0, 0)
p2 = (1, sp.Rational(-3,2), sp.Rational(13,2), sp.Rational(-9,4),
      sp.Rational(9,2), -10, sp.Rational(-3,2), sp.Rational(3,4),
      sp.Rational(-153,8), 1, sp.Rational(-13,2))
qeval = lambda p: M.q.subs(dict(zip(M.X, p)))
z1 = sp.Matrix(list(p1)+list(qeval(p1))+[1])
z2 = sp.Matrix(list(p2)+list(qeval(p2))+[1])
assert M.G.subs(dict(zip(M.Z, z1))) == M.G.subs(dict(zip(M.Z, z2)))

# Exact algebraic inverse branch of the base map on target (P,Q,R)=(0,rho,rho).
rho, rr = sp.symbols("rho rr")
xx = (1/rr-1)/rho
yy = rho
zz = -rho**2*rr*(rr+3)
field = sp.QQ.frac_field(rho)
modulus = sp.Poly(rr**2-(1-rho**2), rr, domain=field)
def zero_mod(expr: sp.Expr) -> bool:
    num = sp.cancel(expr).as_numer_denom()[0]
    rem = sp.Poly(num, rr, domain=field).rem(modulus)
    return sp.expand(rem.as_expr()) == 0

P0 = (1+M.x*M.y)**3*M.z + M.y**2*(1+M.x*M.y)*(4+3*M.x*M.y)
Q0 = M.y + 3*M.x*(1+M.x*M.y)**2*M.z + 3*M.x*M.y**2*(4+3*M.x*M.y)
R0 = 2*M.x-3*M.x**2*M.y-M.x**3*M.z
base_sub = {M.x:xx, M.y:yy, M.z:zz}
assert zero_mod(P0.subs(base_sub))
assert zero_mod(Q0.subs(base_sub)-rho)
assert zero_mod(R0.subs(base_sub)-rho)

# Lift to the public 11D representative; the last eight outputs vanish.
dd = xx*yy
hh = xx**2
kk = -xx*zz
bb = -3*xx**2*yy
cc = -xx*yy*zz-3*yy**2-2*zz
aa = -xx**2*yy**2
qq = 3*xx*(2*xx*yy*zz+3*yy**2+2*zz)
ss = yy*(3*xx**2*yy*zz+6*xx*yy**2+6*xx*zz+7*yy)
lift = [xx,yy,zz,aa,bb,cc,dd,qq,ss,hh,kk]
phi_eval = M.Phi.subs(dict(zip(M.X, lift)))
for got, want in zip(phi_eval, [0,rho,rho]+[0]*8):
    assert zero_mod(got-want)

# The normalized target direction is ybar=(1/2,1,0,...,0,1).
ybar = sp.zeros(19, 1)
ybar[0] = sp.Rational(1,2)
ybar[1] = 1
ybar[18] = 1
assert M.L.inv()*sp.Matrix([0,1,1]+[0]*8) == ybar[:11, :]

# First coordinate of G^{-1}(s*ybar): x(s^2)/s.
svar = sp.Symbol("s")
series = sp.series((1/sp.sqrt(1-svar**4)-1)/svar**3, svar, 0, 30).removeO()
expected = sum(sp.binomial(2*r, r)/4**r*svar**(4*r-3) for r in range(1, 9))
assert sp.expand(series-expected) == 0

# First explicit Zhao/VC nonvanishing value.  Put P=-Q38.  Since the relevant
# exponent is even for m=1, Delta(P^2)=Delta(Q38^2).
ybar_sub = dict(zip(M.Z, list(ybar)))
Hv = M.H.subs(ybar_sub)
Av = M.JH.subs(ybar_sub)
first_laplacian_derivative = 2*(Av*Hv)[0]
assert first_laplacian_derivative == sp.Rational(3,4)

# Serialize the expanded quartic for independent systems.
out = Path(__file__).with_name("quartic38.txt")
out.write_text(str(Q38)+"\n", encoding="utf-8")

print("[ok] Q38 has", len(polyQ.terms()), "quartic monomials over Q(i)")
print("[ok] conjugated nonlinear part equals grad(Q38)")
print("[ok] generic Hessian certificate: rank 35, index 35")
print("[result] generic Hessian Jordan type is (35,2,1)")
print("[ok] exact base/11D inverse branch on (0,rho,rho)")
print("[result] inverse-ray coefficient [s^(4r-3)] = (1/2)*binom(2r,r)/4^r")
print("[result] d/du1 Delta(Q38^2)(wbar) =", first_laplacian_derivative)
print("[result] for r>=2, m=2r-3:")
print("         d/du1 Delta^m(Q38^(m+1))(wbar)")
print("         = binom(2r,r)*(2r-3)!*(2r-2)!/16 != 0")
