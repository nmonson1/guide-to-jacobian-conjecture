#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sympy as sp
import base19_data as M
P=Path(__file__).resolve().parent
J=json.loads((P/'pairing_110.json').read_text())
B=sp.Matrix([[sp.Rational(x) for x in row] for row in J['B']])
D=sp.Matrix([[sp.Rational(x) for x in row] for row in J['D']])
A=D*B
_,piv=B.rref(); PB=B[:,list(piv)]; Pinv=PB.inv(); C=sp.zeros(110,19)
for i,j in enumerate(piv): C[j,:]=Pinv[i,:]
def wr(name,Mx):
    (P/name).write_text('\n'.join('\t'.join(str(Mx[i,j]) for j in range(Mx.cols)) for i in range(Mx.rows))+'\n')
wr('A_110.tsv',A); wr('B_110.tsv',B); wr('D_110.tsv',D); wr('C_110.tsv',C)
p1=(sp.Rational(0),sp.Rational(0),sp.Rational(-1,4),0,0,sp.Rational(1,2),0,0,0,0,0)
p2=(1,sp.Rational(-3,2),sp.Rational(13,2),sp.Rational(-9,4),sp.Rational(9,2),-10,sp.Rational(-3,2),sp.Rational(3,4),sp.Rational(-153,8),1,sp.Rational(-13,2))
qe=lambda p:M.q.subs(dict(zip(M.X,p)))
z1=sp.Matrix(list(p1)+list(qe(p1))+[1]); z2=sp.Matrix(list(p2)+list(qe(p2))+[1])
def DA(v): return v+(A*v).applyfunc(lambda e:sp.expand(e**3))
u=C*z1; v=C*z2; vp=v+DA(u)-DA(v); image=DA(u)
with (P/'collision_110.tsv').open('w') as f:
    f.write('index\tu\tv\tcommon_image\n')
    for i in range(110): f.write(f'{i+1}\t{u[i]}\t{vp[i]}\t{image[i]}\n')
assert u!=vp and DA(u)==DA(vp)
print('[ok] serialized A,B,D,C and exact 110D collision')
