#!/usr/bin/env python3
"""Attack 1: exact reductions and a boundary ansatz for N=5.

This script does not claim to classify all 5-dimensional cubic-homogeneous
Keller maps.  It verifies the algebraic identities used to reduce the search,
and performs an exhaustive finite-field check in a sharply bounded sparse
subclass of the commutator ansatz H_C = C x^{*3} - (Cx)^{*3}.
"""
from __future__ import annotations
import itertools
import numpy as np
import sympy as sp

# Number of scalar equations in the coefficient formulation.
# H has 5*C(7,3)=175 coefficients.  tr(JH^k)=0 has C(2k+4,4)
# coefficient equations before redundancies.
counts = [sp.binomial(2*k + 4, 4) for k in range(1, 6)]
assert counts == [15, 70, 210, 495, 1001]
assert sum(counts) == 1791

# Midpoint collision identity.  For H=T(x,x,x), put a=u+v,b=u-v.
# H(u+v)-H(u-v)=2*JH(u)v+2*H(v).
# We verify it for a generic scalar cubic in two formal vector slots by the
# binomial coefficients; componentwise the tensor identity is universal.
s, t = sp.symbols("s t")
assert sp.expand((s+t)**3 - (s-t)**3 - (6*s**2*t + 2*t**3)) == 0

# The commutator ansatz H_C = phi(Cx)-C phi(x), phi(z)=z-z^{*3}.
n = 5
x = sp.Matrix(sp.symbols("x1:6"))
c = sp.symbols("c0:25")
C = sp.Matrix(5, 5, c)
y = C*x
phi_x = x - x.applyfunc(lambda e: e**3)
phi_Cx = y - y.applyfunc(lambda e: e**3)
H = C*x.applyfunc(lambda e: e**3) - y.applyfunc(lambda e: e**3)
assert (phi_Cx - C*phi_x - H).applyfunc(sp.expand) == sp.zeros(5, 1)

X2 = sp.diag(*[e**2 for e in x])
Y2 = sp.diag(*[e**2 for e in y])
M = C*X2 - Y2*C  # JH/3
assert H.jacobian(list(x)) == 3*M

# First trace condition: C^T Delta C = Delta, Delta=diag(c_ii).
Delta = sp.diag(*[C[i, i] for i in range(5)])
trace_formula = (x.T*(Delta - C.T*Delta*C)*x)[0]
assert sp.expand(sp.trace(M) - trace_formula) == 0

# For zero diagonal, tr(M^2) is controlled exactly by reciprocal directed edges.
C0 = C.copy()
for i in range(5):
    C0[i, i] = 0
y0 = C0*x
M0 = C0*X2 - sp.diag(*[e**2 for e in y0])*C0
rhs = 0
for i in range(5):
    for j in range(i+1, 5):
        rhs += 2*C0[i, j]*C0[j, i]*(x[j]**2-y0[i]**2)*(x[i]**2-y0[j]**2)
assert sp.expand(sp.trace(M0*M0) - rhs) == 0

# Exhaustive finite-field check: zero diagonal, normalized collision e1/e2,
# total support <=4.  The forced entries are c12=c21=3 over F5 and =2 over F7.
def sparse_check(p: int, alpha: int) -> tuple[int, int, int]:
    target = np.array([p-1, 1, 0, 0, 0], dtype=np.int64)
    base = np.zeros((5, 5), dtype=np.int64)
    base[0, 1] = alpha
    base[1, 0] = alpha
    positions = [(i, j) for i in range(5) for j in range(5)
                 if i != j and (i, j) not in [(0, 1), (1, 0)]]
    samples = []
    for supp in (1, 2):
        for inds in itertools.combinations(range(5), supp):
            for vals in itertools.product(range(1, p), repeat=supp):
                v = np.zeros(5, dtype=np.int64)
                for i, a in zip(inds, vals):
                    v[i] = a
                samples.append(v)

    def collision(A: np.ndarray) -> bool:
        a, b = A[:, 0], A[:, 1]
        return np.all((a-a**3-b+b**3) % p == target)

    def nilpotent_on_samples(A: np.ndarray) -> bool:
        for v in samples:
            v2 = v*v % p
            Av = A@v % p
            N = (A*v2[None, :] - (Av*Av % p)[:, None]*A) % p
            N2 = N@N % p
            N5 = (N2@N2 % p)@N % p
            if np.any(N5):
                return False
        return True

    total = collision_count = survivors = 0
    # 2 forced nonzeros plus at most 2 further nonzeros.
    for extra in range(3):
        for pos in itertools.combinations(positions, extra):
            for vals in itertools.product(range(1, p), repeat=extra):
                total += 1
                A = base.copy()
                for ij, a in zip(pos, vals):
                    A[ij] = a
                if not collision(A):
                    continue
                collision_count += 1
                if nilpotent_on_samples(A):
                    survivors += 1
    return total, collision_count, survivors

assert sparse_check(5, 3) == (2521, 1759, 0)
assert sparse_check(7, 2) == (5617, 3397, 0)

print("[ok] N=5 coefficient system: 175 unknowns, 5 collision equations,")
print("     1791 trace-coefficient equations before redundancies")
print("[ok] no-collinear and midpoint collision reductions are recorded in the report")
print("[ok] exact commutator and trace identities for H_C")
print("[ok] exhaustive F5/F7 sparse search: no zero-diagonal H_C candidate of support <=4")
