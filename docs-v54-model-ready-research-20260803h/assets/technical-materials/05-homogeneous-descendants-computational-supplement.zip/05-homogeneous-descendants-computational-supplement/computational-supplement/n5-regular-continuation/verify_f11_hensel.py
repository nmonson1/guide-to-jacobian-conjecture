#!/usr/bin/env python3
"""Pure-Python finite-field and Hensel certificate for the regular line.

No CAS is used.  The script verifies an F_11 point, computes the full
15x16 Jacobian by dual-number automatic differentiation, checks a 15x15
minor equals 3 mod 11, and Hensel-lifts with v_3 fixed to precision 11^12.
"""
from __future__ import annotations
from math import gcd

P = 11
A_PARAM = [8,7,1,7,2,9,0,1]
U0 = [7,6,3,10,4]
V0 = [8,9,7,9,1]


def inv_unit(a: int, m: int) -> int:
    a %= m
    if gcd(a,m) != 1:
        raise ZeroDivisionError((a,m))
    return pow(a,-1,m)


def rank_mod(A, p):
    A = [[x % p for x in row] for row in A]
    m,n = len(A),len(A[0]); r=0
    for c in range(n):
        piv = next((i for i in range(r,m) if A[i][c]),None)
        if piv is None: continue
        A[r],A[piv] = A[piv],A[r]
        z = pow(A[r][c],-1,p)
        A[r] = [x*z % p for x in A[r]]
        for i in range(m):
            if i != r and A[i][c]:
                f=A[i][c]
                A[i] = [(A[i][j]-f*A[r][j])%p for j in range(n)]
        r += 1
    return r


def det_mod(A,p):
    A=[[x%p for x in row] for row in A];n=len(A);d=1
    for c in range(n):
        piv=next((i for i in range(c,n) if A[i][c]),None)
        if piv is None:return 0
        if piv!=c:A[c],A[piv]=A[piv],A[c];d=-d
        q=A[c][c];d=d*q%p;z=pow(q,-1,p)
        for i in range(c+1,n):
            if A[i][c]:
                f=A[i][c]*z%p
                for j in range(c,n):A[i][j]=(A[i][j]-f*A[c][j])%p
    return d%p


def invmat_scalar(M,m):
    n=len(M)
    A=[[x%m for x in M[i]]+[int(i==j) for j in range(n)] for i in range(n)]
    for c in range(n):
        piv=next((i for i in range(c,n) if gcd(A[i][c],m)==1),None)
        if piv is None: raise ZeroDivisionError(("pivot",c,m))
        A[c],A[piv]=A[piv],A[c]
        z=inv_unit(A[c][c],m);A[c]=[x*z%m for x in A[c]]
        for i in range(n):
            if i!=c and A[i][c]%m:
                f=A[i][c]%m
                A[i]=[(A[i][j]-f*A[c][j])%m for j in range(2*n)]
    return [row[n:] for row in A]


def mm(X,Y,m):
    return [[sum(X[i][k]*Y[k][j] for k in range(len(Y)))%m
             for j in range(len(Y[0]))] for i in range(len(X))]


def mv(M,x,m):
    return [sum(M[i][j]*x[j] for j in range(len(x)))%m for i in range(len(M))]


def matrices_scalar(a,m):
    i2=inv_unit(2,m);i3=inv_unit(3,m)
    a0,a1,a2,a3,a4,a5,a6,a7=[x%m for x in a]
    T=[[-a6+a7*i2,3*a2,-3*a1,a0],
       [a5*i3,3*a6-a7*i2,-3*a2,a1],
       [-a4*i3,-a5,-3*a6+a7,a2],
       [a3,a4,a5,a6]]
    T=[[x%m for x in row] for row in T]
    Ti=invmat_scalar(T,m)
    Rs=[[a7,-3*a2,6*a1,-3*a0],
        [0,-3*a6+3*a7*i2,6*a2,-3*a1],
        [0,a5,6*a6-a7,-3*a2],
        [0,-a4,-2*a5,-3*a6+a7],
        [0,3*a3,2*a4,a5]]
    Rt=[[3*a2,-6*a1,3*a0,0],
        [3*a6-a7*i2,-6*a2,3*a1,0],
        [-a5,-6*a6+2*a7,3*a2,0],
        [a4,2*a5,3*a6,0],
        [-3*a3,-2*a4,-a5,a7]]
    Rs=[[x%m for x in row] for row in Rs]
    Rt=[[x%m for x in row] for row in Rt]
    Xs=mm(Rs,Ti,m);Xt=mm(Rt,Ti,m)
    A=[[0]*5 for _ in range(5)]
    B=[[0]*5 for _ in range(5)]
    C=[[0]*5 for _ in range(5)]
    for i in range(5):
        for j in range(1,5):A[i][j]=Xs[i][j-1]
        for j in range(4):
            B[i][j]=(-Xs[i][j]+(Xt[i][j-1] if j else 0))%m
            C[i][j]=-Xt[i][j]%m
        B[i][4]=Xt[i][3]
    return T,A,B,C


def equations_scalar(x,m):
    # x=(a0..a6,u0..u4,v0..v3), with a7=1 and v4=1.
    a=x[:7]+[1];u=x[7:12];v=x[12:16]+[1]
    _,A,B,C=matrices_scalar(a,m);i3=inv_unit(3,m)
    bu,av,bv,cu,au=mv(B,u,m),mv(A,v,m),mv(B,v,m),mv(C,u,m),mv(A,u,m)
    return ([(bu[i]-2*av[i])%m for i in range(5)]
           +[(bv[i]-2*cu[i])%m for i in range(5)]
           +[(u[i]+i3*au[i]+av[i]+cu[i])%m for i in range(5)])


class Dual:
    __slots__=("v","d")
    def __init__(self,v,d=None):self.v=v%P;self.d=([0]*16 if d is None else [x%P for x in d])
    def __add__(self,o):
        o=dual(o);return Dual(self.v+o.v,[(x+y)%P for x,y in zip(self.d,o.d)])
    __radd__=__add__
    def __neg__(self):return Dual(-self.v,[-x%P for x in self.d])
    def __sub__(self,o):return self+(-dual(o))
    def __rsub__(self,o):return dual(o)-self
    def __mul__(self,o):
        o=dual(o);return Dual(self.v*o.v,[(self.v*y+o.v*x)%P for x,y in zip(self.d,o.d)])
    __rmul__=__mul__
    def inv(self):
        z=pow(self.v,-1,P);return Dual(z,[(-q*z*z)%P for q in self.d])
    def __truediv__(self,o):return self*dual(o).inv()
    def __rtruediv__(self,o):return dual(o)*self.inv()


def dual(x):return x if isinstance(x,Dual) else Dual(x)


def invmat_dual(M):
    n=len(M);Z=Dual(0);O=Dual(1)
    A=[[M[i][j] for j in range(n)]+[O if i==j else Z for j in range(n)] for i in range(n)]
    for c in range(n):
        piv=next(i for i in range(c,n) if A[i][c].v)
        A[c],A[piv]=A[piv],A[c]
        z=A[c][c].inv();A[c]=[x*z for x in A[c]]
        for i in range(n):
            if i!=c and A[i][c].v:
                f=A[i][c];A[i]=[A[i][j]-f*A[c][j] for j in range(2*n)]
    return [row[n:] for row in A]


def mm_dual(X,Y):
    return [[sum((X[i][k]*Y[k][j] for k in range(len(Y))),Dual(0))
             for j in range(len(Y[0]))] for i in range(len(X))]


def mv_dual(M,x):
    return [sum((M[i][j]*x[j] for j in range(len(x))),Dual(0)) for i in range(len(M))]


def equations_dual(x):
    a=x[:7]+[Dual(1)];u=x[7:12];v=x[12:16]+[Dual(1)]
    i2=Dual(2).inv();i3=Dual(3).inv();a0,a1,a2,a3,a4,a5,a6,a7=a
    T=[[-a6+a7*i2,3*a2,-3*a1,a0],
       [a5*i3,3*a6-a7*i2,-3*a2,a1],
       [-a4*i3,-a5,-3*a6+a7,a2],[a3,a4,a5,a6]]
    Ti=invmat_dual(T)
    Rs=[[a7,-3*a2,6*a1,-3*a0],[0,-3*a6+3*a7*i2,6*a2,-3*a1],
        [0,a5,6*a6-a7,-3*a2],[0,-a4,-2*a5,-3*a6+a7],[0,3*a3,2*a4,a5]]
    Rt=[[3*a2,-6*a1,3*a0,0],[3*a6-a7*i2,-6*a2,3*a1,0],
        [-a5,-6*a6+2*a7,3*a2,0],[a4,2*a5,3*a6,0],[-3*a3,-2*a4,-a5,a7]]
    Xs=mm_dual(Rs,Ti);Xt=mm_dual(Rt,Ti)
    A=[[Dual(0) for _ in range(5)] for _ in range(5)]
    B=[[Dual(0) for _ in range(5)] for _ in range(5)]
    C=[[Dual(0) for _ in range(5)] for _ in range(5)]
    for i in range(5):
        for j in range(1,5):A[i][j]=Xs[i][j-1]
        for j in range(4):
            B[i][j]=-Xs[i][j]+(Xt[i][j-1] if j else 0);C[i][j]=-Xt[i][j]
        B[i][4]=Xt[i][3]
    bu,av,bv,cu,au=mv_dual(B,u),mv_dual(A,v),mv_dual(B,v),mv_dual(C,u),mv_dual(A,u)
    return ([bu[i]-2*av[i] for i in range(5)]
           +[bv[i]-2*cu[i] for i in range(5)]
           +[u[i]+au[i]/3+av[i]+cu[i] for i in range(5)])


# Base point and finite-field checks.
x0=A_PARAM[:7]+U0+V0[:4]
assert equations_scalar(x0,P)==[0]*15
T0,A0,B0,C0=matrices_scalar(A_PARAM,P)
assert det_mod(T0,P)==1

# Every rational projective point has the regular rank sequence (4,3,2,1,0).
for s,t in [(1,q) for q in range(P)]+[(0,1)]:
    M=[[(s*s*A0[i][j]+s*t*B0[i][j]+t*t*C0[i][j])%P for j in range(5)] for i in range(5)]
    power=M;seq=[]
    for _ in range(5):
        seq.append(rank_mod(power,P));power=mm(power,M,P)
    assert seq==[4,3,2,1,0]

# Automatic-differentiation Jacobian.
xd=[]
for j,val in enumerate(x0):
    d=[0]*16;d[j]=1;xd.append(Dual(val,d))
out=equations_dual(xd)
assert [q.v for q in out]==[0]*15
J=[q.d for q in out]
assert rank_mod(J,P)==15
minor=[row[:15] for row in J]
assert det_mod(minor,P)==3

# Hensel lift with v3=x[15]=9 fixed.  The first 15 variables are corrected.
Jinv=invmat_scalar(minor,P)
x=x0[:]
for k in range(1,12):
    old=P**k;mod=P**(k+1)
    vals=equations_scalar(x,mod)
    rhs=[-(v//old)%P for v in vals]
    delta=mv(Jinv,rhs,P)
    for j in range(15):x[j]+=old*delta[j]
    assert x[15]==9
    assert equations_scalar(x,mod)==[0]*15

MOD=P**12
EXPECTED=[975032660269,1166914071088,1132097078025,2645513248781,
          2490147814068,585560787788,315228184700,2678133359557,
          2707586605158,2070991223172,3004643365063,63846186628,
          2053897594130,43686183803,2589807566265,9]
assert MOD==3138428376721
assert x==EXPECTED

print("[ok] F_11 parameter point satisfies integrability and collision")
print("[ok] det(T)=1 mod 11")
print("[ok] rank sequences are (4,3,2,1,0) at all P^1(F_11) points")
print("[ok] 15x16 Jacobian has rank 15; first minor determinant = 3 mod 11")
print("[ok] Hensel lift verified through modulus",MOD)
print("[ok] lifted residue vector:",x)
