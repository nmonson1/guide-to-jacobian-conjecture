#include <bits/stdc++.h>
#ifdef _OPENMP
#include <omp.h>
#endif
using namespace std;
struct FF{
 int p; vector<int> iv;
 FF(int q):p(q),iv(q){for(int a=1;a<p;a++)for(int b=1;b<p;b++)if(a*b%p==1)iv[a]=b;}
 inline int md(long long x)const{x%=p;if(x<0)x+=p;return (int)x;}
};
int rref(vector<vector<int>>& A,const FF& f, vector<int>* pivout=nullptr){
 int m=A.size(),n=A.empty()?0:A[0].size(),r=0;vector<int> piv;
 for(int c=0;c<n&&r<m;c++){
  int q=-1;for(int i=r;i<m;i++)if(A[i][c]){q=i;break;}if(q<0)continue;
  swap(A[r],A[q]);int z=f.iv[A[r][c]];for(int j=0;j<n;j++)A[r][j]=A[r][j]*z%f.p;
  for(int i=0;i<m;i++)if(i!=r&&A[i][c]){int g=A[i][c];for(int j=0;j<n;j++)A[i][j]=f.md(A[i][j]-1LL*g*A[r][j]);}
  piv.push_back(c);r++;
 }
 if(pivout)*pivout=piv;return r;
}
bool invmat4(int T[4][4],int Ti[4][4],const FF&f){
 vector<vector<int>> A(4,vector<int>(8));for(int i=0;i<4;i++)for(int j=0;j<4;j++){A[i][j]=T[i][j];A[i][4+j]=(i==j);}
 vector<int>piv;int r=rref(A,f,&piv);if(r<4||piv[0]!=0||piv[1]!=1||piv[2]!=2||piv[3]!=3)return false;
 for(int i=0;i<4;i++)for(int j=0;j<4;j++)Ti[i][j]=A[i][4+j];return true;
}
bool invmat5(int S[5][5],int Si[5][5],const FF&f){
 vector<vector<int>> A(5,vector<int>(10));for(int i=0;i<5;i++)for(int j=0;j<5;j++){A[i][j]=S[i][j];A[i][5+j]=(i==j);}
 vector<int>piv;int r=rref(A,f,&piv);if(r<5)return false;for(int i=0;i<5;i++)for(int j=0;j<5;j++)Si[i][j]=A[i][5+j];return true;
}
void mm5(int A[5][5],int B[5][5],int C[5][5],const FF&f){for(int i=0;i<5;i++)for(int j=0;j<5;j++){long long s=0;for(int k=0;k<5;k++)s+=1LL*A[i][k]*B[k][j];C[i][j]=s%f.p;}}
void mats(const array<int,8>&a,int A[5][5],int B[5][5],int C[5][5],bool&ok,const FF&f){
 int i2=f.iv[2],i3=f.iv[3];int a0=a[0],a1=a[1],a2=a[2],a3=a[3],a4=a[4],a5=a[5],a6=a[6],a7=a[7];
 int T[4][4]={{f.md(-a6+1LL*a7*i2),f.md(3*a2),f.md(-3*a1),a0},{f.md(1LL*a5*i3),f.md(3*a6-1LL*a7*i2),f.md(-3*a2),a1},{f.md(-1LL*a4*i3),f.md(-a5),f.md(-3*a6+a7),a2},{a3,a4,a5,a6}},Ti[4][4];
 if(!invmat4(T,Ti,f)){ok=false;return;}ok=true;
 int Rs[5][4]={{a7,f.md(-3*a2),f.md(6*a1),f.md(-3*a0)},{0,f.md(-3*a6+3LL*a7*i2),f.md(6*a2),f.md(-3*a1)},{0,a5,f.md(6*a6-a7),f.md(-3*a2)},{0,f.md(-a4),f.md(-2*a5),f.md(-3*a6+a7)},{0,f.md(3*a3),f.md(2*a4),a5}};
 int Rt[5][4]={{f.md(3*a2),f.md(-6*a1),f.md(3*a0),0},{f.md(3*a6-a7*i2),f.md(-6*a2),f.md(3*a1),0},{f.md(-a5),f.md(-6*a6+2*a7),f.md(3*a2),0},{a4,f.md(2*a5),f.md(3*a6),0},{f.md(-3*a3),f.md(-2*a4),f.md(-a5),a7}};
 int Xs[5][4],Xt[5][4];for(int i=0;i<5;i++)for(int j=0;j<4;j++){long long s=0,t=0;for(int k=0;k<4;k++){s+=1LL*Rs[i][k]*Ti[k][j];t+=1LL*Rt[i][k]*Ti[k][j];}Xs[i][j]=s%f.p;Xt[i][j]=t%f.p;}
 memset(A,0,25*sizeof(int));memset(B,0,25*sizeof(int));memset(C,0,25*sizeof(int));
 for(int i=0;i<5;i++){for(int j=1;j<5;j++)A[i][j]=Xs[i][j-1];for(int j=0;j<4;j++){B[i][j]=f.md(-Xs[i][j]+(j?Xt[i][j-1]:0));C[i][j]=f.md(-Xt[i][j]);}B[i][4]=Xt[i][3];}
}
vector<array<int,10>> line_null(int A[5][5],int B[5][5],int C[5][5],const FF&f){
 vector<vector<int>> L(15,vector<int>(10));int i3=f.iv[3];
 for(int i=0;i<5;i++)for(int j=0;j<5;j++){
  L[i][j]=B[i][j];L[i][5+j]=f.md(-2*A[i][j]);
  L[5+i][j]=f.md(-2*C[i][j]);L[5+i][5+j]=B[i][j];
  L[10+i][j]=f.md((i==j)+1LL*i3*A[i][j]+C[i][j]);L[10+i][5+j]=A[i][j];
 }
 vector<int>piv;int r=rref(L,f,&piv);vector<int>free;for(int j=0;j<10;j++)if(find(piv.begin(),piv.end(),j)==piv.end())free.push_back(j);
 vector<array<int,10>> bas;for(int fr:free){array<int,10>x{};x[fr]=1;for(int ii=r-1;ii>=0;ii--){int c=piv[ii],s=0;for(int j:free)s=f.md(s+1LL*L[ii][j]*x[j]);x[c]=f.md(-s);}bas.push_back(x);}return bas;
}
int rank2(const array<int,10>&x,const FF&f){bool u=false,v=false;for(int i=0;i<5;i++){u|=x[i]!=0;v|=x[5+i]!=0;}if(!u||!v)return 1;int ratio=-1;for(int i=0;i<5;i++)if(x[i]){ratio=x[5+i]*f.iv[x[i]]%f.p;break;}for(int i=0;i<5;i++)if(x[5+i]!=ratio*x[i]%f.p)return 2;return 1;}
bool find_good(const vector<array<int,10>>&bas,array<int,10>&out,const FF&f){
 // A 2x5 matrix has rank two iff one of its 2x2 minors is nonzero.
 // Every such minor is quadratic in the coordinates on the kernel space.
 // For p>2, if a quadratic is nonzero then it is detected on a coordinate
 // line or coordinate two-plane.  Hence basis vectors and two-term
 // combinations suffice, with no nullity cutoff.
 for(const auto&x:bas)if(rank2(x,f)==2){out=x;return true;}
 for(int i=0;i<(int)bas.size();i++)for(int j=i+1;j<(int)bas.size();j++)for(int c=1;c<f.p;c++){
  array<int,10>x{};for(int q=0;q<10;q++)x[q]=f.md(bas[i][q]+1LL*c*bas[j][q]);
  if(rank2(x,f)==2){out=x;return true;}
 }
 return false;
}
int rank5mat(int M[5][5],const FF&f){vector<vector<int>>X(5,vector<int>(5));for(int i=0;i<5;i++)for(int j=0;j<5;j++)X[i][j]=M[i][j];return rref(X,f);}
bool regular(int A[5][5],int B[5][5],int C[5][5],const FF&f){for(int q=0;q<=f.p;q++){int s=q==f.p?0:1,t=q==f.p?1:q,M[5][5];for(int i=0;i<5;i++)for(int j=0;j<5;j++)M[i][j]=f.md(1LL*s*s*A[i][j]+1LL*s*t*B[i][j]+1LL*t*t*C[i][j]);if(rank5mat(M,f)!=4)return false;}return true;}
bool chooseS(const array<int,10>&x,int S[5][5],const FF&f){vector<array<int,5>>cols;array<int,5>u{},v{};for(int i=0;i<5;i++){u[i]=x[i];v[i]=x[5+i];}cols.push_back(u);cols.push_back(v);for(int e=0;e<5&&cols.size()<5;e++){array<int,5>w{};w[e]=1;auto tmp=cols;tmp.push_back(w);vector<vector<int>>M(5,vector<int>(tmp.size()));for(int i=0;i<5;i++)for(int j=0;j<(int)tmp.size();j++)M[i][j]=tmp[j][i];if(rref(M,f)==(int)tmp.size())cols.push_back(w);}if(cols.size()<5)return false;for(int i=0;i<5;i++)for(int j=0;j<5;j++)S[i][j]=cols[j][i];return true;}
void transform(int A[5][5],int B[5][5],int C[5][5],int S[5][5],int Ao[5][5],int Bo[5][5],int Co[5][5],const FF&f){int Si[5][5],tmp[5][5];invmat5(S,Si,f);mm5(Si,A,tmp,f);mm5(tmp,S,Ao,f);mm5(Si,B,tmp,f);mm5(tmp,S,Bo,f);mm5(Si,C,tmp,f);mm5(tmp,S,Co,f);}
pair<int,int> firstfull(int A[5][5],int B[5][5],int C[5][5],const FF&f){
 const int NV=60;int vid[5][2][3][3],cnt=0;memset(vid,-1,sizeof(vid));for(int i=0;i<5;i++)for(int pp=0;pp<2;pp++)for(int r=0;r<3;r++)for(int q=r;q<3;q++)vid[i][pp][r][q]=vid[i][pp][q][r]=cnt++;
 using Mat=array<array<int,5>,5>;auto zeroMat=[](){Mat M{};return M;};auto mul=[&](const Mat&X,const Mat&Y){Mat Z{};for(int i=0;i<5;i++)for(int j=0;j<5;j++){long long z=0;for(int k=0;k<5;k++)z+=1LL*X[i][k]*Y[k][j];Z[i][j]=z%f.p;}return Z;};
 Mat Am{},Bm{},Cm{},I{};for(int i=0;i<5;i++){I[i][i]=1;for(int j=0;j<5;j++){Am[i][j]=A[i][j];Bm[i][j]=B[i][j];Cm[i][j]=C[i][j];}}
 vector<Mat>Mpoly={Am,Bm,Cm};vector<vector<Mat>> pows(5);pows[0]={I};for(int kk=1;kk<5;kk++){pows[kk].assign(pows[kk-1].size()+2,zeroMat());for(int aa=0;aa<(int)pows[kk-1].size();aa++)for(int bb=0;bb<3;bb++){Mat Z=mul(pows[kk-1][aa],Mpoly[bb]);for(int i=0;i<5;i++)for(int j=0;j<5;j++)pows[kk][aa+bb][i][j]=f.md(pows[kk][aa+bb][i][j]+Z[i][j]);}}
 vector<vector<int>> rows;rows.reserve(90);
 for(int r=0;r<3;r++){int gr=2+r;for(int k=1;k<=5;k++){int deg=2*(k-1)+1;for(int jj=0;jj<=deg;jj++){vector<int> row(NV+1);long long constant=0;for(int bb=0;bb<2;bb++){int aa=jj-bb;if(aa<0||aa>=(int)pows[k-1].size())continue;const Mat&X=pows[k-1][aa];for(int i=0;i<5;i++)for(int c=0;c<5;c++){int coeff=X[i][c];if(!coeff)continue;if(i==0){int val=(bb==0?2*A[c][gr]:B[c][gr]);constant+=1LL*coeff*val;}else if(i==1){int val=(bb==0?B[c][gr]:2*C[c][gr]);constant+=1LL*coeff*val;}else{int q=i-2;int id=vid[c][bb][r][q];row[id]=f.md(row[id]+1LL*coeff);}}}row[NV]=f.md(-constant);rows.push_back(row);}}}
 vector<vector<int>> coeff=rows;for(auto&z:coeff)z.pop_back();int rc=rref(coeff,f),ra=rref(rows,f);return {rc,ra};
}
int main(int argc,char**argv){
 int p=argc>1?atoi(argv[1]):7;if(p<=5){cerr<<"Use a prime p>5.\n";return 2;}FF f(p);long long tot=0,invT=0,line=0,reg=0,pass=0;
 for(int pivot=7;pivot>=0;pivot--){long long num=1;for(int i=0;i<pivot;i++)num*=p;
  #pragma omp parallel for schedule(dynamic,1000) reduction(+:tot,invT,line,reg,pass)
  for(long long idx=0;idx<num;idx++){array<int,8>a{};long long z=idx;for(int i=0;i<pivot;i++){a[i]=z%p;z/=p;}a[pivot]=1;tot++;int A[5][5],B[5][5],C[5][5];bool ok;mats(a,A,B,C,ok,f);if(!ok)continue;invT++;auto bas=line_null(A,B,C,f);if(bas.empty())continue;array<int,10>x;if(!find_good(bas,x,f))continue;line++;if(!regular(A,B,C,f))continue;reg++;int S[5][5],At[5][5],Bt[5][5],Ct[5][5];chooseS(x,S,f);transform(A,B,C,S,At,Bt,Ct,f);auto rr=firstfull(At,Bt,Ct,f);if(rr.first==rr.second)pass++;}
 }
 cout<<"p "<<p<<" total "<<tot<<" invT "<<invT<<" line "<<line<<" regular "<<reg<<" firstpass "<<pass<<"\n";
}
