#!/usr/bin/env python3
"""Exact F_11 first-normal obstruction for the smooth regular collision line.

The first four characteristic identities form a 60x60 system with determinant 3.
Adding the fifth identity gives an augmented 61x61 minor with determinant 1.
All arithmetic is exact in F_11 and uses only the Python standard library.
"""
from itertools import combinations_with_replacement
P=11
A=[[6,4,0,10,2],[6,1,0,9,10],[8,0,0,6,2],[3,8,0,5,2],[3,6,0,1,10]]
B=[[8,8,1,4,7],[2,5,2,6,9],[0,2,5,4,4],[5,4,6,9,7],[1,8,10,3,6]]
C=[[4,0,5,1,3],[8,1,6,6,6],[1,8,5,6,10],[2,6,0,0,2],[4,7,9,1,1]]

def inv(a): return pow(a%P,-1,P)
def mm(X,Y): return [[sum(X[i][k]*Y[k][j] for k in range(5))%P for j in range(5)] for i in range(5)]
def rank(A):
    A=[[x%P for x in row] for row in A];m=len(A);n=len(A[0]) if m else 0;r=0;piv=[]
    for c in range(n):
        q=next((i for i in range(r,m) if A[i][c]),None)
        if q is None: continue
        A[r],A[q]=A[q],A[r];z=inv(A[r][c]);A[r]=[x*z%P for x in A[r]]
        for i in range(m):
            if i!=r and A[i][c]:
                f=A[i][c];A[i]=[(A[i][j]-f*A[r][j])%P for j in range(n)]
        piv.append(c);r+=1
    return r,piv,A
def det(A):
    A=[[x%P for x in row] for row in A];n=len(A);d=1
    for c in range(n):
        q=next((i for i in range(c,n) if A[i][c]),None)
        if q is None:return 0
        if q!=c:A[c],A[q]=A[q],A[c];d=-d
        z=A[c][c];d=d*z%P;zi=inv(z)
        for i in range(c+1,n):
            if A[i][c]:
                f=A[i][c]*zi%P
                for j in range(c,n):A[i][j]=(A[i][j]-f*A[c][j])%P
    return d%P
pairs=list(combinations_with_replacement(range(3),2));vid={}
for i in range(5):
    for pp in range(2):
        for pair in pairs:vid[(i,pp,pair)]=len(vid)
NV=60
def za():return[0]*(NV+1)
def add(x,y):return[(a+b)%P for a,b in zip(x,y)]
def sc(c,x):return[c*a%P for a in x]
PQs=[]
for r in range(3):
    Pm=[[za() for _ in range(5)] for __ in range(5)];Qm=[[za() for _ in range(5)] for __ in range(5)];gr=2+r
    for i in range(5):
        Pm[i][0][0]=2*A[i][gr]%P;Pm[i][1][0]=B[i][gr]%P
        Qm[i][0][0]=B[i][gr]%P;Qm[i][1][0]=2*C[i][gr]%P
        for q in range(3):
            pair=tuple(sorted((r,q)));gq=2+q
            Pm[i][gq][1+vid[(i,0,pair)]]=1;Qm[i][gq][1+vid[(i,1,pair)]]=1
    PQs.append((Pm,Qm))
def pmul(Xs,Ys):
    out=[[[0]*5 for _ in range(5)] for __ in range(len(Xs)+len(Ys)-1)]
    for aa,X in enumerate(Xs):
        for bb,Y in enumerate(Ys):
            Z=mm(X,Y)
            for i in range(5):
                for j in range(5):out[aa+bb][i][j]=(out[aa+bb][i][j]+Z[i][j])%P
    return out
I=[[int(i==j) for j in range(5)] for i in range(5)];powers=[[I]]
for _ in range(4):powers.append(pmul(powers[-1],[A,B,C]))
def tr_aff(X,Y):
    out=za()
    for i in range(5):
        for j in range(5):
            if X[i][j]:out=add(out,sc(X[i][j],Y[j][i]))
    return out
rows=[];labels=[]
for r,(Pm,Qm) in enumerate(PQs):
    for k in range(1,6):
        coeff=[za() for _ in range(2*(k-1)+2)]
        for aa,X in enumerate(powers[k-1]):
            for bb,Y in enumerate([Pm,Qm]):coeff[aa+bb]=add(coeff[aa+bb],tr_aff(X,Y))
        for j,a in enumerate(coeff):rows.append(a[1:]+[(-a[0])%P]);labels.append((r,k,j))
idx4=[i for i,l in enumerate(labels) if l[1]<=4]
M4=[rows[i][:-1] for i in idx4]
assert len(M4)==60 and det(M4)==3
sel=[];rr=0
for i,row in enumerate(rows):
    rnew=rank([rows[j] for j in sel+[i]])[0]
    if rnew>rr:sel.append(i);rr=rnew
    if rr==61:break
assert len(sel)==61 and det([rows[i] for i in sel])==1
aug=[M4[i]+[rows[idx4[i]][-1]] for i in range(60)]
_,piv,R=rank(aug);assert piv[:60]==list(range(60));sol=[R[i][-1] for i in range(60)]
res=[]
for i,l in enumerate(labels):
    if l[1]==5:res.append((sum(rows[i][j]*sol[j] for j in range(60))-rows[i][-1])%P)
R5=[res[:10],res[10:20],res[20:]]
assert rank(R5)[0]==3
assert det([[R5[i][j] for j in (0,1,2)] for i in range(3)])==2
print('[ok] first-four 60x60 determinant = 3 mod 11')
print('[ok] augmented 61x61 determinant = 1 mod 11')
print('[ok] fifth-identity residual has rank 3; minor determinant = 2 mod 11')
print('[ok] residual coefficient rows:',R5)
