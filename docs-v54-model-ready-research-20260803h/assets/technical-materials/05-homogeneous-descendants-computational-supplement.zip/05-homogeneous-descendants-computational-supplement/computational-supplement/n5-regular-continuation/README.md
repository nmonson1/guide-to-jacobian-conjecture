# N=5 regular-Jordan continuation

This directory verifies the first-normal obstruction described in
`CONTINUATION_REPORT.md`.

## Fast checks

```bash
python3 verify_f11_hensel.py
python3 verify_first_normal_transformed.py
python3 verify_first_normal_coordinatefree.py
python3 check_f7_candidates_exact.py
python3 check_f11_candidates_exact.py
python3 check_candidate_geometry.py
```

The last script uses SymPy.  The two core obstruction scripts use only the
Python standard library.

## Exhaustive chart enumeration

```bash
make
./enumerate_full_kernel 7
./enumerate_full_kernel 11
```

The fifth characteristic identity requires a prime greater than five.  The
enumerator deliberately rejects `p <= 5`.
