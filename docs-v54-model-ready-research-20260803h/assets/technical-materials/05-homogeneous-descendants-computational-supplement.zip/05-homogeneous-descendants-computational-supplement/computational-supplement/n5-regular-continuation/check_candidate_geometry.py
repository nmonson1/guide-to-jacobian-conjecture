#!/usr/bin/env python3
"""Check geometric regularity of all listed F_7 and F_11 chart candidates."""
import sympy as sp
from itertools import combinations
from ff_helpers import mats,rank
SETS={
7:[([1,4,6,5,3,1,1,1],[4,5,6,6,0,4,3,2,1,1]),([3,3,0,2,5,1,1,1],[3,4,0,6,5,4,1,0,1,1]),([4,2,6,0,1,0,2,1],[5,4,5,6,2,2,1,6,2,1]),([3,3,3,5,3,3,2,1],[4,5,1,5,3,3,1,3,2,1]),([2,0,4,6,3,5,2,1],[1,2,1,4,1,1,0,4,6,1]),([1,6,3,1,4,5,3,1],[5,4,1,6,3,3,3,5,2,1])],
11:[([1,9,2,5,5,1,1,1],[3,4,6,1,5,3,8,9,2,1]),([9,10,2,2,8,5,1,1],[3,1,10,10,0,6,8,10,1,1]),([5,8,10,1,3,2,2,1],[3,9,9,7,2,0,3,1,8,1]),([6,3,4,7,8,9,2,1],[2,4,3,9,10,0,8,7,2,1]),([3,9,1,8,5,10,2,1],[9,3,0,6,7,2,0,10,4,1]),([1,0,8,9,9,2,3,1],[4,0,3,4,0,0,7,9,5,1]),([3,10,0,10,3,5,3,1],[8,3,4,8,3,1,8,9,5,1]),([7,2,10,9,8,8,6,1],[3,1,10,4,10,0,0,9,6,1]),([9,10,10,9,10,3,8,1],[5,9,3,9,8,3,1,8,7,1]),([10,2,10,10,3,10,10,1],[4,5,5,5,2,6,4,8,0,1]),([8,7,1,7,2,9,0,1],[7,6,3,10,4,8,9,7,9,1])]
}
t=sp.symbols('t')
for p,cands in SETS.items():
    for a,z in cands:
        A,B,C=mats(a,p)
        M=sp.Matrix([[A[i][j]+B[i][j]*t+C[i][j]*t*t for j in range(5)] for i in range(5)])
        gs=[]
        for rs in combinations(range(5),4):
            for cs in combinations(range(5),4):
                q=sp.Poly(M.extract(rs,cs).det(),t,modulus=p)
                if not q.is_zero:gs.append(q)
        g=gs[0]
        for q in gs[1:]:g=sp.gcd(g,q)
        i3=pow(3,-1,p);L=[]
        for i in range(5):L.append(B[i]+[(-2*x)%p for x in A[i]])
        for i in range(5):L.append([(-2*x)%p for x in C[i]]+B[i])
        for i in range(5):L.append([((int(i==j)+i3*A[i][j]+C[i][j])%p) for j in range(5)]+A[i])
        assert g.degree()==0 and rank(C,p)[0]==4 and rank(L,p)[0]==9
    print(f'[ok] all {len(cands)} F_{p} candidates are regular over algebraic closure')
