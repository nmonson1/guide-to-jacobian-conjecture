"""Small exact finite-field helpers for the regular-line chart."""
from itertools import combinations_with_replacement

def inv(a,p):return pow(a%p,-1,p)
def rank(A,p):
    A=[[x%p for x in row] for row in A];m=len(A);n=len(A[0]) if m else 0;r=0;pivs=[]
    for c in range(n):
        q=next((i for i in range(r,m) if A[i][c]),None)
        if q is None:continue
        A[r],A[q]=A[q],A[r];z=inv(A[r][c],p);A[r]=[x*z%p for x in A[r]]
        for i in range(m):
            if i!=r and A[i][c]:
                f=A[i][c];A[i]=[(A[i][j]-f*A[r][j])%p for j in range(n)]
        pivs.append(c);r+=1
    return r,pivs,A
def mm(A,B,p):return [[sum(A[i][k]*B[k][j] for k in range(len(B)))%p for j in range(len(B[0]))] for i in range(len(A))]
def invmat(A,p):
    n=len(A);M=[[x%p for x in A[i]]+[int(i==j) for j in range(n)] for i in range(n)]
    r,pivs,R=rank(M,p)
    if pivs[:n]!=list(range(n)):raise ZeroDivisionError
    return [row[n:] for row in R]
def mats(a,p):
    i2=inv(2,p);i3=inv(3,p);a0,a1,a2,a3,a4,a5,a6,a7=a
    T=[[-a6+a7*i2,3*a2,-3*a1,a0],[a5*i3,3*a6-a7*i2,-3*a2,a1],[-a4*i3,-a5,-3*a6+a7,a2],[a3,a4,a5,a6]]
    T=[[x%p for x in row] for row in T];Ti=invmat(T,p)
    Rs=[[a7,-3*a2,6*a1,-3*a0],[0,-3*a6+3*a7*i2,6*a2,-3*a1],[0,a5,6*a6-a7,-3*a2],[0,-a4,-2*a5,-3*a6+a7],[0,3*a3,2*a4,a5]]
    Rt=[[3*a2,-6*a1,3*a0,0],[3*a6-a7*i2,-6*a2,3*a1,0],[-a5,-6*a6+2*a7,3*a2,0],[a4,2*a5,3*a6,0],[-3*a3,-2*a4,-a5,a7]]
    Rs=[[x%p for x in row] for row in Rs];Rt=[[x%p for x in row] for row in Rt]
    Xs=mm(Rs,Ti,p);Xt=mm(Rt,Ti,p);A=[[0]*5 for _ in range(5)];B=[[0]*5 for _ in range(5)];C=[[0]*5 for _ in range(5)]
    for i in range(5):
        for j in range(1,5):A[i][j]=Xs[i][j-1]
        for j in range(4):B[i][j]=(-Xs[i][j]+(Xt[i][j-1] if j else 0))%p;C[i][j]=-Xt[i][j]%p
        B[i][4]=Xt[i][3]
    return A,B,C
def chooseS(u,v,p):
    cols=[u,v]
    for eidx in range(5):
        e=[0]*5;e[eidx]=1;T=[list(row) for row in zip(*(cols+[e]))]
        if rank(T,p)[0]==len(cols)+1:cols.append(e)
        if len(cols)==5:break
    return [list(row) for row in zip(*cols)]
def transform(A,B,C,S,p):
    Si=invmat(S,p);return mm(mm(Si,A,p),S,p),mm(mm(Si,B,p),S,p),mm(mm(Si,C,p),S,p)
def firstfull(A,B,C,p):
    if p<=5:raise ValueError('requires characteristic > 5')
    pairs=list(combinations_with_replacement(range(3),2));vid={}
    for i in range(5):
        for pp in range(2):
            for pair in pairs:vid[(i,pp,pair)]=len(vid)
    nv=60
    def za():return[0]*(nv+1)
    def add(x,y):return[(a+b)%p for a,b in zip(x,y)]
    def sc(c,x):return[c*a%p for a in x]
    PQ=[]
    for r in range(3):
        Pm=[[za() for _ in range(5)] for __ in range(5)];Qm=[[za() for _ in range(5)] for __ in range(5)];gr=2+r
        for i in range(5):
            Pm[i][0][0]=2*A[i][gr]%p;Pm[i][1][0]=B[i][gr]%p;Qm[i][0][0]=B[i][gr]%p;Qm[i][1][0]=2*C[i][gr]%p
            for q in range(3):
                pair=tuple(sorted((r,q)));gq=2+q;Pm[i][gq][1+vid[(i,0,pair)]]=1;Qm[i][gq][1+vid[(i,1,pair)]]=1
        PQ.append((Pm,Qm))
    I=[[int(i==j) for j in range(5)] for i in range(5)]
    def pmul(Xs,Ys):
        out=[[[0]*5 for _ in range(5)] for __ in range(len(Xs)+len(Ys)-1)]
        for aa,X in enumerate(Xs):
            for bb,Y in enumerate(Ys):
                Z=mm(X,Y,p)
                for i in range(5):
                    for j in range(5):out[aa+bb][i][j]=(out[aa+bb][i][j]+Z[i][j])%p
        return out
    pows=[[I]]
    for _ in range(4):pows.append(pmul(pows[-1],[A,B,C]))
    def tr(X,Y):
        o=za()
        for i in range(5):
            for j in range(5):
                if X[i][j]:o=add(o,sc(X[i][j],Y[j][i]))
        return o
    rows=[]
    for r,(Pm,Qm) in enumerate(PQ):
        for k in range(1,6):
            co=[za() for _ in range(2*(k-1)+2)]
            for aa,X in enumerate(pows[k-1]):
                for bb,Y in enumerate([Pm,Qm]):co[aa+bb]=add(co[aa+bb],tr(X,Y))
            rows += [a[1:]+[(-a[0])%p] for a in co]
    rc=rank([z[:-1] for z in rows],p)[0];ra=rank(rows,p)[0]
    return rc,ra
