#!/usr/bin/env python3
from ff_helpers import mats,chooseS,transform,firstfull
p=7
cands=[
([1,4,6,5,3,1,1,1],[4,5,6,6,0,4,3,2,1,1]),
([3,3,0,2,5,1,1,1],[3,4,0,6,5,4,1,0,1,1]),
([4,2,6,0,1,0,2,1],[5,4,5,6,2,2,1,6,2,1]),
([3,3,3,5,3,3,2,1],[4,5,1,5,3,3,1,3,2,1]),
([2,0,4,6,3,5,2,1],[1,2,1,4,1,1,0,4,6,1]),
([1,6,3,1,4,5,3,1],[5,4,1,6,3,3,3,5,2,1])]
for a,z in cands:
    A,B,C=mats(a,p);S=chooseS(z[:5],z[5:],p);At,Bt,Ct=transform(A,B,C,S,p);r=firstfull(At,Bt,Ct,p)
    assert r==(60,61);print(a,r)
print('[ok] all 6 F_7 candidates fail the exact first-normal system')
