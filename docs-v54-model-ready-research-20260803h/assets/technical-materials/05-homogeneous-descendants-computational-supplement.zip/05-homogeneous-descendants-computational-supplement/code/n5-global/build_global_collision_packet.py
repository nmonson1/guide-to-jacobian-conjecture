#!/usr/bin/env python3
"""Build an exact, reusable packet for the full-kernel N=5 collision chart.

The packet has two deliberately separate parts:

* the characteristic-zero polynomial collision system on a concrete affine
  chart, with denominators removed and a Macaulay2 replay file; and
* exact samples of the first-normal obstruction covariant over F_7 and F_11.

It does not compute the saturated global collision curve or prove that the
first-normal covariant is nowhere zero.  The output directory must be new.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from itertools import combinations, combinations_with_replacement
from pathlib import Path
from typing import Any

import sympy as sp


HERE = Path(__file__).resolve().parent
CONTINUATION = HERE.parents[1] / "computational-supplement/n5-regular-continuation"
sys.path.insert(0, str(CONTINUATION))

from ff_helpers import mats, mm, rank, transform  # noqa: E402


SAMPLES = {
    7: [
        ([1, 4, 6, 5, 3, 1, 1, 1], [4, 5, 6, 6, 0, 4, 3, 2, 1, 1]),
        ([3, 3, 0, 2, 5, 1, 1, 1], [3, 4, 0, 6, 5, 4, 1, 0, 1, 1]),
        ([4, 2, 6, 0, 1, 0, 2, 1], [5, 4, 5, 6, 2, 2, 1, 6, 2, 1]),
        ([3, 3, 3, 5, 3, 3, 2, 1], [4, 5, 1, 5, 3, 3, 1, 3, 2, 1]),
        ([2, 0, 4, 6, 3, 5, 2, 1], [1, 2, 1, 4, 1, 1, 0, 4, 6, 1]),
        ([1, 6, 3, 1, 4, 5, 3, 1], [5, 4, 1, 6, 3, 3, 3, 5, 2, 1]),
    ],
    11: [
        ([1, 9, 2, 5, 5, 1, 1, 1], [3, 4, 6, 1, 5, 3, 8, 9, 2, 1]),
        ([9, 10, 2, 2, 8, 5, 1, 1], [3, 1, 10, 10, 0, 6, 8, 10, 1, 1]),
        ([5, 8, 10, 1, 3, 2, 2, 1], [3, 9, 9, 7, 2, 0, 3, 1, 8, 1]),
        ([6, 3, 4, 7, 8, 9, 2, 1], [2, 4, 3, 9, 10, 0, 8, 7, 2, 1]),
        ([3, 9, 1, 8, 5, 10, 2, 1], [9, 3, 0, 6, 7, 2, 0, 10, 4, 1]),
        ([1, 0, 8, 9, 9, 2, 3, 1], [4, 0, 3, 4, 0, 0, 7, 9, 5, 1]),
        ([3, 10, 0, 10, 3, 5, 3, 1], [8, 3, 4, 8, 3, 1, 8, 9, 5, 1]),
        ([7, 2, 10, 9, 8, 8, 6, 1], [3, 1, 10, 4, 10, 0, 0, 9, 6, 1]),
        ([9, 10, 10, 9, 10, 3, 8, 1], [5, 9, 3, 9, 8, 3, 1, 8, 7, 1]),
        ([10, 2, 10, 10, 3, 10, 10, 1], [4, 5, 5, 5, 2, 6, 4, 8, 0, 1]),
        ([8, 7, 1, 7, 2, 9, 0, 1], [7, 6, 3, 10, 4, 8, 9, 7, 9, 1]),
    ],
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path: Path, text: str) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite {path}")
    path.write_text(text, encoding="utf-8")


def primitive_integer_polynomial(
    expression: sp.Expr, variables: tuple[sp.Symbol, ...]
) -> sp.Poly:
    polynomial = sp.Poly(sp.expand(expression), *variables, domain=sp.QQ)
    _, integral = polynomial.clear_denoms(convert=True)
    _, primitive = integral.primitive()
    if primitive.LC() < 0:
        primitive = -primitive
    return primitive


def det_mod(matrix: list[list[int]], prime: int) -> int:
    values = [[entry % prime for entry in row] for row in matrix]
    size = len(values)
    result = 1
    for column in range(size):
        pivot = next(
            (row for row in range(column, size) if values[row][column]), None
        )
        if pivot is None:
            return 0
        if pivot != column:
            values[column], values[pivot] = values[pivot], values[column]
            result = -result
        diagonal = values[column][column]
        result = result * diagonal % prime
        inverse = pow(diagonal, -1, prime)
        for row in range(column + 1, size):
            factor = values[row][column] * inverse % prime
            if factor:
                values[row] = [
                    (values[row][index] - factor * values[column][index]) % prime
                    for index in range(size)
                ]
    return result % prime


def symbolic_collision_system() -> dict[str, Any]:
    a = sp.symbols("a0:7") + (sp.Integer(1),)
    a0, a1, a2, a3, a4, a5, a6, a7 = a
    u = sp.Matrix(sp.symbols("u0:5"))
    v = sp.Matrix(sp.symbols("v0:4") + (sp.Integer(1),))
    variables = tuple(a[:7]) + tuple(u) + tuple(v[:4])

    half = sp.Rational(1, 2)
    third = sp.Rational(1, 3)
    chart_matrix = sp.Matrix(
        [
            [-a6 + a7 * half, 3 * a2, -3 * a1, a0],
            [a5 * third, 3 * a6 - a7 * half, -3 * a2, a1],
            [-a4 * third, -a5, -3 * a6 + a7, a2],
            [a3, a4, a5, a6],
        ]
    )
    rs = sp.Matrix(
        [
            [a7, -3 * a2, 6 * a1, -3 * a0],
            [0, -3 * a6 + 3 * a7 * half, 6 * a2, -3 * a1],
            [0, a5, 6 * a6 - a7, -3 * a2],
            [0, -a4, -2 * a5, -3 * a6 + a7],
            [0, 3 * a3, 2 * a4, a5],
        ]
    )
    rt = sp.Matrix(
        [
            [3 * a2, -6 * a1, 3 * a0, 0],
            [3 * a6 - a7 * half, -6 * a2, 3 * a1, 0],
            [-a5, -6 * a6 + 2 * a7, 3 * a2, 0],
            [a4, 2 * a5, 3 * a6, 0],
            [-3 * a3, -2 * a4, -a5, a7],
        ]
    )
    ks = sp.zeros(4, 5)
    kt = sp.zeros(4, 5)
    for index in range(4):
        ks[index, index + 1] = 1
        kt[index, index] = -1

    determinant = sp.factor(chart_matrix.det())
    adjugate = chart_matrix.adjugate()
    a_numerator = sp.expand(rs * adjugate * ks)
    b_numerator = sp.expand(rs * adjugate * kt + rt * adjugate * ks)
    c_numerator = sp.expand(rt * adjugate * kt)

    raw = list(b_numerator * u - 2 * a_numerator * v)
    raw += list(b_numerator * v - 2 * c_numerator * u)
    raw += list(
        3 * determinant * u
        + a_numerator * u
        + 3 * a_numerator * v
        + 3 * c_numerator * u
    )
    equations = [primitive_integer_polynomial(item, variables) for item in raw]
    determinant_poly = primitive_integer_polynomial(determinant, variables)
    delta = primitive_integer_polynomial(u[3] - u[4] * v[3], variables)

    base = [8, 7, 1, 7, 2, 9, 0, 7, 6, 3, 10, 4, 8, 9, 7, 9]
    substitution = dict(zip(variables, base))
    values = [int(poly.as_expr().subs(substitution)) % 11 for poly in equations]
    if any(values):
        raise AssertionError(f"cleared collision equations miss the base point: {values}")
    jacobian = sp.Matrix([poly.as_expr() for poly in equations]).jacobian(variables)
    jacobian_mod = [
        [int(entry.subs(substitution)) % 11 for entry in row]
        for row in jacobian.tolist()
    ]
    selected_minor = det_mod([row[:15] for row in jacobian_mod], 11)
    if selected_minor == 0:
        raise AssertionError("the recorded 15-by-15 Jacobian minor vanished")

    return {
        "chart": {
            "normalizations": ["a7=1", "v4=1"],
            "variables": [str(item) for item in variables],
            "open_polynomial_factors": {
                "det_T": sp.sstr(determinant_poly.as_expr()),
                "collision_plane_minor": sp.sstr(delta.as_expr()),
            },
            "open_condition": "det(T)*(u3-u4*v3) != 0",
        },
        "equations": [
            {
                "index": index + 1,
                "block": (
                    "integrability_Bu_2Av"
                    if index < 5
                    else "integrability_Bv_2Cu"
                    if index < 10
                    else "collision"
                ),
                "total_degree": poly.total_degree(),
                "term_count": len(poly.terms()),
                "polynomial": sp.sstr(poly.as_expr()),
            }
            for index, poly in enumerate(equations)
        ],
        "base_point_F11": {
            "coordinates": base,
            "equation_values": values,
            "jacobian_rank": rank([row[:] for row in jacobian_mod], 11)[0],
            "selected_minor": "first 15 variables; v3 omitted",
            "selected_minor_mod_11": selected_minor,
        },
        "interpretation": {
            "proved": (
                "On this affine chart the displayed 15 primitive integer "
                "polynomials are exactly the denominator-cleared line "
                "integrability and collision equations.  Their Jacobian has "
                "rank 15 at the recorded F_11 point."
            ),
            "not_proved": (
                "No global saturation, irreducible decomposition, or zero-"
                "scheme calculation for the first-normal covariant is claimed."
            ),
        },
    }


def standard_complement(
    u: list[int], v: list[int], prime: int
) -> tuple[list[list[int]], list[int]]:
    for indices in combinations(range(5), 3):
        columns = [u, v]
        for index in indices:
            column = [0] * 5
            column[index] = 1
            columns.append(column)
        matrix = [list(row) for row in zip(*columns)]
        if rank(matrix, prime)[0] == 5:
            return matrix, list(indices)
    raise ValueError("collision pair is not independent")


def first_normal_rows(
    a_matrix: list[list[int]],
    b_matrix: list[list[int]],
    c_matrix: list[list[int]],
    prime: int,
) -> tuple[list[list[int]], list[tuple[int, int, int]]]:
    pairs = list(combinations_with_replacement(range(3), 2))
    variable_id: dict[tuple[int, int, tuple[int, int]], int] = {}
    for output in range(5):
        for plane_index in range(2):
            for pair in pairs:
                variable_id[(output, plane_index, pair)] = len(variable_id)
    variable_count = 60

    def affine_zero() -> list[int]:
        return [0] * (variable_count + 1)

    def add(left: list[int], right: list[int]) -> list[int]:
        return [(x + y) % prime for x, y in zip(left, right)]

    def scale(scalar: int, vector: list[int]) -> list[int]:
        return [scalar * value % prime for value in vector]

    normal_pencils = []
    for normal in range(3):
        p_matrix = [[affine_zero() for _ in range(5)] for _ in range(5)]
        q_matrix = [[affine_zero() for _ in range(5)] for _ in range(5)]
        global_normal = normal + 2
        for output in range(5):
            p_matrix[output][0][0] = 2 * a_matrix[output][global_normal] % prime
            p_matrix[output][1][0] = b_matrix[output][global_normal] % prime
            q_matrix[output][0][0] = b_matrix[output][global_normal] % prime
            q_matrix[output][1][0] = 2 * c_matrix[output][global_normal] % prime
            for other in range(3):
                pair = tuple(sorted((normal, other)))
                column = other + 2
                p_matrix[output][column][
                    1 + variable_id[(output, 0, pair)]
                ] = 1
                q_matrix[output][column][
                    1 + variable_id[(output, 1, pair)]
                ] = 1
        normal_pencils.append((p_matrix, q_matrix))

    identity = [[int(i == j) for j in range(5)] for i in range(5)]

    def polynomial_multiply(
        left: list[list[list[int]]], right: list[list[list[int]]]
    ) -> list[list[list[int]]]:
        result = [
            [[0] * 5 for _ in range(5)]
            for _ in range(len(left) + len(right) - 1)
        ]
        for left_degree, left_matrix in enumerate(left):
            for right_degree, right_matrix in enumerate(right):
                product = mm(left_matrix, right_matrix, prime)
                for row in range(5):
                    for column in range(5):
                        result[left_degree + right_degree][row][column] = (
                            result[left_degree + right_degree][row][column]
                            + product[row][column]
                        ) % prime
        return result

    powers = [[identity]]
    for _ in range(4):
        powers.append(
            polynomial_multiply(powers[-1], [a_matrix, b_matrix, c_matrix])
        )

    def trace_affine(
        numeric: list[list[int]], affine: list[list[list[int]]]
    ) -> list[int]:
        result = affine_zero()
        for row in range(5):
            for column in range(5):
                if numeric[row][column]:
                    result = add(
                        result,
                        scale(numeric[row][column], affine[column][row]),
                    )
        return result

    rows: list[list[int]] = []
    labels: list[tuple[int, int, int]] = []
    for normal, (p_matrix, q_matrix) in enumerate(normal_pencils):
        for power in range(1, 6):
            coefficients = [affine_zero() for _ in range(2 * power)]
            for left_degree, numeric in enumerate(powers[power - 1]):
                for right_degree, affine in enumerate([p_matrix, q_matrix]):
                    coefficients[left_degree + right_degree] = add(
                        coefficients[left_degree + right_degree],
                        trace_affine(numeric, affine),
                    )
            for degree, affine in enumerate(coefficients):
                rows.append(affine[1:] + [(-affine[0]) % prime])
                labels.append((normal, power, degree))
    return rows, labels


def sample_covariant(
    parameters: list[int], collision: list[int], prime: int
) -> dict[str, Any]:
    u = collision[:5]
    v = collision[5:]
    a_matrix, b_matrix, c_matrix = mats(parameters, prime)
    basis, complement = standard_complement(u, v, prime)
    transformed = transform(a_matrix, b_matrix, c_matrix, basis, prime)
    rows, labels = first_normal_rows(*transformed, prime)
    first_four_indices = [
        index for index, label in enumerate(labels) if label[1] <= 4
    ]
    first_four = [rows[index][:-1] for index in first_four_indices]
    determinant = det_mod(first_four, prime)
    first_four_augmented = [rows[index] for index in first_four_indices]
    first_four_coefficient_rank = rank(first_four, prime)[0]
    first_four_augmented_rank = rank(first_four_augmented, prime)[0]
    coefficient_rank = rank([row[:-1] for row in rows], prime)[0]
    augmented_rank = rank(rows, prime)[0]
    result: dict[str, Any] = {
        "parameters": parameters,
        "u": u,
        "v": v,
        "standard_complement_indices": complement,
        "first_four_determinant": determinant,
        "first_four_coefficient_rank": first_four_coefficient_rank,
        "first_four_augmented_rank": first_four_augmented_rank,
        "coefficient_rank": coefficient_rank,
        "augmented_rank": augmented_rank,
    }
    if determinant:
        augmented_first_four = [
            first_four[row] + [rows[first_four_indices[row]][-1]]
            for row in range(60)
        ]
        _, pivots, reduced = rank(augmented_first_four, prime)
        if pivots[:60] != list(range(60)):
            raise AssertionError("unexpected first-four pivot pattern")
        solution = [reduced[row][-1] for row in range(60)]
        residual = []
        for index, label in enumerate(labels):
            if label[1] != 5:
                continue
            residual.append(
                (
                    sum(rows[index][column] * solution[column] for column in range(60))
                    - rows[index][-1]
                )
                % prime
            )
        residual_rows = [residual[0:10], residual[10:20], residual[20:30]]
        result["omega_residual_rows"] = residual_rows
        result["omega_residual_rank"] = rank(residual_rows, prime)[0]
    return result


def macaulay2(collision: dict[str, Any]) -> str:
    variables = collision["chart"]["variables"]
    equations = [item["polynomial"].replace("**", "^") for item in collision["equations"]]
    determinant = collision["chart"]["open_polynomial_factors"]["det_T"].replace("**", "^")
    delta = collision["chart"]["open_polynomial_factors"]["collision_plane_minor"].replace("**", "^")
    return "\n".join(
        [
            "-- Exact full-kernel collision chart; generated, not yet globally solved.",
            f"R = QQ[{','.join(variables)}, MonomialOrder => GRevLex];",
            "I = ideal(" + ",\n  ".join(equations) + ");",
            f"h = ({determinant})*({delta});",
            "J = saturate(I, ideal(h));",
            "-- Suggested audit commands; their outputs are not asserted here:",
            "-- dim J",
            "-- degree J",
            "-- decompose radical J",
            "",
        ]
    )


def report(collision: dict[str, Any], samples: list[dict[str, Any]]) -> str:
    terms = [item["term_count"] for item in collision["equations"]]
    degrees = sorted({item["total_degree"] for item in collision["equations"]})
    invertible_first_four = sum(bool(item["first_four_determinant"]) for item in samples)
    singular_profiles = sorted(
        {
            (
                item["first_four_coefficient_rank"],
                item["first_four_augmented_rank"],
            )
            for item in samples
            if not item["first_four_determinant"]
        }
    )
    omega_ranks = sorted(
        {item.get("omega_residual_rank") for item in samples if "omega_residual_rank" in item}
    )
    return f"""# Program 5 global-collision calculation packet

## What was computed

On the affine chart `a7=1`, `v4=1`, the regular full-kernel pencil is written
without matrix denominators by replacing `T^(-1)` with `adj(T)/det(T)`.
The two tensor-integrability identities and the collision identity become 15
primitive integer polynomials in 16 variables. Their total degrees are
{degrees}; their term counts range from {min(terms)} to {max(terms)}.

The relevant open set is

```text
det(T) * (u3-u4*v3) != 0.
```

The second factor is the determinant of the collision-adapted basis obtained
by adjoining `e0,e1,e2` to `(u,v)`. The exact polynomial list is in
`collision-system.json`; `collision-system.m2` defines the corresponding
saturation for a future Macaulay2 computation.

At the known F_11 point all 15 equations vanish and the Jacobian has rank
{collision['base_point_F11']['jacobian_rank']}. The selected 15-by-15 minor
is {collision['base_point_F11']['selected_minor_mod_11']} modulo 11. This
reconfirms a smooth one-dimensional local collision locus on the stated open
chart; it does not describe every global component.

## First-normal samples

The exact first-normal system was evaluated at all {len(samples)} previously
enumerated rational collision-line points over F_7 and F_11. The first four
linearized characteristic identities have an invertible 60-by-60 matrix at
{invertible_first_four}/{len(samples)} points. At those points the fifth
identity gives residual covariant ranks {omega_ranks}. Full coefficient and
augmented ranks are recorded point by point in `omega-samples.json`. At the
remaining {len(samples) - invertible_first_four} points the first-four
coefficient/augmented rank profiles are {singular_profiles}; the full system
still has ranks (60,61). Thus those points are already inconsistent through
the fourth identity. The convenient fifth-residual formula defines `Omega`
only on the open locus where the first-four determinant is nonzero; globally
the obstruction should be treated as a determinantal/cokernel class.

## Mathematical boundary

This packet supplies the explicit global collision ideal that was previously
only described procedurally, plus reusable coefficient-level samples of the
first-normal obstruction. It also shows that a single globally defined
`Omega` obtained by inverting the first-four matrix is not the right object
on its determinant divisor. It does **not** compute the saturated ideal,
prove irreducibility of the collision locus, or prove that the full cokernel
obstruction is nowhere zero in characteristic zero. Those are still the
global theorem.
"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError(f"refusing to overwrite {output}")
    output.mkdir(parents=True)

    collision = symbolic_collision_system()
    samples = []
    for prime, entries in sorted(SAMPLES.items()):
        for parameters, collision_pair in entries:
            item = sample_covariant(parameters, collision_pair, prime)
            item["prime"] = prime
            samples.append(item)

    write_new(
        output / "collision-system.json",
        json.dumps(collision, indent=2, sort_keys=True) + "\n",
    )
    write_new(output / "collision-system.m2", macaulay2(collision))
    write_new(
        output / "omega-samples.json",
        json.dumps(
            {
                "format": 1,
                "sample_count": len(samples),
                "samples": samples,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
    )
    write_new(output / "REPORT.md", report(collision, samples))

    files = []
    for path in sorted(output.iterdir()):
        if path.name == "manifest.json":
            continue
        files.append(
            {
                "path": path.name,
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
        )
    manifest = {
        "format": 1,
        "release_id": "program5-global-collision-v1-20260726c",
        "files": files,
        "collision_equations": len(collision["equations"]),
        "variables": len(collision["chart"]["variables"]),
        "omega_samples": len(samples),
    }
    write_new(
        output / "manifest.json",
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
    )
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
