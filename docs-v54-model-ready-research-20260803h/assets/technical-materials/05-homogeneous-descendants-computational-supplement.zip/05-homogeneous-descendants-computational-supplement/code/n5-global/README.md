# N=5 global collision packet

`build_global_collision_packet.py` turns the full-kernel regular-Jordan chart
into a reusable exact calculation:

```bash
uv run python build_global_collision_packet.py /new/output/directory
```

It emits the 15 denominator-cleared collision/integrability polynomials, a
Macaulay2 saturation input, coefficient-level first-normal obstruction data
at all 17 known F_7/F_11 rational chart points, a short report, and hashes.
The output directory must not exist.

The packet is intentionally a formulation and data improvement, not the
still-open global theorem. It does not calculate the saturated collision
curve or prove that the first-normal covariant is nowhere zero.
