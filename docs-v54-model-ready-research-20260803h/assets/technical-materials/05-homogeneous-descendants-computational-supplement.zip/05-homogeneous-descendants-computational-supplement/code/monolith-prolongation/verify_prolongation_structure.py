#!/usr/bin/env python3
r"""Exact/modular continuation certificate for the 19D descendant.

This script imports the reconstruction from ``verify_affine_lie_hankel.py`` and
verifies the additional structural claims used in
``prolongation_monolith_continuation.md``:

* the intrinsic product layers A^3=U, U^3=W and mu(W,U,U)=0;
* the codimension-one tensor decomposition and its operator-span dimensions;
* irreducibility of the 18-dimensional monolith action (associative closure
  M_18) together with the absence of an invariant alternating 2-form;
* a 153-by-153 modular determinant ruling out the symplectic alternative;
* exact stable left-right equivalence of the t=1 fibre to K x id_7;
* the much smaller Lie/associative closures of the three branch Jacobians in
  the unsuspended 11-dimensional presentation, demonstrating that the raw
  Lie/Hankel data are not stable-left-right invariants.

A nonzero determinant modulo PRIME is an exact characteristic-zero
certificate because all source entries are rational and PRIME avoids all
relevant denominators.
"""
from __future__ import annotations

import argparse
import functools
import json
import time
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import sympy as sp

from verify_affine_lie_hankel import (
    PRIME,
    ModularRowBasis,
    associative_closure,
    build_tensor,
    closure_certificate,
    determinant_mod,
    lie_closure,
    matrix_mod,
)


def independent_matrices(matrices: Sequence[sp.Matrix], prime: int) -> list[sp.Matrix]:
    basis = ModularRowBasis(prime)
    result: list[sp.Matrix] = []
    for matrix in matrices:
        independent, _ = basis.add(matrix_mod(matrix, prime).reshape(-1))
        if independent:
            result.append(matrix)
    return result


def vector_span_rank(vectors: Sequence[sp.Matrix]) -> int:
    if not vectors:
        return 0
    return int(sp.Matrix.hstack(*vectors).rank())


def vector_support_subspace(vectors: Sequence[sp.Matrix]) -> tuple[int, list[int]]:
    matrix = sp.Matrix.hstack(*vectors) if vectors else sp.zeros(0, 0)
    rank = int(matrix.rank())
    nonzero_rows = [
        row for row in range(matrix.rows)
        if any(matrix[row, column] != 0 for column in range(matrix.cols))
    ]
    return rank, nonzero_rows


def alternating_form_certificate(
    generators: Sequence[sp.Matrix], prime: int
) -> dict:
    """Certify that no nonzero skew form J satisfies A^T J + J A = 0.

    ``generators`` are square matrices acting on an even-dimensional space.
    The equations are assembled over F_p in the coordinates J_ij, i<j.  A
    selected full-rank square minor is returned as an exact certificate.
    """
    dimension = generators[0].rows
    if dimension % 2:
        raise ValueError("symplectic test requires even dimension")
    pairs = [(i, j) for i in range(dimension) for j in range(i + 1, dimension)]
    coordinate = {pair: index for index, pair in enumerate(pairs)}
    modular_generators = [matrix_mod(matrix, prime) for matrix in generators]

    rows: list[np.ndarray] = []
    row_metadata: list[tuple[int, int, int]] = []
    for generator_index, matrix in enumerate(modular_generators):
        for row in range(dimension):
            for column in range(dimension):
                equation = np.zeros(len(pairs), dtype=np.int64)

                # (A^T J)_{row,column} = sum_k A_{k,row} J_{k,column}
                for k in range(dimension):
                    coefficient = int(matrix[k, row])
                    if not coefficient or k == column:
                        continue
                    if k < column:
                        index = coordinate[(k, column)]
                        equation[index] = (equation[index] + coefficient) % prime
                    else:
                        index = coordinate[(column, k)]
                        equation[index] = (equation[index] - coefficient) % prime

                # (J A)_{row,column} = sum_k J_{row,k} A_{k,column}
                for k in range(dimension):
                    coefficient = int(matrix[k, column])
                    if not coefficient or row == k:
                        continue
                    if row < k:
                        index = coordinate[(row, k)]
                        equation[index] = (equation[index] + coefficient) % prime
                    else:
                        index = coordinate[(k, row)]
                        equation[index] = (equation[index] - coefficient) % prime

                if np.any(equation):
                    rows.append(equation)
                    row_metadata.append((generator_index, row, column))

    basis = ModularRowBasis(prime)
    selected_rows: list[np.ndarray] = []
    selected_metadata: list[tuple[int, int, int]] = []
    for equation, metadata in zip(rows, row_metadata):
        independent, _ = basis.add(equation)
        if independent:
            selected_rows.append(equation)
            selected_metadata.append(metadata)
            if len(selected_rows) == len(pairs):
                break

    selected_matrix = np.array(selected_rows, dtype=np.int64)
    determinant = determinant_mod(selected_matrix, prime)
    return {
        "space_dimension": dimension,
        "skew_form_variable_count": len(pairs),
        "equation_count_after_zero_rows_removed": len(rows),
        "rank_mod_prime": len(selected_rows),
        "selected_minor_determinant_mod_prime": determinant,
        "selected_equations": [
            {
                "generator_zero_based": g,
                "matrix_row_zero_based": i,
                "matrix_column_zero_based": j,
            }
            for g, i, j in selected_metadata
        ],
        "conclusion": (
            "The common invariant alternating-form space is zero; in particular "
            "the irreducible Lie algebra is not contained in sp_18."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("prolongation_structure_certificate.json"),
    )
    parser.add_argument("--prime", type=int, default=PRIME)
    args = parser.parse_args()
    started = time.time()

    data = build_tensor()
    H = data["H"]
    variables = list(data["Z"])
    ambient_dimension = len(variables)
    if ambient_dimension != 19:
        raise AssertionError("unexpected ambient dimension")

    @functools.lru_cache(maxsize=None)
    def mu(i: int, j: int, k: int) -> sp.Matrix:
        # H(z)=mu(z,z,z), so the third derivative is 6 mu.
        return sp.Matrix([
            sp.diff(component, variables[i], variables[j], variables[k]) / 6
            for component in H
        ])

    U = list(range(18))
    W = list(range(11, 18))
    t = 18

    all_products = [
        mu(i, j, k)
        for i in range(19)
        for j in range(i, 19)
        for k in range(j, 19)
    ]
    U_products = [
        mu(i, j, k)
        for i in U
        for j in range(i, 18)
        for k in range(j, 18)
    ]
    A3_rank, A3_rows = vector_support_subspace(all_products)
    U3_rank, U3_rows = vector_support_subspace(U_products)
    if A3_rank != 18 or A3_rows != U:
        raise AssertionError("failed to verify A^3=U")
    if U3_rank != 7 or U3_rows != W:
        raise AssertionError("failed to verify U^3=W")

    W_annihilation = all(
        mu(i, j, k).is_zero_matrix
        for i in W
        for j in U
        for k in U
    )
    if not W_annihilation:
        raise AssertionError("mu(W,U,U) was expected to vanish")

    def restricted_partial(i: int, j: int) -> sp.Matrix:
        return sp.Matrix.hstack(*[mu(i, j, k)[:18, 0] for k in U])

    layer_generators = {
        "mu_0_UU": [restricted_partial(i, j) for i in U for j in range(i, 18)],
        "mu_1_tU": [restricted_partial(t, i) for i in U],
        "mu_2_tt": [restricted_partial(t, t)],
    }
    layer_certificates: dict[str, dict] = {}
    independent_layers: dict[str, list[sp.Matrix]] = {}
    for name, matrices in layer_generators.items():
        independent = independent_matrices(matrices, args.prime)
        independent_layers[name] = independent
        lie_matrices, lie_words, _ = lie_closure(independent, args.prime, 323)
        associative_matrices, associative_words, _ = associative_closure(
            independent, args.prime, 324
        )
        layer_certificates[name] = {
            "linear_span_dimension": len(independent),
            "lie_closure_dimension": len(lie_matrices),
            "associative_closure_dimension": len(associative_matrices),
            "maximum_lie_word_length": max(map(len, lie_words)),
            "maximum_associative_word_length": max(map(len, associative_words)),
        }

    combined = independent_matrices(
        independent_layers["mu_0_UU"]
        + independent_layers["mu_1_tU"]
        + independent_layers["mu_2_tt"],
        args.prime,
    )
    combined_lie, combined_lie_words, combined_lie_basis = lie_closure(
        combined, args.prime, 323
    )
    combined_associative, combined_associative_words, combined_associative_basis = (
        associative_closure(combined, args.prime, 324)
    )
    if len(combined_lie) != 323 or len(combined_associative) != 324:
        raise AssertionError("the restricted monolith action did not close to sl_18/M_18")

    restricted_collision_generators = [matrix[:18, :18] for matrix in data["N"]]
    symplectic = alternating_form_certificate(
        restricted_collision_generators, args.prime
    )
    if (
        symplectic["rank_mod_prime"] != 153
        or symplectic["selected_minor_determinant_mod_prime"] == 0
    ):
        raise AssertionError("failed to rule out an invariant symplectic form")

    # Exact stable left-right equivalence of the t=1 fibre.
    X = data["X"]
    Q = data["Q"]
    K = data["K"]
    q_vector = data["q_vector"]
    w_symbols = sp.Matrix(variables[11:18])
    B = sp.zeros(11, 7)
    for column, row in enumerate([0, 1, 2, 3, 4, 5, 8]):
        B[row, column] = 1
    source_shear = sp.Matrix.vstack(X, w_symbols - q_vector)
    K_times_identity_after_source = sp.Matrix.vstack(K, w_symbols - q_vector)
    target_shear_after_source = sp.Matrix.vstack(
        K + B * (w_symbols - q_vector), w_symbols - q_vector
    )
    fibre_at_t_one = sp.Matrix.vstack(X + Q + B * w_symbols, w_symbols - q_vector)
    stable_equivalence_residual = sp.simplify(
        target_shear_after_source - fibre_at_t_one
    )
    if not stable_equivalence_residual.is_zero_matrix:
        raise AssertionError("stable left-right equivalence failed symbolically")

    # Diagnostic: branch Jacobians before suspension.
    JK = K.jacobian(X)
    branch_11 = [
        sp.Matrix(JK.subs(dict(zip(X, point))) - sp.eye(11))
        for point in data["points"]
    ]
    branch_11_lie, branch_11_lie_words, branch_11_lie_basis = lie_closure(
        branch_11, args.prime
    )
    branch_11_associative, branch_11_associative_words, branch_11_associative_basis = (
        associative_closure(branch_11, args.prime)
    )
    branch_11_lie_certificate = closure_certificate(
        branch_11_lie, branch_11_lie_words, branch_11_lie_basis, args.prime
    )
    branch_11_associative_certificate = closure_certificate(
        branch_11_associative,
        branch_11_associative_words,
        branch_11_associative_basis,
        args.prime,
    )

    L_tt = restricted_partial(t, t)
    if not (L_tt**2).is_zero_matrix:
        raise AssertionError("L_tt should be square-zero")

    result = {
        "source": "19D tensor reconstructed by verify_affine_lie_hankel.py",
        "prime": args.prime,
        "intrinsic_product_layers": {
            "A_cubed_dimension": A3_rank,
            "A_cubed_coordinate_rows_zero_based": A3_rows,
            "U_cubed_dimension": U3_rank,
            "U_cubed_coordinate_rows_zero_based": U3_rows,
            "mu_W_U_U_is_zero": W_annihilation,
            "interpretation": "A^3=U (dimension 18), U^3=W=span(w_1,...,w_7), and mu(W,U,U)=0.",
        },
        "codimension_one_tensor_layers": {
            "decomposition": (
                "mu_0=mu|Sym^3(U), mu_1=mu(t,-,-), "
                "mu_2=mu(t,t,-), mu_3=mu(t,t,t)=0"
            ),
            "mu_0_image_dimension": U3_rank,
            "mu_1_image_dimension": vector_span_rank(
                [mu(t, i, j) for i in U for j in range(i, 18)]
            ),
            "mu_2_image_dimension": vector_span_rank([mu(t, t, i) for i in U]),
            "mu_3_is_zero": mu(t, t, t).is_zero_matrix,
            "mu_2_rank": int(L_tt.rank()),
            "mu_2_square_zero": (L_tt**2).is_zero_matrix,
            "individual_layer_operator_closures": layer_certificates,
            "all_layers_restricted_lie": closure_certificate(
                combined_lie, combined_lie_words, combined_lie_basis, args.prime
            ),
            "all_layers_restricted_associative": closure_certificate(
                combined_associative,
                combined_associative_words,
                combined_associative_basis,
                args.prime,
            ),
        },
        "prolongation_classification_boundary_check": {
            "restricted_action_is_irreducible_because_associative_closure_dimension": len(
                combined_associative
            ),
            "restricted_lie_dimension": len(combined_lie),
            "no_invariant_symplectic_form": symplectic,
            "conclusion": (
                "The irreducible traceless Lie algebra with nonzero second prolongation "
                "is the sl_18 alternative, not sp_18."
            ),
        },
        "stable_left_right_diagnostic": {
            "symbolic_residual_is_zero": stable_equivalence_residual.is_zero_matrix,
            "identity": "K_f = T o (K x id_7) o S at t=1",
            "source_shear": "S(X,w)=(X,w-q(X))",
            "target_shear": "T(Y,v)=(Y+Bv,v)",
            "unsuspended_11D_branch_jacobians": {
                "ranks": [int(matrix.rank()) for matrix in branch_11],
                "lie": branch_11_lie_certificate,
                "associative": branch_11_associative_certificate,
            },
            "interpretation": (
                "The 19D affine-Lie/Hankel envelope is not itself a stable-left-right "
                "invariant; the suspension creates substantial operator complexity."
            ),
        },
        "elapsed_seconds": time.time() - started,
    }

    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"wrote {args.output}")
    print(f"A^3={A3_rank}, U^3={U3_rank}, mu(W,U,U)=0: {W_annihilation}")
    print(
        "restricted action: Lie",
        len(combined_lie),
        "associative",
        len(combined_associative),
    )
    print(
        f"no-symplectic 153x153 determinant mod {args.prime}: "
        f"{symplectic['selected_minor_determinant_mod_prime']}"
    )
    print(
        "11D branch closures: Lie",
        len(branch_11_lie),
        "associative",
        len(branch_11_associative),
    )
    print(f"elapsed: {result['elapsed_seconds']:.3f}s")


if __name__ == "__main__":
    main()
