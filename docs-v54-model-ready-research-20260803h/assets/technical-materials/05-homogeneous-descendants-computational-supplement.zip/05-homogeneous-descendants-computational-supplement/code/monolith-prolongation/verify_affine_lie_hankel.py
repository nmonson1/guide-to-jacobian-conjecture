#!/usr/bin/env python3
r"""Exact/modular certificate for the 19D homogeneous descendant.

Reconstructs the map from Monson, "Normal-Form Complexity of a
Three-Sheeted Keller Cover" (2026-07-22), evaluates the nonlinear Jacobian
at the three displayed collision lifts, and verifies:

  * the three logarithms generate sl_18 \ltimes Q^18 (dimension 341);
  * the three multiplication operators generate Hom(Q^19,Q^18)
    associatively (dimension 342);
  * the last two collision branches alone generate the 324-dimensional
    algebra {T : T r = 0, im(T) subset U}; the first branch removes the
    common kernel;
  * an explicit 19 x 19 noncommutative Hankel minor is nonzero.

A nonzero modular determinant is an exact characteristic-zero certificate:
all matrix entries are rational and the chosen prime avoids the denominators.

Requirements: Python 3.10+, sympy, numpy.
"""
from __future__ import annotations

import argparse
import collections
import json
import time
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import sympy as sp

PRIME = 1_000_003


def homogeneous_component(poly: sp.Expr, degree: int, variables: Sequence[sp.Symbol]) -> sp.Expr:
    out = sp.Integer(0)
    for monomial, coefficient in sp.Poly(sp.expand(poly), *variables).terms():
        if sum(monomial) == degree:
            term = coefficient
            for variable, exponent in zip(variables, monomial):
                term *= variable**exponent
            out += term
    return sp.expand(out)


def build_tensor():
    x, y, z, a, b, c, d, q, s, h, k = sp.symbols("x y z a b c d q s h k")
    X = sp.Matrix([x, y, z, a, b, c, d, q, s, h, k])

    Phi = sp.Matrix([
        -a*c - a*d*z - 3*a*y**2 - 2*a*z - c*d**2 + d**2*z - d*s
        + 7*d*y**2 + s*x*y + 3*x*y*z + 4*y**2 + z,
        -b*c - b*d*z - 3*b*y**2 - 2*b*z - 3*c*d*x - d*q
        + q*x*y + 12*x*y**2 + 3*x*z + y,
        -h*k - h*x*z + k*x**2 - 3*x**2*y + 2*x,
        a - d**2 + 2*d*x*y,
        b + 3*x**2*y,
        c + x*y*z + 3*y**2 + 2*z,
        d - x*y,
        b*z + 3*c*x + q,
        s + a*z + c*x*y - x*y*z - 7*y**2 + c*d - d*z,
        h - x**2,
        k + x*z,
    ])

    origin = {variable: 0 for variable in X}
    linear_part = Phi.jacobian(X).subs(origin)
    K = sp.simplify(linear_part.inv() * Phi)
    Q = sp.Matrix([homogeneous_component(component, 2, X) for component in K])
    C = sp.Matrix([homogeneous_component(component, 3, X) for component in K])

    cubic_rows = [0, 1, 2, 3, 4, 5, 8]
    q_vector = sp.Matrix([C[index] for index in cubic_rows])
    w = sp.symbols("w1:8")
    t = sp.symbols("t")
    Z = sp.Matrix(list(X) + list(w) + [t])

    Bw = sp.zeros(11, 1)
    for j, row in enumerate(cubic_rows):
        Bw[row] = w[j]
    H = sp.Matrix.vstack(t*Q + t**2*Bw, -q_vector, sp.Matrix([0]))

    R = sp.Rational
    points = [
        sp.Matrix([0, 0, -R(1, 4), 0, 0, R(1, 2), 0, 0, 0, 0, 0]),
        sp.Matrix([1, -R(3, 2), R(13, 2), -R(9, 4), R(9, 2), -10,
                   -R(3, 2), R(3, 4), -R(153, 8), 1, -R(13, 2)]),
        sp.Matrix([-1, R(3, 2), R(13, 2), -R(9, 4), -R(9, 2), -10,
                   -R(3, 2), -R(3, 4), -R(153, 8), 1, R(13, 2)]),
    ]

    def evaluate(vector: sp.Matrix, point: sp.Matrix) -> sp.Matrix:
        substitution = dict(zip(X, point))
        return sp.Matrix([sp.simplify(entry.subs(substitution)) for entry in vector])

    lifted = []
    nonlinear_jacobians = []
    JH = H.jacobian(Z)
    for point in points:
        q_value = evaluate(q_vector, point)
        lift = sp.Matrix(list(point) + list(q_value) + [1])
        lifted.append(lift)
        nonlinear_jacobians.append(sp.Matrix(JH.subs(dict(zip(Z, lift)))))

    return {
        "X": X,
        "Z": Z,
        "Phi": Phi,
        "linear_part": linear_part,
        "K": K,
        "Q": Q,
        "C": C,
        "q_vector": q_vector,
        "H": H,
        "points": points,
        "lifted": lifted,
        "N": nonlinear_jacobians,
    }


def nilpotency_data(matrix: sp.Matrix) -> dict:
    power = sp.eye(matrix.rows)
    ranks = []
    index = None
    for exponent in range(1, matrix.rows + 1):
        power = power * matrix
        ranks.append(int(power.rank()))
        if power.is_zero_matrix:
            index = exponent
            break
    return {"rank": int(matrix.rank()), "nilpotency_index": index, "power_ranks": ranks}


def log_unipotent_part(N: sp.Matrix) -> sp.Matrix:
    result = sp.zeros(N.rows)
    power = sp.eye(N.rows)
    for exponent in range(1, N.rows + 1):
        power = power * N
        if power.is_zero_matrix:
            break
        result += sp.Rational((-1) ** (exponent + 1), exponent) * power
    return sp.Matrix(result)


def rational_mod(value: sp.Expr, prime: int) -> int:
    value = sp.Rational(value)
    denominator = int(value.q) % prime
    if denominator == 0:
        raise ZeroDivisionError(f"denominator divisible by certificate prime {prime}")
    return (int(value.p) % prime) * pow(denominator, -1, prime) % prime


def matrix_mod(matrix: sp.Matrix, prime: int) -> np.ndarray:
    array = np.empty(matrix.shape, dtype=np.int64)
    for row in range(matrix.rows):
        for column in range(matrix.cols):
            array[row, column] = rational_mod(matrix[row, column], prime)
    return array


class ModularRowBasis:
    """Incremental reduced row-echelon basis over F_p."""

    def __init__(self, prime: int):
        self.prime = prime
        self.rows: dict[int, np.ndarray] = {}
        self.pivots: list[int] = []

    def reduce(self, vector: np.ndarray) -> np.ndarray:
        vector = np.array(vector, dtype=np.int64, copy=True) % self.prime
        for pivot in self.pivots:
            coefficient = int(vector[pivot])
            if coefficient:
                vector = (vector - coefficient * self.rows[pivot]) % self.prime
        return vector

    def add(self, vector: np.ndarray) -> tuple[bool, int | None]:
        vector = self.reduce(vector)
        nonzero = np.flatnonzero(vector)
        if len(nonzero) == 0:
            return False, None
        pivot = int(nonzero[0])
        vector = (vector * pow(int(vector[pivot]), -1, self.prime)) % self.prime
        for old_pivot in list(self.pivots):
            coefficient = int(self.rows[old_pivot][pivot])
            if coefficient:
                self.rows[old_pivot] = (
                    self.rows[old_pivot] - coefficient * vector
                ) % self.prime
        self.rows[pivot] = vector
        self.pivots = sorted(self.rows)
        return True, pivot


def determinant_mod(matrix: np.ndarray, prime: int) -> int:
    matrix = np.array(matrix, dtype=np.int64, copy=True) % prime
    rows, columns = matrix.shape
    if rows != columns:
        raise ValueError("determinant requires a square matrix")
    determinant = 1
    for column in range(columns):
        pivot_row = next((row for row in range(column, rows) if matrix[row, column]), None)
        if pivot_row is None:
            return 0
        if pivot_row != column:
            matrix[[column, pivot_row]] = matrix[[pivot_row, column]]
            determinant = -determinant % prime
        pivot = int(matrix[column, column])
        determinant = determinant * pivot % prime
        matrix[column, column:] = (
            matrix[column, column:] * pow(pivot, -1, prime)
        ) % prime
        if column + 1 < rows:
            coefficients = matrix[column + 1 :, column].copy()
            matrix[column + 1 :, column:] = (
                matrix[column + 1 :, column:]
                - coefficients[:, None] * matrix[column, column:]
            ) % prime
    return int(determinant)


def lie_closure(
    generators: Sequence[sp.Matrix], prime: int, maximum_dimension: int | None = None
):
    reduced_generators = [matrix_mod(generator, prime) for generator in generators]
    basis = ModularRowBasis(prime)
    matrices: list[np.ndarray] = []
    words: list[tuple[int, ...]] = []
    queue: collections.deque[int] = collections.deque()

    for index, generator in enumerate(reduced_generators, start=1):
        independent, _ = basis.add(generator.reshape(-1))
        if independent:
            matrices.append(generator)
            words.append((index,))
            queue.append(len(matrices) - 1)

    while queue:
        basis_index = queue.popleft()
        left = matrices[basis_index]
        for generator_index, right in enumerate(reduced_generators, start=1):
            commutator = (left @ right - right @ left) % prime
            independent, _ = basis.add(commutator.reshape(-1))
            if independent:
                matrices.append(commutator)
                words.append(words[basis_index] + (generator_index,))
                queue.append(len(matrices) - 1)
                if maximum_dimension and len(matrices) >= maximum_dimension:
                    return matrices, words, basis
    return matrices, words, basis


def associative_closure(
    generators: Sequence[sp.Matrix], prime: int, maximum_dimension: int | None = None
):
    reduced_generators = [matrix_mod(generator, prime) for generator in generators]
    basis = ModularRowBasis(prime)
    matrices: list[np.ndarray] = []
    words: list[tuple[int, ...]] = []
    queue: collections.deque[int] = collections.deque()

    for index, generator in enumerate(reduced_generators, start=1):
        independent, _ = basis.add(generator.reshape(-1))
        if independent:
            matrices.append(generator)
            words.append((index,))
            queue.append(len(matrices) - 1)

    while queue:
        basis_index = queue.popleft()
        left = matrices[basis_index]
        for generator_index, right in enumerate(reduced_generators, start=1):
            product = (left @ right) % prime
            independent, _ = basis.add(product.reshape(-1))
            if independent:
                matrices.append(product)
                words.append(words[basis_index] + (generator_index,))
                queue.append(len(matrices) - 1)
                if maximum_dimension and len(matrices) >= maximum_dimension:
                    return matrices, words, basis
    return matrices, words, basis


def closure_certificate(matrices, words, basis: ModularRowBasis, prime: int) -> dict:
    selected_columns = basis.pivots
    minor = np.array(
        [matrix.reshape(-1)[selected_columns] for matrix in matrices], dtype=np.int64
    )
    determinant = determinant_mod(minor, prime)
    return {
        "dimension": len(matrices),
        "maximum_word_length": max(map(len, words)),
        "word_convention": (
            "Lie: (i1,...,ik) means [...[[g_i1,g_i2],g_i3],...,g_ik]; "
            "associative: it means g_i1...g_ik."
        ),
        "words": [list(word) for word in words],
        "pivot_flat_coordinates_zero_based": selected_columns,
        "selected_minor_determinant_mod_prime": determinant,
    }


def word_matrix(word: Sequence[int], generators: Sequence[sp.Matrix]) -> sp.Matrix:
    result = sp.eye(generators[0].rows)
    for letter in word:
        result = result * generators[letter - 1]
    return sp.Matrix(result)


def factor_rational(value: sp.Expr) -> dict:
    value = sp.Rational(value)
    return {
        "sign": -1 if value < 0 else 1,
        "numerator_factors": {str(p): exponent for p, exponent in sp.factorint(abs(int(value.p))).items()},
        "denominator_factors": {str(p): exponent for p, exponent in sp.factorint(int(value.q)).items()},
    }


def hankel_certificate(generators: Sequence[sp.Matrix]) -> dict:
    row_words = [
        (), (1,), (2,), (3,), (1, 2), (1, 3), (2, 2), (1, 2, 1),
        (1, 2, 2), (1, 2, 3), (1, 3, 1), (1, 3, 2), (1, 2, 2, 1),
        (1, 2, 2, 2), (1, 2, 2, 3), (1, 2, 3, 1), (1, 3, 2, 1),
        (1, 3, 2, 2), (1, 2, 2, 1, 1),
    ]
    column_words = [
        (), (2,), (3,), (1, 2), (2, 2), (3, 2), (1, 3), (2, 3),
        (3, 3), (2, 1, 2), (3, 1, 2), (1, 2, 2), (2, 2, 2),
        (3, 2, 2), (1, 3, 2), (2, 3, 2), (3, 3, 2), (2, 1, 3),
        (1, 2, 3),
    ]

    e_x = sp.zeros(1, 19)
    e_x[0, 0] = 1
    e_t = sp.zeros(19, 1)
    e_t[18, 0] = 1
    observability = sp.Matrix.vstack(
        *[e_x * word_matrix(word, generators) for word in row_words]
    )
    reachability = sp.Matrix.hstack(
        *[word_matrix(word, generators) * e_t for word in column_words]
    )
    hankel = observability * reachability

    det_observability = sp.factor(observability.det())
    det_reachability = sp.factor(reachability.det())
    det_hankel = sp.factor(hankel.det())
    if sp.simplify(det_hankel - det_observability * det_reachability) != 0:
        raise AssertionError("Hankel determinant did not factor as det(O)det(R)")

    return {
        "series": "s(w)=e_x^T N_w e_t, with N_empty=I",
        "row_words": [list(word) for word in row_words],
        "column_words": [list(word) for word in column_words],
        "det_observability": str(det_observability),
        "det_observability_factorization": factor_rational(det_observability),
        "det_reachability": str(det_reachability),
        "det_reachability_factorization": factor_rational(det_reachability),
        "det_hankel": str(det_hankel),
        "det_hankel_factorization": factor_rational(det_hankel),
        "rank": int(hankel.rank()),
    }


def coefficient_span_rank(H: sp.Matrix, variables: Sequence[sp.Symbol]) -> int:
    monomials: set[tuple[int, ...]] = set()
    polynomials = []
    for component in H:
        polynomial = sp.Poly(sp.expand(component), *variables)
        polynomials.append(polynomial)
        monomials.update(monomial for monomial, coefficient in polynomial.terms() if coefficient)
    monomials = sorted(monomials)
    coefficient_matrix = sp.zeros(len(H), len(monomials))
    for row, polynomial in enumerate(polynomials):
        coefficients = dict(polynomial.terms())
        for column, monomial in enumerate(monomials):
            coefficient_matrix[row, column] = coefficients.get(monomial, 0)
    return int(coefficient_matrix.rank())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("affine_lie_hankel_certificate.json"))
    parser.add_argument("--prime", type=int, default=PRIME)
    args = parser.parse_args()

    started = time.time()
    data = build_tensor()
    N = data["N"]
    logs = [log_unipotent_part(matrix) for matrix in N]

    if data["linear_part"].det() != -2:
        raise AssertionError("unexpected determinant of the 11D linear part")
    expected_image = sp.Matrix([-sp.Rational(1, 4)] + [0] * 10)
    for point in data["points"]:
        if sp.simplify(data["Phi"].subs(dict(zip(data["X"], point))) - expected_image) != sp.zeros(11, 1):
            raise AssertionError("the displayed 11D points do not collide")

    q_values = [list(lift[11:18, 0]) for lift in data["lifted"]]
    nilpotency = [nilpotency_data(matrix) for matrix in N]

    for matrix in logs:
        if matrix.trace() != 0 or any(matrix[18, column] != 0 for column in range(19)):
            raise AssertionError("a collision logarithm left the affine Lie upper bound")

    lie_matrices, lie_words, lie_basis = lie_closure(logs, args.prime, 341)
    lie_certificate = closure_certificate(lie_matrices, lie_words, lie_basis, args.prime)
    if lie_certificate["dimension"] != 341 or lie_certificate["selected_minor_determinant_mod_prime"] == 0:
        raise AssertionError("failed to certify the 341-dimensional logarithmic Lie algebra")

    raw_lie_matrices, raw_lie_words, raw_lie_basis = lie_closure(N, args.prime, 341)
    raw_lie_certificate = closure_certificate(raw_lie_matrices, raw_lie_words, raw_lie_basis, args.prime)

    associative_matrices, associative_words, associative_basis = associative_closure(N, args.prime, 342)
    associative_certificate = closure_certificate(
        associative_matrices, associative_words, associative_basis, args.prime
    )
    if associative_certificate["dimension"] != 342 or associative_certificate["selected_minor_determinant_mod_prime"] == 0:
        raise AssertionError("failed to certify the full 342-dimensional multiplication algebra")

    pair_lie_matrices, pair_lie_words, pair_lie_basis = lie_closure(N[1:], args.prime, 323)
    pair_associative_matrices, pair_associative_words, pair_associative_basis = associative_closure(
        N[1:], args.prime, 324
    )

    common_kernel = N[1].col_join(N[2]).nullspace()
    if len(common_kernel) != 1:
        raise AssertionError("unexpected common kernel for the second and third branches")
    kernel_vector = common_kernel[0]
    unlocked_vector = sp.simplify(N[0] * kernel_vector)

    result = {
        "source": "Normal-Form Complexity of a Three-Sheeted Keller Cover, 2026-07-22-v3",
        "prime": args.prime,
        "linear_part_determinant": str(data["linear_part"].det()),
        "q_values_at_collision_points": [[str(value) for value in row] for row in q_values],
        "nilpotency_at_collision_lifts": nilpotency,
        "derived_ideal_dimension": coefficient_span_rank(data["H"], data["Z"]),
        "ambient_dimension": 19,
        "logarithmic_lie_algebra": lie_certificate,
        "raw_jacobian_lie_algebra": raw_lie_certificate,
        "raw_associative_multiplication_algebra": associative_certificate,
        "branches_2_and_3": {
            "lie_dimension": len(pair_lie_matrices),
            "associative_dimension": len(pair_associative_matrices),
            "maximum_lie_word_length": max(map(len, pair_lie_words)),
            "maximum_associative_word_length": max(map(len, pair_associative_words)),
            "common_kernel_vector": [str(value) for value in kernel_vector],
            "branch_1_image_of_common_kernel": [str(value) for value in unlocked_vector],
        },
        "hankel": hankel_certificate(N),
        "interpretation": {
            "lie": "sl_18 semidirect Q^18, dimension 323+18=341",
            "associative": "Hom(Q^19,U) for U=span(e_1,...,e_18), dimension 18*19=342",
            "caveat": (
                "These are exact invariants of the displayed tensor / simultaneous-similarity class. "
                "They are not proved invariant under nonlinear stable left-right equivalence or under "
                "arbitrary alternative cubic-homogeneous presentations of the same cover."
            ),
        },
        "elapsed_seconds": time.time() - started,
    }

    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")

    print(f"wrote {args.output}")
    print(f"Lie(log JG(z_j)) dimension: {lie_certificate['dimension']}")
    print(f"  selected 341x341 determinant mod {args.prime}: "
          f"{lie_certificate['selected_minor_determinant_mod_prime']}")
    print(f"Associative multiplication algebra dimension: {associative_certificate['dimension']}")
    print(f"  selected 342x342 determinant mod {args.prime}: "
          f"{associative_certificate['selected_minor_determinant_mod_prime']}")
    print(f"Pair (branches 2,3): Lie {len(pair_lie_matrices)}, associative {len(pair_associative_matrices)}")
    print(f"Hankel determinant: {result['hankel']['det_hankel']}")
    print(f"elapsed: {result['elapsed_seconds']:.3f}s")


if __name__ == "__main__":
    main()
