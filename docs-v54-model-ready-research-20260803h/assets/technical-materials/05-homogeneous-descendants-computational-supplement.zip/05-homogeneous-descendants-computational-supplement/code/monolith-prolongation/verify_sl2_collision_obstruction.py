#!/usr/bin/env python3
r"""Verify the principal-sl2 regular-pencil collision obstruction.

For V=Sym^m(k^2), use the standard irreducible sl2 matrices

    E e_i = i e_{i-1},
    F e_i = (m-i)e_{i+1},
    H e_i = (m-2i)e_i.

The quadratic pencil M(s,t)=s^2 E + st H - t^2 F is everywhere regular
nilpotent.  The tensor-symmetry conditions from a collision pencil would
require

    H u = 2 E v,       H v = -2 F u.

Coefficient elimination gives m(m+2)u_i=0, so u=v=0 in characteristic zero.
This script checks the matrix statement exactly for a configurable range of m
and records the symbolic coefficient identity.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import sympy as sp


def sl2_matrices(m: int) -> tuple[sp.Matrix, sp.Matrix, sp.Matrix]:
    n = m + 1
    E = sp.zeros(n)
    F = sp.zeros(n)
    H = sp.zeros(n)
    for i in range(n):
        H[i, i] = m - 2 * i
        if i >= 1:
            E[i - 1, i] = i
        if i < m:
            F[i + 1, i] = m - i
    return E, F, H


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-m", type=int, default=40)
    parser.add_argument(
        "--output", type=Path, default=Path("sl2_collision_obstruction_certificate.json")
    )
    args = parser.parse_args()

    m_symbol, i_symbol = sp.symbols("m i")
    coefficient = sp.expand(
        (m_symbol - 2 * i_symbol) * (m_symbol - 2 * i_symbol + 2)
        + 4 * i_symbol * (m_symbol - i_symbol + 1)
    )
    if sp.factor(coefficient) != m_symbol * (m_symbol + 2):
        raise AssertionError("symbolic elimination identity failed")

    checks = []
    for m in range(1, args.max_m + 1):
        E, F, H = sl2_matrices(m)
        n = m + 1
        block = H.row_join(-2 * E).col_join((2 * F).row_join(H))
        nullity = 2 * n - int(block.rank())
        if nullity != 0:
            raise AssertionError(f"unexpected nonzero collision solution at m={m}")
        if H * E - E * H != 2 * E:
            raise AssertionError("[H,E]=2E failed")
        if H * F - F * H != -2 * F:
            raise AssertionError("[H,F]=-2F failed")
        if E * F - F * E != H:
            raise AssertionError("[E,F]=H failed")
        checks.append({
            "m": m,
            "dimension": n,
            "collision_linear_system_rank": int(block.rank()),
            "collision_linear_system_nullity": nullity,
        })

    result = {
        "statement": (
            "For the principal sl2 pencil M(s,t)=s^2E+stH-t^2F on Sym^m(k^2), "
            "the collision symmetry equations Hu=2Ev and Hv=-2Fu have only u=v=0 "
            "in characteristic zero."
        ),
        "coefficient_elimination": (
            "[(m-2i)(m-2i+2)+4i(m-i+1)]u_{i-1}=m(m+2)u_{i-1}=0"
        ),
        "symbolic_coefficient": str(sp.factor(coefficient)),
        "checked_range": [1, args.max_m],
        "checks": checks,
        "interpretation": (
            "The maximally symmetric regular nilpotent conic is incompatible with a "
            "collision tensor in every dimension; any regular collision pencil must be "
            "a genuinely non-principal deformation."
        ),
    }
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"wrote {args.output}")
    print(f"symbolic obstruction coefficient: {sp.factor(coefficient)}")
    print(f"verified m=1,...,{args.max_m}")


if __name__ == "__main__":
    main()
